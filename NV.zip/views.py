from django.http import HttpResponse
from django.http import StreamingHttpResponse
from django.shortcuts import render
import binascii, os
from werkzeug.utils import secure_filename
from django.views.decorators.csrf import csrf_exempt
from django.core.files.storage import FileSystemStorage
from django.views.decorators import gzip
from kaizen.models import Administrador
from kaizen.models import Instructor
from kaizen.models import Alumno
from kaizen.models import Curso
from kaizen.models import *
from datetime import datetime
from datetime import date
from datetime import timedelta
#import time
from datetime import time
from django.contrib.sessions.models import Session
from django.contrib.auth.hashers import make_password
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.decorators import user_passes_test
from django.conf import settings
import zipfile
import zlib
from random import randint
import random
import string
import qrcode
from PIL import Image
from django.shortcuts import redirect
import smtplib
import DNS
import socket
import argparse
import mandrill
from django.core.paginator import Paginator
import pymysql
import shutil
import stat
import git
import sys, json
from django.core.mail import send_mail
from django.template.loader import render_to_string
from django.core.mail import EmailMessage
import xlsxwriter


from ProyectoKaizen.cart import Cart
from ProyectoKaizen.compare import Compare

#import datetime
from datetime import *
from django.http import JsonResponse


from paypalcheckoutsdk.core import PayPalHttpClient, SandboxEnvironment

from paypalcheckoutsdk.orders import OrdersGetRequest, OrdersCaptureRequest

from forex_python.converter import CurrencyRates

import requests
import datetime as dt

import stripe
#from django.views import View

from Crypto.Cipher import AES


#Verificar tamaño imagen

def calculate_scale(file_path, bound_size):

    im = Image.open(file_path)
    original_width, original_height = im.size

    bound_width, bound_height = bound_size
    ratios = (float(bound_width) / original_width, float(bound_height) / original_height)
    return min(ratios)


#Verificar correo

ServerError = DNS.ServerError

def get_mx(hostname):
    try:
        servidor_mx = DNS.mxlookup(hostname)
    except ServerError as e:
        if e.rcode == 3 or e.rcode == 2:  # NXDOMAIN (Non-Existent Domain) or SERVFAIL
            servidor_mx = None
        else:
            raise
    return servidor_mx

def validar_email(email, debug=False):
    try:
        hostname = email[email.find('@') + 1:]
        mx_hosts = get_mx(hostname)
        if mx_hosts is None:
            #print('No se encuentra MX para el dominio {}'.format(hostname))
            return None
        for mx in mx_hosts:
            try:
                #print('Servidor {}'.format(mx[1]))
                #print('Cuenta {}'.format(email))
                servidor = smtplib.SMTP(timeout=10)
                servidor.connect(mx[1])
                servidor.set_debuglevel(debug)
                status, _ = servidor.helo()
                if status != 250:
                    servidor.quit()
                    continue
                servidor.mail('')
                status, _ = servidor.rcpt(email)
                if status == 250:
                    servidor.quit()
                    return True
                servidor.quit()
            except smtplib.SMTPServerDisconnected:  # Server not permits verify user
                if debug:
                    pass
                    #print('{} disconected.'.format(mx[1]))
            except smtplib.SMTPConnectError:
                if debug:
                    pass
                    #print('Unable to connect to {}.'.format(mx[1]))
        return False
    except (ServerError, socket.error) as e:
        #print('ServerError or socket.error exception raised ({}).'.format(e))
        return None


#views Generales

def identificar_estudiante(user):

    try:

        tipousuario = user.tipo_usuario

    except Exception as e:

        return False


    if tipousuario == 3:

        return True

    else:

        return False

def identificar_instructor(user):

    try:

        tipousuario = user.tipo_usuario

    except Exception as e:

        return False


    if tipousuario == 2:

        return True

    else:

        return False

def identificar_administrador(user):

    try:

        tipousuario = user.tipo_usuario

    except Exception as e:

        return False


    if tipousuario == 1:

        return True

    else:

        return False



#cierre navegador
def cerrar_navegador(request):

    correo = request.user.email

    fecha_actual = datetime.now()
    actu = fecha_actual + timedelta(seconds=90)

    ses = Usuarios.objects.get(email=correo)
    ses.ultima_actualizacion = actu
    ses.save()

    return HttpResponse("Actualizado")



# Views del Administrador

#Nuevas vistas siguiente version

@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def mostrar_instructores_transmision(request):

    request.session.set_expiry(request.session.get_expiry_age())

    instructor = Instructor.objects.all()
    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)

    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    contexto = {'instructores':instructor, 'usuarios':usuario, 'datosPagina':datoPagina}
    return render(request, 'Admin/Extras/TransmisionesInstructor/instructores.html', contexto)



@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def mostrar_conferencias_instructor_admin(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)

    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    idinstructor = id

    conferencia = TransmisionesInstructores.objects.filter(id_instructorR=idinstructor)

    filtro = CursoInstructor.objects.filter(id_instructorR=idinstructor).values('id_cursoR')

    curso = Curso.objects.filter(id_curso__in=filtro)

    contexto = {'idinstructor':idinstructor, 'conferencias':conferencia, 'cursos':curso, 'usuarios':usuario, 'datosPagina':datoPagina}

    return render(request, 'Admin/Extras/TransmisionesInstructor/transmisiones.html', contexto)


@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def mostrar_agregar_transmision_instructor_admin(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)

    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    idinstructor = id

    filtro = CursoInstructor.objects.filter(id_instructorR=idinstructor).values('id_cursoR')

    fecha = date.today()

    curso = Curso.objects.filter(id_curso__in=filtro, fecha_cierre__gte=fecha)

    fechis = str(fecha)

    contexto = {'idinstructor':idinstructor, 'cursos':curso, 'usuarios':usuario, 'datosPagina':datoPagina, 'fecha':fechis}

    return render(request, 'Admin/Extras/TransmisionesInstructor/agregar_transmision.html', contexto)



@csrf_exempt
@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def agregar_transmision_instructor_admin(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    if request.method == "POST":

        nombreG = request.POST["nombre"]
        fechaG = request.POST["fecha"]
        horaG = request.POST["hora"]
        idcurso = request.POST["curso"]

        idreunionG = request.POST["idreunion"]
        contrareunionG = request.POST["contrareunion"]

        '''
        urlpartida = url.split("=")

        if len(urlpartida) == 1:

            urlpartida = url.split('/')

        urlvideo = urlpartida[-1]
        '''

        fechahora = str(fechaG) + " " + str(horaG)

        idinstructor = id

        tv = TransmisionesInstructores(id_instructorR=idinstructor, id_cursoR=idcurso, nombre_transmision=nombreG,
        fecha_transmision=fechaG, hora_transmision=horaG, fecha_completa=fechahora, statusT=1, numero_reunion=idreunionG,
        contra_reunion=contrareunionG)
        tv.save()

        url = '/mostrar_transmision_instructor/' + str(idinstructor)

        return redirect(url)



@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def mostrar_editar_transmision_instructor_admin(request, id, id2):

    request.session.set_expiry(request.session.get_expiry_age())

    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)

    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    idtransmision = id
    idinstructor = id2

    conferencia = TransmisionesInstructores.objects.filter(id_transmisionInstructor=idtransmision)

    filtro = CursoInstructor.objects.filter(id_instructorR=idinstructor).values('id_cursoR')

    fecha = date.today()

    curso = Curso.objects.filter(id_curso__in=filtro, fecha_cierre__gte=fecha)

    fechis = str(fecha)

    contexto = {'idinstructor':idinstructor, 'conferencias':conferencia, 'cursos':curso, 'usuarios':usuario, 'datosPagina':datoPagina,
    'fecha':fechis}

    return render(request, 'Admin/Extras/TransmisionesInstructor/editar_transmision.html', contexto)


@csrf_exempt
@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def editar_transmision_instructor_admin(request, id, id2):

    request.session.set_expiry(request.session.get_expiry_age())

    if request.method == "POST":

        nombreG = request.POST["nombre"]
        fechaG = request.POST["fecha"]
        horaG = request.POST["hora"]
        idcurso = request.POST["curso"]

        idreunionG = request.POST["idreunion"]
        contrareunionG = request.POST["contrareunion"]

        idtransmision = id

        '''
        urlpartida = url.split("=")

        if len(urlpartida) == 1:

            urlpartida = url.split('/')

        urlvideo = urlpartida[-1]
        '''

        fechahora = str(fechaG) + " " + str(horaG)

        idinstructor = id2

        tv = TransmisionesInstructores.objects.get(id_transmisionInstructor=idtransmision)
        tv.fecha_transmision = fechaG
        tv.hora_transmision = horaG
        tv.id_cursoR = idcurso
        tv.fecha_completa = fechahora
        tv.nombre_transmision = nombreG
        tv.numero_reunion = idreunionG
        tv.contra_reunion = contrareunionG
        tv.save()

        url = '/mostrar_transmision_instructor/' + str(idinstructor)

        return redirect(url)



@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def habilitar_transmision_instructor_admin(request, id, id2):

    request.session.set_expiry(request.session.get_expiry_age())

    idtransmision = id
    idinstructor = id2

    entra = TransmisionesInstructores.objects.get(id_transmisionInstructor=idtransmision)
    estado = entra.statusT

    if estado == 0:

        entra.statusT = 1
        entra.save()

    else:

        entra.statusT = 0
        entra.save()


    url = '/mostrar_transmision_instructor/' + str(idinstructor)

    return redirect(url)

#Terminan vistas transmisiones instructor

#Inician vistas transmisiones anteriores instructor

@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def mostrar_instructores_transmision_anterior(request):

    request.session.set_expiry(request.session.get_expiry_age())

    instructor = Instructor.objects.all()
    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)

    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    contexto = {'instructores':instructor, 'usuarios':usuario, 'datosPagina':datoPagina}
    return render(request, 'Admin/Extras/TransmisionesInstructorAnterior/instructores.html', contexto)



@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def mostrar_conferencias_instructor_anterior_admin(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)

    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    idinstructor = id

    conferencia = TransmisionesInstructoresAnteriores.objects.filter(id_instructorR=idinstructor)

    filtro = CursoInstructor.objects.filter(id_instructorR=idinstructor).values('id_cursoR')

    curso = Curso.objects.filter(id_curso__in=filtro)

    contexto = {'idinstructor':idinstructor, 'conferencias':conferencia, 'cursos':curso, 'usuarios':usuario, 'datosPagina':datoPagina}

    return render(request, 'Admin/Extras/TransmisionesInstructorAnterior/transmisiones.html', contexto)



@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def mostrar_agregar_transmision_instructor_anterior_admin(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)

    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    idinstructor = id

    filtro = CursoInstructor.objects.filter(id_instructorR=idinstructor).values('id_cursoR')

    fecha = date.today()

    curso = Curso.objects.filter(id_curso__in=filtro, fecha_cierre__gte=fecha)

    fechis = str(fecha)

    contexto = {'idinstructor':idinstructor, 'cursos':curso, 'usuarios':usuario, 'datosPagina':datoPagina, 'fecha':fechis}

    return render(request, 'Admin/Extras/TransmisionesInstructorAnterior/agregar_transmision.html', contexto)


@csrf_exempt
@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def agregar_transmision_instructor_anterior_admin(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    if request.method == "POST":

        nombreG = request.POST["nombre"]
        fechaG = request.POST["fecha"]
        horaG = request.POST["hora"]
        idcurso = request.POST["curso"]

        urlG = request.POST["url"]

        urlpartida = urlG.split("=")

        if len(urlpartida) == 1:

            urlpartida = urlG.split('/')

        urlvideo = urlpartida[-1]


        fechahora = str(fechaG) + " " + str(horaG)

        idinstructor = id

        tv = TransmisionesInstructoresAnteriores(id_instructorR=idinstructor, id_cursoR=idcurso, nombre_transmision=nombreG,
        fecha_transmision=fechaG, hora_transmision=horaG, fecha_completa=fechahora, statusT=1, url_video=urlvideo)
        tv.save()

        url = '/mostrar_transmision_instructor_anterior/' + str(idinstructor)

        return redirect(url)



@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def mostrar_editar_transmision_instructor_anterior_admin(request, id, id2):

    request.session.set_expiry(request.session.get_expiry_age())

    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)

    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    idtransmision = id
    idinstructor = id2

    conferencia = TransmisionesInstructoresAnteriores.objects.filter(id_transmisionInstructorAnterior=idtransmision)

    filtro = CursoInstructor.objects.filter(id_instructorR=idinstructor).values('id_cursoR')

    fecha = date.today()

    curso = Curso.objects.filter(id_curso__in=filtro, fecha_cierre__gte=fecha)

    fechis = str(fecha)

    contexto = {'idinstructor':idinstructor, 'conferencias':conferencia, 'cursos':curso, 'usuarios':usuario, 'datosPagina':datoPagina,
    'fecha':fechis}

    return render(request, 'Admin/Extras/TransmisionesInstructorAnterior/editar_transmision.html', contexto)



@csrf_exempt
@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def editar_transmision_instructor_anterior_admin(request, id, id2):

    request.session.set_expiry(request.session.get_expiry_age())

    if request.method == "POST":

        nombreG = request.POST["nombre"]
        fechaG = request.POST["fecha"]
        horaG = request.POST["hora"]
        idcurso = request.POST["curso"]

        urlG = request.POST["url"]

        idtransmision = id

        urlpartida = urlG.split("=")

        if len(urlpartida) == 1:

            urlpartida = urlG.split('/')

        urlvideo = urlpartida[-1]

        fechahora = str(fechaG) + " " + str(horaG)

        idinstructor = id2

        tv = TransmisionesInstructoresAnteriores.objects.get(id_transmisionInstructorAnterior=idtransmision)
        tv.fecha_transmision = fechaG
        tv.hora_transmision = horaG
        tv.id_cursoR = idcurso
        tv.fecha_completa = fechahora
        tv.nombre_transmision = nombreG
        tv.url_video = urlvideo
        tv.save()

        url = '/mostrar_transmision_instructor_anterior/' + str(idinstructor)

        return redirect(url)



@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def habilitar_transmision_instructor_anterior_admin(request, id, id2):

    request.session.set_expiry(request.session.get_expiry_age())

    idtransmision = id
    idinstructor = id2

    entra = TransmisionesInstructoresAnteriores.objects.get(id_transmisionInstructorAnterior=idtransmision)
    estado = entra.statusT

    if estado == 0:

        entra.statusT = 1
        entra.save()

    else:

        entra.statusT = 0
        entra.save()


    url = '/mostrar_transmision_instructor_anterior/' + str(idinstructor)

    return redirect(url)


#Terminan vistas transmisiones instructor anteriores



@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def mostrar_alumnos(request):

    request.session.set_expiry(request.session.get_expiry_age())

    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)

    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    alumno = Alumno.objects.all()

    contexto = {'alumnos':alumno, 'usuarios':usuario, 'datosPagina':datoPagina}

    return render(request, 'Admin/Extras/Alumno/alumnos.html', contexto)



@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def mostrar_agregar_alumno(request):

    request.session.set_expiry(request.session.get_expiry_age())

    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)

    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    carrera = Carreras.objects.all()

    contexto = {'carreras':carrera, 'usuarios':usuario, 'datosPagina':datoPagina}

    return render(request, 'Admin/Extras/Alumno/agregar_alumno.html', contexto)


@csrf_exempt
@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def agregar_alumno_admin(request):

    request.session.set_expiry(request.session.get_expiry_age())

    if request.method == "POST":

        matriculaAL = request.POST["matricula"]
        nombreAL = request.POST["nombre"]
        apellidosAL = request.POST["apellidos"]
        #profesionAL = request.POST["profesion"]
        correo = request.POST["correo"]
        #contrasena = request.POST["password"]

        try:
            licenciaturaG = request.POST["licenciatura"]
        except Exception as e:
            licenciaturaG = 0

        try:
            semestreG = request.POST["semestre"]
        except Exception as e:
            semestreG = 0

        try:
            gradoG = request.POST["grado"]
        except Exception as e:
            gradoG = 0


        valorGrado = 0

        if semestreG != 0:

            valorGrado = semestreG

        elif gradoG != 0:

            valorGrado = gradoG

        else:

            valorGrado = 1


        #add = Alumno.objects.filter(correoAl=correo)
        add = Usuarios.objects.filter(email=correo)

        if add:
            pass

        else:

            al = Alumno(nombreA=nombreAL, apellidosA=apellidosAL, direccionA="", codigopostalA="",
            estadoA="", ciudadA="", paisA="", profesionA="Estudiante", edadA=1, celularA="", tiposangreA="",
            alergiasA="", nombreT="", apellidosT="", direccionT="", codigopostalT="", estadoT="",
            ciudadT="", paisT="", profesionT="", edadT=0, celularT=0, statusAL=1, correoAL=correo,
            ruta_avatar="avatar.png", sexo_alumno="Otro", imagen_portada="portada.jpg", imagen_qr="Ninguna", matricula=matriculaAL,
            licenciatura=licenciaturaG, grado=valorGrado)
            al.save()

            alal = Alumno.objects.get(correoAL=correo)
            idalumno = alal.id_alumno
            nombrealumno = alal.nombreA + " " + alal.apellidosA

            opcio = OpcionesAlumno(id_alumnoR=idalumno, color_barra="#01A1DD", tipo_plantilla="_barra",
            widget_clima=0, widget_juego_cartas=0, widget_juego_tetris=0)
            opcio.save()

            #Crear contraseña aleatoria
            chars = string.ascii_uppercase + string.digits
            size = 10
            contrasena = ''.join(random.choice(chars) for _ in range(size))

            contra = make_password(contrasena)

            usus = Usuarios(email=correo, password=contra, tipo_usuario=3,
            id_relacionado=idalumno, is_active=1)
            usus.save()

            hoy = date.today()

            caduca = hoy + timedelta(days=30)

            vc = VerificarCuenta(correo_vinculado=correo, fecha_creacion=hoy,
            fecha_limite=caduca, codigo="ABCD1234EF", verificado=1, perfil_editado=0)
            vc.save()

            #Enviar correo con la contraseña
            texto = 'Da clic en el siguiente enlace, https://seiko.global/iniciar_sesion/, e introduce la contraseña para activar tu cuenta. Contraseña:  ' + str(contrasena)

            html_version = 'Principal/email_general.html'

            html_message = render_to_string(html_version, { 'context': texto, })

            message = EmailMessage('Contraseña', html_message, 'hola@seiko.dev', [correo])
            message.content_subtype = 'html'
            message.send()


            texto = "Agrego el alumno: "
            texto2 = ". Con este id: "
            detalle = texto + nombrealumno + texto2 + str(idalumno)
            fecha = datetime.now()
            id_adm = request.user.id_relacionado
            adminis = Administrador.objects.get(id_admin=id_adm)
            nombre_adminis = adminis.nombre

            l = LogAdmin(fecha_accion=fecha, id_admin_accion=id_adm,
            nombre_admin_accion=nombre_adminis, detalles_accion=detalle)
            l.save()

        return redirect('/alumnos_admin/')


@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def mostrar_editar_alumno(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    idalumno = id

    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)

    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    alumno = Alumno.objects.filter(id_alumno=idalumno)

    contexto = {'alumnos':alumno, 'usuarios':usuario, 'datosPagina':datoPagina}

    return render(request, 'Admin/Extras/Alumno/editar_alumno.html', contexto)



@csrf_exempt
@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def editar_alumno_admin(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    if request.method == "POST":

        matriculaAL = request.POST["matricula"]
        nombreAL = request.POST["nombre"]
        apellidosAL = request.POST["apellidos"]
        contrasena = request.POST["password"]

        try:
            licenciaturaG = request.POST["licenciatura"]
        except Exception as e:
            licenciaturaG = 0

        try:
            semestreG = request.POST["semestre"]
        except Exception as e:
            semestreG = 0

        try:
            gradoG = request.POST["grado"]
        except Exception as e:
            gradoG = 0


        valorGrado = 0

        if semestreG != 0:

            valorGrado = semestreG

        elif gradoG != 0:

            valorGrado = gradoG

        else:

            valorGrado = 1


        idalumno = id

        al = Alumno.objects.get(id_alumno=idalumno)
        correo = al.correoAL
        al.nombreA = nombreAL
        al.apellidosA = apellidosAL
        al.matricula = matriculaAL
        al.licenciatura = licenciaturaG
        al.grado = valorGrado
        al.save()


        if contrasena:
            contra = make_password(contrasena)
            usus = Usuarios.objects.get(email=correo)
            usus.password = contra
            usus.save()


        nombrealumno = nombreAL + " " +apellidosAL

        texto = "Edito el alumno: "
        texto2 = ". Con este id: "
        detalle = texto + nombrealumno + texto2 + str(idalumno)
        fecha = datetime.now()
        id_adm = request.user.id_relacionado
        adminis = Administrador.objects.get(id_admin=id_adm)
        nombre_adminis = adminis.nombre

        l = LogAdmin(fecha_accion=fecha, id_admin_accion=id_adm,
        nombre_admin_accion=nombre_adminis, detalles_accion=detalle)
        l.save()

        return redirect('/alumnos_admin/')



@csrf_exempt
@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def eliminar_alumno(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    valor = id
    #id_usu = request.session['id_usuario']

    i = Alumno.objects.get(id_alumno=valor)
    va = i.statusAL
    correo = i.correoAL
    u = Usuarios.objects.get(email=correo)
    if va == 1:
        i.statusAL = 0
        i.save()
        u.is_active = 0
        u.save()

        texto = "Deshabilito al alumno: "
        texto2 = ". Con este id: "
        nombre = i.nombreA + " " + i.apellidosA
        detalle = texto + nombre + texto2 + str(valor)
        fecha = datetime.now()
        id_adm = request.user.id_relacionado
        adminis = Administrador.objects.get(id_admin=id_adm)
        nombre_adminis = adminis.nombre

        l = LogAdmin(fecha_accion=fecha, id_admin_accion=id_adm,
        nombre_admin_accion=nombre_adminis, detalles_accion=detalle)
        l.save()

    else:
        i.statusAL = 1
        i.save()
        u.is_active = 1
        u.save()

        texto = "Rehabilito al alumno: "
        texto2 = ". Con este id: "
        nombre = i.nombreA + " " + i.apellidosA
        detalle = texto + nombre + texto2 + str(valor)
        fecha = datetime.now()
        id_adm = request.user.id_relacionado
        adminis = Administrador.objects.get(id_admin=id_adm)
        nombre_adminis = adminis.nombre

        l = LogAdmin(fecha_accion=fecha, id_admin_accion=id_adm,
        nombre_admin_accion=nombre_adminis, detalles_accion=detalle)
        l.save()


    #instructor = Instructor.objects.all()
    #contexto = {'instructores':instructor}
    #return render(request, 'Admin/admi_instructores.html', contexto)
    return redirect('/alumnos_admin/')



@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def mostrar_carreras(request):

    request.session.set_expiry(request.session.get_expiry_age())

    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)

    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    carrera = Carreras.objects.all()

    contexto = {'carreras':carrera, 'usuarios':usuario, 'datosPagina':datoPagina}

    return render(request, 'Admin/Extras/Carreras/carreras.html', contexto)



@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def mostrar_agregar_carrera(request):

    request.session.set_expiry(request.session.get_expiry_age())

    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)

    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    contexto = {'usuarios':usuario, 'datosPagina':datoPagina}

    return render(request, 'Admin/Extras/Carreras/agregar_carrera.html', contexto)



@csrf_exempt
@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def agregar_carrera(request):

    request.session.set_expiry(request.session.get_expiry_age())

    if request.method == "POST":

        nombreAL = request.POST["nombre"]

        car = Carreras(nombre_carrera=nombreAL, statusCA=1)
        car.save()

        texto = "Agrego la carrera: "
        texto2 = "."
        detalle = texto + nombreAL + texto2
        fecha = datetime.now()
        id_adm = request.user.id_relacionado
        adminis = Administrador.objects.get(id_admin=id_adm)
        nombre_adminis = adminis.nombre

        l = LogAdmin(fecha_accion=fecha, id_admin_accion=id_adm,
        nombre_admin_accion=nombre_adminis, detalles_accion=detalle)
        l.save()

        return redirect('/carreras/')



@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def mostrar_editar_carrera(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    idcarrera = id

    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)

    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    carrera = Carreras.objects.filter(id_carrera=idcarrera)

    contexto = {'carreras':carrera, 'usuarios':usuario, 'datosPagina':datoPagina}

    return render(request, 'Admin/Extras/Carreras/editar_carrera.html', contexto)



@csrf_exempt
@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def editar_carrera(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    if request.method == "POST":

        nombreAL = request.POST["nombre"]

        idcarrera = id

        al = Carreras.objects.get(id_carrera=idcarrera)
        al.nombre_carrera = nombreAL
        al.save()

        texto = "Edito la carrera: "
        texto2 = ". Con este id: "
        detalle = texto + nombreAL + texto2 + str(idcarrera)
        fecha = datetime.now()
        id_adm = request.user.id_relacionado
        adminis = Administrador.objects.get(id_admin=id_adm)
        nombre_adminis = adminis.nombre

        l = LogAdmin(fecha_accion=fecha, id_admin_accion=id_adm,
        nombre_admin_accion=nombre_adminis, detalles_accion=detalle)
        l.save()

        return redirect('/carreras/')



@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def eliminar_carrera(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    valor = id
    c = Carreras.objects.get(id_carrera=valor)
    nombre = c.nombre_carrera
    va = c.statusCA
    if va == 1:
        c.statusCA = 0
        c.save()

        texto = "Deshabilito la carrera: "
        texto2 = ". Con este id: "
        detalle = texto + nombre + texto2 + str(valor)
        fecha = datetime.now()
        id_adm = request.user.id_relacionado
        adminis = Administrador.objects.get(id_admin=id_adm)
        nombre_adminis = adminis.nombre

        l = LogAdmin(fecha_accion=fecha, id_admin_accion=id_adm,
        nombre_admin_accion=nombre_adminis, detalles_accion=detalle)
        l.save()

    else:
        c.statusCA = 1
        c.save()

        texto = "Rehabilito la carrera: "
        texto2 = ". Con este id: "
        detalle = texto + nombre + texto2 + str(valor)
        fecha = datetime.now()
        id_adm = request.user.id_relacionado
        adminis = Administrador.objects.get(id_admin=id_adm)
        nombre_adminis = adminis.nombre

        l = LogAdmin(fecha_accion=fecha, id_admin_accion=id_adm,
        nombre_admin_accion=nombre_adminis, detalles_accion=detalle)
        l.save()


    return redirect('/carreras/')



@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def mostrar_grupos(request):

    request.session.set_expiry(request.session.get_expiry_age())

    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)

    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    grupo = Grupos.objects.all()

    contexto = {'grupos':grupo, 'usuarios':usuario, 'datosPagina':datoPagina}

    return render(request, 'Admin/Extras/Grupos/grupos.html', contexto)



@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def mostrar_agregar_grupo(request):

    request.session.set_expiry(request.session.get_expiry_age())

    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)

    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    carrera = Carreras.objects.all()

    contexto = {'carreras':carrera, 'usuarios':usuario, 'datosPagina':datoPagina}

    return render(request, 'Admin/Extras/Grupos/agregar_grupo.html', contexto)




@csrf_exempt
@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def agregar_grupo(request):

    request.session.set_expiry(request.session.get_expiry_age())

    if request.method == "POST":

        nombreAL = request.POST["nombre"]
        try:
            carreraAL = request.POST["carrera"]
        except Exception as e:
            carreraAL = 0


        car = Grupos(nombre_grupo=nombreAL, statusG=1, id_carreraR=carreraAL)
        car.save()

        texto = "Agrego el grupo: "
        texto2 = "."
        detalle = texto + nombreAL + texto2
        fecha = datetime.now()
        id_adm = request.user.id_relacionado
        adminis = Administrador.objects.get(id_admin=id_adm)
        nombre_adminis = adminis.nombre

        l = LogAdmin(fecha_accion=fecha, id_admin_accion=id_adm,
        nombre_admin_accion=nombre_adminis, detalles_accion=detalle)
        l.save()

        return redirect('/grupos/')



@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def mostrar_editar_grupo(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    idgrupo = id

    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)

    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    grupo = Grupos.objects.filter(id_grupo=idgrupo)

    carrera = Carreras.objects.all()

    contexto = {'carreras':carrera, 'grupos':grupo, 'usuarios':usuario, 'datosPagina':datoPagina}

    return render(request, 'Admin/Extras/Grupos/editar_grupo.html', contexto)



@csrf_exempt
@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def editar_grupo(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    if request.method == "POST":

        nombreAL = request.POST["nombre"]
        try:
            carreraAL = request.POST["carrera"]
        except Exception as e:
            carreraAL = 0

        idgrupo = id

        al = Grupos.objects.get(id_grupo=idgrupo)
        al.nombre_grupo = nombreAL
        al.id_carreraR = carreraAL
        al.save()

        texto = "Edito el grupo: "
        texto2 = ". Con este id: "
        detalle = texto + nombreAL + texto2 + str(idgrupo)
        fecha = datetime.now()
        id_adm = request.user.id_relacionado
        adminis = Administrador.objects.get(id_admin=id_adm)
        nombre_adminis = adminis.nombre

        l = LogAdmin(fecha_accion=fecha, id_admin_accion=id_adm,
        nombre_admin_accion=nombre_adminis, detalles_accion=detalle)
        l.save()

        return redirect('/grupos/')




@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def mostrar_asignar_materia(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)

    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    idgrupo = id

    curso = GruposCursos.objects.filter(id_grupoR=idgrupo)

    contexto = {'cursos':curso, 'idgrupo':idgrupo, 'usuarios':usuario, 'datosPagina':datoPagina}

    return render(request, 'Admin/Extras/Grupos/grupos_cursos.html', contexto)



@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def mostrar_agregar_materia(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)

    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    idgrupo = id

    curso = CursoInstructor.objects.all()

    cursoD = Curso.objects.all()

    instructor = Instructor.objects.all()

    contexto = {'instructores':instructor, 'cursosD':cursoD, 'cursos':curso, 'idgrupo':idgrupo, 'usuarios':usuario, 'datosPagina':datoPagina}

    return render(request, 'Admin/Extras/Grupos/cursos.html', contexto)



@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def asignar_curso_grupo(request, id, id2, id3):

    request.session.set_expiry(request.session.get_expiry_age())

    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)

    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    idgrupo = id
    idcurso = id2
    idinstructor = id3

    cur = Curso.objects.get(id_curso=idcurso)
    nombre_curso = cur.nombreC

    instr = Instructor.objects.get(id_instructor=idinstructor)
    nombre_instructor = str(instr.nombreI) + " " + str(instr.apellidosI)

    GC = GruposCursos(id_grupoR=idgrupo, id_cursoR=idcurso, nombre_cursoR=nombre_curso,
    id_instructorR=idinstructor, nombre_instructorR=nombre_instructor)
    GC.save()

    url = '/mostrar_asignar_materia/' + str(idgrupo)

    return redirect(url)

    #curso = CursoInstructor.objects.all()

    #cursoD = Curso.objects.all()

    #instructor = Instructor.objects.all()

    #contexto = {'instructores':instructor, 'cursosD':cursoD, 'cursos':curso, 'idgrupo':idgrupo, 'usuarios':usuario, 'datosPagina':datoPagina}

    #return render(request, 'Admin/Extras/Grupos/cursos.html', contexto)


@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def mostrar_asignar_alumnos(request, id, id2, id3, id4):

    request.session.set_expiry(request.session.get_expiry_age())

    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)

    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    idgrupocurso = id
    idgrupo = id2
    idcurso = id3
    idinstructor= id4

    Galumno = GruposAlumnos.objects.filter(id_grupoCursoR=idgrupocurso)
    alumnoD = Alumno.objects.all()

    contexto = {'alumnosD':alumnoD, 'Galumnos':Galumno, 'idgrupocurso':idgrupocurso, 'idgrupo':idgrupo, 'idcurso':idcurso,
    'idinstructor':idinstructor, 'usuarios':usuario, 'datosPagina':datoPagina}

    return render(request, 'Admin/Extras/Grupos/grupos_alumnos.html', contexto)



@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def mostrar_agregar_alumno_grupo(request, id, id2, id3, id4):

    request.session.set_expiry(request.session.get_expiry_age())

    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)

    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    idgrupocurso = id
    idgrupo = id2
    idcurso = id3
    idinstructor= id4

    alumno = Alumno.objects.all()

    contexto = {'alumnos':alumno, 'idgrupocurso':idgrupocurso, 'idgrupo':idgrupo, 'idcurso':idcurso,
    'idinstructor':idinstructor, 'usuarios':usuario, 'datosPagina':datoPagina}

    return render(request, 'Admin/Extras/Grupos/alumnos.html', contexto)



@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def asignar_curso_grupo_alumno(request, id, id2, id3, id4, id5):

    request.session.set_expiry(request.session.get_expiry_age())

    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)

    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    idgrupocurso = id
    idgrupo = id2
    idcurso = id3
    idinstructor= id4
    idalumno = id5

    alum = Alumno.objects.get(id_alumno=idalumno)
    nombre_alumno = str(alum.nombreA) + " " + str(alum.apellidosA)

    GA = GruposAlumnos(id_grupoCursoR=idgrupocurso, id_grupoR=idgrupo,
    id_cursoR=idcurso, id_instructorR=idinstructor, id_alumnoR=idalumno,
    nombre_alumnoR=nombre_alumno)
    GA.save()

    filtro = CursoEstudiante.objects.filter(id_cursoR=idcurso, id_estudianteR=idalumno, id_instructorRC=idinstructor)

    if filtro:

        pass

    else:

        CE = CursoEstudiante(id_cursoR=idcurso, id_estudianteR=idalumno, nombre_estudianteR=nombre_alumno,
        promedio_curso=0, id_instructorRC=idinstructor)
        CE.save()

    #contexto = {'alumnos':alumno, 'idgrupocurso':idgrupocurso, 'idgrupo':idgrupo, 'idcurso':idcurso,
    #'idinstructor':idinstructor, 'usuarios':usuario, 'datosPagina':datoPagina}

    #return render(request, 'Admin/Extras/Grupos/alumnos.html', contexto)

    url = '/mostrar_asignar_materia/' + str(idgrupo)

    return redirect(url)




#vistas consultas

@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def mostrar_cursos_consulta(request):

    request.session.set_expiry(request.session.get_expiry_age())

    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)

    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    idgrupo = id

    curso = CursoInstructor.objects.all()

    cursoD = Curso.objects.all()

    instructor = Instructor.objects.all()

    contexto = {'instructores':instructor, 'cursosD':cursoD, 'cursos':curso, 'idgrupo':idgrupo, 'usuarios':usuario, 'datosPagina':datoPagina}

    return render(request, 'Admin/Extras/CAcademicas/cursos.html', contexto)



@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def grupos_cursos_consulta(request, id, id2):

    request.session.set_expiry(request.session.get_expiry_age())

    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)

    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    idcurso = id
    idinstructor = id2

    filtro = GruposCursos.objects.filter(id_cursoR=idcurso, id_instructorR=idinstructor).values('id_grupoR')

    grupo = Grupos.objects.filter(id_grupo__in=filtro)

    contexto = {'idinstructor':idinstructor, 'idcurso':idcurso, 'grupos':grupo, 'usuarios':usuario, 'datosPagina':datoPagina}

    return render(request, 'Admin/Extras/CAcademicas/grupos.html', contexto)



@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def mostrar_alumnos_calificacion(request, id, id2, id3):

    request.session.set_expiry(request.session.get_expiry_age())

    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)

    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    idgrupo = id
    idcurso = id2
    idinstructor = id3

    filtro = GruposAlumnos.objects.filter(id_grupoR=idgrupo, id_cursoR=idcurso, id_instructorR=idinstructor).values('id_alumnoR')

    alumno = Alumno.objects.filter(id_alumno__in=filtro)

    carrera = Carreras.objects.all()

    contexto = {'idgrupo':idgrupo, 'idcurso':idcurso, 'idinstructor':idinstructor, 'carreras':carrera, 'alumnos':alumno, 'usuarios':usuario, 'datosPagina':datoPagina}

    return render(request, 'Admin/Extras/CAcademicas/alumnos_lista.html', contexto)



@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def mostrar_alumnos_calificacion_reload_ajax(request, id, id2, id3, id4, id5, id6):

    request.session.set_expiry(request.session.get_expiry_age())

    estado = id
    carrera = id2
    gradoG = id3

    idgrupo = id4
    idcurso = id5
    idinstructor = id6

    filtro2 = GruposAlumnos.objects.filter(id_grupoR=idgrupo, id_cursoR=idcurso, id_instructorR=idinstructor).values('id_alumnoR')

    if estado == "Todos" and carrera == "Todos" and gradoG == "Todos":

        alumno = Alumno.objects.filter(id_alumno__in=filtro2)

    elif estado == "Todos" and carrera != "Todos" and gradoG == "Todos":

        alumno = Alumno.objects.filter(id_alumno__in=filtro2, licenciatura=carrera)

    elif estado == "Todos" and carrera == "Todos" and gradoG != "Todos":

        alumno = Alumno.objects.filter(id_alumno__in=filtro2, grado=gradoG)


    elif estado == "Todos" and carrera != "Todos" and gradoG != "Todos":

        alumno = Alumno.objects.filter(id_alumno__in=filtro2, grado=gradoG, licenciatura=carrera)


    elif estado == "Aprobados" and carrera == "Todos" and gradoG == "Todos":

        filtro = CursoEstudiante.objects.filter(id_estudianteR__in=filtro2, promedio_curso__range=[7, 10]).values('id_estudianteR')

        alumno = Alumno.objects.filter(id_alumno__in=filtro)

    elif estado == "Aprobados" and carrera != "Todos" and gradoG == "Todos":

        filtro = CursoEstudiante.objects.filter(id_estudianteR__in=filtro2, promedio_curso__range=[7, 10]).values('id_estudianteR')

        alumno = Alumno.objects.filter(id_alumno__in=filtro, licenciatura=carrera)

    elif estado == "Aprobados" and carrera == "Todos" and gradoG != "Todos":

        filtro = CursoEstudiante.objects.filter(id_estudianteR__in=filtro2, promedio_curso__range=[7, 10]).values('id_estudianteR')

        alumno = Alumno.objects.filter(id_alumno__in=filtro, grado=gradoG)


    elif estado == "Aprobados" and carrera != "Todos" and gradoG != "Todos":

        filtro = CursoEstudiante.objects.filter(id_estudianteR__in=filtro2, promedio_curso__range=[7, 10]).values('id_estudianteR')

        alumno = Alumno.objects.filter(id_alumno__in=filtro, grado=gradoG, licenciatura=carrera)


    elif estado == "Reprobados" and carrera == "Todos" and gradoG == "Todos":

        filtro = CursoEstudiante.objects.filter(id_estudianteR__in=filtro2, promedio_curso__range=[0, 6]).values('id_estudianteR')
        alumno = Alumno.objects.filter(id_alumno__in=filtro)

    elif estado == "Reprobados" and carrera != "Todos" and gradoG == "Todos":

        filtro = CursoEstudiante.objects.filter(id_estudianteR__in=filtro2, promedio_curso__range=[0, 6]).values('id_estudianteR')
        alumno = Alumno.objects.filter(id_alumno__in=filtro, licenciatura=carrera)

    elif estado == "Reprobados" and carrera == "Todos" and gradoG != "Todos":

        filtro = CursoEstudiante.objects.filter(id_estudianteR__in=filtro2, promedio_curso__range=[0, 6]).values('id_estudianteR')
        alumno = Alumno.objects.filter(id_alumno__in=filtro, grado=gradoG)


    elif estado == "Reprobados" and carrera != "Todos" and gradoG != "Todos":

        filtro = CursoEstudiante.objects.filter(id_estudianteR__in=filtro2, promedio_curso__range=[0, 6]).values('id_estudianteR')

        alumno = Alumno.objects.filter(id_alumno__in=filtro, grado=gradoG, licenciatura=carrera)



    contexto = {'alumnos':alumno}

    return render(request, 'Admin/Extras/CAcademicas/alumnos_lista_ajax.html', contexto)




@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def mostrar_calificaciones_alumno(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)

    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    idalumno = id

    filtro = CursoEstudiante.objects.filter(id_estudianteR=idalumno).values('id_cursoR')

    total = CursoEstudiante.objects.filter(id_estudianteR=idalumno).count()

    calumno = CursoEstudiante.objects.filter(id_estudianteR=idalumno)

    suma = 0

    for valor in calumno:

        dato = valor.promedio_curso

        suma = suma + dato

    if total != 0:
        promedioGeneral = suma/total
    else:
        promedioGeneral = 0


    curso = Curso.objects.filter(id_curso__in=filtro)

    alumno = Alumno.objects.filter(id_alumno=idalumno)

    contexto = {'idalumno':idalumno, 'promedioGeneral':promedioGeneral, 'calumnos':calumno, 'cursos':curso, 'alumnos':alumno, 'usuarios':usuario, 'datosPagina':datoPagina}

    return render(request, 'Admin/Extras/CAcademicas/alumno_materias.html', contexto)




@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def mostrar_calificaciones_curso(request, id, id2, id3):

    request.session.set_expiry(request.session.get_expiry_age())

    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)

    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    idalumno = id

    idcurso = id2

    idinstructor = id3

    actividad = Actividad.objects.filter(id_cursoR=idcurso, id_instructorR=idinstructor)

    actividadA = ActividadAlumno.objects.filter(id_alumnoR=idalumno, id_cursoR=idcurso)

    examen = EvaluacionesCursos.objects.filter(id_cursoR=idcurso, id_instructorR=idinstructor)

    examenA = EvaluacionCursosEstudiante.objects.filter(id_estudianteR=idalumno, id_cursoR=idcurso, id_instructorR=idinstructor)

    curso = Curso.objects.filter(id_curso=idcurso)

    alumno = Alumno.objects.filter(id_alumno=idalumno)

    contexto = {'actividades':actividad, 'actividadesA':actividadA, 'examenes':examen, 'examenesA':examenA, 'cursos':curso, 'alumnos':alumno, 'usuarios':usuario, 'datosPagina':datoPagina}

    return render(request, 'Admin/Extras/CAcademicas/materias_lista.html', contexto)





@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def imprimir_lista(request, id, id2, id3):

    request.session.set_expiry(request.session.get_expiry_age())

    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)

    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    idgrupo = id

    idcurso = id2

    idinstructor = id3

    gr = Grupos.objects.get(id_grupo=idgrupo)
    nombre_grupoG = gr.nombre_grupo

    emp = PaginasActivas.objects.get(id_paginaActiva=1)
    nombre_empre = emp.nombre_empresa

    filtro = GruposAlumnos.objects.filter(id_grupoR=idgrupo, id_cursoR=idcurso, id_instructorR=idinstructor).values('id_alumnoR')

    alumnos = CursoEstudiante.objects.filter(id_cursoR=idcurso, id_instructorRC=idinstructor, id_estudianteR__in=filtro)

    alumnos2 = Alumno.objects.filter(id_alumno__in=filtro).order_by("apellidosA")

    nombrearchivo = nombre_grupoG + ' - con calificaciones.xlsx'

    workbook = xlsxwriter.Workbook(os.path.join(settings.MEDIA_ROOT+'/Listas/Administrador/'+ nombrearchivo))
    worksheet = workbook.add_worksheet()

    worksheet.set_column('A:A', 4)

    merge_format = workbook.add_format({
        'bold': 1,
        'text_wrap': True,
        'align': 'center',
        'valign': 'vcenter'})

    merge_format2 = workbook.add_format({
        'bold': 1,
        'border': 1,
        'align': 'center',
        'valign': 'vcenter',
        'fg_color': 'silver'})

    merge_format3 = workbook.add_format({
        'border': 1})


    merge_format4 = workbook.add_format({
        'border': 1,
        'align': 'center'})


    imagen = os.path.join(settings.MEDIA_ROOT+'/Imagenes', "LogoKaizen.jpg")
    nombre_escuela = nombre_empre

    grupo = nombre_grupoG

    bound_width_height = (110, 110)
    resize_scale = calculate_scale(imagen, bound_width_height)
    worksheet.insert_image('B2', imagen, {'x_scale': resize_scale, 'y_scale': resize_scale})


    worksheet.merge_range('D3:G4', nombre_escuela, merge_format)
    worksheet.merge_range('D6:G6', grupo, merge_format)


    worksheet.write('A8', 'No.', merge_format2)
    worksheet.merge_range('B8:F8', 'Nombre del alumno', merge_format2)
    worksheet.merge_range('G8:H8', 'Calificacion', merge_format2)


    no_lista = 'A'

    lista = 9

    nombre1 = 'B'
    nombre2 = 'F'

    nombre = 9

    calificacion1 = 'G'
    calificacion2 = 'H'

    calificacion = 9

    contador = 1

    for alumnoD in alumnos2:

        id = alumnoD.id_alumno

        alumno = alumnoD.apellidosA + " " + alumnoD.nombreA

        for alumnoF in alumnos:

            if alumnoF.id_estudianteR == id:

                resultado = alumnoF.promedio_curso

        contador_final = contador
        lista_final = no_lista + str(lista)
        nombre_final = nombre1 + str(nombre) + ':' + nombre2 + str(nombre)
        calificacion_final = calificacion1 + str(calificacion) + ':' + calificacion2 + str(calificacion)


        worksheet.write(lista_final, contador_final, merge_format4)
        worksheet.merge_range(nombre_final, alumno, merge_format3)
        worksheet.merge_range(calificacion_final, resultado, merge_format4)

        lista = lista + 1
        nombre = nombre + 1
        calificacion = calificacion + 1
        contador = contador + 1


    workbook.close()

    #archivo = os.path.join(settings.MEDIA_ROOT+'/Listas/Administrador', nombrearchivo)
    archivo = open(os.path.join(settings.MEDIA_ROOT+'/Listas/Administrador', nombrearchivo), "rb")

    #response = HttpResponse(archivo, content_type='application/ms-excel')
    response = HttpResponse(archivo.read(), content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    response['Content-Disposition'] = 'attachment; filename=lista-con-calificaciones.xlsx'
    return(response)



@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def imprimir_lista_sin(request, id, id2, id3):

    request.session.set_expiry(request.session.get_expiry_age())

    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)

    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    idgrupo = id

    idcurso = id2

    idinstructor = id3

    gr = Grupos.objects.get(id_grupo=idgrupo)
    nombre_grupoG = gr.nombre_grupo

    emp = PaginasActivas.objects.get(id_paginaActiva=1)
    nombre_empre = emp.nombre_empresa

    filtro = GruposAlumnos.objects.filter(id_grupoR=idgrupo, id_cursoR=idcurso, id_instructorR=idinstructor).values('id_alumnoR')

    alumnos = CursoEstudiante.objects.filter(id_cursoR=idcurso, id_instructorRC=idinstructor, id_estudianteR__in=filtro)

    alumnos2 = Alumno.objects.filter(id_alumno__in=filtro).order_by("apellidosA")

    nombrearchivo = nombre_grupoG + ' - sin calificaciones.xlsx'

    workbook = xlsxwriter.Workbook(os.path.join(settings.MEDIA_ROOT+'/Listas/Administrador/'+ nombrearchivo))
    worksheet = workbook.add_worksheet()

    worksheet.set_column('A:A', 4)

    merge_format = workbook.add_format({
        'bold': 1,
        'text_wrap': True,
        'align': 'center',
        'valign': 'vcenter'})

    merge_format2 = workbook.add_format({
        'bold': 1,
        'border': 1,
        'align': 'center',
        'valign': 'vcenter',
        'fg_color': 'silver'})

    merge_format3 = workbook.add_format({
        'border': 1})


    merge_format4 = workbook.add_format({
        'border': 1,
        'align': 'center'})


    imagen = os.path.join(settings.MEDIA_ROOT+'/Imagenes', "LogoKaizen.jpg")
    nombre_escuela = nombre_empre

    grupo = nombre_grupoG

    bound_width_height = (110, 110)
    resize_scale = calculate_scale(imagen, bound_width_height)
    worksheet.insert_image('B2', imagen, {'x_scale': resize_scale, 'y_scale': resize_scale})


    worksheet.merge_range('D3:G4', nombre_escuela, merge_format)
    worksheet.merge_range('D6:G6', grupo, merge_format)


    worksheet.write('A8', 'No.', merge_format2)
    worksheet.merge_range('B8:H8', 'Nombre del alumno', merge_format2)

    no_lista = 'A'

    lista = 9

    nombre1 = 'B'
    nombre2 = 'H'

    nombre = 9

    contador = 1

    for alumnoD in alumnos2:

        alumno = alumnoD.apellidosA + " " + alumnoD.nombreA

        contador_final = contador
        lista_final = no_lista + str(lista)
        nombre_final = nombre1 + str(nombre) + ':' + nombre2 + str(nombre)

        worksheet.write(lista_final, contador_final, merge_format4)
        worksheet.merge_range(nombre_final, alumno, merge_format3)

        lista = lista + 1
        nombre = nombre + 1
        contador = contador + 1


    workbook.close()

    #archivo = os.path.join(settings.MEDIA_ROOT+'/Listas/Administrador', nombrearchivo)
    archivo = open(os.path.join(settings.MEDIA_ROOT+'/Listas/Administrador', nombrearchivo), "rb")

    #response = HttpResponse(archivo, content_type='application/ms-excel')
    response = HttpResponse(archivo.read(), content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    response['Content-Disposition'] = 'attachment; filename=lista-sin-calificaciones.xlsx'
    return(response)





#Terminan vistas siguiente version
def iniciar_sesion_admin(request):

    return render(request, "Admin/inicio_sesion.html")

@csrf_exempt
def procesar_sesion_admin(request):

    if request.method == "POST":

        usuario = request.POST["user_name"]
        contra = request.POST["user_password"]

        admin = authenticate(username=usuario, password=contra)

        if admin is not None:

            if admin.is_active == 1 and admin.tipo_usuario == 1:

                login(request, admin)
                return redirect('/inicio_admin/')

            else:

                return render(request, 'Admin/inactivo_inicio_sesion.html')

        else:

            return render(request, 'Admin/error_inicio_sesion.html')


@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def mostrar_cursos(request):

    request.session.set_expiry(request.session.get_expiry_age())

    curso = Curso.objects.all()
    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)
    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    eva = EvaluacionServicioCurso.objects.all()

    contexto = {'evas':eva, 'cursos':curso, 'usuarios':usuario, 'datosPagina':datoPagina}
    return render(request, 'Admin/administrador_cursos.html', contexto)


@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def regresar_inicio_admin(request):

    Afganistan = 0
    Albania = 0
    Alemania = 0
    Andorra = 0
    Angola = 0
    Antigua_y_Barbuda = 0
    Arabia_Saudita = 0
    Argelia = 0
    Argentina = 0
    Armenia = 0
    Australia = 0
    Austria = 0
    Azerbaiyan = 0
    Bahamas = 0
    Banglades = 0
    Barbados = 0
    Barein = 0
    Belgica = 0
    Belice = 0
    Benin = 0
    Bielorrusia = 0
    Birmania_Myanmar = 0
    Bolivia = 0
    Bosnia_y_Herzegovina = 0
    Botsuana = 0
    Brasil = 0
    Brunei = 0
    Bulgaria = 0
    Burkina_Faso = 0
    Burundi = 0
    Butan = 0
    Cabo_Verde = 0
    Camboya = 0
    Camerun = 0
    Canada = 0
    Catar = 0
    Chad = 0
    Chile = 0
    China = 0
    Chipre = 0
    Ciudad_del_Vaticano = 0
    Colombia = 0
    Comoras = 0
    Corea_del_Norte = 0
    Corea_del_Sur = 0
    Costa_de_Marfil = 0
    Costa_Rica = 0
    Croacia = 0
    Cuba = 0
    Dinamarca = 0
    Dominica = 0
    Ecuador = 0
    Egipto = 0
    El_Salvador = 0
    Emiratos_Arabes_Unidos = 0
    Eritrea = 0
    Eslovaquia = 0
    Eslovenia = 0
    Espana = 0
    Estados_Unidos = 0
    Estonia = 0
    Etiopia = 0
    Filipinas = 0
    Finlandia = 0
    Fiyi = 0
    Francia = 0
    Gabon = 0
    Gambia = 0
    Georgia = 0
    Ghana = 0
    Granada = 0
    Grecia = 0
    Guatemala = 0
    Guyana = 0
    Guinea = 0
    Guinea_ecuatorial = 0
    Guinea_Bisau = 0
    Haiti = 0
    Honduras = 0
    Hungria = 0
    India = 0
    Indonesia = 0
    Irak = 0
    Iran = 0
    Irlanda = 0
    Islandia = 0
    Islas_Marshall = 0
    Islas_Salomon = 0
    Israel = 0
    Italia = 0
    Jamaica = 0
    Japon = 0
    Jordania = 0
    Kazajistan = 0
    Kenia = 0
    Kirguistan = 0
    Kiribati = 0
    Kuwait = 0
    Laos = 0
    Lesoto = 0
    Letonia = 0
    Libano = 0
    Liberia = 0
    Libia = 0
    Liechtenstein = 0
    Lituania = 0
    Luxemburgo = 0
    Macedonia_del_Norte = 0
    Madagascar = 0
    Malasia = 0
    Malaui = 0
    Maldivas = 0
    Mali = 0
    Malta = 0
    Marruecos = 0
    Mauricio = 0
    Mauritania = 0
    Mexico = 0
    Micronesia = 0
    Moldavia = 0
    Monaco = 0
    Mongolia = 0
    Montenegro = 0
    Mozambique = 0
    Namibia = 0
    Nauru = 0
    Nepal = 0
    Nicaragua = 0
    Niger = 0
    Nigeria = 0
    Noruega = 0
    Nueva_Zelanda = 0
    Oman = 0
    Paises_Bajos = 0
    Pakistan = 0
    Palaos = 0
    Panama = 0
    Papua_Nueva_Guinea = 0
    Paraguay = 0
    Peru = 0
    Polonia = 0
    Portugal = 0
    Reino_Unido = 0
    Republica_Centroafricana = 0
    Republica_Checa = 0
    Republica_del_Congo = 0
    Republica_Democratica_del_Congo = 0
    Republica_Dominicana = 0
    Republica_Sudafricana = 0
    Ruanda = 0
    Rumania = 0
    Rusia = 0
    Samoa = 0
    San_Cristobal_y_Nieves = 0
    San_Marino = 0
    San_Vicente_y_las_Granadinas = 0
    Santa_Lucia = 0
    Santo_Tome_y_Principe = 0
    Senegal = 0
    Serbia = 0
    Seychelles = 0
    Sierra_Leona = 0
    Singapur = 0
    Siria = 0
    Somalia = 0
    Sri_Lanka = 0
    Suazilandia = 0
    Sudan = 0
    Sudan_del_Sur = 0
    Suecia = 0
    Suiza = 0
    Surinam = 0
    Tailandia = 0
    Tanzania = 0
    Tayikistan = 0
    Timor_Oriental = 0
    Togo = 0
    Tonga = 0
    Trinidad_y_Tobago = 0
    Tunez = 0
    Turkmenistan = 0
    Turquia = 0
    Tuvalu = 0
    Ucrania = 0
    Uganda = 0
    Uruguay = 0
    Uzbekistan = 0
    Vanuatu = 0
    Venezuela = 0
    Vietnam = 0
    Yemen = 0
    Yibuti = 0
    Zambia = 0
    Zimbabue = 0
    Chequia = 0
    Hong_Kong = 0
    Sudafrica = 0
    Taiwan = 0
    Gran_Bretana = 0

    alumnos = Alumno.objects.all()

    if alumnos:

        for alumno in alumnos:

            pais = alumno.paisA

            if pais == "Afganistan":
                Afganistan = Afganistan + 1
            elif pais == "Albania":
                Albania = Albania + 1
            elif pais == "Germany":
                Alemania = Alemania + 1
            elif pais == "Andorra":
                Andorra = Andorra + 1
            elif pais == "Angola":
                Angola = Angola + 1
            elif pais == "Antigua and Barbuda":
                Antigua_y_Barbuda = Antigua_y_Barbuda + 1
            elif pais == "Saudi Arabia":
                Arabia_Saudita = Arabia_Saudita + 1
            elif pais == "Algeria":
                Argelia = Argelia + 1
            elif pais == "Argentina":
                Argentina = Argentina + 1
            elif pais == "Armenia":
                Armenia = Armenia + 1
            elif pais == "Australia":
                Australia = Australia + 1
            elif pais == "Austria":
                Austria = Austria + 1
            elif pais == "Azerbaijan":
                Azerbaiyan = Azerbaiyan + 1
            elif pais == "Bahamas":
                Bahamas = Bahamas + 1
            elif pais == "Bangladesh":
                Banglades = Banglades + 1
            elif pais == "Barbados":
                Barbados = Barbados + 1
            elif pais == "Barein":
                Barein = Barein + 1
            elif pais == "Belgium":
                Belgica = Belgica + 1
            elif pais == "Belize":
                Belice = Belice + 1
            elif pais == "Benin":
                Benin = Benin + 1
            elif pais == "Belarus":
                Bielorrusia = Bielorrusia + 1
            elif pais == "Burna and Myanmar":
                Birmania_Myanmar =Birmania_Myanmar + 1
            elif pais == "Bolivia":
                Bolivia =Bolivia + 1
            elif pais == "Bosnia and Herzegovina":
                Bosnia_y_Herzegovina = Bosnia_y_Herzegovina + 1
            elif pais == "Botswana":
                Botsuana = Botsuana + 1
            elif pais == "Brazil":
                Brasil = Brasil  + 1
            elif pais == "Brunei":
                Brunei = Brunei + 1
            elif pais == "Bulgaria":
                Bulgaria = Bulgaria + 1
            elif pais == "Burkina Faso":
                Burkina_Faso = Burkina_Faso + 1
            elif pais == "Burundi":
                Burundi =Burundi + 1
            elif pais == "Bhutan":
                Butan = Butan + 1
            elif pais == "Cape Verde":
                Cabo_Verde = Cabo_Verde + 1
            elif pais == "Camboya":
                Camboya = Camboya + 1
            elif pais == "Camerun":
                Camerun = Camerun + 1
            elif pais == "Canada":
                Canada = Canada + 1
            elif pais == "Catar":
                Catar = Catar + 1
            elif pais == "Chad":
                Chad = Chad + 1
            elif pais == "Chile":
                Chile = Chile + 1
            elif pais == "China":
                China = China + 1
            elif pais == "Chipre":
                Chipre = Chipre + 1
            elif pais == "Ciudad del Vaticano":
                Ciudad_del_Vaticano = Ciudad_del_Vaticano + 1
            elif pais == "Colombia":
                Colombia = Colombia + 1
            elif pais == "Comoras":
                Comoras = Comoras + 1
            elif pais == "Corea del Norte":
                Corea_del_Norte = Corea_del_Norte + 1
            elif pais == "Corea del Sur":
                Corea_del_Sur = Corea_del_Sur + 1
            elif pais == "Costa de Marfil":
                Costa_de_Marfil = Costa_de_Marfil + 1
            elif pais == "Costa Rica":
                Costa_Rica = Costa_Rica + 1
            elif pais == "Croacia":
                Croacia = Croacia + 1
            elif pais == "Cuba":
                Cuba = Cuba + 1
            elif pais == "Dinamarca":
                Dinamarca = Dinamarca + 1
            elif pais == "Dominica":
                Dominica = Dominica + 1
            elif pais == "Ecuador":
                Ecuador = Ecuador + 1
            elif pais == "Egypt":
                Egipto = Egipto + 1
            elif pais == "El Salvador":
                El_Salvador = El_Salvador + 1
            elif pais == "Emiratos Arabes Unidos":
                Emiratos_Arabes_Unidos = Emiratos_Arabes_Unidos + 1
            elif pais == "Eritrea":
                Eritrea = Eritrea + 1
            elif pais == "Eslovaquia":
                Eslovaquia = Eslovaquia + 1
            elif pais == "Eslovenia":
                Eslovenia = Eslovenia + 1
            elif pais == "España":
                Espana = Espana + 1
            elif pais == "United States":
                 Estados_Unidos = Estados_Unidos + 1
            elif pais == "Estonia":
                Estonia = Estonia + 1
            elif pais == "Etiopia":
                Etiopia = Etiopia + 1
            elif pais == "Filipinas":
                Filipinas = Filipinas + 1
            elif pais == "Finlandia":
                Finlandia = Finlandia + 1
            elif pais == "Fiyi":
                Fiyi = Fiyi + 1
            elif pais == "France":
                Francia = Francia + 1
            elif pais == "Gabon":
                Gabon = Gabon + 1
            elif pais == "Gambia":
                Gambia = Gambia + 1
            elif pais == "Georgia":
                Georgia = Georgia + 1
            elif pais == "Ghana":
                Ghana = Ghana + 1
            elif pais == "Granada":
                Granada = Granada + 1
            elif pais == "Grecia":
                Grecia = Grecia + 1
            elif pais == "Guatemala":
                Guatemala = Guatemala + 1
            elif pais == "Guyana":
                Guyana = Guyana + 1
            elif pais == "Guinea":
                Guinea = Guinea + 1
            elif pais == "Guinea ecuatorial":
                Guinea_ecuatorial = Guinea_ecuatorial + 1
            elif pais == "Guinea-Bisau":
                Guinea_Bisau = Guinea_Bisau + 1
            elif pais == "Haiti":
                Haiti = Haiti + 1
            elif pais == "Honduras":
                Honduras = Honduras + 1
            elif pais == "Hungria":
                Hungria = Hungria + 1
            elif pais == "India":
                India = India + 1
            elif pais == "Indonesia":
                Indonesia = Indonesia + 1
            elif pais == "Irak":
                Irak = Irak + 1
            elif pais == "Iran":
                Iran = Iran + 1
            elif pais == "Irlanda":
                Irlanda = Irlanda + 1
            elif pais == "Islandia":
                Islandia = Islandia + 1
            elif pais == "Islas Marshall":
                Islas_Marshall = Islas_Marshall + 1
            elif pais == "Islas Salomon":
                Islas_Salomon = Islas_Salomon + 1
            elif pais == "Israel":
                Israel = Israel + 1
            elif pais == "Italy":
                Italia = Italia + 1
            elif pais == "Jamaica":
                Jamaica = Jamaica + 1
            elif pais == "Japan":
                Japon = Japon + 1
            elif pais == "Jordania":
                Jordania = Jordania + 1
            elif pais == "Kazajistan":
                Kazajistan = Kazajistan + 1
            elif pais == "Kenia":
                Kenia = Kenia + 1
            elif pais == "Kirguistan":
                Kirguistan = Kirguistan + 1
            elif pais == "Kiribati":
                Kiribati = Kiribati + 1
            elif pais == "Kuwait":
                Kuwait = Kuwait + 1
            elif pais == "Laos":
                Laos = Laos + 1
            elif pais == "Lesoto":
                Lesoto = Lesoto + 1
            elif pais == "Letonia":
                Letonia = Letonia + 1
            elif pais == "Libano":
                Libano = Libano + 1
            elif pais == "Liberia":
                Liberia = Liberia + 1
            elif pais == "Libia":
                Libia = Libia + 1
            elif pais == "Liechtenstein":
                Liechtenstein = Liechtenstein + 1
            elif pais == "Lituania":
                Lituania = Lituania + 1
            elif pais == "Luxemburgo":
                Luxemburgo = Luxemburgo + 1
            elif pais == "Macedonia del Norte":
                Macedonia_del_Norte = Macedonia_del_Norte + 1
            elif pais == "Madagascar":
                Madagascar = Madagascar + 1
            elif pais == "Malasia":
                Malasia = Malasia + 1
            elif pais == "Malaui":
                Malaui = Malaui + 1
            elif pais == "Maldivas":
                Maldivas = Maldivas + 1
            elif pais == "Mali":
                Mali = Mali + 1
            elif pais == "Malta":
                Malta = Malta + 1
            elif pais == "Marruecos":
                Marruecos = Marruecos + 1
            elif pais == "Mauricio":
                Mauricio = Mauricio + 1
            elif pais == "Mauritania":
                Mauritania = Mauritania + 1
            elif pais == "México":
                Mexico = Mexico + 1
            elif pais == "Micronesia":
                Micronesia = Micronesia + 1
            elif pais == "Moldavia":
                Moldavia = Moldavia + 1
            elif pais == "Monaco":
                Monaco = Monaco + 1
            elif pais == "Mongolia":
                Mongolia = Mongolia + 1
            elif pais == "Montenegro":
                Montenegro = Montenegro + 1
            elif pais == "Mozambique":
                Mozambique = Mozambique + 1
            elif pais == "Namibia":
                Namibia = Namibia + 1
            elif pais == "Nauru":
                Nauru = Nauru + 1
            elif pais == "Nepal":
                Nepal = Nepal + 1
            elif pais == "Nicaragua":
                Nicaragua = Nicaragua + 1
            elif pais == "Niger":
                Niger = Niger + 1
            elif pais == "Nigeria":
                Nigeria = Nigeria + 1
            elif pais == "Noruega":
                Noruega = Noruega + 1
            elif pais == "Nueva Zelanda":
                Nueva_Zelanda = Nueva_Zelanda + 1
            elif pais == "Oman":
                Oman = Oman + 1
            elif pais == "Paises Bajos":
                Paises_Bajos = Paises_Bajos + 1
            elif pais == "Pakistan":
                Pakistan = Pakistan + 1
            elif pais == "Palaos":
                Palaos = Palaos + 1
            elif pais == "Panamá":
                Panama = Panama + 1
            elif pais == "Papua Nueva Guinea":
                Papua_Nueva_Guinea = Papua_Nueva_Guinea + 1
            elif pais == "Paraguay":
                Paraguay = Paraguay + 1
            elif pais == "Perú":
                Peru = Peru + 1
            elif pais == "Poland":
                Polonia = Polonia + 1
            elif pais == "Portugal":
                Portugal = Portugal + 1
            elif pais == "Reino Unido":
                Reino_Unido = Reino_Unido + 1
            elif pais == "Republica Centroafricana":
                Republica_Centroafricana = Republica_Centroafricana + 1
            elif pais == "Republica Checa":
                Republica_Checa = Republica_Checa + 1
            elif pais == "Republica del Congo":
                Republica_del_Congo = Republica_del_Congo + 1
            elif pais == "Republica Democratica del Congo":
                Republica_Democratica_del_Congo = Republica_Democratica_del_Congo + 1
            elif pais == "Republica Dominicana":
                Republica_Dominicana = Republica_Dominicana + 1
            elif pais == "Republica Sudafricana":
                Republica_Sudafricana = Republica_Sudafricana + 1
            elif pais == "Ruanda":
                Ruanda = Ruanda + 1
            elif pais == "Rumania":
                Rumania = Rumania + 1
            elif pais == "Rusia":
                Rusia = Rusia + 1
            elif pais == "Samoa":
                Samoa = Samoa + 1
            elif pais == "San Cristobal y Nieves":
                San_Cristobal_y_Nieves = San_Cristobal_y_Nieves + 1
            elif pais == "San Marino":
                San_Marino = San_Marino + 1
            elif pais == "San Vicente y las Granadinas":
                San_Vicente_y_las_Granadinas = San_Vicente_y_las_Granadinas + 1
            elif pais == "Santa Lucia":
                Santa_Lucia = Santa_Lucia + 1
            elif pais == "Santo Tome y Principe":
                Santo_Tome_y_Principe = Santo_Tome_y_Principe + 1
            elif pais == "Senegal":
                Senegal = Senegal + 1
            elif pais == "Serbia":
                Serbia = Serbia + 1
            elif pais == "Sierra Leona":
                Sierra_Leona = Sierra_Leona + 1
            elif pais == "Seychelles":
                Seychelles = Seychelles + 1
            elif pais == "Singapur":
                Singapur = Singapur + 1
            elif pais == "Siria":
                Siria = Siria + 1
            elif pais == "Sri Lanka":
                Sri_Lanka = Sri_Lanka + 1
            elif pais == "Somalia":
                Somalia = Somalia + 1
            elif pais == "Sudan":
                Sudan = Sudan + 1
            elif pais == "Suazilandia":
                Suazilandia = Suazilandia + 1
            elif pais == "Suecia":
                Suecia = Suecia + 1
            elif pais == "Sudan":
                Sudan_del_Sur = Sudan_del_Sur + 1
            elif pais == "Suiza":
                Suiza = Suiza + 1
            elif pais == "Surinam":
                Surinam = Surinam + 1
            elif pais == "Tailandia":
                Tailandia = Tailandia + 1
            elif pais == "Tanzania":
                Tanzania = Tanzania + 1
            elif pais == "Timor Oriental":
                Timor_Oriental = Timor_Oriental + 1
            elif pais == "Tayikistan":
                Tayikistan = Tayikistan + 1
            elif pais == "Togo":
                Togo = Togo + 1
            elif pais == "Tonga":
                Tonga = Tonga + 1
            elif pais == "Trinidad and Tobago":
                Trinidad_y_Tobago = Trinidad_y_Tobago + 1
            elif pais == "Tunez":
                Tunez = Tunez + 1
            elif pais == "Turkmenistan":
                Turkmenistan = Turkmenistan + 1
            elif pais == "Turquia":
                Turquia = Turquia + 1
            elif pais == "Tuvalu":
                Tuvalu = Tuvalu + 1
            elif pais == "Ucrania":
                Ucrania = Ucrania + 1
            elif pais == "Uganda":
                Uganda = Uganda + 1
            elif pais == "Uruguay":
                Uruguay = Uruguay + 1
            elif pais == "Uzbekistan":
                Uzbekistan = Uzbekistan + 1
            elif pais == "Vanuatu":
                Vanuatu = Vanuatu + 1
            elif pais == "Venezuela":
                Venezuela = Venezuela + 1
            elif pais == "Vietnam":
                Vietnam = Vietnam + 1
            elif pais == "Yemen":
                Yemen = Yemen + 1
            elif pais == "Yibuti":
                Yibuti = Yibuti + 1
            elif pais == "Zambia":
                Zambia = Zambia + 1
            elif pais == "Zimbabue":
                Zimbabue = Zimbabue + 1
            elif pais == "Chequia":
                Chequia = Chequia + 1
            elif pais == "Hong Kong":
                Hong_Kong = Hong_Kong + 1
            elif pais == "South Africa":
                Sudafrica = Sudafrica + 1
            elif pais == "Taiwan":
                Taiwan = Taiwan + 1
            elif pais == "Gran Bretana":
                Gran_Bretana = Gran_Bretana + 1


    pais_data = {"af":Afganistan,"al":Albania,
    "dz":Argelia,"ao":Angola,"ag":Antigua_y_Barbuda,
    "ar":Argentina,"am":Armenia,"au":Australia,
    "at":Austria,"az":Azerbaiyan,"bs":Bahamas,
    "bh":Barein,"bd":Banglades,"bb":Barbados,
    "by":Bielorrusia,"be":Belgica,"bz":Belice,
    "bj":Benin,"bt":Butan,"bo":Bolivia,"ba":Bosnia_y_Herzegovina,
    "bw":Botsuana,"br":Brasil,"bn":Brunei,"bg":Bulgaria,
    "bf":Burkina_Faso,"bi":Burundi,"kh":Camboya,"cm":Camerun,
    "ca":Canada,"cv":Cabo_Verde,"cf":Republica_Centroafricana,"td":Chad,
    "cl":Chile,"cn":China,"co":Colombia,"km":Comoras,
    "cd":Republica_Democratica_del_Congo,"cg":Republica_del_Congo,"cr":Costa_Rica,"ci":Costa_de_Marfil,
    "hr":Croacia,"cy":Chipre,"cz":Chequia,"dk":Dinamarca,"dj":Yibuti,
    "dm":Dominica,"do":Republica_Dominicana,"ec":Ecuador,"eg":Egipto,
    "sv":El_Salvador,"gq":Guinea_ecuatorial,"er":Eritrea,"ee":Estonia,
    "et":Etiopia,"fj":Fiyi,"fi":Finlandia,"fr":Francia,
    "ga":Gabon,"gm":Gambia,"ge":Georgia,"de":Alemania,
    "gh":Ghana,"gr":Grecia,"gd":Granada,"gt":Guatemala,
    "gn":Guinea,"gw":Guinea_Bisau,"gy":Guyana,"ht":Haiti,
    "hn":Honduras,"hk":Hong_Kong,"hu":Hungria,
    "is":Islandia,"in":India,"id":Indonesia,
    "ir":Iran,"iq":Irak,"ie":Irlanda,"il":Israel,
    "it":Italia,"jm":Jamaica,"jp":Japon,"jo":Jordania,
    "kz":Kazajistan,"ke":Kenia,"ki":Kiribati,"kr":Corea_del_Sur,
    "kp":Corea_del_Norte,"kw":Kuwait,"kg":Kirguistan,"la":Laos,
    "lv":Letonia,"lb":Libano,"ls":Lesoto,"lr":Liberia,"ly":Libia,
    "lt":Lituania,"lu":Luxemburgo,"mk":Macedonia_del_Norte,"mg":Madagascar,"mw":Malaui,
    "my":Malasia,"mv":Maldivas,"ml":Mali,"mt":Malta,"mr":Mauritania,
    "mu":Mauricio,"mx":Mexico,"md":Moldavia,"mn":Mongolia,"me":Montenegro,
    "ma":Marruecos,"mz":Mozambique,"mm":Birmania_Myanmar,"na":Namibia,"np":Nepal,
    "nl":Paises_Bajos,"nz":Nueva_Zelanda,"ni":Nicaragua,"ne":Niger,"ng":Nigeria,
    "no":Noruega,"om":Oman,"pk":Pakistan,"pa":Panama,"pg":Papua_Nueva_Guinea,
    "py":Paraguay,"pe":Peru,"ph":Filipinas,"pl":Polonia,"pt":Portugal,
    "qa":Catar,"ro":Rumania,"ru":Rusia,"rw":Ruanda,"ws":Samoa,
    "st":Santo_Tome_y_Principe,"sa":Arabia_Saudita,"sn":Senegal,"rs":Serbia,"sc":Seychelles,"sl":Sierra_Leona,
    "sg":Singapur,"sk":Eslovaquia,"si":Eslovenia,"sb":Islas_Salomon,"za":Sudafrica,"es":Espana,
    "lk":Sri_Lanka,"kn":San_Cristobal_y_Nieves,"lc":Santa_Lucia,"vc":San_Vicente_y_las_Granadinas,"sd":Sudan,"sr":Surinam,
    "sz":Suazilandia,"se":Suecia,"ch":Suiza,"sy":Siria,"tw":Taiwan,
    "tj":Tayikistan,"tz":Tanzania,"th":Tailandia,"tl":Timor_Oriental,"tg":Togo,"to":Tonga,
    "tt":Trinidad_y_Tobago,"tn":Tunez,"tr":Turquia,"tm":Turkmenistan,"ug":Uganda,"ua":Ucrania,
    "ae":Emiratos_Arabes_Unidos,"gb":Gran_Bretana,"us":Estados_Unidos,"uy":Uruguay,"uz":Uzbekistan,
    "vu":Vanuatu,"ve":Venezuela,"vn":Vietnam,"ye":Yemen,"zm":Zambia,"zw":Zimbabue, "cu":Cuba, "so":Somalia}

    #dato = str(pais_data)
    #datos = {'todo':dat}
    #valor = id
    no_alumnos = Alumno.objects.all().count()
    no_cursos = Curso.objects.all().count()
    no_instructores = Instructor.objects.all().count()
    #Permite obtener los ultimos 4 registros de la tabla
    transaccion = Transacciones.objects.order_by('-id_transaccion').all()[:4]

    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)

    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    request.session.set_expiry(request.session.get_expiry_age())

    #admin = Administrador.objects.filter(id_admin=valor)
    contexto = {'pais_data':pais_data, 'no_alumnos':no_alumnos,
    'no_cursos':no_cursos, 'no_instructores':no_instructores, 'transacciones':transaccion,
    'usuarios':usuario, 'datosPagina':datoPagina}

    return render(request, 'Admin/administrador_index.html', contexto)


@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def mostrar_agregar_curso(request):

    request.session.set_expiry(request.session.get_expiry_age())

    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)

    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    categoria = CursoCategoria.objects.all()

    todaynoti = date.today()

    fecha = str(todaynoti)

    contexto = {'categorias':categoria, 'usuarios':usuario, 'datosPagina':datoPagina, 'fecha':fecha}

    return render(request, 'Admin/Extras/Curso/agregar_curso.html', contexto)



@csrf_exempt
@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def agregar_curso(request):

    request.session.set_expiry(request.session.get_expiry_age())

    if request.method == "POST":

        nombreCurso = request.POST["nombreCurso"]
        fechaInicio = request.POST["fechaInicio"]
        fechaCierre = request.POST["fechaCierre"]
        nominalum = request.POST["nomin"]
        nomaxalum = request.POST["nomax"]
        precioG = request.POST["precio"]
        tipo = request.POST["tipo"]
        descrip = request.POST["descripcion"]
        try:
            imagen = request.FILES["imagencurso"]
        except Exception as e:
            imagen = ""

        video = request.POST["video"]

        duracion = request.POST["tiempo"]
        duraciontipo = request.POST["tipotiempo"]

        categoriauno = request.POST["categoria1"]
        categoriados = request.POST["categoria2"]
        categoriatres = request.POST["categoria3"]
        categoriacuatro = request.POST["categoria4"]
        categoriacinco = request.POST["categoria5"]

        aprendizajeS = request.POST["aprendizaje"]
        temarioS = request.POST["temario"]
        recursosS = request.POST["recursos"]
        requisistosS = request.POST["requisitos"]
        tareasS = request.POST["tareas"]
        leccionesS = request.POST["lecciones"]
        horasvideoS = request.POST["horasvideo"]
        tipohorarioS = request.POST["tipohorario"]
        try:
            horarioS = request.POST["horario"]
        except Exception as e:
            horarioS = ""

        if imagen:

            nombreimagen = secure_filename(imagen.name)

            #fs = FileSystemStorage(location='ProyectoKaizen/static/media/Imagenes/Cursos')
            fs = FileSystemStorage(location= os.path.join(settings.MEDIA_ROOT+'/Imagenes/Cursos'))
            filenam = fs.save(nombreimagen, imagen)

        else:

            nombreimagen = "CursoPrede.jpg"


        opcion = ElementosPagina.objects.get(id_elementoPagina=1)
        apro = opcion.aprobacion_cursos

        if apro == 1:
            c = Curso(nombreC = nombreCurso, fecha_inicio = fechaInicio,
            fecha_cierre = fechaCierre, no_minimo_alumnos = nominalum,
            no_maximo_alumnos = nomaxalum, precio = precioG, tipo_Curso=tipo, statusC=1,
            ruta_imagen=nombreimagen, descripcion_curso=descrip, video_muestra=video, duracion_curso_numero=duracion,
            duracion_curso_tipo=duraciontipo, veces_vendido=0, valoracion=0, aprobado=0, es_libre=0, url_inorganico="", url_sensei="",
            aprendizaje=aprendizajeS, temario=temarioS, recursos=recursosS, requisitos=requisistosS, no_lecciones=leccionesS, tareas_actividades=tareasS,
            no_horas_video=horasvideoS, tipo_horario=tipohorarioS, horario=horarioS)
            c.save()
        else:
            c = Curso(nombreC = nombreCurso, fecha_inicio = fechaInicio,
            fecha_cierre = fechaCierre, no_minimo_alumnos = nominalum,
            no_maximo_alumnos = nomaxalum, precio = precioG, tipo_Curso=tipo, statusC=1,
            ruta_imagen=nombreimagen, descripcion_curso=descrip, video_muestra=video, duracion_curso_numero=duracion,
            duracion_curso_tipo=duraciontipo, veces_vendido=0, valoracion=0, aprobado=1, es_libre=0, url_inorganico="", url_sensei="",
            aprendizaje=aprendizajeS, temario=temarioS, recursos=recursosS, requisitos=requisistosS, no_lecciones=leccionesS, tareas_actividades=tareasS,
            no_horas_video=horasvideoS, tipo_horario=tipohorarioS, horario=horarioS)
            c.save()

        cur = Curso.objects.get(nombreC = nombreCurso, fecha_inicio = fechaInicio,
        fecha_cierre = fechaCierre, no_minimo_alumnos = nominalum,
        no_maximo_alumnos = nomaxalum, precio = precioG, tipo_Curso=tipo)

        id_curs = cur.id_curso
        nombrecurso = cur.nombreC

        urlinorganico = "http://seiko.global/curso-inorganico/?curso=" + str(id_curs) + "&curson=" + str(nombrecurso)
        urlsensei = "http://seiko.global/curso-sensei/?curso=" + str(id_curs) + "&curson=" + str(nombrecurso)

        cur.url_inorganico = urlinorganico
        cur.url_sensei = urlsensei
        cur.save()

        if categoriauno:

            rel = Cursos_Categorias(id_curso=id_curs, id_categoria=categoriauno)
            rel.save()

        if categoriados:

            rell = Cursos_Categorias(id_curso=id_curs, id_categoria=categoriados)
            rell.save()

        if categoriatres:

            relll = Cursos_Categorias(id_curso=id_curs, id_categoria=categoriatres)
            relll.save()

        if categoriacuatro:

            rellll = Cursos_Categorias(id_curso=id_curs, id_categoria=categoriacuatro)
            rellll.save()

        if categoriacinco:

            relllll = Cursos_Categorias(id_curso=id_curs, id_categoria=categoriacinco)
            relllll.save()


        texto = "Agrego el curso: "
        texto2 = ". Con este id: "
        detalle = texto + nombreCurso + texto2 + str(id_curs)
        fecha = datetime.now()
        id_adm = request.user.id_relacionado
        adminis = Administrador.objects.get(id_admin=id_adm)
        nombre_adminis = adminis.nombre

        l = LogAdmin(fecha_accion=fecha, id_admin_accion=id_adm,
        nombre_admin_accion=nombre_adminis, detalles_accion=detalle)
        l.save()

        return redirect('/cursos/')


@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def mostrar_editar_curso(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    valor = id
    curso = Curso.objects.filter(id_curso=valor)
    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)
    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    contexto = {'cursos':curso, 'usuarios':usuario, 'datosPagina':datoPagina}
    return render(request, 'Admin/Extras/Curso/editar_curso.html', contexto)




@csrf_exempt
@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def editar_curso(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    if request.method == "POST":

        nombreCurso = request.POST["nombreCurso"]
        fechaInicio = request.POST["fechaInicio"]
        fechaCierre = request.POST["fechaCierre"]
        nominalum = request.POST["nomin"]
        nomaxalum = request.POST["nomax"]
        precioG = request.POST["precio"]
        tipo = request.POST["tipo"]
        descrip = request.POST["descripcion"]
        try:
            imagen = request.FILES["imagencurso"]
        except Exception as e:
            imagen = ""

        video = request.POST["video"]
        duracionnum = request.POST["tiempo"]
        duraciontipo = request.POST["tipotiempo"]

        aprendizajeS = request.POST["aprendizaje"]
        temarioS = request.POST["temario"]
        recursosS = request.POST["recursos"]
        requisistosS = request.POST["requisitos"]
        tareasS = request.POST["tareas"]
        leccionesS = request.POST["lecciones"]
        horasvideoS = request.POST["horasvideo"]
        tipohorarioS = request.POST["tipohorario"]
        try:
            horarioS = request.POST["horario"]
        except Exception as e:
            horarioS = ""


        if imagen:
            nombreimagen = secure_filename(imagen.name)
        else:
            nombreimagen = ""

        valor = id

        c = Curso.objects.get(id_curso=valor)

        nombreimagenGurdada = c.ruta_imagen

        c.nombreC = nombreCurso
        c.fecha_inicio = fechaInicio
        c.fecha_cierre = fechaCierre
        c.no_minimo_alumnos = nominalum
        c.no_maximo_alumnos = nomaxalum
        c.precio = precioG
        c.tipo_Curso = tipo

        if nombreimagen == "":
            pass

        else:

            if os.path.exists(os.path.join(settings.MEDIA_ROOT+'/Imagenes/Cursos/' + nombreimagenGurdada)):

                os.remove(os.path.join(settings.MEDIA_ROOT+'/Imagenes/Cursos/' + nombreimagenGurdada))

            #fs = FileSystemStorage(location='ProyectoKaizen/static/media/Imagenes/Cursos')
            fs = FileSystemStorage(location= os.path.join(settings.MEDIA_ROOT+'/Imagenes/Cursos'))
            filenam = fs.save(nombreimagen, imagen)

            c.ruta_imagen = nombreimagen

        c.descripcion_curso = descrip
        c.video_muestra = video
        c.duracion_curso_numero = duracionnum
        c.duracion_curso_tipo = duraciontipo
        c.aprendizaje = aprendizajeS
        c.temario = temarioS
        c.recursos = recursosS
        c.requisitos = requisistosS
        c.tareas_actividades = tareasS
        c.no_lecciones = leccionesS
        c.no_horas_video = horasvideoS
        c.tipo_horario = tipohorarioS
        c.horario = horarioS
        c.save()

        texto = "Modifico el curso: "
        texto2 = ". Con este id: "
        detalle = texto + nombreCurso + texto2 + str(valor)
        fecha = datetime.now()
        id_adm = request.user.id_relacionado
        adminis = Administrador.objects.get(id_admin=id_adm)
        nombre_adminis = adminis.nombre

        l = LogAdmin(fecha_accion=fecha, id_admin_accion=id_adm,
        nombre_admin_accion=nombre_adminis, detalles_accion=detalle)
        l.save()

        #curso = Curso.objects.all()
        #contexto = {'cursos':curso}
        #return render(request, 'Admin/administrador_cursos.html', contexto)
        return redirect('/cursos/')



@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def eliminar_curso(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    valor = id
    c = Curso.objects.get(id_curso=valor)
    va = c.statusC
    if va == 1:
        c.statusC = 0
        c.save()

        texto = "Deshabilito el curso: "
        texto2 = ". Con este id: "
        nombre = c.nombreC
        detalle = texto + nombre + texto2 + str(valor)
        fecha = datetime.now()
        id_adm = request.user.id_relacionado
        adminis = Administrador.objects.get(id_admin=id_adm)
        nombre_adminis = adminis.nombre

        l = LogAdmin(fecha_accion=fecha, id_admin_accion=id_adm,
        nombre_admin_accion=nombre_adminis, detalles_accion=detalle)
        l.save()

    else:
        c.statusC = 1
        c.save()

        texto = "Rehabilito el curso: "
        texto2 = ". Con este id: "
        nombre = c.nombreC
        detalle = texto + nombre + texto2 + str(valor)
        fecha = datetime.now()
        id_adm = request.user.id_relacionado
        adminis = Administrador.objects.get(id_admin=id_adm)
        nombre_adminis = adminis.nombre

        l = LogAdmin(fecha_accion=fecha, id_admin_accion=id_adm,
        nombre_admin_accion=nombre_adminis, detalles_accion=detalle)
        l.save()

    #curso = Curso.objects.all()
    #contexto = {'cursos':curso}
    #return render(request, 'Admin/administrador_cursos.html', contexto)
    return redirect('/cursos/')



@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def aprobar_curso(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    valor = id
    c = Curso.objects.get(id_curso=valor)
    va = c.aprobado
    if va == 1:
        c.aprobado = 0
        c.save()

        texto = "Desaprobo el curso: "
        texto2 = ". Con este id: "
        nombre = c.nombreC
        detalle = texto + nombre + texto2 + str(valor)
        fecha = datetime.now()
        id_adm = request.user.id_relacionado
        adminis = Administrador.objects.get(id_admin=id_adm)
        nombre_adminis = adminis.nombre

        l = LogAdmin(fecha_accion=fecha, id_admin_accion=id_adm,
        nombre_admin_accion=nombre_adminis, detalles_accion=detalle)
        l.save()

    else:
        c.aprobado = 1
        c.save()

        texto = "Aprobo el curso: "
        texto2 = ". Con este id: "
        nombre = c.nombreC
        detalle = texto + nombre + texto2 + str(valor)
        fecha = datetime.now()
        id_adm = request.user.id_relacionado
        adminis = Administrador.objects.get(id_admin=id_adm)
        nombre_adminis = adminis.nombre

        l = LogAdmin(fecha_accion=fecha, id_admin_accion=id_adm,
        nombre_admin_accion=nombre_adminis, detalles_accion=detalle)
        l.save()

    #curso = Curso.objects.all()
    #contexto = {'cursos':curso}
    #return render(request, 'Admin/administrador_cursos.html', contexto)
    return redirect('/cursos/')



@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def mostrar_instructores(request):

    request.session.set_expiry(request.session.get_expiry_age())

    instructor = Instructor.objects.all()
    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)

    caliIns = EvaluacionServicioInstructor.objects.all()

    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)


    contexto = {'calisIns':caliIns, 'instructores':instructor, 'usuarios':usuario, 'datosPagina':datoPagina}
    return render(request, 'Admin/administrador_instructores.html', contexto)


@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def calificaciones_cursos_instructor(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    idinstructor = id

    filtro = CursoInstructor.objects.filter(id_instructorR=idinstructor).values('id_cursoR')
    curso = Curso.objects.filter(id_curso__in=filtro)
    instructor = Instructor.objects.filter(id_instructor=idinstructor)

    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)

    listacalificacion = []
    listaid = []

    filtro2 = CursoEstudiante.objects.filter(id_cursoR__in=filtro, id_instructorRC=idinstructor).values('id_estudianteR')

    evaluaciones = EvaluacionSEstudiante.objects.filter(tipo_evaluacion="Curso", id_evaluado__in=filtro, id_estudianteR__in=filtro2)

    for item in curso:

        id = item.id_curso
        cantidad = 0
        contador = 0

        for value in evaluaciones:

            id2 = value.id_evaluado

            if id == id2:

                cantidad = cantidad + value.resultadoE
                contador = contador + 1

        if contador == 0:
            total = 0
        else:
            total = cantidad/contador

        listacalificacion.append(total)
        dt = {'id':id, 'calificacion':total}
        listaid.append(dt)


    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    contexto = {'idinstructor':idinstructor,'listacalificacion':listacalificacion, 'listaid':listaid, 'instructores':instructor, 'cursos':curso, 'usuarios':usuario, 'datosPagina':datoPagina}
    return render(request, 'Admin/Extras/Instructor/calificacion_curso.html', contexto)


@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def detalles_calificacion(request, id, id2):

    idcurso = id
    idinstructor = id2

    request.session.set_expiry(request.session.get_expiry_age())

    filtro = CursoInstructor.objects.filter(id_instructorR=idinstructor).values('id_cursoR')

    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)

    filtro2 = CursoEstudiante.objects.filter(id_cursoR=idcurso, id_instructorRC=idinstructor).values('id_estudianteR')

    alumno = Alumno.objects.filter(id_alumno__in=filtro2)

    evaluacion = EvaluacionSEstudiante.objects.filter(tipo_evaluacion="Curso", id_evaluado=idcurso, id_estudianteR__in=filtro2)

    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    contexto = {'evaluaciones':evaluacion, 'alumnos':alumno, 'usuarios':usuario, 'datosPagina':datoPagina}
    return render(request, 'Admin/Extras/Instructor/detalles.html', contexto)


@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def mostrar_agregar_instructor(request):

    request.session.set_expiry(request.session.get_expiry_age())

    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)

    profesion = Profesiones.objects.all()

    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    pais = Pais.objects.all()

    contexto = {'paises':pais, 'profesiones':profesion, 'usuarios':usuario, 'datosPagina':datoPagina}

    return render(request, 'Admin/Extras/Instructor/agregar_instructor.html', contexto)


@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def mostrar_estado_admin(request, id):

    codigo = id

    codigo2 = codigo.split("_")

    codigopais = codigo2[0]

    estado = Ciudad.objects.filter(PaisCodigo=codigopais).values('CiudadDistrito').distinct()

    contexto = {'estados':estado, 'codigopais':codigopais}

    return render(request, 'Admin/Extras/Instructor/pais_ajax.html', contexto)



@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def mostrar_ciudad_admin(request, id, id2):

    nombreestado = id

    nombreestado2 = nombreestado.replace("_", " ")

    codigopais = id2

    ciudad = Ciudad.objects.filter(PaisCodigo=codigopais, CiudadDistrito=nombreestado2).values('CiudadNombre').distinct()

    contexto = {'ciudades':ciudad}

    return render(request, 'Admin/Extras/Instructor/estado_ajax.html', contexto)



@csrf_exempt
@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def agregar_instructor(request):

    request.session.set_expiry(request.session.get_expiry_age())

    if request.method == "POST":

        nombreIG = request.POST["nombreI"]
        apellidosIG = request.POST["apellidosI"]
        codigopostalIG = request.POST["cpI"]
        estadoIG = request.POST["estadoI"]
        ciudadIG = request.POST["ciudadI"]
        pais = request.POST["paisI"]
        estudiosIG = request.POST["estudiosI"]
        #profesionIG = request.POST["profesionI"]
        edadIG = request.POST["edadI"]
        celularIG = request.POST["celularI"]
        experienciaPG = request.POST["experienciaPI"]
        experienciaIG = request.POST["experienciaI"]
        socio_kaizenG = request.POST["socio"]
        correo = request.POST["correoI"]
        #contrasena = request.POST["contraI"]
        calleS = request.POST["calle"]
        numeroCS = request.POST["numerocasa"]
        coloniaS = request.POST["colonia"]

        direccionIG = str(calleS) + ", " + str(numeroCS) + ", " + str(coloniaS)

        profesionuno = request.POST["profesion1"]
        profesiondos = request.POST["profesion2"]
        profesiontres = request.POST["profesion3"]
        profesioncuatro = request.POST["profesion4"]
        profesioncinco = request.POST["profesion5"]

        pais2 = pais.split("_")
        paisIG = pais2[1]

        #Crear contraseña aleatoria
        chars = string.ascii_uppercase + string.digits
        size = 10

        contrasena= ''.join(random.choice(chars) for _ in range(size))

        contra = make_password(contrasena)

        #add = Instructor.objects.filter(correoI=correo)
        add = Usuarios.objects.filter(email=correo)

        if add:
            pass

        else:

            i = Instructor(nombreI=nombreIG, apellidosI=apellidosIG, direccionI=direccionIG,
            codigopostalI=codigopostalIG, estadoI=estadoIG, ciudadI=ciudadIG, paisI=paisIG,
            estudiosI=estudiosIG, profesionI="", edadI=edadIG, celularI=celularIG,
            experienciaP=experienciaPG, experienciaI=experienciaIG, socio_kaizen=socio_kaizenG,
            statusI=1, sexo_instructor="Otro", correoI=correo, ruta_imagen_perfil="avatar.png")
            i.save()

            ad = Instructor.objects.get(correoI=correo)
            idR = ad.id_instructor

            u = Usuarios(email=correo, password=contra, tipo_usuario=2,
            id_relacionado=idR, is_active=1)
            u.save()

            op = OpcionesInstructor(id_instructorR=idR, color_barra="#01A1DD", widget_clima=0, widget_juego_tetris=0, widget_juego_cartas=0, tipo_plantilla="_barra")
            op.save()

            if profesionuno:

                rel = RelacionProfesiones(id_profesionR=profesionuno, id_usuarioR=idR, tipo_usuarioR="Instructor")
                rel.save()

            if profesiondos:

                rell = RelacionProfesiones(id_profesionR=profesiondos, id_usuarioR=idR, tipo_usuarioR="Instructor")
                rell.save()

            if profesiontres:

                relll = RelacionProfesiones(id_profesionR=profesiontres, id_usuarioR=idR, tipo_usuarioR="Instructor")
                relll.save()

            if profesioncuatro:

                rellll = RelacionProfesiones(id_profesionR=profesioncuatro, id_usuarioR=idR, tipo_usuarioR="Instructor")
                rellll.save()

            if profesioncinco:

                relllll = RelacionProfesiones(id_profesionR=profesioncinco, id_usuarioR=idR, tipo_usuarioR="Instructor")
                relllll.save()


            #Enviar correo con la contraseña
            texto = 'Da clic en el siguiente enlace, https://seiko.global/iniciar_sesion/, e introduce la contraseña para activar tu cuenta. Contraseña:  ' + str(contrasena)

            html_version = 'Principal/email_general.html'

            html_message = render_to_string(html_version, { 'context': texto, })

            message = EmailMessage('Contraseña', html_message, 'hola@seiko.dev', [correo])
            message.content_subtype = 'html'
            message.send()

            texto = "Agrego al instructor: "
            texto2 = ". Con este id: "
            nombre = nombreIG + " " + apellidosIG
            detalle = texto + nombre + texto2 + str(idR)
            fecha = datetime.now()
            id_adm = request.user.id_relacionado
            adminis = Administrador.objects.get(id_admin=id_adm)
            nombre_adminis = adminis.nombre

            l = LogAdmin(fecha_accion=fecha, id_admin_accion=id_adm,
            nombre_admin_accion=nombre_adminis, detalles_accion=detalle)
            l.save()


        #instructor = Instructor.objects.all()
        #contexto = {'instructores':instructor}
        #return render(request, 'Admin/administrador_instructores.html', contexto)
        return redirect('/instructores/')



@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def mostrar_editar_instructor(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    valor = id
    instructor = Instructor.objects.filter(id_instructor=valor)
    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)
    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    pais = Pais.objects.all()

    for ins in instructor:

        nombrePai = ins.paisI
        nombreEsta = ins.estadoI

    for pai in pais:

        if pai.PaisNombre == nombrePai:

            codigoPai = pai.PaisCodigo

    estado = Ciudad.objects.filter(PaisCodigo=codigoPai).values('CiudadDistrito').distinct()

    ciudad = Ciudad.objects.filter(PaisCodigo=codigoPai, CiudadDistrito=nombreEsta).values('CiudadNombre').distinct()

    profesion = Profesiones.objects.all()

    profesionInstructor = RelacionProfesiones.objects.filter(id_usuarioR=valor, tipo_usuarioR="Instructor")

    profesion1 = 0
    profesion2 = 0
    profesion3 = 0
    profesion4 = 0
    profesion5 = 0

    for data in profesionInstructor:

        id = data.id_profesionR

        if profesion1 == 0:
            profesion1 = id

        elif profesion2 == 0:
            profesion2 = id

        elif profesion3 == 0:
            profesion3 = id

        elif profesion4 == 0:
            profesion4 = id

        elif profesion5 == 0:
            profesion5 == id


    contexto = {'codigopais':codigoPai, 'ciudades':ciudad, 'estados':estado, 'paises':pais, 'profesion1':profesion1, 'profesion2':profesion2, 'profesion3':profesion3, 'profesion4':profesion4, 'profesion5':profesion5, 'profesiones':profesion, 'instructores':instructor, 'usuarios':usuario, 'datosPagina':datoPagina}
    return render(request, 'Admin/Extras/Instructor/editar_instructor.html', contexto)


@csrf_exempt
@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def editar_instructor(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    if request.method == "POST":

        nombreIG = request.POST["nombreI"]
        apellidosIG = request.POST["apellidosI"]
        direccionIG = request.POST["direccionI"]
        codigopostalIG = request.POST["cpI"]
        estadoIG = request.POST["estadoI"]
        ciudadIG = request.POST["ciudadI"]
        pais = request.POST["paisI"]
        estudiosIG = request.POST["estudiosI"]
        #profesionIG = request.POST["profesionI"]
        edadIG = request.POST["edadI"]
        celularIG = request.POST["celularI"]
        experienciaPG = request.POST["experienciaPI"]
        experienciaIG = request.POST["experienciaI"]
        socio_kaizenG = request.POST["socio"]
        correo = request.POST["correoI"]
        contrasena = request.POST["contraI"]

        pais2 = pais.split("_")
        paisIG = pais2[1]


        if contrasena:
            contra = make_password(contrasena)
        else:
            contra = ""



        valor = id
        i = Instructor.objects.get(id_instructor=valor)
        nombreimagenGurdada = i.ruta_imagen_perfil
        i.nombreI = nombreIG
        i.apellidosI = apellidosIG
        i.direccionI = direccionIG
        i.codigopostalI = codigopostalIG
        i.estadoI = estadoIG
        i.ciudadI = ciudadIG
        i.paisI = paisIG
        i.estudiosI = estudiosIG
        #i.profesionI = profesionIG
        i.edadI = edadIG
        i.celularI = celularIG
        i.experienciaP = experienciaPG
        i.experienciaI = experienciaIG
        i.socio_kaizen = socio_kaizenG
        i.correoI = correo
        i.save()

        if contrasena:
            u = Usuarios.objects.get(id_relacionado=valor, tipo_usuario=2)
            u.password = contra
            u.save()

        texto = "Edito al instructor: "
        texto2 = ". Con este id: "
        nombre = nombreIG + " " + apellidosIG
        detalle = texto + nombre + texto2 + str(valor)
        fecha = datetime.now()
        id_adm = request.user.id_relacionado
        adminis = Administrador.objects.get(id_admin=id_adm)
        nombre_adminis = adminis.nombre

        l = LogAdmin(fecha_accion=fecha, id_admin_accion=id_adm,
        nombre_admin_accion=nombre_adminis, detalles_accion=detalle)
        l.save()

        #instructor = Instructor.objects.all()
        #contexto = {'instructores':instructor}
        #return render(request, 'Admin/administrador_instructores.html', contexto)
        return redirect('/instructores/')


@csrf_exempt
@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def eliminar_instructor(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    valor = id
    #id_usu = request.session['id_usuario']

    i = Instructor.objects.get(id_instructor=valor)
    va = i.statusI
    idd = i.id_instructor
    u = Usuarios.objects.get(id_relacionado=idd, tipo_usuario=2)
    if va == 1:
        i.statusI = 0
        i.save()
        u.is_active = 0
        u.save()

        texto = "Deshabilito al instructor: "
        texto2 = ". Con este id: "
        nombre = i.nombreI + " " + i.apellidosI
        detalle = texto + nombre + texto2 + str(valor)
        fecha = datetime.now()
        id_adm = request.user.id_relacionado
        adminis = Administrador.objects.get(id_admin=id_adm)
        nombre_adminis = adminis.nombre

        l = LogAdmin(fecha_accion=fecha, id_admin_accion=id_adm,
        nombre_admin_accion=nombre_adminis, detalles_accion=detalle)
        l.save()

    else:
        i.statusI = 1
        i.save()
        u.is_active = 1
        u.save()

        texto = "Rehabilito al instructor: "
        texto2 = ". Con este id: "
        nombre = i.nombreI + " " + i.apellidosI
        detalle = texto + nombre + texto2 + str(valor)
        fecha = datetime.now()
        id_adm = request.user.id_relacionado
        adminis = Administrador.objects.get(id_admin=id_adm)
        nombre_adminis = adminis.nombre

        l = LogAdmin(fecha_accion=fecha, id_admin_accion=id_adm,
        nombre_admin_accion=nombre_adminis, detalles_accion=detalle)
        l.save()


    #instructor = Instructor.objects.all()
    #contexto = {'instructores':instructor}
    #return render(request, 'Admin/admi_instructores.html', contexto)
    return redirect('/instructores/')



@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def mostrar_administradores(request):

    request.session.set_expiry(request.session.get_expiry_age())

    administrador = Administrador.objects.all()
    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)

    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    contexto = {'administradores':administrador, 'usuarios':usuario, 'datosPagina':datoPagina}
    return render(request, 'Admin/administrador_admin.html', contexto)


@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def mostrar_agregar_administrador(request):

    request.session.set_expiry(request.session.get_expiry_age())

    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)

    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    contexto = {'usuarios':usuario, 'datosPagina':datoPagina}

    return render(request, 'Admin/Extras/Administrador/agregar_admin.html', contexto)


@csrf_exempt
@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def agregar_administrador(request):

    request.session.set_expiry(request.session.get_expiry_age())

    if request.method == "POST":

        nombreAA = request.POST["nombreA"]
        usuarioAA = request.POST["usuarioA"]
        #contrasenaAA = request.POST["contraA"]

        chars = string.ascii_uppercase + string.digits
        size = 10

        contrasena = ''.join(random.choice(chars) for _ in range(size))

        contra = make_password(contrasena)

        #add = Administrador.objects.filter(correoA=usuarioAA)
        add = Usuarios.objects.filter(email=usuarioAA)

        if add:
            pass

        else:

            a = Administrador(nombre=nombreAA, statusA=1, correoA=usuarioAA, ruta_imagen_admin="avatar.png")
            a.save()

            ad = Administrador.objects.get(correoA=usuarioAA)
            idR = ad.id_admin

            u = Usuarios(email=usuarioAA, password=contra, tipo_usuario=1,
            id_relacionado=idR, is_active=1)
            u.save()

            #Enviar correo con la contraseña
            texto = 'Da clic en el siguiente enlace, https://seiko.global/iniciar_sesion/, e introduce la contraseña para activar tu cuenta. Contraseña:  ' + str(contrasena)

            html_version = 'Principal/email_general.html'

            html_message = render_to_string(html_version, { 'context': texto, })

            message = EmailMessage('Contraseña', html_message, 'hola@seiko.dev', [usuarioAA])
            message.content_subtype = 'html'
            message.send()

            texto = "Agrego al administrador: "
            texto2 = ". Con este id: "
            nombre = nombreAA
            detalle = texto + nombre + texto2 + str(idR)
            fecha = datetime.now()
            id_adm = request.user.id_relacionado
            adminis = Administrador.objects.get(id_admin=id_adm)
            nombre_adminis = adminis.nombre

            l = LogAdmin(fecha_accion=fecha, id_admin_accion=id_adm,
            nombre_admin_accion=nombre_adminis, detalles_accion=detalle)
            l.save()

        #administrador = Administrador.objects.all()
        #contexto = {'administradores':administrador}
        #return render(request, 'Admin/administrador_admin.html', contexto)
        return redirect('/administradores/')



@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def mostrar_editar_administrador(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    valor = id
    administrador = Administrador.objects.filter(id_admin=valor)
    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)
    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    contexto = {'administradores':administrador, 'usuarios':usuario, 'datosPagina':datoPagina}
    return render(request, 'Admin/Extras/Administrador/editar_admin.html', contexto)


@csrf_exempt
@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def editar_administrador(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    if request.method == "POST":

        nombreAA = request.POST["nombreA"]

        valor = id
        a = Administrador.objects.get(id_admin=valor)
        a.nombre = nombreAA
        a.save()

        texto = "Edito al administrador: "
        texto2 = ". Con este id: "
        nombre = nombreAA
        detalle = texto + nombre + texto2 + str(valor)
        fecha = datetime.now()
        id_adm = request.user.id_relacionado
        adminis = Administrador.objects.get(id_admin=id_adm)
        nombre_adminis = adminis.nombre

        l = LogAdmin(fecha_accion=fecha, id_admin_accion=id_adm,
        nombre_admin_accion=nombre_adminis, detalles_accion=detalle)
        l.save()

        #administrador = Administrador.objects.all()
        #contexto = {'administradores':administrador}
        #return render(request, 'Admin/administrador_admin.html', contexto)
        return redirect('/administradores/')


@csrf_exempt
@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def eliminar_administrador(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    valor = id
    #id_usu = request.session[0]

    a = Administrador.objects.get(id_admin=valor)
    va = a.statusA
    iid = a.id_admin
    u = Usuarios.objects.get(id_relacionado=iid, tipo_usuario=1)
    if va == 1:
        a.statusA = 0
        a.save()
        u.is_active = 0
        u.save()

        texto = "Deshabilito al administrador: "
        texto2 = ". Con este id: "
        nombre = a.nombre
        detalle = texto + nombre + texto2 + str(iid)
        fecha = datetime.now()
        id_adm = request.user.id_relacionado
        adminis = Administrador.objects.get(id_admin=id_adm)
        nombre_adminis = adminis.nombre

        l = LogAdmin(fecha_accion=fecha, id_admin_accion=id_adm,
        nombre_admin_accion=nombre_adminis, detalles_accion=detalle)
        l.save()

    else:
        a.statusA = 1
        a.save()
        u.is_active = 1
        u.save()

        texto = "Rehabilito al administrador: "
        texto2 = ". Con este id: "
        nombre = a.nombre
        detalle = texto + nombre + texto2 + str(iid)
        fecha = datetime.now()
        id_adm = request.user.id_relacionado
        adminis = Administrador.objects.get(id_admin=id_adm)
        nombre_adminis = adminis.nombre

        l = LogAdmin(fecha_accion=fecha, id_admin_accion=id_adm,
        nombre_admin_accion=nombre_adminis, detalles_accion=detalle)
        l.save()

    #administrador = Administrador.objects.all()
    #contexto = {'administradores':administrador}
    #return render(request, 'Admin/administrador_admin.html', contexto)
    return redirect('/administradores/')



@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def mostrar_evaluaciones(request):

    request.session.set_expiry(request.session.get_expiry_age())

    evaluacion = EvaluacionesServicio.objects.all()

    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)
    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    contexto = {'evaluaciones':evaluacion, 'usuarios':usuario, 'datosPagina':datoPagina}

    return render(request, 'Admin/administrador_evaluaciones.html', contexto)


@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def mostrar_agregar_evaluacion(request):

    request.session.set_expiry(request.session.get_expiry_age())

    idadmin = request.user.id_relacionado

    usuario = Administrador.objects.filter(id_admin=idadmin)

    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    contexto = {'usuarios':usuario, 'datosPagina':datoPagina}

    return render(request, 'Admin/Extras/Evaluaciones/agregar_evaluacion.html', contexto)



@csrf_exempt
@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def agregar_evaluacion(request):

    request.session.set_expiry(request.session.get_expiry_age())

    if request.method == "POST":

        categoriaG = request.POST["categoria"]

        fecha = date.today()

        e = EvaluacionesServicio(categoria=categoriaG, fecha_publicacion=fecha, statusES=1)
        e.save()

        texto = "Agrego una evaluacion de servicio"
        detalle = texto
        fecha = datetime.now()
        id_adm = request.user.id_relacionado
        adminis = Administrador.objects.get(id_admin=id_adm)
        nombre_adminis = adminis.nombre

        l = LogAdmin(fecha_accion=fecha, id_admin_accion=id_adm,
        nombre_admin_accion=nombre_adminis, detalles_accion=detalle)
        l.save()

        idadmin = request.user.id_relacionado
        usuario = Administrador.objects.filter(id_admin=idadmin)

        evaluacion = EvaluacionesServicio.objects.filter(categoria=categoriaG, fecha_publicacion=fecha)
        evas = EvaluacionesServicio.objects.get(categoria=categoriaG, fecha_publicacion=fecha)
        idevaluacion = evas.id_evalucionServicio

        pregunta = PreguntasEvaluacionServicio.objects.filter(id_EvaluacionServicioR=idevaluacion)

        datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

        contexto = {'evaluaciones':evaluacion, 'usuarios':usuario, 'preguntas':pregunta, 'datosPagina':datoPagina}

        return render(request, 'Admin/Extras/Evaluaciones/agregar_preguntas.html', contexto)



@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def mostrar_editar_pregunta_evaluacion(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    idpregunta = id

    pregunta = PreguntasEvaluacionServicio.objects.filter(id_PreguntaEvaluacionServicio=idpregunta)

    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    contexto = {'preguntas':pregunta, 'datosPagina':datoPagina}

    return render(request, 'Admin/Extras/Evaluaciones/editar_pregunta.html', contexto)



@csrf_exempt
@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def editar_pregunta_evaluacion(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    if request.method == "POST":

        preguntaG = request.POST["pregunta"]

        idpregunta = id

        idadmin = request.user.id_relacionado

        p = PreguntasEvaluacionServicio.objects.get(id_PreguntaEvaluacionServicio=idpregunta)
        idevaluacion = p.id_EvaluacionServicioR
        p.pregunta = preguntaG
        p.save()


        pregunta = PreguntasEvaluacionServicio.objects.filter(id_EvaluacionServicioR=idevaluacion)

        evaluacion = EvaluacionesServicio.objects.filter(id_evalucionServicio=idevaluacion)

        usuario = Administrador.objects.filter(id_admin=idadmin)

        datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

        contexto = {'preguntas':pregunta, 'evaluaciones':evaluacion, 'usuarios':usuario, 'datosPagina':datoPagina}

        return render(request, 'Admin/Extras/Evaluaciones/agregar_preguntas.html', contexto)



@csrf_exempt
@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def agregar_pregunta_evaluacion(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    if request.method == "POST":

        preguntaG = request.POST["pregunta"]

        idevaluacion = id

        idadmin = request.user.id_relacionado

        p = PreguntasEvaluacionServicio(id_EvaluacionServicioR=idevaluacion, pregunta=preguntaG)
        p.save()

        pregunta = PreguntasEvaluacionServicio.objects.filter(id_EvaluacionServicioR=idevaluacion)

        evaluacion = EvaluacionesServicio.objects.filter(id_evalucionServicio=idevaluacion)

        usuario = Administrador.objects.filter(id_admin=idadmin)

        datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

        contexto = {'preguntas':pregunta, 'evaluaciones':evaluacion, 'usuarios':usuario, 'datosPagina':datoPagina}

        return render(request, 'Admin/Extras/Evaluaciones/agregar_preguntas.html', contexto)



@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def mostrar_agregar_evaluado(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    idevaluacion = id
    idadmin = request.user.id_relacionado
    evas = EvaluacionesServicio.objects.get(id_evalucionServicio=idevaluacion)
    tipo = evas.categoria

    if tipo == "Curso":

        evaluacion = EvaluacionesServicio.objects.filter(id_evalucionServicio=idevaluacion)
        curso = Curso.objects.all()
        usuario = Administrador.objects.filter(id_admin=idadmin)

        datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

        contexto = {'evaluaciones':evaluacion, 'cursos':curso, 'usuarios':usuario, 'datosPagina':datoPagina}

        return render(request, 'Admin/Extras/Evaluaciones/asignar_evaluado.html', contexto)

    elif tipo == "Instructor":

        evaluacion = EvaluacionesServicio.objects.filter(id_evalucionServicio=idevaluacion)
        instructor = Instructor.objects.all()
        usuario = Administrador.objects.filter(id_admin=idadmin)
        datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

        contexto = {'evaluaciones':evaluacion, 'instructores':instructor, 'usuarios':usuario, 'datosPagina':datoPagina}

        return render(request, 'Admin/Extras/Evaluaciones/asignar_evaluado_instructor.html', contexto)

    else:

        evaluacion = EvaluacionesServicio.objects.filter(id_evalucionServicio=idevaluacion)
        usuario = Administrador.objects.filter(id_admin=idadmin)
        datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

        contexto = {'evaluaciones':evaluacion, 'usuarios':usuario, 'datosPagina':datoPagina}

        return render(request, 'Admin/Extras/Evaluaciones/asignar_evaluado_otro.html', contexto)


@csrf_exempt
@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def agregar_evaluado(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    if request.method == "POST":

        evaluado = request.POST["curso"]
        evaluadoGG = evaluado.split(sep=',')

        idevaluacion = id

        idcurso = int(evaluadoGG[0])
        nombrecurso = evaluadoGG[1]

        evc = EvaluacionServicioCurso(id_EvaluacionServicioR=idevaluacion,
        id_cursoR=idcurso, nombre_cursoEva=nombrecurso, calificacion=0)
        evc.save()

        texto = "Agrego un curso. "
        texto2 = "A la evaluacion con este id: "
        detalle = texto + texto2 + str(idevaluacion)
        fecha = datetime.now()
        id_adm = request.user.id_relacionado
        adminis = Administrador.objects.get(id_admin=id_adm)
        nombre_adminis = adminis.nombre

        l = LogAdmin(fecha_accion=fecha, id_admin_accion=id_adm,
        nombre_admin_accion=nombre_adminis, detalles_accion=detalle)
        l.save()

        #evaluacion = EvaluacionesServicio.objects.all()
        #contexto = {'evaluaciones':evaluacion}
        #return render(request, 'Admin/evaluacion_servicio.html', contexto)
        return redirect('/evaluaciones/')


@csrf_exempt
@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def agregar_evaluado_instructor(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    if request.method == "POST":

        evaluado = request.POST["instructor"]
        evaluadoGG = evaluado.split(sep=',')

        idevaluacion = id

        idinstructor = int(evaluadoGG[0])
        nombreinstructor = evaluadoGG[1]

        evc = EvaluacionServicioInstructor(id_EvaluacionServicioR=idevaluacion,
        id_instructorR=idinstructor, nombre_instructorEva=nombreinstructor, calificacion=0)
        evc.save()

        texto = "Agrego un instructor. "
        texto2 = "A la evaluacion con este id: "
        detalle = texto + texto2 + str(idevaluacion)
        fecha = datetime.now()
        id_adm = request.user.id_relacionado
        adminis = Administrador.objects.get(id_admin=id_adm)
        nombre_adminis = adminis.nombre

        l = LogAdmin(fecha_accion=fecha, id_admin_accion=id_adm,
        nombre_admin_accion=nombre_adminis, detalles_accion=detalle)
        l.save()

        #evaluacion = EvaluacionesServicio.objects.all()
        #contexto = {'evaluaciones':evaluacion}
        #return render(request, 'Admin/evaluacion_servicio.html', contexto)
        return redirect('/evaluaciones/')



@csrf_exempt
@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def agregar_evaluado_otro(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    if request.method == "POST":

        evaluado = request.POST["servicio"]

        idevaluacion = id

        evc = EvaluacionServicioOtro(id_EvaluacionServicioR=idevaluacion,
        nombre_otroEva=evaluado, calificacion=0)
        evc.save()

        texto = "Agrego un servicio. "
        texto2 = "A la evaluacion con este id: "
        detalle = texto + texto2 + str(idevaluacion)
        fecha = datetime.now()
        id_adm = request.user.id_relacionado
        adminis = Administrador.objects.get(id_admin=id_adm)
        nombre_adminis = adminis.nombre

        l = LogAdmin(fecha_accion=fecha, id_admin_accion=id_adm,
        nombre_admin_accion=nombre_adminis, detalles_accion=detalle)
        l.save()

        #evaluacion = EvaluacionesServicio.objects.all()
        #contexto = {'evaluaciones':evaluacion}
        #return render(request, 'Admin/evaluacion_servicio.html', contexto)
        return redirect('/evaluaciones/')


#Posiblemente Borrar
@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def mostrar_asignar_evaluacion(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    valor = id
    evaluacion = EvaluacionesServicio.objects.filter(id_evalucionServicio=valor)
    contexto = {'evaluaciones':evaluacion}
    return render(request, 'Admin/Modals/asignar_evaluacion.html', contexto)


#Posiblemente Borrar
@csrf_exempt
@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def asignar_evaluacion(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    if request.method == "POST":

        valor = id
        e = EvaluacionesServicio.objects.get(id_evalucionServicio=valor)
        tipo = e.categoria


        if tipo == "Curso":

            id_Curso = e.id_cursoEva
            relacionEC = CursoEstudiante.objects.filter(id_cursoR=id_Curso)

            if relacionEC:

                for relacion in relacionEC:

                    estu = relacion.id_estudianteR
                    es = EvaluacionSEstudiante(id_evalucionServicioR=valor, id_estudianteR=estu, respuestas="", resultadoE=0)
                    es.save()

            else:

                pass


        elif tipo == "Instructor":

            id_Instructor = e.id_instructorEva
            relacionCI = CursoInstructor.objects.filter(id_instructorR=id_Instructor)

            if relacionCI:

                for relaciones in relacionCI:

                    relacionECR = CursoEstudiante.objects.filter(id_cursoR=relaciones[id_cursoR])

                    if relacionECR:

                        for relacions in relacionECR:

                            estu = relacions.id_estudianteR
                            es = EvaluacionSEstudiante(id_evalucionServicioR=valor, id_estudianteR=estu, respuestas="", resultadoE=0)
                            es.save()

                    else:

                        pass

            else:

                pass

        elif tipo == "Otra":

            alumnos = Alumno.objects.all()

            if alumnos:

                for alumno in alumnos:

                    id = alumno.id_alumno
                    es = EvaluacionSEstudiante(id_evalucionServicioR=valor, id_estudianteR=id, respuestas="", resultadoE=0)
                    es.save()



        texto = "Asigno la evaluacion. "
        texto2 = "Con este id: "
        detalle = texto + texto2 + str(valor)
        fecha = datetime.now()
        id_adm = request.user.id_relacionado
        adminis = Administrador.objects.get(id_admin=id_adm)
        nombre_adminis = adminis.nombre

        l = LogAdmin(fecha_accion=fecha, id_admin_accion=id_adm,
        nombre_admin_accion=nombre_adminis, detalles_accion=detalle)
        l.save()

        evaluacion = EvaluacionesServicio.objects.all()
        contexto = {'evaluaciones':evaluacion}
        return render(request, 'Admin/evaluacion_servicio.html', contexto)




@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def mostrar_coniguraciones(request):

    request.session.set_expiry(request.session.get_expiry_age())

    empresa = PaginasActivas.objects.all()
    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)
    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    contexto = {'empresas':empresa, 'usuarios':usuario, 'datosPagina':datoPagina}
    return render(request, 'Admin/administrador_configuraciones.html', contexto)



@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def mostrar_agregar_pagina(request):

    request.session.set_expiry(request.session.get_expiry_age())

    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)
    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    contexto = {'usuarios':usuario, 'datosPagina':datoPagina}

    return render(request, 'Admin/Extras/Configuraciones/agregar_pagina.html', contexto)



@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def mostrar_configurar_pagina(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    valor = id

    empresa = PaginasActivas.objects.filter(id_paginaActiva=valor)
    valor = ElementosPagina.objects.filter(id_paginaActivaR=valor)

    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)
    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)


    contexto = {'empresas':empresa, 'valores': valor, 'usuarios':usuario, 'datosPagina':datoPagina}
    return render(request, 'Admin/Extras/Configuraciones/configurar_pagina.html', contexto)


@csrf_exempt
@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def agregar_pagina(request):

    request.session.set_expiry(request.session.get_expiry_age())

    if request.method == "POST":

        nombreEE = request.POST["nombreE"]
        imagenlogoG = request.FILES["imagenlogo"]
        imagenportadaG = request.FILES["imagenportada"]

        nombreimagenlogo = secure_filename(imagenlogoG.name)

        #fs = FileSystemStorage(location='ProyectoKaizen/static/media/Imagenes/Empresas')
        fs = FileSystemStorage(location= os.path.join(settings.MEDIA_ROOT+'/Imagenes/Empresas'))
        filenam = fs.save(nombreimagenlogo, imagenlogoG)

        nombreimagenportada = secure_filename(imagenportadaG.name)

        #fs = FileSystemStorage(location='ProyectoKaizen/static/media/Imagenes/Empresas')
        fs = FileSystemStorage(location= os.path.join(settings.MEDIA_ROOT+'/Imagenes/Empresas'))
        filenam = fs.save(nombreimagenportada, imagenportadaG)


        nombrecompleto = ""
        nombrecompleto2 = ""

        separar = nombreEE.split(sep=' ')

        for sep in separar:

            nombrecompleto = nombrecompleto + sep

        nombr = nombrecompleto.lower()
        nombress = nombr.split(sep='.')

        for sepp in nombress:

            nombrecompleto2 = nombrecompleto2 + sepp

        nombrebd = "pagina"+nombrecompleto2
        id = ""


        p = PaginasActivas(nombre_empresa=nombreEE, nombre_bd=nombrebd, statusPA=1,
        ruta_logo=nombreimagenlogo, ruta_portada=nombreimagenportada)
        p.save()

        empre = PaginasActivas.objects.filter(nombre_empresa=nombreEE)

        for em in empre:

            id = em.id_paginaActiva

        e = ElementosPagina(id_paginaActivaR=id, formato_hora="12", videoconferencias=0, crear_examenes=0, actividades=0, evaluaciones_servicio=0)
        e.save()

        texto = "Agrego la empresa: "
        texto2 = ". Con este id: "
        nombre = nombreEE
        detalle = texto + nombre + texto2 + str(id)
        fecha = datetime.now()
        id_adm = request.user.id_relacionado
        adminis = Administrador.objects.get(id_admin=id_adm)
        nombre_adminis = adminis.nombre

        l = LogAdmin(fecha_accion=fecha, id_admin_accion=id_adm,
        nombre_admin_accion=nombre_adminis, detalles_accion=detalle)
        l.save()

        #empresa = PaginasActivas.objects.all()
        #contexto = {'empresas':empresa}
        #return render(request, 'Admin/administrador_configuraciones.html', contexto)
        return redirect('/configuraciones/')



@csrf_exempt
@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def configurar_pagina(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    if request.method == "POST":

        horaG = request.POST["hora"]
        videoG = request.POST["video"]
        examenesG = request.POST["examenes"]
        actividadesG = request.POST["actividades"]
        evaluacionesG = request.POST["evaluaciones"]
        cursosinstructorG = request.POST["cursoinstructor"]
        cursoaprobacionG = request.POST["cursoaprobacion"]
        configuracionG = request.POST["configuracion"]
        cuponG = request.POST["cupon"]
        pagoG = request.POST["pago"]
        devolucionG = request.POST["devolucion"]
        blogG = request.POST["blog"]
        transmisionG = request.POST["transmision"]
        categoriaG = request.POST["categoria"]
        boletinG = request.POST["boletin"]
        porcentajeEmpre = request.POST["porcentajeempresa"]
        porcentajeInst = request.POST["porcentajeinstructor"]

        porcentajeEmpreInor = request.POST["porcentajeempresainorganico"]
        porcentajeInstInor = request.POST["porcentajeinstructorinorganico"]

        porcentajeEmpreSen = request.POST["porcentajeempresasensei"]
        porcentajeInstSen = request.POST["porcentajeinstructorsensei"]

        profesionG = request.POST["profesion"]
        alumnosG = request.POST["alumnos"]
        gruposG = request.POST["grupos"]
        escuelaG = request.POST["escuela"]

        tipoEmpresaG = request.POST["tipoEmpresa"]

        valor = id

        empre = PaginasActivas.objects.get(id_paginaActiva=valor)
        nombrebase = empre.nombre_bd

        connection = pymysql.connect(

            host="localhost",
            user="kaizenprueba",
            password="kaizen%T00R",
            #user="root",
            #password="toortoor",
            db=nombrebase
        )

        cursor = connection.cursor()

        sql="UPDATE kaizen_elementospagina SET formato_hora='"+ str(horaG) +"', videoconferencias="+ str(videoG) + ", crear_examenes=" + str(examenesG) + ", actividades=" + str(actividadesG) + ", evaluaciones_servicio=" + str(evaluacionesG) + ", agregar_curso_instructor=" + str(cursosinstructorG) + ", aprobacion_cursos=" + str(cursoaprobacionG) + ", configuraciones=" + str(configuracionG) + ", cupones=" + str(cuponG) + ", pagos=" + str(pagoG) + ", devoluciones=" + str(devolucionG) + ", blog=" +str(blogG)+ ", transmisiones=" + str(transmisionG) + ", porcentajeEmpresa=" + str(porcentajeEmpre) + ", porcentajeInstructor=" + str(porcentajeInst) + " WHERE id_elementoPagina=1"
        cursor.execute(sql)
        connection.commit()

        a = ElementosPagina.objects.get(id_paginaActivaR=valor)
        a.formato_hora = horaG
        a.videoconferencias = videoG
        a.crear_examenes = examenesG
        a.actividades = actividadesG
        a.evaluaciones_servicio = evaluacionesG
        a.agregar_curso_instructor = cursosinstructorG
        a.aprobacion_cursos = cursoaprobacionG
        a.configuraciones = configuracionG
        a.cupones = cuponG
        a.pagos = pagoG
        a.devoluciones = devolucionG
        a.blog = blogG
        a.transmisiones = transmisionG
        a.porcentajeEmpresa = porcentajeEmpre
        a.porcentajeInstructor = porcentajeInst
        a.categorias = categoriaG
        a.boletin = boletinG
        a.porcentajeEmpresaInorganico = porcentajeEmpreInor
        a.porcentajeInstructorInorganico = porcentajeInstInor
        a.porcentajeEmpresaSensei = porcentajeEmpreSen
        a.porcentajeInstructorSensei = porcentajeInstSen
        a.profesiones = profesionG
        a.agregar_alumnos = alumnosG
        a.grupos = gruposG
        a.tipo_institucion = escuelaG
        a.tipo_empresa = tipoEmpresaG
        a.save()

        empre = PaginasActivas.objects.get(id_paginaActiva=valor)

        texto = "Configuro la empresa: "
        texto2 = ". Con este id: "
        nombre = empre.nombre_empresa
        detalle = texto + nombre + texto2 + str(valor)
        fecha = datetime.now()
        id_adm = request.user.id_relacionado
        adminis = Administrador.objects.get(id_admin=id_adm)
        nombre_adminis = adminis.nombre

        l = LogAdmin(fecha_accion=fecha, id_admin_accion=id_adm,
        nombre_admin_accion=nombre_adminis, detalles_accion=detalle)
        l.save()

        #empresa = PaginasActivas.objects.all()
        #contexto = {'empresas':empresa}
        #return render(request, 'Admin/configuraciones_pagina.html', contexto)
        return redirect('/configuraciones/')



@csrf_exempt
@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def eliminar_pagina(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    valor = id
    a = PaginasActivas.objects.get(id_paginaActiva=valor)
    va = a.statusPA
    if va == 1:
        a.statusPA = 0
        a.save()

        texto = "Deshabilito la empresa: "
        texto2 = ". Con este id: "
        nombre = a.nombre_empresa
        detalle = texto + nombre + texto2 + str(valor)
        fecha = datetime.now()
        id_adm = request.user.id_relacionado
        adminis = Administrador.objects.get(id_admin=id_adm)
        nombre_adminis = adminis.nombre

        l = LogAdmin(fecha_accion=fecha, id_admin_accion=id_adm,
        nombre_admin_accion=nombre_adminis, detalles_accion=detalle)
        l.save()

    else:
        a.statusPA = 1
        a.save()

        texto = "Rehabilito la empresa: "
        texto2 = ". Con este id: "
        nombre = a.nombre_empresa
        detalle = texto + nombre + texto2 + str(valor)
        fecha = datetime.now()
        id_adm = request.user.id_relacionado
        adminis = Administrador.objects.get(id_admin=id_adm)
        nombre_adminis = adminis.nombre

        l = LogAdmin(fecha_accion=fecha, id_admin_accion=id_adm,
        nombre_admin_accion=nombre_adminis, detalles_accion=detalle)
        l.save()

    #b = ElementosPagina.objects.get(id_paginaActivaR=valor)
    #b.delete()

    #empresa = PaginasActivas.objects.all()
    #contexto = {'empresas':empresa}
    #return render(request, 'Admin/configuraciones_pagina.html', contexto)
    return redirect('/configuraciones/')



@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def bitacora(request):

    request.session.set_expiry(request.session.get_expiry_age())

    bitacorad = LogAdmin.objects.all()
    paginator = Paginator(bitacorad, 10)

    page_number = request.GET.get('page')
    bitacora = paginator.get_page(page_number)

    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)
    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    contexto = {'bitacoras':bitacora, 'usuarios':usuario, 'datosPagina':datoPagina}
    return render(request, 'Admin/administrador_bitacora.html', contexto)



@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def mostrar_actualizar_pagina(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    valor = id

    empresa = PaginasActivas.objects.filter(id_paginaActiva=valor)

    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)
    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    contexto = {'empresas':empresa, 'usuarios':usuario, 'datosPagina':datoPagina}

    return render(request, 'Admin/Extras/Configuraciones/crear_actualizacion.html', contexto)



@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def realizar_actualizacion(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    idempresa = id

    emp = PaginasActivas.objects.get(id_paginaActiva=idempresa)

    nombrebase = emp.nombre_bd

    usuario = "Desarrollo-at-029326455000"
    contra = "9VZuhMt4vjIAjWJO42czhaL9qGc3fjrI287DJkLw2Lc="

    ruta = "https://git-codecommit.us-east-2.amazonaws.com/v1/repos/kaizen-unlimited"

    respositorio = "https://" + usuario + ":" + contra + "@git-codecommit.us-east-2.amazonaws.com/v1/repos/kaizen-unlimited"

    #respositorio = "https://github.com/gitpython-developers/GitPython"

    #ruta_principal = str(ruta_completa) + "\\Respaldo"
    #print(ruta_principal)
    ruta_principal = settings.MEDIA_ROOT+'/Actualizaciones'


    #git.Repo.clone_from(respositorio, ruta_completa)
    git.Git(ruta_principal).clone(respositorio)

    print("Se clono la aplicacion")

    #editar settings

    texto = "\r\nDATABASES = {\r\n'default': {\r\n'ENGINE': 'django.db.backends.mysql',\r\n'NAME': '" + nombrebase + "',\r\n'USER': 'root',\r\n'PASSWORD': 'toortoor',\r\n'HOST': 'localhost',\r\n'PORT': '3306',\r\n}\r\n}"

    destFile = settings.MEDIA_ROOT+'/Actualizaciones/kaizen-unlimited/ProyectoKaizen/settings.py'

    archivo = open(destFile, 'a')

    archivo.write(texto)

    archivo.close()
    print("Se agrego texto al settings")

    #Hacemos las migraciones

    # Detectar Sistema Operativo
    if sys.platform == "win32":
        ruta = settings.MEDIA_ROOT+'/Actualizaciones/kaizen-unlimited'
        os.system(r"cd " + ruta +  " && python manage.py makemigrations & python manage.py migrate")
    else:
        ruta = settings.MEDIA_ROOT+'/Actualizaciones/kaizen-unlimited'
        os.system(r"cd " + ruta +  " && python3 manage.py makemigrations ; python3 manage.py migrate")

    print("Se realizaron las migraciones")

    #Borramos el setting

    os.remove(destFile)
    print("Se borro el archivo settings")

    #Comprimiendo archivos

    nombre = "Actualizacion-" + str(nombrebase) + ".zip"

    nombrezip = settings.MEDIA_ROOT+'/Actualizaciones/' + nombre
    nombrecarpeta = settings.MEDIA_ROOT+'/Actualizaciones/kaizen-unlimited'

    if os.path.exists(os.path.join(settings.MEDIA_ROOT+'/Actualizaciones/' + nombre)):

        os.remove(os.path.join(settings.MEDIA_ROOT+'/Actualizaciones/' + nombre))


    fantasy_zip = zipfile.ZipFile(nombrezip, 'w')

    for folder, subfolders, files in os.walk(nombrecarpeta):

        for file in files:

            fantasy_zip.write(os.path.join(folder, file), os.path.relpath(os.path.join(folder,file), nombrecarpeta), compress_type = zipfile.ZIP_DEFLATED)

    fantasy_zip.close()
    print("Se creo el archivo zip")

    #Guardamos en BD

    empre = PaginasActivas.objects.get(id_paginaActiva=idempresa)
    empre.ruta_actualizacion = nombre
    empre.save()


    #Borrar Respaldo
    rutaborrar = settings.MEDIA_ROOT+'/Actualizaciones/kaizen-unlimited'

    def remove_readonly(func, path, _):
        "Clear the readonly bit and reattempt the removal"
        os.chmod(path, stat.S_IWRITE)
        func(path)

    shutil.rmtree(rutaborrar, onerror=remove_readonly)

    print("Se borro el respaldo")

    print("Se realizo la actualizacion")

    return redirect('/configuraciones/')


@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def mostrar_crear_instalador(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    valor = id

    empresa = PaginasActivas.objects.filter(id_paginaActiva=valor)

    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)
    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    contexto = {'empresas':empresa, 'usuarios':usuario, 'datosPagina':datoPagina}

    return render(request, 'Admin/Extras/Configuraciones/crear_paquete.html', contexto)



@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def crear_paquete(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    idempresa = id

    emp = PaginasActivas.objects.get(id_paginaActiva=idempresa)

    nombrebase = emp.nombre_bd

    rutaprincipal = settings.MEDIA_ROOT+'/Instaladores/Base'

    #Crear nueva ruta
    rutacrear = settings.MEDIA_ROOT+'/Instaladores/' + str(nombrebase)

    shutil.copytree(rutaprincipal, rutacrear)
    print("Se copearon los elementos")


    #editar settings

    texto = "\r\nDATABASES = {\r\n'default': {\r\n'ENGINE': 'django.db.backends.mysql',\r\n'NAME': '" + nombrebase + "',\r\n'USER': 'root',\r\n'PASSWORD': 'toortoor',\r\n'HOST': 'localhost',\r\n'PORT': '3306',\r\n}\r\n}"

    destFile = settings.MEDIA_ROOT+'/Instaladores/' + nombrebase + "/ProyectoKaizen/settings.py"

    archivo = open(destFile, 'a')

    archivo.write(texto)

    archivo.close()
    print("Se agrego texto al settings")

    #Comprimiendo archivos

    nombre = "Instalador-" + str(nombrebase) + ".zip"

    nombrezip = settings.MEDIA_ROOT+'/Instaladores/' + nombre
    nombrecarpeta = settings.MEDIA_ROOT+'/Instaladores/' + nombrebase

    fantasy_zip = zipfile.ZipFile(nombrezip, 'w')

    for folder, subfolders, files in os.walk(nombrecarpeta):

        for file in files:

            fantasy_zip.write(os.path.join(folder, file), os.path.relpath(os.path.join(folder,file), nombrecarpeta), compress_type = zipfile.ZIP_DEFLATED)

    fantasy_zip.close()
    print("Se creo el archivo zip")


    #Borramos la carpeta creada para no consumir espacio
    shutil.rmtree(rutacrear)
    print("Se borro la carpeta")

    #Guardamos nombre zip en base de datos

    empre = PaginasActivas.objects.get(id_paginaActiva=idempresa)
    empre.ruta_instalador = nombre
    empre.save()


    #Editamos Scritp SQL y creamos la base de datos

    texto = "CREATE DATABASE " + nombrebase + ";\r\nUSE " + nombrebase + ";\r\n"

    archivo = settings.MEDIA_ROOT+'/BD/BD.sql'

    archivo2 = settings.MEDIA_ROOT+'/BD/' + nombrebase + '.sql'

    shutil.copy(archivo, archivo2)

    destFile = r'' + settings.MEDIA_ROOT+'/BD/' + nombrebase + '.sql'

    archivo2 = open(destFile, 'r+', encoding="utf8")

    contenido = archivo2.read()

    archivo2.seek(0, 0)

    archivo2.write(texto + contenido)

    archivo2.close()

    print("Se creo el sql y se modifico")

    #Crear base de datos

    usuario = "kaizenprueba"
    contra = "kaizen%T00R"
    basedatos = "\\" + str(nombrebase)

    #Windows
    #os.system(r"cd C:\xampp\mysql\bin\ && mysql -u " + str(usuario) + " -p" + str(contra) + " < C:\\Users\\Nes\\Desktop\\Proyecto Kaizen\\BD" + basedatos + ".sql")

    #Linux
    os.system(r"mysql -u " + str(usuario) +" -p" + str(contra) + " < /var/www/html/cursos-kaizen/kaizen-unlimited/ProyectoKaizen/static/media/BD" + basedatos + ".sql")
    print("Se genero la base de datos")

    archivoeliminar = settings.MEDIA_ROOT+'/BD/' + nombrebase + '.sql'
    os.remove(archivoeliminar)
    #os.path.join()
    print("Se elimino la base de datos creada")

    return redirect('/configuraciones/')


@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def mostrar_asignar_curso(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    valor = id

    curso = Curso.objects.filter(id_curso=valor)
    instructor = Instructor.objects.all()

    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)
    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    contexto = {'cursos':curso, 'instructores':instructor, 'usuarios':usuario, 'datosPagina':datoPagina}
    return render(request, 'Admin/Extras/Curso/asignar_curso.html', contexto)


@csrf_exempt
@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def asignar_curso(request, id, id2):

    request.session.set_expiry(request.session.get_expiry_age())

    id_intruc = id2

    valor = id

    cins = CursoInstructor.objects.filter(id_cursoR=valor, id_instructorR=id_intruc)

    if cins:
        pass

    else:
        ci = CursoInstructor(id_cursoR=valor, id_instructorR=id_intruc)
        ci.save()

        cur = Curso.objects.get(id_curso=valor)
        ins = Instructor.objects.get(id_instructor=id_intruc)

        texto = "Asigno el curso: "
        texto2 = ". Con id: "
        texto3 = ". Al instructor: "
        texto4 = ". Con id: "
        nombre = cur.nombreC
        nombre2 = ins.nombreI + " " + ins.apellidosI
        detalle = texto + nombre + texto2 + str(valor) + texto3 + nombre2 + texto4 + str(id_intruc)
        fecha = datetime.now()
        id_adm = request.user.id_relacionado
        adminis = Administrador.objects.get(id_admin=id_adm)
        nombre_adminis = adminis.nombre

        l = LogAdmin(fecha_accion=fecha, id_admin_accion=id_adm,
        nombre_admin_accion=nombre_adminis, detalles_accion=detalle)
        l.save()

    #curso = Curso.objects.all()
    #contexto = {'cursos':curso}

    #return render(request, 'Admin/administrador_cursos.html', contexto)
    return redirect('/cursos/')



@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def estadisticas_administrador(request):

    request.session.set_expiry(request.session.get_expiry_age())

    #Datos Grafica sexo alumnos
    no_alumnos_mujeres = Alumno.objects.filter(sexo_alumno="Femenino").count()
    no_alumnos_hombres = Alumno.objects.filter(sexo_alumno="Masculino").count()
    no_alumnos_otros = Alumno.objects.filter(sexo_alumno="Otro").count()

    #Datos grafica sexo instructores
    no_instructores_mujeres = Instructor.objects.filter(sexo_instructor="Femenino").count()
    no_instructores_hombres = Instructor.objects.filter(sexo_instructor="Masculino").count()
    no_instructores_otros = Instructor.objects.filter(sexo_instructor="Otro").count()

    #Datos grafica edades alumnos
    rango017A = Alumno.objects.filter(edadA__range=[0,17]).count()
    rango1825A = Alumno.objects.filter(edadA__range=[18,25]).count()
    rango2635A = Alumno.objects.filter(edadA__range=[26,35]).count()
    rango3645A = Alumno.objects.filter(edadA__range=[36,45]).count()
    rango4655A = Alumno.objects.filter(edadA__range=[46,55]).count()
    rango5665A = Alumno.objects.filter(edadA__range=[56,65]).count()
    rango66masA = Alumno.objects.filter(edadA__range=[66,100]).count()

    #Datos grafica edades instructores
    rango017I = Instructor.objects.filter(edadI__range=[0,17]).count()
    rango1825I = Instructor.objects.filter(edadI__range=[18,25]).count()
    rango2635I = Instructor.objects.filter(edadI__range=[26,35]).count()
    rango3645I = Instructor.objects.filter(edadI__range=[36,45]).count()
    rango4655I = Instructor.objects.filter(edadI__range=[46,55]).count()
    rango5665I = Instructor.objects.filter(edadI__range=[56,65]).count()
    rango66masI = Instructor.objects.filter(edadI__range=[66,100]).count()

    #Datos ingresos al ano
    anoactual = date.today().year
    mesactual = date.today().month

    totalene = 0
    totalfeb = 0
    totalmar = 0
    totalabr = 0
    totalmay = 0
    totaljun = 0
    totaljul = 0
    totalago = 0
    totalsep = 0
    totaloct = 0
    totalnov = 0
    totaldic = 0


    ene = Transacciones.objects.filter(fecha_transaccion__month=1, fecha_transaccion__year=date.today().year)
    feb = Transacciones.objects.filter(fecha_transaccion__month=2, fecha_transaccion__year=date.today().year)
    mar = Transacciones.objects.filter(fecha_transaccion__month=3, fecha_transaccion__year=date.today().year)
    abr = Transacciones.objects.filter(fecha_transaccion__month=4, fecha_transaccion__year=date.today().year)
    may = Transacciones.objects.filter(fecha_transaccion__month=5, fecha_transaccion__year=date.today().year)
    jun = Transacciones.objects.filter(fecha_transaccion__month=6, fecha_transaccion__year=date.today().year)
    jul = Transacciones.objects.filter(fecha_transaccion__month=7, fecha_transaccion__year=date.today().year)
    ago = Transacciones.objects.filter(fecha_transaccion__month=8, fecha_transaccion__year=date.today().year)
    sep = Transacciones.objects.filter(fecha_transaccion__month=9, fecha_transaccion__year=date.today().year)
    oct = Transacciones.objects.filter(fecha_transaccion__month=10, fecha_transaccion__year=date.today().year)
    nov = Transacciones.objects.filter(fecha_transaccion__month=11, fecha_transaccion__year=date.today().year)
    dic = Transacciones.objects.filter(fecha_transaccion__month=12, fecha_transaccion__year=date.today().year)

    for dato in ene:

        cantidad = int(dato.precio_curso)
        totalene = totalene + cantidad

    for dato in feb:

        cantidad = int(dato.precio_curso)
        totalfeb = totalfeb + cantidad

    for dato in mar:

        cantidad = int(dato.precio_curso)
        totalmar = totalmar + cantidad

    for dato in abr:

        cantidad = int(dato.precio_curso)
        totalabr = totalabr + cantidad

    for dato in may:

        cantidad = int(dato.precio_curso)
        totalmay = totalmay + cantidad

    for dato in jun:

        cantidad = int(dato.precio_curso)
        totaljun = totaljun + cantidad

    for dato in jul:

        cantidad = int(dato.precio_curso)
        totaljul = totaljul + cantidad

    for dato in ago:

        cantidad = int(dato.precio_curso)
        totalago = totalago + cantidad

    for dato in sep:

        cantidad = int(dato.precio_curso)
        totalsep = totalsep + cantidad

    for dato in oct:

        cantidad = int(dato.precio_curso)
        totaloct = totaloct + cantidad

    for dato in nov:

        cantidad = int(dato.precio_curso)
        totalnov = totalnov + cantidad

    for dato in dic:

        cantidad = int(dato.precio_curso)
        totaldic = totaldic + cantidad


    #Datos insgresos del mes
    uno = 0
    dos = 0
    tres = 0
    cuatro = 0
    cinco = 0
    seis = 0
    siete = 0
    ocho = 0
    nueve = 0
    diez = 0
    once = 0
    doce = 0
    trece = 0
    catorce = 0
    quince = 0
    diesiseis= 0
    diesisiete = 0
    diesiocho = 0
    diesinueve = 0
    veinte = 0
    veintiuno = 0
    veintidos = 0
    veintitres = 0
    veinticuatro = 0
    veinticinco = 0
    veintiseis = 0
    veintisiete = 0
    veintiocho = 0
    veintinueve = 0
    treinta = 0
    treintaiuno = 0



    doce_1 = Transacciones.objects.filter(fecha_transaccion__month=date.today().month, fecha_transaccion__year=date.today().year, fecha_transaccion__day=1)
    doce_2 = Transacciones.objects.filter(fecha_transaccion__month=date.today().month, fecha_transaccion__year=date.today().year, fecha_transaccion__day=2)
    doce_3 = Transacciones.objects.filter(fecha_transaccion__month=date.today().month, fecha_transaccion__year=date.today().year, fecha_transaccion__day=3)
    doce_4 = Transacciones.objects.filter(fecha_transaccion__month=date.today().month, fecha_transaccion__year=date.today().year, fecha_transaccion__day=4)
    doce_5 = Transacciones.objects.filter(fecha_transaccion__month=date.today().month, fecha_transaccion__year=date.today().year, fecha_transaccion__day=5)
    doce_6 = Transacciones.objects.filter(fecha_transaccion__month=date.today().month, fecha_transaccion__year=date.today().year, fecha_transaccion__day=6)
    doce_7 = Transacciones.objects.filter(fecha_transaccion__month=date.today().month, fecha_transaccion__year=date.today().year, fecha_transaccion__day=7)
    doce_8 = Transacciones.objects.filter(fecha_transaccion__month=date.today().month, fecha_transaccion__year=date.today().year, fecha_transaccion__day=8)
    doce_9 = Transacciones.objects.filter(fecha_transaccion__month=date.today().month, fecha_transaccion__year=date.today().year, fecha_transaccion__day=9)
    doce_10 = Transacciones.objects.filter(fecha_transaccion__month=date.today().month, fecha_transaccion__year=date.today().year, fecha_transaccion__day=10)
    doce_11 = Transacciones.objects.filter(fecha_transaccion__month=date.today().month, fecha_transaccion__year=date.today().year, fecha_transaccion__day=11)
    doce_12 = Transacciones.objects.filter(fecha_transaccion__month=date.today().month, fecha_transaccion__year=date.today().year, fecha_transaccion__day=12)
    doce_13 = Transacciones.objects.filter(fecha_transaccion__month=date.today().month, fecha_transaccion__year=date.today().year, fecha_transaccion__day=13)
    doce_14 = Transacciones.objects.filter(fecha_transaccion__month=date.today().month, fecha_transaccion__year=date.today().year, fecha_transaccion__day=14)
    doce_15 = Transacciones.objects.filter(fecha_transaccion__month=date.today().month, fecha_transaccion__year=date.today().year, fecha_transaccion__day=15)
    doce_16 = Transacciones.objects.filter(fecha_transaccion__month=date.today().month, fecha_transaccion__year=date.today().year, fecha_transaccion__day=16)
    doce_17 = Transacciones.objects.filter(fecha_transaccion__month=date.today().month, fecha_transaccion__year=date.today().year, fecha_transaccion__day=17)
    doce_18 = Transacciones.objects.filter(fecha_transaccion__month=date.today().month, fecha_transaccion__year=date.today().year, fecha_transaccion__day=18)
    doce_19 = Transacciones.objects.filter(fecha_transaccion__month=date.today().month, fecha_transaccion__year=date.today().year, fecha_transaccion__day=19)
    doce_20 = Transacciones.objects.filter(fecha_transaccion__month=date.today().month, fecha_transaccion__year=date.today().year, fecha_transaccion__day=20)
    doce_21 = Transacciones.objects.filter(fecha_transaccion__month=date.today().month, fecha_transaccion__year=date.today().year, fecha_transaccion__day=21)
    doce_22 = Transacciones.objects.filter(fecha_transaccion__month=date.today().month, fecha_transaccion__year=date.today().year, fecha_transaccion__day=22)
    doce_23 = Transacciones.objects.filter(fecha_transaccion__month=date.today().month, fecha_transaccion__year=date.today().year, fecha_transaccion__day=23)
    doce_24 = Transacciones.objects.filter(fecha_transaccion__month=date.today().month, fecha_transaccion__year=date.today().year, fecha_transaccion__day=24)
    doce_25 = Transacciones.objects.filter(fecha_transaccion__month=date.today().month, fecha_transaccion__year=date.today().year, fecha_transaccion__day=25)
    doce_26 = Transacciones.objects.filter(fecha_transaccion__month=date.today().month, fecha_transaccion__year=date.today().year, fecha_transaccion__day=26)
    doce_27 = Transacciones.objects.filter(fecha_transaccion__month=date.today().month, fecha_transaccion__year=date.today().year, fecha_transaccion__day=27)
    doce_28 = Transacciones.objects.filter(fecha_transaccion__month=date.today().month, fecha_transaccion__year=date.today().year, fecha_transaccion__day=28)
    doce_29 = Transacciones.objects.filter(fecha_transaccion__month=date.today().month, fecha_transaccion__year=date.today().year, fecha_transaccion__day=29)
    doce_30 = Transacciones.objects.filter(fecha_transaccion__month=date.today().month, fecha_transaccion__year=date.today().year, fecha_transaccion__day=30)
    doce_31 = Transacciones.objects.filter(fecha_transaccion__month=date.today().month, fecha_transaccion__year=date.today().year, fecha_transaccion__day=31)

    for dato in doce_1:

        valor2 = int(dato.precio_curso)
        uno = uno + valor2

    for dato in doce_2:

        valor2 = int(dato.precio_curso)
        dos = dos + valor2

    for dato in doce_3:

        valor2 = int(dato.precio_curso)
        tres = tres + valor2

    for dato in doce_4:

        valor2 = int(dato.precio_curso)
        cuatro = cuatro + valor2

    for dato in doce_5:

        valor2 = int(dato.precio_curso)
        cinco = cinco + valor2

    for dato in doce_6:

        valor2 = int(dato.precio_curso)
        seis = seis + valor2

    for dato in doce_7:

        valor2 = int(dato.precio_curso)
        siete = siete + valor2

    for dato in doce_8:

        valor2 = int(dato.precio_curso)
        ocho = ocho + valor2

    for dato in doce_9:

        valor2 = int(dato.precio_curso)
        nueve = nueve + valor2

    for dato in doce_10:

        valor2 = int(dato.precio_curso)
        diez = diez + valor2

    for dato in doce_11:

        valor2 = int(dato.precio_curso)
        once = once + valor2

    for dato in doce_12:

        valor2 = int(dato.precio_curso)
        doce = doce + valor2

    for dato in doce_13:

        valor2 = int(dato.precio_curso)
        trece = trece + valor2

    for dato in doce_14:

        valor2 = int(dato.precio_curso)
        catorce = catorce + valor2

    for dato in doce_15:

        valor2 = int(dato.precio_curso)
        quince = quince + valor2

    for dato in doce_16:

        valor2 = int(dato.precio_curso)
        diesiseis = diesiseis + valor2

    for dato in doce_17:

        valor2 = int(dato.precio_curso)
        diesisiete = diesisiete + valor2

    for dato in doce_18:

        valor2 = int(dato.precio_curso)
        diesiocho = diesiocho + valor2

    for dato in doce_19:

        valor2 = int(dato.precio_curso)
        diesinueve = diesinueve + valor2

    for dato in doce_20:

        valor2 = int(dato.precio_curso)
        veinte = veinte + valor2


    for dato in doce_21:

        valor2 = int(dato.precio_curso)
        veintiuno = veintiuno + valor2

    for dato in doce_22:

        valor2 = int(dato.precio_curso)
        veintidos = veintidos + valor2

    for dato in doce_23:

        valor2 = int(dato.precio_curso)
        veintitres = veintitres + valor2

    for dato in doce_24:

        valor2 = int(dato.precio_curso)
        veinticuatro = veinticuatro + valor2

    for dato in doce_25:

        valor2 = int(dato.precio_curso)
        veinticinco = veinticinco + valor2

    for dato in doce_26:

        valor2 = int(dato.precio_curso)
        veintiseis = veintiseis + valor2

    for dato in doce_27:

        valor2 = int(dato.precio_curso)
        veintisiete = veintisiete + valor2

    for dato in doce_28:

        valor2 = int(dato.precio_curso)
        veintiocho = veintiocho + valor2

    for dato in doce_29:

        valor2 = int(dato.precio_curso)
        veintinueve = veintinueve + valor2

    for dato in doce_30:

        valor2 = int(dato.precio_curso)
        treinta = treinta + valor2

    for dato in doce_31:

        valor2 = int(dato.precio_curso)
        treintaiuno = treintaiuno + valor2


    #Datos Cursos Cerrados Abiertos
    cursosactivos = Curso.objects.filter(statusC=1).count()
    cursosnoactivos = Curso.objects.filter(statusC=0).count()


    #Datos Cursos Linea
    cursoslinea = Curso.objects.filter(tipo_Curso="Linea").count()
    cursospresencial = Curso.objects.filter(tipo_Curso="Presencial").count()
    cursossemipresencial = Curso.objects.filter(tipo_Curso="Semipresencial").count()

    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)
    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    contexto = {'no_alumnos_mujeres':no_alumnos_mujeres, 'no_alumnos_hombres':no_alumnos_hombres,
    'no_instructores_mujeres':no_instructores_mujeres, 'no_instructores_hombres':no_instructores_hombres,
    'rango017A':rango017A, 'rango1825A':rango1825A, 'rango2635A':rango2635A, 'rango3645A':rango3645A,
    'rango4655A':rango4655A, 'rango5665A':rango5665A, 'rango66masA':rango66masA,
    'rango017I':rango017I, 'rango1825I':rango1825I, 'rango2635I':rango2635I, 'rango3645I':rango3645I,
    'rango4655I':rango4655I, 'rango5665I':rango5665I, 'rango66masI':rango66masI, 'anoactual':anoactual,
    'mesactual':mesactual, 'totalene':totalene, 'totalfeb':totalfeb, 'totalmar':totalmar, 'totalabr':totalabr,
    'totalmay':totalmay, 'totaljun':totaljun, 'totaljul':totaljul, 'totalago':totalago, 'totalsep':totalsep,
    'totaloct':totaloct, 'totalnov':totalnov, 'totaldic':totaldic, 'uno':uno, 'dos':dos, 'tres':tres, 'cuatro':cuatro,
    'cinco':cinco, 'seis':seis, 'siete':siete, 'ocho':ocho, 'nueve':nueve, 'diez':diez, 'once':once, 'doce':doce, 'trece':trece,
    'catorce':catorce, 'quince':quince, 'diesiseis':diesiseis, 'diesisiete':diesisiete, 'diesiocho':diesiocho, 'diesinueve':diesinueve,
    'veinte':veinte, 'veintiuno':veintiuno, 'veintidos':veintidos, 'veintitres':veintitres, 'veinticuatro':veinticuatro, 'veinticinco':veinticinco,
    'veintiseis':veintiseis, 'veintisiete':veintisiete, 'veintiocho':veintiocho, 'veintinueve':veintinueve, 'treinta':treinta, 'treintaiuno':treintaiuno,
    'cursosactivos':cursosactivos, 'cursosnoactivos':cursosnoactivos, 'cursoslinea':cursoslinea, 'cursospresencial':cursospresencial, 'cursossemipresencial':cursossemipresencial,
    'no_alumnos_otros':no_alumnos_otros, 'no_instructores_otros':no_instructores_otros, 'usuarios':usuario, 'datosPagina':datoPagina}

    return render(request, 'Admin/Extras/General/estadisticas.html', contexto)



@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def estadisticas_dinamicas_alumnos(request):

    request.session.set_expiry(request.session.get_expiry_age())

    alumno = Alumno.objects.all()

    totalalumnos = Alumno.objects.all().count()
    totalsexo = Alumno.objects.all().count()
    totalpais = Alumno.objects.all().count()
    totaledad = Alumno.objects.all().count()

    sexoT = "Ambos"
    paisT = "Todos"
    edadT = "Todos"

    pais = Alumno.objects.all().values('paisA').distinct()

    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)
    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    contexto = {'alumnos':alumno, 'totalalumnos':totalalumnos, 'totalsexo':totalsexo,
    'totalpais':totalpais, 'totaledad':totaledad, 'sexoT':sexoT, 'paisT':paisT, 'edadT':edadT,
    'paises':pais, 'usuarios':usuario, 'datosPagina':datoPagina}

    return render(request, 'Admin/Extras/General/estadisticas_alumnos.html', contexto)


@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def estadisticas_dinamicas_alumnos_reload_ajax(request, id, id2, id3, id4):

    request.session.set_expiry(request.session.get_expiry_age())

    sexo = id
    pais = id2
    edadinicio = int(id3)
    edadfinal = int(id4)

    if sexo == "Todos" and pais == "Todos":

        alumno = Alumno.objects.filter(edadA__range=[edadinicio, edadfinal])

        totalsexo = Alumno.objects.filter(edadA__range=[edadinicio, edadfinal]).count()
        totalpais = Alumno.objects.filter(edadA__range=[edadinicio, edadfinal]).count()
        totaledad = Alumno.objects.filter(edadA__range=[edadinicio, edadfinal]).count()

        sexoT = "Todos"
        paisT = "Todos"
        edadT = "De " + str(edadinicio) + " a " + str(edadfinal)

    elif sexo == "Todos" and pais != "Todos":

        alumno = Alumno.objects.filter(edadA__range=[edadinicio, edadfinal], paisA=pais)

        totalsexo = Alumno.objects.filter(edadA__range=[edadinicio, edadfinal], paisA=pais).count()
        totalpais = Alumno.objects.filter(edadA__range=[edadinicio, edadfinal], paisA=pais).count()
        totaledad = Alumno.objects.filter(edadA__range=[edadinicio, edadfinal], paisA=pais).count()

        sexoT = "Todos"
        paisT = pais
        edadT = "De " + str(edadinicio) + " a " + str(edadfinal)

    elif sexo != "Todos" and pais == "Todos":

        alumno = Alumno.objects.filter(edadA__range=[edadinicio, edadfinal], sexo_alumno=sexo)

        totalsexo = Alumno.objects.filter(edadA__range=[edadinicio, edadfinal], sexo_alumno=sexo).count()
        totalpais = Alumno.objects.filter(edadA__range=[edadinicio, edadfinal], sexo_alumno=sexo).count()
        totaledad = Alumno.objects.filter(edadA__range=[edadinicio, edadfinal], sexo_alumno=sexo).count()

        sexoT = sexo
        paisT = "Todos"
        edadT = "De " + str(edadinicio) + " a " + str(edadfinal)

    elif sexo != "Todos" and pais != "Todos":

        alumno = Alumno.objects.filter(edadA__range=[edadinicio, edadfinal], sexo_alumno=sexo, paisA=pais)

        totalsexo = Alumno.objects.filter(edadA__range=[edadinicio, edadfinal], sexo_alumno=sexo, paisA=pais).count()
        totalpais = Alumno.objects.filter(edadA__range=[edadinicio, edadfinal], sexo_alumno=sexo, paisA=pais).count()
        totaledad = Alumno.objects.filter(edadA__range=[edadinicio, edadfinal], sexo_alumno=sexo, paisA=pais).count()

        sexoT = sexo
        paisT = pais
        edadT = "De " + str(edadinicio) + " a " + str(edadfinal)



    pais = Alumno.objects.all().values('paisA').distinct()
    totalalumnos = Alumno.objects.all().count()

    contexto = {'alumnos':alumno, 'totalalumnos':totalalumnos, 'totalsexo':totalsexo,
    'totalpais':totalpais, 'totaledad':totaledad, 'sexoT':sexoT, 'paisT':paisT, 'edadT':edadT,
    'paises':pais}

    return render(request, 'Admin/Extras/General/estadisticas_alumno_ajax.html', contexto)



@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def estadisticas_dinamicas_transacciones(request):

    request.session.set_expiry(request.session.get_expiry_age())

    transaccion = Transacciones.objects.all()

    totaltransacciones = Transacciones.objects.all().count()

    curso = Curso.objects.all()

    pais = Alumno.objects.all().values('paisA').distinct()

    cadena = ""

    hoy = str(date.today())

    gananciasI = 0
    gananciasK = 0
    ganaciasG = 0
    totalDevoluciones = 0
    totalVSDevoluciones = 0

    for transa in transaccion:

        fecha = str(transa.fecha_transaccion)
        total = transa.total_venta
        gi = transa.total_instructor
        gk = transa.total_kaizen
        gg = transa.total_venta
        devo = transa.devolucion

        totalVSDevoluciones = totalVSDevoluciones + gg

        if devo == 1:

            totalDevoluciones = totalDevoluciones + gg

        else:

            gananciasI = gananciasI + gi
            gananciasK = gananciasK + gk

            ganaciasG = ganaciasG + gg

        fechaconvertida = datetime.strptime(fecha, "%Y-%m-%d").strftime("%m/%d/%Y")

        unir = str(fechaconvertida) + "," + str(total) + "\n"

        cadena = cadena + unir



    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)
    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    contexto = {'transacciones':transaccion, 'cadena':cadena, 'hoy':hoy, 'cursos':curso,
    'paises':pais, 'totaltransacciones':totaltransacciones, 'gananciasI':gananciasI,
    'gananciasK':gananciasK,'ganaciasG':ganaciasG,'totalDevoluciones':totalDevoluciones,
    'totalVSDevoluciones':totalVSDevoluciones, 'usuarios':usuario, 'datosPagina':datoPagina}

    return render(request, 'Admin/Extras/General/estadisticas_transacciones.html', contexto)


@csrf_exempt
@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def estadisticas_dinamicas_transacciones_reload(request):

    request.session.set_expiry(request.session.get_expiry_age())

    if request.method == "POST":

        fechainicio = request.POST["fechainicio"] #T
        fechafin = request.POST["fechafin"]#T
        tipopago = request.POST["pago"]#T
        valorinicio = request.POST["costoinicio"]#T
        valorfinal = request.POST["costofinal"]#T

        pais = request.POST["pais"]#A
        sexo = request.POST["sexo"]#A
        edadinicio = request.POST["edadinicio"]#A
        edadfinal = request.POST["edadfinal"]#A

        curso = request.POST["curso"]#C
        fechainicioC = request.POST["fechainicioC"]#C
        fechafinC = request.POST["fechafinC"]#C
        tiempoinicio = request.POST["duracioninicio"]#C
        tiempofinal = request.POST["duracionfinal"]#C
        tipotiempoC = request.POST["tipotiempo"]#C
        ventasinicio = request.POST["ventasinicio"]#C
        ventasfinal = request.POST["ventasfinal"]#C
        valoracioninicio = request.POST["valoracioninicio"]#C
        valoracionfinal = request.POST["valoracionfinal"]#C
        compartida = request.POST["compartida"]#C

        hoy = str(date.today())

        #Filtro Alumnos
        if pais == "Todos" and sexo == "Todos":

            filtroalumnos = Alumno.objects.filter(edadA__range=[edadinicio, edadfinal]).values('id_alumno')

        elif pais == "Todos" and sexo != "Todos":

            filtroalumnos = Alumno.objects.filter(edadA__range=[edadinicio, edadfinal], sexo_alumno=sexo).values('id_alumno')

        elif pais != "Todos" and sexo == "Todos":

            filtroalumnos = Alumno.objects.filter(edadA__range=[edadinicio, edadfinal], paisA=pais).values('id_alumno')

        elif pais != "Todos" and sexo != "Todos":

            filtroalumnos = Alumno.objects.filter(edadA__range=[edadinicio, edadfinal], paisA=pais, sexo_alumno=sexo).values('id_alumno')

        #Fin filtro alumnos

        #Filtro para Cursos

            #Filtro Compartir
        if compartida == "Todos":

            filtrocompartir = Curso.objects.all().values('id_curso')

        else:

            filtrocompartir = CompartirCurso.objects.filter(plataforma_compartio=compartida).values('id_cursoR')

            #Termina filtro Compartir


        if curso == "Todos" and tipotiempoC == "Todos":

            filtrocurso = Curso.objects.filter(id_curso__in=filtrocompartir, fecha_registro__range=[fechainicioC, fechafinC], veces_vendido__range=[ventasinicio, ventasfinal], valoracion__range=[valoracioninicio, valoracionfinal]).values('id_curso')

        elif curso != "Todos" and tipotiempoC == "Todos":

            filtrocurso = Curso.objects.filter(id_curso__in=filtrocompartir, id_curso=curso, fecha_registro__range=[fechainicioC, fechafinC], veces_vendido__range=[ventasinicio, ventasfinal], valoracion__range=[valoracioninicio, valoracionfinal]).values('id_curso')

        elif curso == "Todos" and tipotiempoC != "Todos":

            filtrocurso = Curso.objects.filter(id_curso__in=filtrocompartir, fecha_registro__range=[fechainicioC, fechafinC], veces_vendido__range=[ventasinicio, ventasfinal], valoracion__range=[valoracioninicio, valoracionfinal], duracion_curso_numero__range=[tiempoinicio, tiempofinal], duracion_curso_tipo=tipotiempoC).values('id_curso')

        elif curso != "Todos" and tipotiempoC != "Todos":

            filtrocurso = Curso.objects.filter(id_curso__in=filtrocompartir, id_curso=curso, fecha_registro__range=[fechainicioC, fechafinC], veces_vendido__range=[ventasinicio, ventasfinal], valoracion__range=[valoracioninicio, valoracionfinal], duracion_curso_numero__range=[tiempoinicio, tiempofinal], duracion_curso_tipo=tipotiempoC).values('id_curso')


        #Termina filtro cursos


        #Inicia Consulta de transacciones

        if tipopago == "Todos":

            transaccion = Transacciones.objects.filter(id_curso_comprado__in=filtrocurso, id_alumno_compro__in=filtroalumnos, fecha_transaccion__range=[fechainicio, fechafin], total_venta__range=[valorinicio, valorfinal])
            totaltransacciones = Transacciones.objects.filter(id_curso_comprado__in=filtrocurso, id_alumno_compro__in=filtroalumnos, fecha_transaccion__range=[fechainicio, fechafin], total_venta__range=[valorinicio, valorfinal]).count()

        else:

            transaccion = Transacciones.objects.filter(id_curso_comprado__in=filtrocurso, id_alumno_compro__in=filtroalumnos, fecha_transaccion__range=[fechainicio, fechafin], total_venta__range=[valorinicio, valorfinal], tipo_pago=tipopago)
            totaltransacciones = Transacciones.objects.filter(id_curso_comprado__in=filtrocurso, id_alumno_compro__in=filtroalumnos, fecha_transaccion__range=[fechainicio, fechafin], total_venta__range=[valorinicio, valorfinal], tipo_pago=tipopago).count()



        cadena = ""
        gananciasI = 0
        gananciasK = 0
        ganaciasG = 0
        totalDevoluciones = 0
        totalVSDevoluciones = 0

        for transa in transaccion:

            fecha = str(transa.fecha_transaccion)
            total = transa.total_venta
            gi = transa.total_instructor
            gk = transa.total_kaizen
            gg = transa.total_venta
            devo = transa.devolucion

            totalVSDevoluciones = totalVSDevoluciones + gg

            if devo == 1:

                totalDevoluciones = totalDevoluciones + gg

            else:

                gananciasI = gananciasI + gi
                gananciasK = gananciasK + gk

                ganaciasG = ganaciasG + gg

            fechaconvertida = datetime.strptime(fecha, "%Y-%m-%d").strftime("%m/%d/%Y")

            unir = str(fechaconvertida) + "," + str(total) + "\n"

            cadena = cadena + unir


        cursof = Curso.objects.all()

        paisf = Alumno.objects.all().values('paisA').distinct()

        idadmin = request.user.id_relacionado
        usuario = Administrador.objects.filter(id_admin=idadmin)

        contexto = {'transacciones':transaccion, 'cadena':cadena, 'hoy':hoy, 'cursos':cursof,
        'paises':paisf, 'totaltransacciones':totaltransacciones,
        'fechainicio':fechainicio, 'fechafin':fechafin, 'tipopago':tipopago,
        'valorinicio':valorinicio, 'valorfinal':valorfinal, 'paisss':pais,
        'sexo':sexo, 'edadinicio':edadinicio, 'edadfinal':edadfinal,
        'cursoss':curso, 'fechainicioC':fechainicioC, 'fechafinC':fechafinC,
        'tiempoinicio':tiempoinicio, 'tiempofinal':tiempofinal, 'tipotiempoC':tipotiempoC,
        'ventasinicio':ventasinicio, 'ventasfinal':ventasfinal, 'valoracioninicio':valoracioninicio,
        'valoracionfinal':valoracionfinal, 'compartida':compartida, 'gananciasI':gananciasI,
        'gananciasK':gananciasK,'ganaciasG':ganaciasG,'totalDevoluciones':totalDevoluciones,
        'totalVSDevoluciones':totalVSDevoluciones, 'usuarios':usuario}

        return render(request, 'Admin/Extras/General/estadisticas_transacciones_reload.html', contexto)



@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def estadisticas_dinamicas_transacciones_reload_ajax(request, id, id2, id3, id4, id5, id6, id7, id8, id9, id10, id11, id12, id13, id14, id15, id16, id17, id18, id19, id20, id21):

    request.session.set_expiry(request.session.get_expiry_age())

    fechainicio = id #T
    fechafin = id2#T
    tipopago = id3#T
    valorinicio = int(id4)#T
    valorfinal = int(id5)#T
    tipoventa = id21#T

    pais = id6#A
    sexo = id7#A
    edadinicio = int(id8)#A
    edadfinal = int(id9)#A

    curso = id10#C
    fechainicioC = id11#C
    fechafinC = id12#C
    tiempoinicio = int(id13)#C
    tiempofinal = int(id14)#C
    tipotiempoC = id15#C
    ventasinicio = int(id16)#C
    ventasfinal = int(id17)#C
    valoracioninicio = int(id18)#C
    valoracionfinal = int(id19)#C
    compartida = id20#C

    hoy = str(date.today())

    #Filtro Alumnos
    if pais == "Todos" and sexo == "Todos":

        filtroalumnos = Alumno.objects.filter(edadA__range=[edadinicio, edadfinal]).values('id_alumno')

    elif pais == "Todos" and sexo != "Todos":

        filtroalumnos = Alumno.objects.filter(edadA__range=[edadinicio, edadfinal], sexo_alumno=sexo).values('id_alumno')

    elif pais != "Todos" and sexo == "Todos":

        filtroalumnos = Alumno.objects.filter(edadA__range=[edadinicio, edadfinal], paisA=pais).values('id_alumno')

    elif pais != "Todos" and sexo != "Todos":

        filtroalumnos = Alumno.objects.filter(edadA__range=[edadinicio, edadfinal], paisA=pais, sexo_alumno=sexo).values('id_alumno')

    #Fin filtro alumnos

    #Filtro para Cursos

        #Filtro Compartir
    if compartida == "Todos":

        filtrocompartir = Curso.objects.all().values('id_curso')

    else:

        filtrocompartir = CompartirCurso.objects.filter(plataforma_compartio=compartida).values('id_cursoR')

        #Termina filtro Compartir


    if curso == "Todos" and tipotiempoC == "Todos":

        filtrocurso = Curso.objects.filter(id_curso__in=filtrocompartir, fecha_registro__range=[fechainicioC, fechafinC], veces_vendido__range=[ventasinicio, ventasfinal], valoracion__range=[valoracioninicio, valoracionfinal]).values('id_curso')

    elif curso != "Todos" and tipotiempoC == "Todos":

        filtrocurso = Curso.objects.filter(id_curso__in=filtrocompartir, id_curso=curso, fecha_registro__range=[fechainicioC, fechafinC], veces_vendido__range=[ventasinicio, ventasfinal], valoracion__range=[valoracioninicio, valoracionfinal]).values('id_curso')

    elif curso == "Todos" and tipotiempoC != "Todos":

        filtrocurso = Curso.objects.filter(id_curso__in=filtrocompartir, fecha_registro__range=[fechainicioC, fechafinC], veces_vendido__range=[ventasinicio, ventasfinal], valoracion__range=[valoracioninicio, valoracionfinal], duracion_curso_numero__range=[tiempoinicio, tiempofinal], duracion_curso_tipo=tipotiempoC).values('id_curso')

    elif curso != "Todos" and tipotiempoC != "Todos":

        filtrocurso = Curso.objects.filter(id_curso__in=filtrocompartir, id_curso=curso, fecha_registro__range=[fechainicioC, fechafinC], veces_vendido__range=[ventasinicio, ventasfinal], valoracion__range=[valoracioninicio, valoracionfinal], duracion_curso_numero__range=[tiempoinicio, tiempofinal], duracion_curso_tipo=tipotiempoC).values('id_curso')


    #Termina filtro cursos


    #Inicia Consulta de transacciones

    if tipopago == "Todos" and tipoventa == "Todos":

        transaccion = Transacciones.objects.filter(id_curso_comprado__in=filtrocurso, id_alumno_compro__in=filtroalumnos, fecha_transaccion__range=[fechainicio, fechafin], total_venta__range=[valorinicio, valorfinal])
        totaltransacciones = Transacciones.objects.filter(id_curso_comprado__in=filtrocurso, id_alumno_compro__in=filtroalumnos, fecha_transaccion__range=[fechainicio, fechafin], total_venta__range=[valorinicio, valorfinal]).count()

    elif tipopago != "Todos" and tipoventa == "Todos":

        transaccion = Transacciones.objects.filter(id_curso_comprado__in=filtrocurso, id_alumno_compro__in=filtroalumnos, fecha_transaccion__range=[fechainicio, fechafin], total_venta__range=[valorinicio, valorfinal], tipo_pago=tipopago)
        totaltransacciones = Transacciones.objects.filter(id_curso_comprado__in=filtrocurso, id_alumno_compro__in=filtroalumnos, fecha_transaccion__range=[fechainicio, fechafin], total_venta__range=[valorinicio, valorfinal], tipo_pago=tipopago).count()

    elif tipopago == "Todos" and tipoventa != "Todos":

        transaccion = Transacciones.objects.filter(id_curso_comprado__in=filtrocurso, id_alumno_compro__in=filtroalumnos, fecha_transaccion__range=[fechainicio, fechafin], total_venta__range=[valorinicio, valorfinal], tipo_venta=tipoventa)
        totaltransacciones = Transacciones.objects.filter(id_curso_comprado__in=filtrocurso, id_alumno_compro__in=filtroalumnos, fecha_transaccion__range=[fechainicio, fechafin], total_venta__range=[valorinicio, valorfinal], tipo_venta=tipoventa).count()

    elif tipopago != "Todos" and tipoventa != "Todos":

        transaccion = Transacciones.objects.filter(id_curso_comprado__in=filtrocurso, id_alumno_compro__in=filtroalumnos, fecha_transaccion__range=[fechainicio, fechafin], total_venta__range=[valorinicio, valorfinal], tipo_venta=tipoventa, tipo_pago=tipopago)
        totaltransacciones = Transacciones.objects.filter(id_curso_comprado__in=filtrocurso, id_alumno_compro__in=filtroalumnos, fecha_transaccion__range=[fechainicio, fechafin], total_venta__range=[valorinicio, valorfinal], tipo_venta=tipoventa, tipo_pago=tipopago).count()


    cadena = ""
    gananciasI = 0
    gananciasK = 0
    ganaciasG = 0
    totalDevoluciones = 0
    totalVSDevoluciones = 0

    for transa in transaccion:

        fecha = str(transa.fecha_transaccion)
        total = transa.total_venta
        gi = transa.total_instructor
        gk = transa.total_kaizen
        gg = transa.total_venta
        devo = transa.devolucion

        totalVSDevoluciones = totalVSDevoluciones + gg

        if devo == 1:

            totalDevoluciones = totalDevoluciones + gg

        else:

            gananciasI = gananciasI + gi
            gananciasK = gananciasK + gk

            ganaciasG = ganaciasG + gg

        fechaconvertida = datetime.strptime(fecha, "%Y-%m-%d").strftime("%m/%d/%Y")

        unir = str(fechaconvertida) + "," + str(total) + "\n"

        cadena = cadena + unir


    cursof = Curso.objects.all()

    paisf = Alumno.objects.all().values('paisA').distinct()

    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)

    contexto = {'transacciones':transaccion, 'cadena':cadena, 'totaltransacciones':totaltransacciones,
    'gananciasI':gananciasI,'gananciasK':gananciasK,'ganaciasG':ganaciasG,'totalDevoluciones':totalDevoluciones,
    'totalVSDevoluciones':totalVSDevoluciones}

    return render(request, 'Admin/Extras/General/estadisticas_transacciones_ajax.html', contexto)



@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def estadisticas_dinamicas_instructores(request):

    request.session.set_expiry(request.session.get_expiry_age())

    alumno = Instructor.objects.all()

    totalalumnos = Instructor.objects.all().count()
    totalsexo = Instructor.objects.all().count()
    totalpais = Instructor.objects.all().count()
    totaledad = Instructor.objects.all().count()

    sexoT = "Ambos"
    paisT = "Todos"
    edadT = "Todos"

    pais = Instructor.objects.all().values('paisI').distinct()

    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)
    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    contexto = {'alumnos':alumno, 'totalalumnos':totalalumnos, 'totalsexo':totalsexo,
    'totalpais':totalpais, 'totaledad':totaledad, 'sexoT':sexoT, 'paisT':paisT, 'edadT':edadT,
    'paises':pais, 'usuarios':usuario, 'datosPagina':datoPagina}

    return render(request, 'Admin/Extras/General/estadisticas_instructor.html', contexto)


@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def estadisticas_dinamicas_instructores_reload_ajax(request, id, id2, id3, id4):

    request.session.set_expiry(request.session.get_expiry_age())

    sexo = id
    pais = id2
    edadinicio = int(id3)
    edadfinal = int(id4)

    if sexo == "Todos" and pais == "Todos":

        alumno = Instructor.objects.filter(edadI__range=[edadinicio, edadfinal])

        totalsexo = Instructor.objects.filter(edadI__range=[edadinicio, edadfinal]).count()
        totalpais = Instructor.objects.filter(edadI__range=[edadinicio, edadfinal]).count()
        totaledad = Instructor.objects.filter(edadI__range=[edadinicio, edadfinal]).count()

        sexoT = "Ambos"
        paisT = "Todos"
        edadT = "De " + str(edadinicio) + " a " + str(edadfinal)

    elif sexo == "Todos" and pais != "Todos":

        alumno = Instructor.objects.filter(edadI__range=[edadinicio, edadfinal], paisI=pais)

        totalsexo = Instructor.objects.filter(edadI__range=[edadinicio, edadfinal], paisI=pais).count()
        totalpais = Instructor.objects.filter(edadI__range=[edadinicio, edadfinal], paisI=pais).count()
        totaledad = Instructor.objects.filter(edadI__range=[edadinicio, edadfinal], paisI=pais).count()

        sexoT = "Ambos"
        paisT = pais
        edadT = "De " + str(edadinicio) + " a " + str(edadfinal)

    elif sexo != "Todos" and pais == "Todos":

        alumno = Instructor.objects.filter(edadI__range=[edadinicio, edadfinal], sexo_instructor=sexo)

        totalsexo = Instructor.objects.filter(edadI__range=[edadinicio, edadfinal], sexo_instructor=sexo).count()
        totalpais = Instructor.objects.filter(edadI__range=[edadinicio, edadfinal], sexo_instructor=sexo).count()
        totaledad = Instructor.objects.filter(edadI__range=[edadinicio, edadfinal], sexo_instructor=sexo).count()

        sexoT = sexo
        paisT = "Todos"
        edadT = "De " + str(edadinicio) + " a " + str(edadfinal)

    elif sexo != "Todos" and pais != "Todos":

        alumno = Instructor.objects.filter(edadI__range=[edadinicio, edadfinal], sexo_instructor=sexo, paisI=pais)

        totalsexo = Instructor.objects.filter(edadI__range=[edadinicio, edadfinal], sexo_instructor=sexo, paisI=pais).count()
        totalpais = Instructor.objects.filter(edadI__range=[edadinicio, edadfinal], sexo_instructor=sexo, paisI=pais).count()
        totaledad = Instructor.objects.filter(edadI__range=[edadinicio, edadfinal], sexo_instructor=sexo, paisI=pais).count()

        sexoT = sexo
        paisT = pais
        edadT = "De " + str(edadinicio) + " a " + str(edadfinal)


    pais = Instructor.objects.all().values('paisI').distinct()
    totalalumnos = Instructor.objects.all().count()

    contexto = {'alumnos':alumno, 'totalalumnos':totalalumnos, 'totalsexo':totalsexo,
    'totalpais':totalpais, 'totaledad':totaledad, 'sexoT':sexoT, 'paisT':paisT, 'edadT':edadT,
    'paises':pais}

    return render(request, 'Admin/Extras/General/estadisticas_instructor_ajax.html', contexto)




@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def estadisticas_dinamicas_cursos(request):

    request.session.set_expiry(request.session.get_expiry_age())

    curso = Curso.objects.all()

    hoy = str(date.today())

    precioT = "Todos"
    cursoT = "Todos"
    fechaT = "Todos"
    duracionT = "Todos"
    ventasT = "Todos"
    valoracionT = "Todos"

    totalprecio = Curso.objects.all().count()
    totaltipo = Curso.objects.all().count()
    totalfecha = Curso.objects.all().count()
    totalduracion = Curso.objects.all().count()
    totalventas = Curso.objects.all().count()
    totalvaloracion = Curso.objects.all().count()

    totalcursos = Curso.objects.all().count()

    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)
    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    contexto = {'cursos':curso, 'hoy':hoy, 'totalcursos':totalcursos,'precioT':precioT, 'cursoT':cursoT,
    'fechaT':fechaT, 'duracionT':duracionT, 'ventasT':ventasT, 'valoracionT':valoracionT,
    'totalprecio':totalprecio, 'totaltipo':totaltipo, 'totalfecha':totalfecha, 'totalduracion':totalduracion,
    'totalventas':totalventas, 'totalvaloracion':totalvaloracion, 'usuarios':usuario, 'datosPagina':datoPagina}

    return render(request, 'Admin/Extras/General/estadisticas_cursos.html', contexto)



@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def estadisticas_dinamicas_cursos_reload_ajax(request, id, id2, id3, id4, id5, id6, id7, id8, id9, id10, id11, id12):

    request.session.set_expiry(request.session.get_expiry_age())

    precioinicio = int(id)
    preciofinal = int(id2)
    tipocurso = id3 #E
    fechainicio = id4
    fechafinal = id5
    tiempoinicio = int(id6)
    tiempofinal = int(id7)
    tipotiempoC = id8 #E
    ventasinicio = int(id9)
    ventasfinal = int(id10)
    valoracioninicio = int(id11)
    valoracionfinal = int(id12)

    if tipocurso == "Todos" and tipotiempoC == "Todos":

        curso = Curso.objects.filter(precio__range=[precioinicio, preciofinal], fecha_registro__range=[fechainicio, fechafinal],
        duracion_curso_numero__range=[tiempoinicio, tiempofinal], veces_vendido__range=[ventasinicio, ventasfinal],
        valoracion__range=[valoracioninicio, valoracionfinal])

        precioT = "De " + str(precioinicio) + " a " + str(preciofinal)
        cursoT = "Todos"
        fechaT = "Del " + str(fechainicio) + " al " + str(fechafinal)
        duracionT = "Todos"
        ventasT = "De " + str(ventasinicio) + " a " + str(ventasfinal)
        valoracionT = "De " + str(valoracioninicio) + " a " + str(valoracionfinal)

        totalprecio = Curso.objects.filter(precio__range=[precioinicio, preciofinal], fecha_registro__range=[fechainicio, fechafinal],
        duracion_curso_numero__range=[tiempoinicio, tiempofinal], veces_vendido__range=[ventasinicio, ventasfinal],
        valoracion__range=[valoracioninicio, valoracionfinal]).count()

        totaltipo = Curso.objects.filter(precio__range=[precioinicio, preciofinal], fecha_registro__range=[fechainicio, fechafinal],
        duracion_curso_numero__range=[tiempoinicio, tiempofinal], veces_vendido__range=[ventasinicio, ventasfinal],
        valoracion__range=[valoracioninicio, valoracionfinal]).count()

        totalfecha = Curso.objects.filter(precio__range=[precioinicio, preciofinal], fecha_registro__range=[fechainicio, fechafinal],
        duracion_curso_numero__range=[tiempoinicio, tiempofinal], veces_vendido__range=[ventasinicio, ventasfinal],
        valoracion__range=[valoracioninicio, valoracionfinal]).count()

        totalduracion = Curso.objects.filter(precio__range=[precioinicio, preciofinal], fecha_registro__range=[fechainicio, fechafinal],
        duracion_curso_numero__range=[tiempoinicio, tiempofinal], veces_vendido__range=[ventasinicio, ventasfinal],
        valoracion__range=[valoracioninicio, valoracionfinal]).count()

        totalventas = Curso.objects.filter(precio__range=[precioinicio, preciofinal], fecha_registro__range=[fechainicio, fechafinal],
        duracion_curso_numero__range=[tiempoinicio, tiempofinal], veces_vendido__range=[ventasinicio, ventasfinal],
        valoracion__range=[valoracioninicio, valoracionfinal]).count()

        totalvaloracion = Curso.objects.filter(precio__range=[precioinicio, preciofinal], fecha_registro__range=[fechainicio, fechafinal],
        duracion_curso_numero__range=[tiempoinicio, tiempofinal], veces_vendido__range=[ventasinicio, ventasfinal],
        valoracion__range=[valoracioninicio, valoracionfinal]).count()


    elif tipocurso == "Todos" and tipotiempoC != "Todos":

        curso = Curso.objects.filter(precio__range=[precioinicio, preciofinal], fecha_registro__range=[fechainicio, fechafinal],
        duracion_curso_numero__range=[tiempoinicio, tiempofinal], veces_vendido__range=[ventasinicio, ventasfinal],
        valoracion__range=[valoracioninicio, valoracionfinal], duracion_curso_tipo=tipotiempoC)

        precioT = "De " + str(precioinicio) + " a " + str(preciofinal)
        cursoT = "Todos"
        fechaT = "Del " + str(fechainicio) + " al " + str(fechafinal)
        duracionT = "De " + str(tiempoinicio) + " a " + str(tiempofinal) + " " +tipotiempoC
        ventasT = "De " + str(ventasinicio) + " a " + str(ventasfinal)
        valoracionT = "De " + str(valoracioninicio) + " a " + str(valoracionfinal)

        totalprecio = Curso.objects.filter(precio__range=[precioinicio, preciofinal], fecha_registro__range=[fechainicio, fechafinal],
        duracion_curso_numero__range=[tiempoinicio, tiempofinal], veces_vendido__range=[ventasinicio, ventasfinal],
        valoracion__range=[valoracioninicio, valoracionfinal], duracion_curso_tipo=tipotiempoC).count()

        totaltipo = Curso.objects.filter(precio__range=[precioinicio, preciofinal], fecha_registro__range=[fechainicio, fechafinal],
        duracion_curso_numero__range=[tiempoinicio, tiempofinal], veces_vendido__range=[ventasinicio, ventasfinal],
        valoracion__range=[valoracioninicio, valoracionfinal], duracion_curso_tipo=tipotiempoC).count()

        totalfecha = Curso.objects.filter(precio__range=[precioinicio, preciofinal], fecha_registro__range=[fechainicio, fechafinal],
        duracion_curso_numero__range=[tiempoinicio, tiempofinal], veces_vendido__range=[ventasinicio, ventasfinal],
        valoracion__range=[valoracioninicio, valoracionfinal], duracion_curso_tipo=tipotiempoC).count()

        totalduracion = Curso.objects.filter(precio__range=[precioinicio, preciofinal], fecha_registro__range=[fechainicio, fechafinal],
        duracion_curso_numero__range=[tiempoinicio, tiempofinal], veces_vendido__range=[ventasinicio, ventasfinal],
        valoracion__range=[valoracioninicio, valoracionfinal], duracion_curso_tipo=tipotiempoC).count()

        totalventas = Curso.objects.filter(precio__range=[precioinicio, preciofinal], fecha_registro__range=[fechainicio, fechafinal],
        duracion_curso_numero__range=[tiempoinicio, tiempofinal], veces_vendido__range=[ventasinicio, ventasfinal],
        valoracion__range=[valoracioninicio, valoracionfinal], duracion_curso_tipo=tipotiempoC).count()

        totalvaloracion = Curso.objects.filter(precio__range=[precioinicio, preciofinal], fecha_registro__range=[fechainicio, fechafinal],
        duracion_curso_numero__range=[tiempoinicio, tiempofinal], veces_vendido__range=[ventasinicio, ventasfinal],
        valoracion__range=[valoracioninicio, valoracionfinal], duracion_curso_tipo=tipotiempoC).count()

    elif tipocurso != "Todos" and tipotiempoC == "Todos":

        curso = Curso.objects.filter(precio__range=[precioinicio, preciofinal], fecha_registro__range=[fechainicio, fechafinal],
        duracion_curso_numero__range=[tiempoinicio, tiempofinal], veces_vendido__range=[ventasinicio, ventasfinal],
        valoracion__range=[valoracioninicio, valoracionfinal], tipo_Curso=tipocurso)

        precioT = "De " + str(precioinicio) + " a " + str(preciofinal)
        cursoT = tipocurso
        fechaT = "Del " + str(fechainicio) + " al " + str(fechafinal)
        duracionT = "Todos"
        ventasT = "De " + str(ventasinicio) + " a " + str(ventasfinal)
        valoracionT = "De " + str(valoracioninicio) + " a " + str(valoracionfinal)

        totalprecio = Curso.objects.filter(precio__range=[precioinicio, preciofinal], fecha_registro__range=[fechainicio, fechafinal],
        duracion_curso_numero__range=[tiempoinicio, tiempofinal], veces_vendido__range=[ventasinicio, ventasfinal],
        valoracion__range=[valoracioninicio, valoracionfinal], tipo_Curso=tipocurso).count()

        totaltipo = Curso.objects.filter(precio__range=[precioinicio, preciofinal], fecha_registro__range=[fechainicio, fechafinal],
        duracion_curso_numero__range=[tiempoinicio, tiempofinal], veces_vendido__range=[ventasinicio, ventasfinal],
        valoracion__range=[valoracioninicio, valoracionfinal], tipo_Curso=tipocurso).count()

        totalfecha = Curso.objects.filter(precio__range=[precioinicio, preciofinal], fecha_registro__range=[fechainicio, fechafinal],
        duracion_curso_numero__range=[tiempoinicio, tiempofinal], veces_vendido__range=[ventasinicio, ventasfinal],
        valoracion__range=[valoracioninicio, valoracionfinal], tipo_Curso=tipocurso).count()

        totalduracion = Curso.objects.filter(precio__range=[precioinicio, preciofinal], fecha_registro__range=[fechainicio, fechafinal],
        duracion_curso_numero__range=[tiempoinicio, tiempofinal], veces_vendido__range=[ventasinicio, ventasfinal],
        valoracion__range=[valoracioninicio, valoracionfinal], tipo_Curso=tipocurso).count()

        totalventas = Curso.objects.filter(precio__range=[precioinicio, preciofinal], fecha_registro__range=[fechainicio, fechafinal],
        duracion_curso_numero__range=[tiempoinicio, tiempofinal], veces_vendido__range=[ventasinicio, ventasfinal],
        valoracion__range=[valoracioninicio, valoracionfinal], tipo_Curso=tipocurso).count()

        totalvaloracion = Curso.objects.filter(precio__range=[precioinicio, preciofinal], fecha_registro__range=[fechainicio, fechafinal],
        duracion_curso_numero__range=[tiempoinicio, tiempofinal], veces_vendido__range=[ventasinicio, ventasfinal],
        valoracion__range=[valoracioninicio, valoracionfinal], tipo_Curso=tipocurso).count()


    elif tipocurso != "Todos" and tipotiempoC != "Todos":

        curso = Curso.objects.filter(precio__range=[precioinicio, preciofinal], fecha_registro__range=[fechainicio, fechafinal],
        duracion_curso_numero__range=[tiempoinicio, tiempofinal], veces_vendido__range=[ventasinicio, ventasfinal],
        valoracion__range=[valoracioninicio, valoracionfinal], duracion_curso_tipo=tipotiempoC, tipo_Curso=tipocurso)

        precioT = "De " + str(precioinicio) + " a " + str(preciofinal)
        cursoT = tipocurso
        fechaT = "Del " + str(fechainicio) + " al " + str(fechafinal)
        duracionT = "De " + str(tiempoinicio) + " a " + str(tiempofinal) + " " +tipotiempoC
        ventasT = "De " + str(ventasinicio) + " a " + str(ventasfinal)
        valoracionT = "De " + str(valoracioninicio) + " a " + str(valoracionfinal)

        totalprecio = Curso.objects.filter(precio__range=[precioinicio, preciofinal], fecha_registro__range=[fechainicio, fechafinal],
        duracion_curso_numero__range=[tiempoinicio, tiempofinal], veces_vendido__range=[ventasinicio, ventasfinal],
        valoracion__range=[valoracioninicio, valoracionfinal], duracion_curso_tipo=tipotiempoC, tipo_Curso=tipocurso).count()

        totaltipo = Curso.objects.filter(precio__range=[precioinicio, preciofinal], fecha_registro__range=[fechainicio, fechafinal],
        duracion_curso_numero__range=[tiempoinicio, tiempofinal], veces_vendido__range=[ventasinicio, ventasfinal],
        valoracion__range=[valoracioninicio, valoracionfinal], duracion_curso_tipo=tipotiempoC, tipo_Curso=tipocurso).count()

        totalfecha = Curso.objects.filter(precio__range=[precioinicio, preciofinal], fecha_registro__range=[fechainicio, fechafinal],
        duracion_curso_numero__range=[tiempoinicio, tiempofinal], veces_vendido__range=[ventasinicio, ventasfinal],
        valoracion__range=[valoracioninicio, valoracionfinal], duracion_curso_tipo=tipotiempoC, tipo_Curso=tipocurso).count()

        totalduracion = Curso.objects.filter(precio__range=[precioinicio, preciofinal], fecha_registro__range=[fechainicio, fechafinal],
        duracion_curso_numero__range=[tiempoinicio, tiempofinal], veces_vendido__range=[ventasinicio, ventasfinal],
        valoracion__range=[valoracioninicio, valoracionfinal], duracion_curso_tipo=tipotiempoC, tipo_Curso=tipocurso).count()

        totalventas = Curso.objects.filter(precio__range=[precioinicio, preciofinal], fecha_registro__range=[fechainicio, fechafinal],
        duracion_curso_numero__range=[tiempoinicio, tiempofinal], veces_vendido__range=[ventasinicio, ventasfinal],
        valoracion__range=[valoracioninicio, valoracionfinal], duracion_curso_tipo=tipotiempoC, tipo_Curso=tipocurso).count()

        totalvaloracion = Curso.objects.filter(precio__range=[precioinicio, preciofinal], fecha_registro__range=[fechainicio, fechafinal],
        duracion_curso_numero__range=[tiempoinicio, tiempofinal], veces_vendido__range=[ventasinicio, ventasfinal],
        valoracion__range=[valoracioninicio, valoracionfinal], duracion_curso_tipo=tipotiempoC, tipo_Curso=tipocurso).count()


    totalcursos = Curso.objects.all().count()
    hoy = str(date.today())

    contexto = {'cursos':curso, 'hoy':hoy, 'totalcursos':totalcursos,'precioT':precioT, 'cursoT':cursoT,
    'fechaT':fechaT, 'duracionT':duracionT, 'ventasT':ventasT, 'valoracionT':valoracionT,
    'totalprecio':totalprecio, 'totaltipo':totaltipo, 'totalfecha':totalfecha, 'totalduracion':totalduracion,
    'totalventas':totalventas, 'totalvaloracion':totalvaloracion}

    return render(request, 'Admin/Extras/General/estadisticas_curso_ajax.html', contexto)



@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def mostrar_cupones(request):

    request.session.set_expiry(request.session.get_expiry_age())

    cupon = CuponesDescuento.objects.all()

    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)
    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    contexto = {'cupones':cupon, 'usuarios':usuario, 'datosPagina':datoPagina}

    return render(request, 'Admin/administrador_cupones.html', contexto)



@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def mostrar_agregar_cupon(request):

    request.session.set_expiry(request.session.get_expiry_age())

    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)
    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    todaynoti = date.today()
    fecha = str(todaynoti)

    contexto = {'usuarios':usuario, 'datosPagina':datoPagina, 'fecha':fecha}

    return render(request, 'Admin/Extras/Cupon/agregar_cupon.html', contexto)



@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def mostrar_editar_cupon(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    idcupon = id

    cupon = CuponesDescuento.objects.filter(id_cupon=idcupon)

    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)
    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    todaynoti = date.today()
    fecha = str(todaynoti)

    contexto = {'cupones':cupon, 'usuarios':usuario, 'datosPagina':datoPagina, 'fecha':fecha}

    return render(request, 'Admin/Extras/Cupon/editar_cupon.html', contexto)



@csrf_exempt
@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def agregar_cupon(request):

    request.session.set_expiry(request.session.get_expiry_age())

    if request.method == "POST":

        nombreidentificador = request.POST["nombrecupon"]
        fechavigencia = request.POST["fechacaduca"]
        porcentaje = request.POST["porcentaje"]

        chars = string.ascii_uppercase + string.digits
        size = 10

        cuponaleatorio = ''.join(random.choice(chars) for _ in range(size))

        verificar = CuponesDescuento.objects.filter(codigo_cupon=cuponaleatorio)

        if verificar:

            cuponaleatorio = ''.join(random.choice(chars) for _ in range(size))

        else:

            pass

        cd = CuponesDescuento(codigo_cupon=cuponaleatorio, porcentaje_asignado=porcentaje,
        fecha_caduca=fechavigencia, nombre_identificador=nombreidentificador, status_cupon=1)
        cd.save()

        texto = "Agrego el cupon: "
        nombre = nombreidentificador
        detalle = texto + nombre
        fecha = datetime.now()
        id_adm = request.user.id_relacionado
        adminis = Administrador.objects.get(id_admin=id_adm)
        nombre_adminis = adminis.nombre

        l = LogAdmin(fecha_accion=fecha, id_admin_accion=id_adm,
        nombre_admin_accion=nombre_adminis, detalles_accion=detalle)
        l.save()

        #cupon = CuponesDescuento.objects.all()
        #contexto = {'cupones':cupon}
        #return render(request, 'Admin/administrador_cupones.html', contexto)
        return redirect('/cupones/')




@csrf_exempt
@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def editar_cupon(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    if request.method == "POST":

        nombreidentificador = request.POST["nombrecupon"]
        fechavigencia = request.POST["fechacaduca"]
        porcentaje = request.POST["porcentaje"]

        idcupon = id

        cd = CuponesDescuento.objects.get(id_cupon=idcupon)
        cd.nombre_identificador = nombreidentificador
        cd.fecha_caduca = fechavigencia
        cd.porcentaje_asignado = porcentaje
        cd.save()

        texto = "Edito el cupon: "
        nombre = nombreidentificador
        detalle = texto + nombre
        fecha = datetime.now()
        id_adm = request.user.id_relacionado
        adminis = Administrador.objects.get(id_admin=id_adm)
        nombre_adminis = adminis.nombre

        l = LogAdmin(fecha_accion=fecha, id_admin_accion=id_adm,
        nombre_admin_accion=nombre_adminis, detalles_accion=detalle)
        l.save()

        #cupon = CuponesDescuento.objects.all()
        #contexto = {'cupones':cupon}
        #return render(request, 'Admin/administrador_cupones.html', contexto)
        return redirect('/cupones/')



@csrf_exempt
@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def eliminar_cupon(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    idcupon = id
    cd = CuponesDescuento.objects.get(id_cupon=idcupon)
    va = cd.status_cupon
    if va == 1:
        cd.status_cupon = 0
        cd.save()

        texto = "Deshabilito el cupon: "
        nombre = cd.nombre_identificador
        detalle = texto + nombre
        fecha = datetime.now()
        id_adm = request.user.id_relacionado
        adminis = Administrador.objects.get(id_admin=id_adm)
        nombre_adminis = adminis.nombre

        l = LogAdmin(fecha_accion=fecha, id_admin_accion=id_adm,
        nombre_admin_accion=nombre_adminis, detalles_accion=detalle)
        l.save()

    else:
        cd.status_cupon = 1
        cd.save()

        texto = "Rehabilito el cupon: "
        nombre = cd.nombre_identificador
        detalle = texto + nombre
        fecha = datetime.now()
        id_adm = request.user.id_relacionado
        adminis = Administrador.objects.get(id_admin=id_adm)
        nombre_adminis = adminis.nombre

        l = LogAdmin(fecha_accion=fecha, id_admin_accion=id_adm,
        nombre_admin_accion=nombre_adminis, detalles_accion=detalle)
        l.save()


    #cupon = CuponesDescuento.objects.all()
    #contexto = {'cupones':cupon}
    #return render(request, 'Admin/administrador_cupones.html', contexto)
    return redirect('/cupones/')



@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def mostrar_editar_perfil_administrador(request):

    request.session.set_expiry(request.session.get_expiry_age())

    idadmin = request.user.id_relacionado

    administrador = Administrador.objects.filter(id_admin=idadmin)

    usuario = Administrador.objects.filter(id_admin=idadmin)
    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    contexto = {'administradores':administrador, 'usuarios':usuario, 'datosPagina':datoPagina}

    return render(request, 'Admin/Extras/General/editar_perfil.html', contexto)



@csrf_exempt
@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def guardar_perfil_admin(request):

    request.session.set_expiry(request.session.get_expiry_age())

    if request.method == "POST":

        try:
            imagenperfil = request.FILES["avatar"]
        except Exception as e:
            imagenperfil = ""


        nombre = request.POST["nombres"]
        password = request.POST["password"]

        nombreimagen = ""
        idadmin = request.user.id_relacionado

        alum = Administrador.objects.get(id_admin=idadmin)

        nombre_avatar = alum.ruta_imagen_admin
        correo = alum.correoA


        if imagenperfil :

            nombreimagen = secure_filename(imagenperfil.name)
            #fs = FileSystemStorage(location='ProyectoKaizen/static/media/Imagenes')
            fs = FileSystemStorage(location= os.path.join(settings.MEDIA_ROOT+'/Imagenes'))
            filenam = fs.save(nombreimagen, imagenperfil)

            if nombre_avatar == "avatar.png":

                pass

            else:

                os.remove(os.path.join(settings.MEDIA_ROOT+'/Imagenes/' + nombre_avatar))



        alumn = Administrador.objects.get(id_admin=idadmin)

        alumn.nombre = nombre

        if nombreimagen == "":

            pass

        else:

            alumn.ruta_imagen_admin = nombreimagen


        alumn.save()

        if password:

            nuevacontra = make_password(password)

            usu = Usuarios.objects.get(id_relacionado=idadmin, email=correo, tipo_usuario=1)

            usu.password = nuevacontra

            usu.save()


        #usuario = Administrador.objects.filter(id_admin=idadmin)
        #contexto = {'usuarios':usuario}
        #return render(request, 'Admin/administrador_index.html', contexto)
        return redirect('/inicio_admin/')


@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def mostrar_pagos(request):

    request.session.set_expiry(request.session.get_expiry_age())

    instructor = Instructor.objects.all()

    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)
    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    contexto = {'instructores':instructor, 'usuarios':usuario, 'datosPagina':datoPagina}

    return render(request, 'Admin/Extras/Pagos/pagos.html', contexto)


@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def mostrar_pagos_admin(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    idinstructor = id

    fecha = date.today()

    anioo = fecha.year
    mes = fecha.month

    movimientos = MovimientosInstructor.objects.filter(id_instructorR=idinstructor, fecha_movimiento__year=anioo, fecha_movimiento__month=mes)

    total = 0
    descuento = 0
    devolucion = 0
    ganancias = 0
    contaPagado = 0
    contanoPagado = 0
    estado = ""

    for movimiento in movimientos:

        total = total + movimiento.cantidad_total
        descuento = descuento + movimiento.descuento_aplicado
        devuel = movimiento.devuelto
        esta = movimiento.estado

        if devuel == 0:

            ganancias = ganancias + movimiento.total_ganado

        else:

            devolucion = devolucion + movimiento.total_ganado

        if esta == 0:

            contanoPagado = contanoPagado + 1

        else:

            contaPagado = contaPagado + 1


    if contanoPagado != 0:

        estado = "NoPagado"

    elif contaPagado != 0:

        estado = "Pagado"

    anios = []

    instruc = Instructor.objects.get(id_instructor=idinstructor)
    fecharegistro = instruc.fecha_registro

    ano = fecharegistro.year

    totalanio = int(anioo) - int(ano)

    val = int(ano)
    anios.append(val)

    for i in range(totalanio):

        val = val + 1
        anios.append(val)


    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)
    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    contexto = {'totalmes':total, 'descuentosmes':descuento, 'devolucionesmes':devolucion,
    'ganaciasmes':ganancias, 'estado':estado, 'aniobusqueda':anioo, 'mesbusqueda':mes,
    'idinstructor':idinstructor, 'anios':anios, 'usuarios':usuario, 'datosPagina':datoPagina}

    return render(request, 'Admin/Extras/Pagos/pagos_instructor.html', contexto)


@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def mostrar_pagos_admin_ajax(request, id, id2, id3):

    request.session.set_expiry(request.session.get_expiry_age())

    idinstructor = id

    anioo = id2
    mes = id3

    movimientos = MovimientosInstructor.objects.filter(id_instructorR=idinstructor, fecha_movimiento__year=anioo, fecha_movimiento__month=mes)

    total = 0
    descuento = 0
    devolucion = 0
    ganancias = 0
    contaPagado = 0
    contanoPagado = 0
    estado = ""

    for movimiento in movimientos:

        total = total + movimiento.cantidad_total
        descuento = descuento + movimiento.descuento_aplicado
        devuel = movimiento.devuelto
        esta = movimiento.estado

        if devuel == 0:

            ganancias = ganancias + movimiento.total_ganado

        else:

            devolucion = devolucion + movimiento.total_ganado

        if esta == 0:

            contanoPagado = contanoPagado + 1

        else:

            contaPagado = contaPagado + 1


    if contanoPagado != 0:

        estado = "NoPagado"

    elif contaPagado != 0:

        estado = "Pagado"

    anios = []

    instruc = Instructor.objects.get(id_instructor=idinstructor)
    fecharegistro = instruc.fecha_registro

    ano = fecharegistro.year

    fecha = date.today()

    anis = fecha.year

    totalanio = int(anis) - int(ano)

    val = int(ano)
    anios.append(val)

    for i in range(totalanio):

        val = val + 1
        anios.append(val)


    contexto = {'totalmes':total, 'descuentosmes':descuento, 'devolucionesmes':devolucion,
    'ganaciasmes':ganancias, 'estado':estado, 'aniobusqueda':anioo, 'mesbusqueda':mes,
    'idinstructor':idinstructor, 'anios':anios}

    return render(request, 'Admin/Extras/Pagos/pagos_instructor_ajax.html', contexto)


@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def realizar_pago_instructor(request, id, id2, id3):

    request.session.set_expiry(request.session.get_expiry_age())

    idinstructor = id
    anio = id2
    mes = id3

    listaid = []
    ganancias = 0

    movimientos = MovimientosInstructor.objects.filter(id_instructorR=idinstructor, fecha_movimiento__year=anio, fecha_movimiento__month=mes)

    for movimiento in movimientos:

        id = movimiento.id_movimientoInstructor
        listaid.append(id)
        devuel = movimiento.devuelto

        if devuel == 0:

            ganancias = ganancias + movimiento.total_ganado


    for i in range(len(listaid)):

        idmovimiento = listaid[i]

        mov = MovimientosInstructor.objects.get(id_movimientoInstructor=idmovimiento)
        mov.estado = 1
        mov.save()


    instru = Instructor.objects.get(id_instructor=idinstructor)
    nombreinstructor = instru.nombreI + " " + instru.apellidosI

    texto = "Realizo un pago al instructor "
    texto2 = ". Por un monto de "
    texto3 = ", correspondiente al mes "
    texto4 = " del año "
    detalle = texto + nombreinstructor + texto2 + str(ganancias) + texto3 + str(mes) + texto4 + str(anio)
    fecha = datetime.now()
    id_adm = request.user.id_relacionado
    adminis = Administrador.objects.get(id_admin=id_adm)
    nombre_adminis = adminis.nombre

    l = LogAdmin(fecha_accion=fecha, id_admin_accion=id_adm,
    nombre_admin_accion=nombre_adminis, detalles_accion=detalle)
    l.save()

    return redirect('/pagos/')


@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def mostrar_devoluciones(request):

    request.session.set_expiry(request.session.get_expiry_age())

    filtro = Transacciones.objects.all().values('id_alumno_compro')

    alumno = Alumno.objects.filter(id_alumno__in=filtro)

    transaccion = Transacciones.objects.all()

    curso = Curso.objects.all()

    hoy = str(date.today())

    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)
    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    contexto = {'transacciones':transaccion, 'alumnos':alumno, 'cursos':curso,
    'hoy':hoy, 'usuarios':usuario, 'datosPagina':datoPagina}

    return render(request, 'Admin/Extras/Devoluciones/devolucion.html', contexto)


@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def mostrar_devoluciones_reload_ajax(request, id, id2, id3, id4, id5, id6):

    request.session.set_expiry(request.session.get_expiry_age())

    fechainicial = id
    fechafinal = id2
    tipopago = id3
    totalinicial = int(id4)
    totalfinal = int(id5)
    nombrecurso = id6

    if tipopago == "Todos" and nombrecurso == "Todos":

        filtro = Transacciones.objects.filter(fecha_transaccion__range=[fechainicial, fechafinal], total_venta__range=[totalinicial, totalfinal]).values('id_alumno_compro')

        alumno = Alumno.objects.filter(id_alumno__in=filtro)

        transaccion = Transacciones.objects.filter(fecha_transaccion__range=[fechainicial, fechafinal], total_venta__range=[totalinicial, totalfinal])

    elif tipopago == "Todos" and nombrecurso != "Todos":

         filtro = Transacciones.objects.filter(fecha_transaccion__range=[fechainicial, fechafinal], total_venta__range=[totalinicial, totalfinal], id_curso_comprado=nombrecurso).values('id_alumno_compro')

         alumno = Alumno.objects.filter(id_alumno__in=filtro)

         transaccion = Transacciones.objects.filter(fecha_transaccion__range=[fechainicial, fechafinal], total_venta__range=[totalinicial, totalfinal], id_curso_comprado=nombrecurso)

    elif tipopago != "Todos" and nombrecurso == "Todos":

        filtro = Transacciones.objects.filter(fecha_transaccion__range=[fechainicial, fechafinal], total_venta__range=[totalinicial, totalfinal], tipo_pago=tipopago).values('id_alumno_compro')

        alumno = Alumno.objects.filter(id_alumno__in=filtro)

        transaccion = Transacciones.objects.filter(fecha_transaccion__range=[fechainicial, fechafinal], total_venta__range=[totalinicial, totalfinal], tipo_pago=tipopago)

    elif tipopago != "Todos" and nombrecurso != "Todos":

        filtro = Transacciones.objects.filter(fecha_transaccion__range=[fechainicial, fechafinal], total_venta__range=[totalinicial, totalfinal], tipo_pago=tipopago, id_curso_comprado=nombrecurso).values('id_alumno_compro')

        alumno = Alumno.objects.filter(id_alumno__in=filtro)

        transaccion = Transacciones.objects.filter(fecha_transaccion__range=[fechainicial, fechafinal], total_venta__range=[totalinicial, totalfinal], tipo_pago=tipopago, id_curso_comprado=nombrecurso)


    curso = Curso.objects.all()

    contexto = {'transacciones':transaccion, 'alumnos':alumno}

    return render(request, 'Admin/Extras/Devoluciones/devoluciones_ajax.html', contexto)


@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def realizar_devolucion(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    idtransaccion = id

    tranins = MovimientosInstructor.objects.get(id_transaccionR=idtransaccion)

    tran = Transacciones.objects.get(id_transaccion=idtransaccion)
    estado = tran.devolucion
    total = tran.total_venta

    if estado == 0:

        tran.devolucion = 1
        tran.save()
        tranins.devuelto = 1
        tranins.save()

        texto = "Realizo una devolucion."
        texto2 = " Por un monto de "
        detalle = texto + texto2 + str(total)
        fecha = datetime.now()
        id_adm = request.user.id_relacionado
        adminis = Administrador.objects.get(id_admin=id_adm)
        nombre_adminis = adminis.nombre

        l = LogAdmin(fecha_accion=fecha, id_admin_accion=id_adm,
        nombre_admin_accion=nombre_adminis, detalles_accion=detalle)
        l.save()

    else:

        tran.devolucion = 0
        tran.save()
        tranins.devuelto = 0
        tranins.save()

        texto = "Cancelo una devolucion."
        texto2 = " Por un monto de "
        detalle = texto + texto2 + str(total)
        fecha = datetime.now()
        id_adm = request.user.id_relacionado
        adminis = Administrador.objects.get(id_admin=id_adm)
        nombre_adminis = adminis.nombre

        l = LogAdmin(fecha_accion=fecha, id_admin_accion=id_adm,
        nombre_admin_accion=nombre_adminis, detalles_accion=detalle)
        l.save()


    return redirect('/devoluciones/')


@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def mostrar_entradas(request):

    request.session.set_expiry(request.session.get_expiry_age())

    entrada = EntradasBlog.objects.all()

    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)
    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    contexto = {'entradas':entrada, 'usuarios':usuario, 'datosPagina':datoPagina}

    return render(request, 'Admin/Extras/Entradas/entradas_blog.html', contexto)


@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def mostrar_agregar_entrada(request):

    request.session.set_expiry(request.session.get_expiry_age())

    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)
    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    contexto = {'usuarios':usuario, 'datosPagina':datoPagina}

    return render(request, 'Admin/Extras/Entradas/nueva_entrada.html', contexto)



@csrf_exempt
@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def agregar_entrada(request):

    request.session.set_expiry(request.session.get_expiry_age())

    if request.method == "POST":

        imagenperfil = request.FILES["imagenentrada"]
        nombre = request.POST["titulo"]
        contenido = request.POST["descripcion"]
        urlvideo = request.POST["video"]
        descrip = request.POST["breve"]

        nombreimagen = ""

        if imagenperfil :

            nombreimagen = secure_filename(imagenperfil.name)
            #fs = FileSystemStorage(location='ProyectoKaizen/static/media/Imagenes/Entradas')
            fs = FileSystemStorage(location= os.path.join(settings.MEDIA_ROOT+'/Imagenes/Entradas'))
            #fs = FileSystemStorage(location='/ProyectoKaizen/static/media/Imagenes/Entradas')

            filenam = fs.save(nombreimagen, imagenperfil)

            #if nombre_avatar == "avatar.png":

            #    pass

            #else:

            #    os.remove(os.path.join(settings.MEDIA_ROOT+'/Imagenes/' + nombre_avatar))


        idadmin = request.user.id_relacionado

        eb = EntradasBlog(titulo_entrada=nombre, contenido_entrada=contenido, posteador="Administrador",
        id_posteador=idadmin, no_vistas=0, imagen_entrada=nombreimagen, video_entrada=urlvideo,
        no_me_gusta=0, no_me_encanta=0, no_me_impresiona=0, no_me_risa=0, statusB=0, no_comentarios=0, descripcion=descrip)
        eb.save()

        texto = "Registro una nueva entrada para el blog."
        detalle = texto
        fecha = datetime.now()
        id_adm = request.user.id_relacionado
        adminis = Administrador.objects.get(id_admin=id_adm)
        nombre_adminis = adminis.nombre

        l = LogAdmin(fecha_accion=fecha, id_admin_accion=id_adm,
        nombre_admin_accion=nombre_adminis, detalles_accion=detalle)
        l.save()

        return redirect('/entradas/')


@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def mostrar_editar_entrada(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    identrada = id

    entrada = EntradasBlog.objects.filter(id_entrada=identrada)

    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)
    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    contexto = {'entradas':entrada, 'usuarios':usuario, 'datosPagina':datoPagina}

    return render(request, 'Admin/Extras/Entradas/editar_entrada.html', contexto)



@csrf_exempt
@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def editar_entrada(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    if request.method == "POST":

        try:
            imagenperfil = request.FILES["imagenentrada"]
        except Exception as e:
            imagenperfil = ""

        nombre = request.POST["titulo"]
        contenido = request.POST["descripcion"]
        urlvideo = request.POST["video"]
        descrip = request.POST["breve"]

        nombreimagen = ""
        identrada = id

        entra = EntradasBlog.objects.get(id_entrada=identrada)
        nombre_imagen = entra.imagen_entrada

        if imagenperfil :

            nombreimagen = secure_filename(imagenperfil.name)
            #fs = FileSystemStorage(location='ProyectoKaizen/static/media/Imagenes/Entradas')
            #fs = FileSystemStorage(location='ProyectoKaizen/static/media/Imagenes/Entradas')
            fs = FileSystemStorage(location= os.path.join(settings.MEDIA_ROOT+'/Imagenes/Entradas'))
            filenam = fs.save(nombreimagen, imagenperfil)

            os.remove(os.path.join(settings.MEDIA_ROOT+'/Imagenes/Entradas/' + nombre_imagen))


        entrass = EntradasBlog.objects.get(id_entrada=identrada)
        entrass.titulo_entrada = nombre
        entrass.contenido_entrada = contenido

        if nombreimagen:

            entrass.imagen_entrada = nombreimagen

        entrass.video_entrada = urlvideo
        entrass.descripcion = descrip
        entrass.save()

        texto = "Edito una entrada para el blog."
        detalle = texto
        fecha = datetime.now()
        id_adm = request.user.id_relacionado
        adminis = Administrador.objects.get(id_admin=id_adm)
        nombre_adminis = adminis.nombre

        l = LogAdmin(fecha_accion=fecha, id_admin_accion=id_adm,
        nombre_admin_accion=nombre_adminis, detalles_accion=detalle)
        l.save()

        return redirect('/entradas/')



@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def publicar_entrada(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    identrada = id

    entra = EntradasBlog.objects.get(id_entrada=identrada)
    estado = entra.statusB

    if estado == 0:

        entra.statusB = 1
        entra.save()

        texto = "Hizo visible una entrada para el blog."
        detalle = texto
        fecha = datetime.now()
        id_adm = request.user.id_relacionado
        adminis = Administrador.objects.get(id_admin=id_adm)
        nombre_adminis = adminis.nombre

        l = LogAdmin(fecha_accion=fecha, id_admin_accion=id_adm,
        nombre_admin_accion=nombre_adminis, detalles_accion=detalle)
        l.save()

    else:

        entra.statusB = 0
        entra.save()

        texto = "Oculto una entrada para el blog."
        detalle = texto
        fecha = datetime.now()
        id_adm = request.user.id_relacionado
        adminis = Administrador.objects.get(id_admin=id_adm)
        nombre_adminis = adminis.nombre

        l = LogAdmin(fecha_accion=fecha, id_admin_accion=id_adm,
        nombre_admin_accion=nombre_adminis, detalles_accion=detalle)
        l.save()


    return redirect('/entradas/')


@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def mostrar_conferencias(request):

    request.session.set_expiry(request.session.get_expiry_age())

    conferencia = TransmisionesVivo.objects.all()

    idadmin = request.user.id_relacionado

    usuario = Administrador.objects.filter(id_admin=idadmin)
    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    contexto = {'usuarios':usuario, 'conferencias':conferencia, 'datosPagina':datoPagina}

    return render(request, 'Admin/Extras/Transmisiones/transmisiones.html', contexto)


@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def mostrar_agregar_transmision(request):

    request.session.set_expiry(request.session.get_expiry_age())

    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)
    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    todaynoti = date.today()
    fecha = str(todaynoti)

    contexto = {'usuarios':usuario, 'datosPagina':datoPagina, 'fecha':fecha}

    return render(request, 'Admin/Extras/Transmisiones/agregar_transmision.html', contexto)



@csrf_exempt
@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def agregar_transmision(request):

    request.session.set_expiry(request.session.get_expiry_age())

    if request.method == "POST":

        nombreG = request.POST["nombre"]
        fechaG = request.POST["fecha"]
        horaG = request.POST["hora"]
        tipoG = request.POST["tipo"]
        url = request.POST["url"]

        urlpartida = url.split("=")

        if len(urlpartida) == 1:

            urlpartida = url.split('/')

        urlvideo = urlpartida[-1]

        fechahora = str(fechaG) + " " + str(horaG)

        tv = TransmisionesVivo(url_video=urlvideo, fecha_transmision=fechaG, hora_transmision=horaG,
        publico=tipoG, statusT=1, fecha_completa=fechahora, nombre_transmision=nombreG)
        tv.save()

        texto = "Agrego una nueva transmision."
        detalle = texto
        fecha = datetime.now()
        id_adm = request.user.id_relacionado
        adminis = Administrador.objects.get(id_admin=id_adm)
        nombre_adminis = adminis.nombre

        l = LogAdmin(fecha_accion=fecha, id_admin_accion=id_adm,
        nombre_admin_accion=nombre_adminis, detalles_accion=detalle)
        l.save()

        return redirect('/transmisiones/')




@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def mostrar_editar_transmision(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    idtransmision = id
    idadmin = request.user.id_relacionado

    conferencia = TransmisionesVivo.objects.filter(id_transmision=idtransmision)

    usuario = Administrador.objects.filter(id_admin=idadmin)
    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    todaynoti = date.today()
    fecha = str(todaynoti)

    contexto ={'usuarios':usuario, 'conferencias':conferencia, 'datosPagina':datoPagina, 'fecha':fecha}

    return render(request, 'Admin/Extras/Transmisiones/editar_transmision.html', contexto)



@csrf_exempt
@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def editar_transmision(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    if request.method == "POST":

        nombreG = request.POST["nombre"]
        fechaG = request.POST["fecha"]
        horaG = request.POST["hora"]
        tipoG = request.POST["tipo"]
        url = request.POST["url"]

        idtransmision = id

        urlpartida = url.split("=")

        if len(urlpartida) == 1:

            urlpartida = url.split('/')

        urlvideo = urlpartida[-1]

        fechahora = str(fechaG) + " " + str(horaG)

        tv = TransmisionesVivo.objects.get(id_transmision=idtransmision)
        tv.url_video = urlvideo
        tv.fecha_transmision = fechaG
        tv.hora_transmision = horaG
        tv.publico = tipoG
        tv.fecha_completa = fechahora
        tv.nombre_transmision = nombreG
        tv.save()

        texto = "Edito los datos de una transmision."
        detalle = texto
        fecha = datetime.now()
        id_adm = request.user.id_relacionado
        adminis = Administrador.objects.get(id_admin=id_adm)
        nombre_adminis = adminis.nombre

        l = LogAdmin(fecha_accion=fecha, id_admin_accion=id_adm,
        nombre_admin_accion=nombre_adminis, detalles_accion=detalle)
        l.save()

        return redirect('/transmisiones/')


@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def habilitar_transmision(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    idtransmision = id

    entra = TransmisionesVivo.objects.get(id_transmision=idtransmision)
    estado = entra.statusT

    if estado == 0:

        entra.statusT = 1
        entra.save()

        texto = "Rehabilito una transmision."
        detalle = texto
        fecha = datetime.now()
        id_adm = request.user.id_relacionado
        adminis = Administrador.objects.get(id_admin=id_adm)
        nombre_adminis = adminis.nombre

        l = LogAdmin(fecha_accion=fecha, id_admin_accion=id_adm,
        nombre_admin_accion=nombre_adminis, detalles_accion=detalle)
        l.save()

    else:

        entra.statusT = 0
        entra.save()

        texto = "Deshabilito una transmision."
        detalle = texto
        fecha = datetime.now()
        id_adm = request.user.id_relacionado
        adminis = Administrador.objects.get(id_admin=id_adm)
        nombre_adminis = adminis.nombre

        l = LogAdmin(fecha_accion=fecha, id_admin_accion=id_adm,
        nombre_admin_accion=nombre_adminis, detalles_accion=detalle)
        l.save()


    return redirect('/transmisiones/')


@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def mostrar_opciones_transmision(request):

    request.session.set_expiry(request.session.get_expiry_age())

    idadmin = request.user.id_relacionado

    transmision = OpcionesTransmisiones.objects.all()

    usuario = Administrador.objects.filter(id_admin=idadmin)
    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    contexto ={'usuarios':usuario, 'transmisiones':transmision, 'datosPagina':datoPagina}

    return render(request, 'Admin/Extras/Transmisiones/opciones_transmision.html', contexto)


@csrf_exempt
@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def guardar_opciones_transmision(request):

    request.session.set_expiry(request.session.get_expiry_age())

    if request.method == "POST":

        dominioG = request.POST["dominio"]

        if dominioG:

            pass

        else:

            dominioG = "Ninguno"


        op = OpcionesTransmisiones.objects.get(id_opcionTransmision=1)
        op.dominio = dominioG
        op.save()


        texto = "Edito el dominio para las transmisiones a "
        texto2 = dominioG
        detalle = texto + texto2
        fecha = datetime.now()
        id_adm = request.user.id_relacionado
        adminis = Administrador.objects.get(id_admin=id_adm)
        nombre_adminis = adminis.nombre

        l = LogAdmin(fecha_accion=fecha, id_admin_accion=id_adm,
        nombre_admin_accion=nombre_adminis, detalles_accion=detalle)
        l.save()

        return redirect('/transmisiones/')


@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def mostrar_textos(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    idpagina = id

    texto = TextosPagina.objects.filter(id_empresaR=idpagina)
    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)

    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    contexto = {'textos':texto, 'usuarios':usuario, 'datosPagina':datoPagina, 'idpagina':idpagina}
    return render(request, 'Admin/Extras/Textos/textos_pagina.html', contexto)


@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def mostrar_agregar_texto(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    idpagina = id

    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)

    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    contexto = {'usuarios':usuario, 'datosPagina':datoPagina, 'idpagina':idpagina}
    return render(request, 'Admin/Extras/Textos/agregar_texto.html', contexto)


@csrf_exempt
@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def agregar_texto(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    if request.method == "POST":

        nombre = request.POST["titulo"]
        contenido = request.POST["descripcion"]

        idadmin = request.user.id_relacionado
        idpagina = id

        tp = TextosPagina(id_empresaR=idpagina, identificador=nombre, texto_guardado=contenido)
        tp.save()

        texto = "Registro un nuevo documento de texto para la empresa."
        detalle = texto
        fecha = datetime.now()
        id_adm = request.user.id_relacionado
        adminis = Administrador.objects.get(id_admin=id_adm)
        nombre_adminis = adminis.nombre

        l = LogAdmin(fecha_accion=fecha, id_admin_accion=id_adm,
        nombre_admin_accion=nombre_adminis, detalles_accion=detalle)
        l.save()

        ruta = '/textos/' + str(idpagina)
        return redirect(ruta)


@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def mostrar_editar_texto(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    idpagina = id

    texto = TextosPagina.objects.filter(id_textoPagina=idpagina)
    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)

    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    contexto = {'textos':texto, 'usuarios':usuario, 'datosPagina':datoPagina}
    return render(request, 'Admin/Extras/Textos/editar_texto.html', contexto)


@csrf_exempt
@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def editar_texto(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    if request.method == "POST":

        nombre = request.POST["titulo"]
        contenido = request.POST["descripcion"]

        idadmin = request.user.id_relacionado
        idpagina2 = id

        tp = TextosPagina.objects.get(id_textoPagina=idpagina2)
        idpagina = tp.id_empresaR
        tp.identificador = nombre
        tp.texto_guardado = contenido
        tp.save()

        texto = "Edito un documento de texto de una empresa."
        detalle = texto
        fecha = datetime.now()
        id_adm = request.user.id_relacionado
        adminis = Administrador.objects.get(id_admin=id_adm)
        nombre_adminis = adminis.nombre

        l = LogAdmin(fecha_accion=fecha, id_admin_accion=id_adm,
        nombre_admin_accion=nombre_adminis, detalles_accion=detalle)
        l.save()

        ruta = '/textos/' + str(idpagina)
        return redirect(ruta)


@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def mostrar_categorias(request):

    request.session.set_expiry(request.session.get_expiry_age())

    categoria = CursoCategoria.objects.all()
    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)

    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    contexto = {'categorias':categoria, 'usuarios':usuario, 'datosPagina':datoPagina}
    return render(request, 'Admin/Extras/Categorias/mostrar_categorias.html', contexto)


@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def mostrar_agregar_categoria(request):

    request.session.set_expiry(request.session.get_expiry_age())

    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)

    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    contexto = {'usuarios':usuario, 'datosPagina':datoPagina}
    return render(request, 'Admin/Extras/Categorias/agregar_categoria.html', contexto)


@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def mostrar_editar_categoria(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    idcategoria = id

    categoria = CursoCategoria.objects.filter(id_categoria=idcategoria)
    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)

    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    contexto = {'categorias':categoria, 'usuarios':usuario, 'datosPagina':datoPagina}
    return render(request, 'Admin/Extras/Categorias/editar_categoria.html', contexto)


@csrf_exempt
@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def agregar_categoria(request):

    request.session.set_expiry(request.session.get_expiry_age())

    if request.method == "POST":

        imagenperfil = request.FILES["imagencategoria"]
        nombre = request.POST["titulo"]

        nombreimagen = ""

        if imagenperfil :

            nombreimagen = secure_filename(imagenperfil.name)
            #fs = FileSystemStorage(location='ProyectoKaizen/static/media/Imagenes/Categorias')
            fs = FileSystemStorage(location= os.path.join(settings.MEDIA_ROOT+'/Imagenes/Categorias'))
            filenam = fs.save(nombreimagen, imagenperfil)

        idadmin = request.user.id_relacionado

        cc = CursoCategoria(nombre_categoria=nombre, ruta_imagen=nombreimagen, statusC=1)
        cc.save()

        texto = "Registro una nueva categoria para los cursos."
        detalle = texto
        fecha = datetime.now()
        id_adm = request.user.id_relacionado
        adminis = Administrador.objects.get(id_admin=id_adm)
        nombre_adminis = adminis.nombre

        l = LogAdmin(fecha_accion=fecha, id_admin_accion=id_adm,
        nombre_admin_accion=nombre_adminis, detalles_accion=detalle)
        l.save()

        return redirect('/categorias/')


@csrf_exempt
@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def editar_categoria(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    if request.method == "POST":

        try:
            imagenperfil = request.FILES["imagencategoria"]
        except Exception as e:
            imagenperfil = ""

        nombre = request.POST["titulo"]

        nombreimagen = ""
        idcategoria = id

        entra = CursoCategoria.objects.get(id_categoria=idcategoria)
        nombre_imagen = entra.ruta_imagen

        if imagenperfil :

            nombreimagen = secure_filename(imagenperfil.name)
            #fs = FileSystemStorage(location='ProyectoKaizen/static/media/Imagenes/Categorias')
            fs = FileSystemStorage(location= os.path.join(settings.MEDIA_ROOT+'/Imagenes/Categorias'))
            filenam = fs.save(nombreimagen, imagenperfil)

            os.remove(os.path.join(settings.MEDIA_ROOT+'/Imagenes/Categorias/' + nombre_imagen))


        cc = CursoCategoria.objects.get(id_categoria=idcategoria)
        cc.nombre_categoria = nombre

        if nombreimagen:

            cc.ruta_imagen = nombreimagen

        cc.save()

        texto = "Edito una categoria para los cursos."
        detalle = texto
        fecha = datetime.now()
        id_adm = request.user.id_relacionado
        adminis = Administrador.objects.get(id_admin=id_adm)
        nombre_adminis = adminis.nombre

        l = LogAdmin(fecha_accion=fecha, id_admin_accion=id_adm,
        nombre_admin_accion=nombre_adminis, detalles_accion=detalle)
        l.save()

        return redirect('/categorias/')


@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def eliminar_categoria(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    idcategoria = id

    entra = CursoCategoria.objects.get(id_categoria=idcategoria)
    estado = entra.statusC

    if estado == 0:

        entra.statusC = 1
        entra.save()

        texto = "Rehabilito una categoria."
        detalle = texto
        fecha = datetime.now()
        id_adm = request.user.id_relacionado
        adminis = Administrador.objects.get(id_admin=id_adm)
        nombre_adminis = adminis.nombre

        l = LogAdmin(fecha_accion=fecha, id_admin_accion=id_adm,
        nombre_admin_accion=nombre_adminis, detalles_accion=detalle)
        l.save()

    else:

        entra.statusC = 0
        entra.save()

        texto = "Deshabilito una categoria."
        detalle = texto
        fecha = datetime.now()
        id_adm = request.user.id_relacionado
        adminis = Administrador.objects.get(id_admin=id_adm)
        nombre_adminis = adminis.nombre

        l = LogAdmin(fecha_accion=fecha, id_admin_accion=id_adm,
        nombre_admin_accion=nombre_adminis, detalles_accion=detalle)
        l.save()


    return redirect('/categorias/')


@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def relacion_cursos_instructor(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    idinstructor = id

    filtro = CursoInstructor.objects.filter(id_instructorR=idinstructor).values('id_cursoR')
    curso = Curso.objects.filter(id_curso__in=filtro)
    instructor = Instructor.objects.filter(id_instructor=idinstructor)

    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)

    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    contexto = {'instructores':instructor, 'cursos':curso, 'usuarios':usuario, 'datosPagina':datoPagina}
    return render(request, 'Admin/Extras/Instructor/cursos_instructor.html', contexto)


@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def relacion_instructor_cursos(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    idcurso = id

    filtro = CursoInstructor.objects.filter(id_cursoR=idcurso).values('id_instructorR')
    curso = Curso.objects.filter(id_curso=idcurso)
    instructor = Instructor.objects.filter(id_instructor__in=filtro)

    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)

    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    contexto = {'instructores':instructor, 'cursos':curso, 'usuarios':usuario, 'datosPagina':datoPagina}
    return render(request, 'Admin/Extras/Curso/curso_instructor.html', contexto)


@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def mostrar_profesiones(request):

    request.session.set_expiry(request.session.get_expiry_age())

    profesion = Profesiones.objects.all()
    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)

    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    contexto = {'profesiones':profesion, 'usuarios':usuario, 'datosPagina':datoPagina}
    return render(request, 'Admin/Extras/Profesiones/profesiones.html', contexto)


@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def mostrar_agregar_profesion(request):

    request.session.set_expiry(request.session.get_expiry_age())

    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)

    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    contexto = {'usuarios':usuario, 'datosPagina':datoPagina}
    return render(request, 'Admin/Extras/Profesiones/crear_profesion.html', contexto)


@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def mostrar_editar_profesion(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    idprofesion = id

    profesion = Profesiones.objects.filter(id_profesion=idprofesion)
    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)

    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    contexto = {'profesiones':profesion, 'usuarios':usuario, 'datosPagina':datoPagina}
    return render(request, 'Admin/Extras/Profesiones/editar_profesion.html', contexto)


@csrf_exempt
@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def agregar_profesion(request):

    request.session.set_expiry(request.session.get_expiry_age())

    if request.method == "POST":

        nombre = request.POST["titulo"]

        idadmin = request.user.id_relacionado

        cc = Profesiones(nombre_profesion=nombre, status=1)
        cc.save()

        texto = "Registro una profesión nueva."
        detalle = texto
        fecha = datetime.now()
        id_adm = request.user.id_relacionado
        adminis = Administrador.objects.get(id_admin=id_adm)
        nombre_adminis = adminis.nombre

        l = LogAdmin(fecha_accion=fecha, id_admin_accion=id_adm,
        nombre_admin_accion=nombre_adminis, detalles_accion=detalle)
        l.save()

        return redirect('/profesiones/')


@csrf_exempt
@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def editar_profesion(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    if request.method == "POST":

        nombre = request.POST["titulo"]

        idprofesion = id

        cc = Profesiones.objects.get(id_profesion=idprofesion)
        cc.nombre_profesion = nombre
        cc.save()

        texto = "Edito una profesión."
        detalle = texto
        fecha = datetime.now()
        id_adm = request.user.id_relacionado
        adminis = Administrador.objects.get(id_admin=id_adm)
        nombre_adminis = adminis.nombre

        l = LogAdmin(fecha_accion=fecha, id_admin_accion=id_adm,
        nombre_admin_accion=nombre_adminis, detalles_accion=detalle)
        l.save()

        return redirect('/profesiones/')


@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def eliminar_profesion(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    idprofesion = id

    entra = Profesiones.objects.get(id_profesion=idprofesion)
    estado = entra.status

    if estado == 0:

        entra.status = 1
        entra.save()

        texto = "Rehabilito una profesión."
        detalle = texto
        fecha = datetime.now()
        id_adm = request.user.id_relacionado
        adminis = Administrador.objects.get(id_admin=id_adm)
        nombre_adminis = adminis.nombre

        l = LogAdmin(fecha_accion=fecha, id_admin_accion=id_adm,
        nombre_admin_accion=nombre_adminis, detalles_accion=detalle)
        l.save()

    else:

        entra.status = 0
        entra.save()

        texto = "Deshabilito una profesion."
        detalle = texto
        fecha = datetime.now()
        id_adm = request.user.id_relacionado
        adminis = Administrador.objects.get(id_admin=id_adm)
        nombre_adminis = adminis.nombre

        l = LogAdmin(fecha_accion=fecha, id_admin_accion=id_adm,
        nombre_admin_accion=nombre_adminis, detalles_accion=detalle)
        l.save()


    return redirect('/profesiones/')


@user_passes_test(identificar_administrador, login_url='/iniciar_sesion/')
@login_required(login_url='/iniciar_sesion/')
def mostrar_url(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    idcurso = id

    curso = Curso.objects.filter(id_curso=idcurso)
    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)

    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    contexto = {'cursos':curso, 'usuarios':usuario, 'datosPagina':datoPagina}
    return render(request, 'Admin/Extras/Curso/mostrar_url.html', contexto)




def cerrar_sesion_admin(request):

    logout(request)

    #return render(request, "Admin/inicio_sesion.html")
    return redirect('/iniciar_sesion/')





############################################################
############################################################
#inician vistas para alumnos

def cerrar_sesion_usuario(request):

    logout(request)

    #return render(request, "Principal/iniciar_sesion.html")
    return redirect('/iniciar_sesion/')



@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_estudiante, login_url='/iniciar_sesion/')
def reuniones_zoom(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    idalumno = request.user.id_relacionado

    opcion = OpcionesAlumno.objects.filter(id_alumnoR=idalumno)

    usuario = Alumno.objects.filter(id_alumno=idalumno)

    todaynoti = date.today()

    finnoti = todaynoti + timedelta(days=3)

    notificacion = NotificacionesAlumnos.objects.filter(id_alumnoR=idalumno, fecha_fin__range=[todaynoti, finnoti], statusN=0)

    numeronotificaciones = NotificacionesAlumnos.objects.filter(id_alumnoR=idalumno, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()

    horas = datetime.now()

    horamas = horas + timedelta(hours=2)

    horamass = horamas.time()

    horamenos = horas + timedelta(hours=-2)

    horamenoss = horamenos.time()

    cadena1 = str(horamenoss)
    cadena2 = str(horamass)

    fechados = todaynoti + timedelta(days=2)

    begin = datetime.strptime(cadena1, '%H:%M:%S.%f').time()
    end = datetime.strptime(cadena2, '%H:%M:%S.%f').time()

    transmision = TransmisionesInstructores.objects.filter(fecha_transmision=todaynoti, hora_transmision__range=[begin, end]).order_by('hora_transmision')[:1]

    #Filtro recientes
    idalumno = request.user.id_relacionado
    filtroR = CursoEstudiante.objects.filter(id_estudianteR=idalumno).values('id_cursoR')
    ultimo = Curso.objects.all().order_by('-fecha_registro')[:3]

    idconferencia = id

    conferencia = TransmisionesInstructores.objects.filter(id_transmisionInstructor=idconferencia)

    contexto = {'conferencias':conferencia, 'ultimos':ultimo, 'opciones':opcion, 'usuarios':usuario, 'notificaciones':notificacion, 'numeronotificaciones':numeronotificaciones,
    'transmisiones':transmision}

    return render(request, 'Alumno/Zoom/index.html', contexto)


@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_estudiante, login_url='/iniciar_sesion/')
def reunion_zoom(request):

    request.session.set_expiry(request.session.get_expiry_age())

    return render(request, 'Alumno/Zoom/meeting.html')

#Inician nuevas vistas transmisiones anteriores cursos

@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_estudiante, login_url='/iniciar_sesion/')
def transmisiones_anteriores_curso(request, id , id2):

    request.session.set_expiry(request.session.get_expiry_age())

    idalumno = request.user.id_relacionado

    opcion = OpcionesAlumno.objects.filter(id_alumnoR=idalumno)

    usuario = Alumno.objects.filter(id_alumno=idalumno)

    todaynoti = date.today()

    finnoti = todaynoti + timedelta(days=3)

    notificacion = NotificacionesAlumnos.objects.filter(id_alumnoR=idalumno, fecha_fin__range=[todaynoti, finnoti], statusN=0)

    numeronotificaciones = NotificacionesAlumnos.objects.filter(id_alumnoR=idalumno, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()

    fechauno = todaynoti + timedelta(days=-1825)
    fechados = todaynoti + timedelta(days=-1)

    idcurso = id
    idinstructor = id2

    curso = Curso.objects.filter(id_curso=idcurso)

    conferenciad = TransmisionesInstructoresAnteriores.objects.filter(id_cursoR=idcurso, id_instructorR=idinstructor).order_by('-fecha_completa')
    paginator = Paginator(conferenciad, 6)

    page_number = request.GET.get('page')
    conferencia = paginator.get_page(page_number)

    #Empieza consulta de transmision
    horas = datetime.now()

    horamas = horas + timedelta(hours=1)

    horamass = horamas.time()

    horamenos = horas + timedelta(hours=-1)

    horamenoss = horamenos.time()

    cadena1 = str(horamenoss)
    cadena2 = str(horamass)

    fechahoy = date.today()

    begin = datetime.strptime(cadena1, '%H:%M:%S.%f').time()
    end = datetime.strptime(cadena2, '%H:%M:%S.%f').time()

    Ctransmision = TransmisionesVivo.objects.filter(fecha_transmision=fechahoy, hora_transmision__range=[begin, end]).order_by('hora_transmision')[:1]

    Evivo = ""

    if Ctransmision:
        Evivo = "True"
    else:
        Evivo = "False"
    #Termina Consulta Transmision

    #Filtro recientes
    idalumno = request.user.id_relacionado
    filtroR = CursoEstudiante.objects.filter(id_estudianteR=idalumno).values('id_cursoR')
    ultimo = Curso.objects.all().order_by('-fecha_registro')[:3]

    contexto = {'cursos':curso, 'ultimos':ultimo, 'opciones':opcion, 'usuarios':usuario, 'notificaciones':notificacion, 'numeronotificaciones':numeronotificaciones,
    'conferencias':conferencia, 'Evivo':Evivo}

    return render(request, 'Alumno/Extras/ConferenciasAnteriores/emisiones_anteriores.html', contexto)



@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_estudiante, login_url='/iniciar_sesion/')
def mostrar_video_transmisiones_anteriores(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    idtransmision = id

    conferencia = TransmisionesInstructoresAnteriores.objects.filter(id_transmisionInstructorAnterior=idtransmision)

    for confe in conferencia:

        idcurso = confe.id_cursoR
        idinstructor = confe.id_instructorR

    curso = Curso.objects.filter(id_curso=idcurso)

    idalumno = request.user.id_relacionado

    opcion = OpcionesAlumno.objects.filter(id_alumnoR=idalumno)

    usuario = Alumno.objects.filter(id_alumno=idalumno)

    todaynoti = date.today()

    finnoti = todaynoti + timedelta(days=3)

    notificacion = NotificacionesAlumnos.objects.filter(id_alumnoR=idalumno, fecha_fin__range=[todaynoti, finnoti], statusN=0)

    numeronotificaciones = NotificacionesAlumnos.objects.filter(id_alumnoR=idalumno, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()

    #Empieza consulta de transmision
    horas = datetime.now()

    horamas = horas + timedelta(hours=1)

    horamass = horamas.time()

    horamenos = horas + timedelta(hours=-1)

    horamenoss = horamenos.time()

    cadena1 = str(horamenoss)
    cadena2 = str(horamass)

    fechahoy = date.today()

    begin = datetime.strptime(cadena1, '%H:%M:%S.%f').time()
    end = datetime.strptime(cadena2, '%H:%M:%S.%f').time()

    Ctransmision = TransmisionesVivo.objects.filter(fecha_transmision=fechahoy, hora_transmision__range=[begin, end]).order_by('hora_transmision')[:1]

    Evivo = ""

    if Ctransmision:
        Evivo = "True"
    else:
        Evivo = "False"
    #Termina Consulta Transmision

    #Filtro recientes
    idalumno = request.user.id_relacionado
    filtroR = CursoEstudiante.objects.filter(id_estudianteR=idalumno).values('id_cursoR')
    ultimo = Curso.objects.all().order_by('-fecha_registro')[:3]

    contexto = {'idcurso':idcurso, 'idinstructor':idinstructor, 'cursos':curso, 'ultimos':ultimo, 'opciones':opcion, 'usuarios':usuario, 'notificaciones':notificacion, 'numeronotificaciones':numeronotificaciones,
    'conferencias':conferencia, 'Evivo':Evivo}

    return render(request, 'Alumno/Extras/ConferenciasAnteriores/mostrar_video.html', contexto)



#Terminan nuevas vistas transmisiones anteriores cursos


@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_estudiante, login_url='/iniciar_sesion/')
def mostrar_transmision_curso(request, id, id2):

    request.session.set_expiry(request.session.get_expiry_age())

    idcurso = id
    idinstructor = id2

    idalumno = request.user.id_relacionado

    opcion = OpcionesAlumno.objects.filter(id_alumnoR=idalumno)

    usuario = Alumno.objects.filter(id_alumno=idalumno)

    todaynoti = date.today()

    finnoti = todaynoti + timedelta(days=3)

    notificacion = NotificacionesAlumnos.objects.filter(id_alumnoR=idalumno, fecha_fin__range=[todaynoti, finnoti], statusN=0)

    numeronotificaciones = NotificacionesAlumnos.objects.filter(id_alumnoR=idalumno, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()

    horas = datetime.now()

    horamas = horas + timedelta(hours=2)

    horamass = horamas.time()

    horamenos = horas + timedelta(hours=-2)

    horamenoss = horamenos.time()

    cadena1 = str(horamenoss)
    cadena2 = str(horamass)

    fechados = todaynoti + timedelta(days=2)

    begin = datetime.strptime(cadena1, '%H:%M:%S.%f').time()
    end = datetime.strptime(cadena2, '%H:%M:%S.%f').time()

    transmision = TransmisionesInstructores.objects.filter(fecha_transmision=todaynoti, hora_transmision__range=[begin, end]).order_by('hora_transmision')[:1]

    #Filtro recientes
    idalumno = request.user.id_relacionado
    filtroR = CursoEstudiante.objects.filter(id_estudianteR=idalumno).values('id_cursoR')
    ultimo = Curso.objects.all().order_by('-fecha_registro')[:3]

    #Consultas conferencias
    conferencia = TransmisionesInstructores.objects.filter(id_instructorR=idinstructor, id_cursoR=idcurso, fecha_transmision__gte=todaynoti).order_by('fecha_completa')

    contexto = {'conferencias':conferencia, 'ultimos':ultimo, 'opciones':opcion, 'usuarios':usuario, 'notificaciones':notificacion, 'numeronotificaciones':numeronotificaciones,
    'transmisiones':transmision}

    return render(request, 'Alumno/Extras/Conferencias/transmision_curso.html', contexto)


@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_estudiante, login_url='/iniciar_sesion/')
def mostrar_transmision(request):

    request.session.set_expiry(request.session.get_expiry_age())

    idalumno = request.user.id_relacionado

    opcion = OpcionesAlumno.objects.filter(id_alumnoR=idalumno)

    usuario = Alumno.objects.filter(id_alumno=idalumno)

    todaynoti = date.today()

    finnoti = todaynoti + timedelta(days=3)

    notificacion = NotificacionesAlumnos.objects.filter(id_alumnoR=idalumno, fecha_fin__range=[todaynoti, finnoti], statusN=0)

    numeronotificaciones = NotificacionesAlumnos.objects.filter(id_alumnoR=idalumno, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()

    horas = datetime.now()

    horamas = horas + timedelta(hours=2)

    horamass = horamas.time()

    horamenos = horas + timedelta(hours=-2)

    horamenoss = horamenos.time()

    cadena1 = str(horamenoss)
    cadena2 = str(horamass)

    fechados = todaynoti + timedelta(days=2)

    begin = datetime.strptime(cadena1, '%H:%M:%S.%f').time()
    end = datetime.strptime(cadena2, '%H:%M:%S.%f').time()

    Evivo = ""

    try:
        transmision = TransmisionesVivo.objects.filter(fecha_transmision=todaynoti, hora_transmision__range=[begin, end]).order_by('hora_transmision')[:1]

    except Exception as e:
        transmision = ""

    if transmision:
        Evivo = "True"
    else:
        Evivo = "False"

    conferencia = TransmisionesVivo.objects.filter(fecha_transmision=todaynoti).order_by('hora_transmision')
    recurso = TransmisionesVivo.objects.filter(fecha_transmision=todaynoti).order_by('hora_transmision')[:1]

    if conferencia:
        pass

    else:
        conferencia = TransmisionesVivo.objects.filter(fecha_transmision__range=[todaynoti, fechados]).order_by('hora_transmision')
        recurso = TransmisionesVivo.objects.filter(fecha_transmision__range=[todaynoti, fechados]).order_by('hora_transmision')[:1]


    op = OpcionesTransmisiones.objects.get(id_opcionTransmision=1)
    dominioG = op.dominio

    #Filtro recientes
    idalumno = request.user.id_relacionado
    filtroR = CursoEstudiante.objects.filter(id_estudianteR=idalumno).values('id_cursoR')
    ultimo = Curso.objects.all().order_by('-fecha_registro')[:3]

    contexto = {'ultimos':ultimo, 'opciones':opcion, 'usuarios':usuario, 'notificaciones':notificacion, 'numeronotificaciones':numeronotificaciones,
    'transmisiones':transmision, 'conferencias':conferencia, 'recursos':recurso, 'dominioG':dominioG, 'Evivo':Evivo}

    return render(request, 'Alumno/Extras/Transmisiones/transmision_vivo.html', contexto)


@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_estudiante, login_url='/iniciar_sesion/')
def emisiones_anteriores(request):

    request.session.set_expiry(request.session.get_expiry_age())

    idalumno = request.user.id_relacionado

    opcion = OpcionesAlumno.objects.filter(id_alumnoR=idalumno)

    usuario = Alumno.objects.filter(id_alumno=idalumno)

    todaynoti = date.today()

    finnoti = todaynoti + timedelta(days=3)

    notificacion = NotificacionesAlumnos.objects.filter(id_alumnoR=idalumno, fecha_fin__range=[todaynoti, finnoti], statusN=0)

    numeronotificaciones = NotificacionesAlumnos.objects.filter(id_alumnoR=idalumno, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()

    fechauno = todaynoti + timedelta(days=-1825)
    fechados = todaynoti + timedelta(days=-1)

    conferenciad = TransmisionesVivo.objects.filter(fecha_transmision__range=[fechauno, fechados]).order_by('-fecha_completa')
    paginator = Paginator(conferenciad, 6)

    page_number = request.GET.get('page')
    conferencia = paginator.get_page(page_number)

    #Empieza consulta de transmision
    horas = datetime.now()

    horamas = horas + timedelta(hours=1)

    horamass = horamas.time()

    horamenos = horas + timedelta(hours=-1)

    horamenoss = horamenos.time()

    cadena1 = str(horamenoss)
    cadena2 = str(horamass)

    fechahoy = date.today()

    begin = datetime.strptime(cadena1, '%H:%M:%S.%f').time()
    end = datetime.strptime(cadena2, '%H:%M:%S.%f').time()

    Ctransmision = TransmisionesVivo.objects.filter(fecha_transmision=fechahoy, hora_transmision__range=[begin, end]).order_by('hora_transmision')[:1]

    Evivo = ""

    if Ctransmision:
        Evivo = "True"
    else:
        Evivo = "False"
    #Termina Consulta Transmision

    #Filtro recientes
    idalumno = request.user.id_relacionado
    filtroR = CursoEstudiante.objects.filter(id_estudianteR=idalumno).values('id_cursoR')
    ultimo = Curso.objects.all().order_by('-fecha_registro')[:3]

    contexto = {'ultimos':ultimo, 'opciones':opcion, 'usuarios':usuario, 'notificaciones':notificacion, 'numeronotificaciones':numeronotificaciones,
    'conferencias':conferencia, 'Evivo':Evivo}

    return render(request, 'Alumno/Extras/Transmisiones/emisiones_anteriores.html', contexto)



@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_estudiante, login_url='/iniciar_sesion/')
def mostrar_video(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    idtransmision = id

    conferencia = TransmisionesVivo.objects.filter(id_transmision=idtransmision)

    idalumno = request.user.id_relacionado

    opcion = OpcionesAlumno.objects.filter(id_alumnoR=idalumno)

    usuario = Alumno.objects.filter(id_alumno=idalumno)

    todaynoti = date.today()

    finnoti = todaynoti + timedelta(days=3)

    notificacion = NotificacionesAlumnos.objects.filter(id_alumnoR=idalumno, fecha_fin__range=[todaynoti, finnoti], statusN=0)

    numeronotificaciones = NotificacionesAlumnos.objects.filter(id_alumnoR=idalumno, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()

    #Empieza consulta de transmision
    horas = datetime.now()

    horamas = horas + timedelta(hours=1)

    horamass = horamas.time()

    horamenos = horas + timedelta(hours=-1)

    horamenoss = horamenos.time()

    cadena1 = str(horamenoss)
    cadena2 = str(horamass)

    fechahoy = date.today()

    begin = datetime.strptime(cadena1, '%H:%M:%S.%f').time()
    end = datetime.strptime(cadena2, '%H:%M:%S.%f').time()

    Ctransmision = TransmisionesVivo.objects.filter(fecha_transmision=fechahoy, hora_transmision__range=[begin, end]).order_by('hora_transmision')[:1]

    Evivo = ""

    if Ctransmision:
        Evivo = "True"
    else:
        Evivo = "False"
    #Termina Consulta Transmision

    contexto = {'opciones':opcion, 'usuarios':usuario, 'notificaciones':notificacion, 'numeronotificaciones':numeronotificaciones,
    'conferencias':conferencia, 'Evivo':Evivo}

    return render(request, 'Alumno/Extras/Transmisiones/mostrar_video.html', contexto)


@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_estudiante, login_url='/iniciar_sesion/')
def mostrar_evaluacion_alumno(request, id, id2):

    request.session.set_expiry(request.session.get_expiry_age())

    idevaluacion = id
    tipoeva = id2

    tipo = ""

    idalumno = request.user.id_relacionado

    if tipoeva == 1:

        tipo = "Instructor"
        evaluacion = EvaluacionServicioInstructor.objects.filter(id_evaluacionServicioI=idevaluacion)

    elif tipoeva == 2:

        tipo = "Curso"
        evaluacion = EvaluacionServicioCurso.objects.filter(id_evaluacionServicioC=idevaluacion)

    else:

        tipo = "Otro"
        evaluacion = EvaluacionServicioOtro.objects.filter(id_evaluacionServicioO=idevaluacion)

    opcion = OpcionesAlumno.objects.filter(id_alumnoR=idalumno)

    usuario = Alumno.objects.filter(id_alumno=idalumno)

    fechahoy = date.today()

    todaynoti = date.today()

    finnoti = todaynoti + timedelta(days=3)

    notificacion = NotificacionesAlumnos.objects.filter(id_alumnoR=idalumno, fecha_fin__range=[todaynoti, finnoti], statusN=0)

    numeronotificaciones = NotificacionesAlumnos.objects.filter(id_alumnoR=idalumno, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()

    #Empieza consulta de transmision
    horas = datetime.now()

    horamas = horas + timedelta(hours=1)

    horamass = horamas.time()

    horamenos = horas + timedelta(hours=-1)

    horamenoss = horamenos.time()

    cadena1 = str(horamenoss)
    cadena2 = str(horamass)

    fechahoy = date.today()

    begin = datetime.strptime(cadena1, '%H:%M:%S.%f').time()
    end = datetime.strptime(cadena2, '%H:%M:%S.%f').time()

    Ctransmision = TransmisionesVivo.objects.filter(fecha_transmision=fechahoy, hora_transmision__range=[begin, end]).order_by('hora_transmision')[:1]

    Evivo = ""

    if Ctransmision:
        Evivo = "True"
    else:
        Evivo = "False"
    #Termina Consulta Transmision

    #Filtro recientes
    idalumno = request.user.id_relacionado
    filtroR = CursoEstudiante.objects.filter(id_estudianteR=idalumno).values('id_cursoR')
    ultimo = Curso.objects.all().order_by('-fecha_registro')[:3]

    contexto = {'ultimos':ultimo, 'evaluaciones':evaluacion, 'tipo':tipo, 'opciones':opcion, 'usuarios':usuario, 'fechahoy':fechahoy,
    'notificaciones':notificacion, 'numeronotificaciones':numeronotificaciones, 'Evivo':Evivo}

    opci = OpcionesAlumno.objects.get(id_alumnoR=idalumno)

    plantilla = opci.tipo_plantilla

    if plantilla == "_barra":

        return render(request, 'Alumno/Extras/General/mostrar_evaluacion_barra.html', contexto)

    else:

        return render(request, 'Alumno/Extras/General/mostrar_evaluacion_boton.html', contexto)


@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_estudiante, login_url='/iniciar_sesion/')
def presentar_evaluacion(request, id, id2, id3):

    request.session.set_expiry(request.session.get_expiry_age())

    idtipoevaluacion = id
    idevaluacion = id2
    tipoeva = id3

    idalumno = request.user.id_relacionado

    if tipoeva == 1:

        tipo = "Instructor"
        evaluacion = EvaluacionServicioInstructor.objects.filter(id_evaluacionServicioI=idtipoevaluacion)
        pregunta = PreguntasEvaluacionServicio.objects.filter(id_EvaluacionServicioR=idevaluacion)

    elif tipoeva == 2:

        tipo = "Curso"
        evaluacion = EvaluacionServicioCurso.objects.filter(id_evaluacionServicioC=idtipoevaluacion)
        pregunta = PreguntasEvaluacionServicio.objects.filter(id_EvaluacionServicioR=idevaluacion)

    else:

        tipo = "Otro"
        evaluacion = EvaluacionServicioOtro.objects.filter(id_evaluacionServicioO=idtipoevaluacion)
        pregunta = PreguntasEvaluacionServicio.objects.filter(id_EvaluacionServicioR=idevaluacion)

    opcion = OpcionesAlumno.objects.filter(id_alumnoR=idalumno)

    usuario = Alumno.objects.filter(id_alumno=idalumno)

    fechahoy = date.today()

    todaynoti = date.today()

    finnoti = todaynoti + timedelta(days=3)

    notificacion = NotificacionesAlumnos.objects.filter(id_alumnoR=idalumno, fecha_fin__range=[todaynoti, finnoti], statusN=0)

    numeronotificaciones = NotificacionesAlumnos.objects.filter(id_alumnoR=idalumno, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()

    #Empieza consulta de transmision
    horas = datetime.now()

    horamas = horas + timedelta(hours=1)

    horamass = horamas.time()

    horamenos = horas + timedelta(hours=-1)

    horamenoss = horamenos.time()

    cadena1 = str(horamenoss)
    cadena2 = str(horamass)

    fechahoy = date.today()

    begin = datetime.strptime(cadena1, '%H:%M:%S.%f').time()
    end = datetime.strptime(cadena2, '%H:%M:%S.%f').time()

    Ctransmision = TransmisionesVivo.objects.filter(fecha_transmision=fechahoy, hora_transmision__range=[begin, end]).order_by('hora_transmision')[:1]

    Evivo = ""

    if Ctransmision:
        Evivo = "True"
    else:
        Evivo = "False"
    #Termina Consulta Transmision

    #Filtro recientes
    idalumno = request.user.id_relacionado
    filtroR = CursoEstudiante.objects.filter(id_estudianteR=idalumno).values('id_cursoR')
    ultimo = Curso.objects.all().order_by('-fecha_registro')[:3]

    contexto = {'ultimos':ultimo, 'evaluaciones':evaluacion, 'tipo':tipo, 'preguntas':pregunta, 'opciones':opcion, 'usuarios':usuario, 'fechahoy':fechahoy,
    'notificaciones':notificacion, 'numeronotificaciones':numeronotificaciones, 'Evivo':Evivo}

    opci = OpcionesAlumno.objects.get(id_alumnoR=idalumno)

    plantilla = opci.tipo_plantilla

    if plantilla == "_barra":

        return render(request, 'Alumno/Extras/General/presentar_evaluacion_barra.html', contexto)

    else:

        return render(request, 'Alumno/Extras/General/presentar_evaluacion_boton.html', contexto)



@csrf_exempt
@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_estudiante, login_url='/iniciar_sesion/')
def entregar_evaluacion(request, id, id2):

    request.session.set_expiry(request.session.get_expiry_age())

    if request.method == "POST":

        respuestas = []
        preguntas = []
        idevaluacion = id
        tipo = id2
        cadenarespuestas = ""

        idalumno = request.user.id_relacionado

        if tipo == 1:

            tipo2 = "Instructor"
            ee = EvaluacionServicioInstructor.objects.get(id_evaluacionServicioI=idevaluacion)
            idevaluacionS = ee.id_EvaluacionServicioR
            idevaluadoS = ee.id_instructorR
            nombreevaluadoS = ee.nombre_instructorEva

        elif tipo == 2:

            tipo2 = "Curso"
            ee = EvaluacionServicioCurso.objects.get(id_evaluacionServicioC=idevaluacion)
            idevaluacionS = ee.id_EvaluacionServicioR
            idevaluadoS = ee.id_cursoR
            nombreevaluadoS = ee.nombre_cursoEva

        else:

            tipo2 = "Otro"
            ee = EvaluacionServicioOtro.objects.get(id_evaluacionServicioO=idevaluacion)
            idevaluacionS = ee.id_EvaluacionServicioR
            idevaluadoS = 0
            nombreevaluadoS = ee.nombre_otroEva


        examenes = PreguntasEvaluacionServicio.objects.filter(id_EvaluacionServicioR=idevaluacionS)

        for examen in examenes:

            nombre = "respuesta" + str(examen.id_PreguntaEvaluacionServicio)

            try:
                valor = request.POST[nombre]
            except Exception as e:
                valor = ""

            respuestas.append(valor)


        puntajeasignado = 0

        for x in range(0,len(respuestas)):

            puntajeasignado = puntajeasignado + int(respuestas[x])

            if cadenarespuestas == "":

                cadenarespuestas = cadenarespuestas + str(respuestas[x])

            else:

                cadenarespuestas = cadenarespuestas + "," + str(respuestas[x])


        total1 = PreguntasEvaluacionServicio.objects.filter(id_EvaluacionServicioR=idevaluacionS).count()

        total2 = (total1*5)

        calificacion = (puntajeasignado * 10)/total2


        es = EvaluacionSEstudiante(id_evalucionServicioR=idevaluacion, id_estudianteR=idalumno,
        respuestas=cadenarespuestas, resultadoE=calificacion, tipo_evaluacion=tipo2, id_evaluado=idevaluadoS, nombre_evaluado=nombreevaluadoS)
        es.save()


        if tipo == 1:

            eee = EvaluacionServicioInstructor.objects.get(id_evaluacionServicioI=idevaluacion)
            califi = eee.calificacion

            if califi == 0:

                eee.calificacion = calificacion
                eee.save()

            else:

                totaltotal = (califi + calificacion)/2
                eee.calificacion = totaltotal
                eee.save()


        elif tipo == 2:

            eee = EvaluacionServicioCurso.objects.get(id_evaluacionServicioC=idevaluacion)
            califi = eee.calificacion

            if califi == 0:

                eee.calificacion = calificacion
                eee.save()

            else:

                totaltotal = (califi + calificacion)/2
                eee.calificacion = totaltotal
                eee.save()

        else:

            eee = EvaluacionServicioOtro.objects.get(id_evaluacionServicioO=idevaluacion)
            califi = eee.calificacion

            if califi == 0:

                eee.calificacion = calificacion
                eee.save()

            else:

                totaltotal = (califi + calificacion)/2
                eee.calificacion = totaltotal
                eee.save()


        return redirect('/inicio_alumno/')


@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_estudiante, login_url='/iniciar_sesion/')
def mostrar_index_alumno(request):

    request.session.set_expiry(request.session.get_expiry_age())

    idalumno = request.user.id_relacionado

    #Empieza actualizador de promedios
    actividades = ActividadAlumno.objects.filter(id_alumnoR=idalumno)
    examenes = EvaluacionCursosEstudiante.objects.filter(id_estudianteR=idalumno)

    filtro = CursoEstudiante.objects.filter(id_estudianteR=idalumno).values('id_cursoR')

    curses = Curso.objects.filter(id_curso__in=filtro)

    for curse in curses:

        idcurso = curse.id_curso
        calificaciones = []

        for actividad in actividades:

            if idcurso == actividad.id_cursoR:

                calificaciones.append(actividad.calificacion)

        for examen in examenes:

            if idcurso == examen.id_cursoR:

                calificaciones.append(examen.resultadoE)

        total_evaluaciones = len(calificaciones)
        total_calificaciones = 0
        promedio_final = 0

        if total_evaluaciones == 0:

            pass

        else:

            for x in range(0,len(calificaciones)):

                total_calificaciones = total_calificaciones + calificaciones[x]


            promedio_final = total_calificaciones/total_evaluaciones

        cursi = CursoEstudiante.objects.get(id_estudianteR=idalumno, id_cursoR=idcurso)
        cursi.promedio_curso = promedio_final
        cursi.save()
    #Termina actulizador de promedios


    filtro = CursoEstudiante.objects.filter(id_estudianteR=idalumno).values('id_cursoR')

    filtro2 = CursoEstudiante.objects.filter(id_estudianteR=idalumno).values('id_instructorRC')

    filtro3 = ActividadAlumno.objects.filter(id_cursoR__in=filtro, id_alumnoR=idalumno).values('id_actividadR')

    filtro4 = EvaluacionCursosEstudiante.objects.filter(id_cursoR__in=filtro, id_estudianteR=idalumno, id_instructorR__in=filtro2).values('id_evaluacionCursoR')

    curso = Curso.objects.filter(id_curso__in=filtro)

    valor = CursoEstudiante.objects.filter(id_estudianteR=idalumno)

    actividadE = Actividad.objects.filter(id_cursoR__in=filtro, id_instructorR__in=filtro2).exclude(id_actividad__in=filtro3)

    examenE = EvaluacionesCursos.objects.filter(id_cursoR__in=filtro, id_instructorR__in=filtro2).exclude(id_evalucionCurso__in=filtro4)

    opcion = OpcionesAlumno.objects.filter(id_alumnoR=idalumno)

    usuario = Alumno.objects.filter(id_alumno=idalumno)


    todaynoti = date.today()

    finnoti = todaynoti + timedelta(days=3)

    notificacion = NotificacionesAlumnos.objects.filter(id_alumnoR=idalumno, fecha_fin__range=[todaynoti, finnoti], statusN=0)

    numeronotificaciones = NotificacionesAlumnos.objects.filter(id_alumnoR=idalumno, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()

    alumnoeva = EvaluacionSEstudiante.objects.filter(id_estudianteR=idalumno)

    evaluacionI = EvaluacionServicioInstructor.objects.all()

    evaluacionC = EvaluacionServicioCurso.objects.all()

    evaluacionO = EvaluacionServicioOtro.objects.all()

    fechados = todaynoti + timedelta(days=7)

    filtroC = CursoEstudiante.objects.filter(id_estudianteR=idalumno).values('id_cursoR')

    transmision = TransmisionesInstructores.objects.filter(id_cursoR__in=filtroC, fecha_transmision__range=[todaynoti, fechados])

    #Empieza consulta de transmision
    horas = datetime.now()

    horamas = horas + timedelta(hours=1)

    horamass = horamas.time()

    horamenos = horas + timedelta(hours=-1)

    horamenoss = horamenos.time()

    cadena1 = str(horamenoss)
    cadena2 = str(horamass)

    fechahoy = date.today()

    begin = datetime.strptime(cadena1, '%H:%M:%S.%f').time()
    end = datetime.strptime(cadena2, '%H:%M:%S.%f').time()

    Ctransmision = TransmisionesVivo.objects.filter(fecha_transmision=fechahoy, hora_transmision__range=[begin, end]).order_by('hora_transmision')[:1]

    Evivo = ""

    if Ctransmision:
        Evivo = "True"
    else:
        Evivo = "False"
    #Termina Consulta Transmision

    #Filtro recientes
    idalumno = request.user.id_relacionado
    filtroR = CursoEstudiante.objects.filter(id_estudianteR=idalumno).values('id_cursoR')
    ultimo = Curso.objects.all().order_by('-fecha_registro')[:3]

    contexto = {'ultimos':ultimo, 'cursos':curso, 'valores':valor, 'actividadesE':actividadE, 'examenesE':examenE,
    'opciones':opcion, 'usuarios':usuario, 'notificaciones':notificacion,
    'numeronotificaciones':numeronotificaciones, 'alumnoevas':alumnoeva,
    'evaluacionesI':evaluacionI, 'evaluacionesC':evaluacionC, 'evaluacionesO':evaluacionO,
    'transmisiones':transmision, 'Evivo':Evivo}

    opci = OpcionesAlumno.objects.get(id_alumnoR=idalumno)

    plantilla = opci.tipo_plantilla

    if plantilla == "_barra":

        return render(request, 'Alumno/alumno_index_barra.html', contexto)

    else:

        return render(request, 'Alumno/alumno_index_boton.html', contexto)



@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_estudiante, login_url='/iniciar_sesion/')
def mostrar_cursos_alumno(request):

    request.session.set_expiry(request.session.get_expiry_age())

    idalumno = request.user.id_relacionado

    #Empieza actualizador de promedios
    actividades = ActividadAlumno.objects.filter(id_alumnoR=idalumno)
    examenes = EvaluacionCursosEstudiante.objects.filter(id_estudianteR=idalumno)

    filtro = CursoEstudiante.objects.filter(id_estudianteR=idalumno).values('id_cursoR')

    curses = Curso.objects.filter(id_curso__in=filtro)

    for curse in curses:

        idcurso = curse.id_curso
        calificaciones = []

        for actividad in actividades:

            if idcurso == actividad.id_cursoR:

                calificaciones.append(actividad.calificacion)

        for examen in examenes:

            if idcurso == examen.id_cursoR:

                calificaciones.append(examen.resultadoE)

        total_evaluaciones = len(calificaciones)
        total_calificaciones = 0
        promedio_final = 0

        if total_evaluaciones == 0:

            pass

        else:

            for x in range(0,len(calificaciones)):

                total_calificaciones = total_calificaciones + calificaciones[x]


            promedio_final = total_calificaciones/total_evaluaciones

        cursi = CursoEstudiante.objects.get(id_estudianteR=idalumno, id_cursoR=idcurso)
        cursi.promedio_curso = promedio_final
        cursi.save()
    #Termina actulizador de promedios

    filtro = CursoEstudiante.objects.filter(id_estudianteR=idalumno).values('id_cursoR')

    curso = Curso.objects.filter(id_curso__in=filtro)

    valor = CursoEstudiante.objects.filter(id_estudianteR=idalumno)

    opcion = OpcionesAlumno.objects.filter(id_alumnoR=idalumno)

    usuario = Alumno.objects.filter(id_alumno=idalumno)

    todaynoti = date.today()

    finnoti = todaynoti + timedelta(days=3)

    notificacion = NotificacionesAlumnos.objects.filter(id_alumnoR=idalumno, fecha_fin__range=[todaynoti, finnoti], statusN=0)

    numeronotificaciones = NotificacionesAlumnos.objects.filter(id_alumnoR=idalumno, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()

    #Empieza consulta de transmision
    horas = datetime.now()

    horamas = horas + timedelta(hours=1)

    horamass = horamas.time()

    horamenos = horas + timedelta(hours=-1)

    horamenoss = horamenos.time()

    cadena1 = str(horamenoss)
    cadena2 = str(horamass)

    fechahoy = date.today()

    begin = datetime.strptime(cadena1, '%H:%M:%S.%f').time()
    end = datetime.strptime(cadena2, '%H:%M:%S.%f').time()

    Ctransmision = TransmisionesVivo.objects.filter(fecha_transmision=fechahoy, hora_transmision__range=[begin, end]).order_by('hora_transmision')[:1]

    Evivo = ""

    if Ctransmision:
        Evivo = "True"
    else:
        Evivo = "False"
    #Termina Consulta Transmision

    #Filtro recientes
    idalumno = request.user.id_relacionado
    filtroR = CursoEstudiante.objects.filter(id_estudianteR=idalumno).values('id_cursoR')
    ultimo = Curso.objects.all().order_by('-fecha_registro')[:3]

    contexto = {'ultimos':ultimo, 'cursos':curso, 'valores':valor, 'opciones':opcion, 'usuarios':usuario,
    'notificaciones':notificacion, 'numeronotificaciones':numeronotificaciones, 'Evivo':Evivo}

    opci = OpcionesAlumno.objects.get(id_alumnoR=idalumno)

    plantilla = opci.tipo_plantilla

    if plantilla == "_barra":

        return render(request, 'Alumno/Extras/Cursos/mostrar_cursos_barra.html', contexto)

    else:

        return render(request, 'Alumno/Extras/Cursos/mostrar_cursos_boton.html', contexto)



def tomar_curso_libre(request, id, id2):

    request.session.set_expiry(request.session.get_expiry_age())

    idcurso = id
    idinstructor = id2

    curso = Curso.objects.filter(id_curso=idcurso)

    unidad = Unidades.objects.filter(id_cursoR=idcurso, id_instructorR=idinstructor)

    unidadU = Unidades.objects.filter(id_cursoR=idcurso, id_instructorR=idinstructor).order_by('id_unidad').all()[:1]

    contexto = {'cursos':curso, 'unidades':unidad, 'unidadesU':unidadU}

    return render(request, 'Alumno/Extras/General/tomar_curso_libre.html', contexto)


def tomar_curso_libre_reload(request, id, id2, id3):

    request.session.set_expiry(request.session.get_expiry_age())

    idcurso = id
    idinstructor = id2
    idunidad = id3

    curso = Curso.objects.filter(id_curso=idcurso)

    unidad = Unidades.objects.filter(id_cursoR=idcurso, id_instructorR=idinstructor)

    unidadU = Unidades.objects.filter(id_unidad=idunidad)

    contexto = {'cursos':curso, 'unidades':unidad, 'unidadesU':unidadU}

    return render(request, 'Alumno/Extras/General/tomar_curso_libre.html', contexto)


def asignar_valoracion(request, id, id2):

    request.session.set_expiry(request.session.get_expiry_age())

    valor = id
    idcurso = id2
    idalumno = request.user.id_relacionado

    cur = Curso.objects.get(id_curso=idcurso)
    val = cur.valoracion

    if val == 0:

        cur.valoracion = valor
        cur.save()

    else:

        total = (int(val) + int(valor))/2
        cur.valoracion = total
        cur.save()


    va = CursoEstudiante.objects.get(id_estudianteR=idalumno, id_cursoR=idcurso)
    va.valoracion_curso = valor
    va.save()


    return HttpResponse('Calificado')


@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_estudiante, login_url='/iniciar_sesion/')
def tomar_curso(request, id, id2):

    request.session.set_expiry(request.session.get_expiry_age())

    idcurso = id
    idinstructor = id2

    idalumno = request.user.id_relacionado

    curso = Curso.objects.filter(id_curso=idcurso)

    unidad = Unidades.objects.filter(id_cursoR=idcurso, id_instructorR=idinstructor)

    actividad = Actividad.objects.filter(id_cursoR=idcurso, id_instructorR=idinstructor)

    examen = EvaluacionesCursos.objects.filter(id_cursoR=idcurso, id_instructorR=idinstructor)

    unidadU = Unidades.objects.filter(id_cursoR=idcurso, id_instructorR=idinstructor).order_by('id_unidad').all()[:1]

    filtro3 = ActividadAlumno.objects.filter(id_cursoR=idcurso, id_alumnoR=idalumno).values('id_actividadR')

    filtro4 = EvaluacionCursosEstudiante.objects.filter(id_cursoR=idcurso, id_estudianteR=idalumno, id_instructorR=idinstructor).values('id_evaluacionCursoR')

    # Actividades y Examenes Pendientes
    actividadE = Actividad.objects.filter(id_cursoR=idcurso, id_instructorR=idinstructor).exclude(id_actividad__in=filtro3)

    examenE = EvaluacionesCursos.objects.filter(id_cursoR=idcurso, id_instructorR=idinstructor).exclude(id_evalucionCurso__in=filtro4)

    # Actividades y Examenes Entregados
    actividadA = Actividad.objects.filter(id_cursoR=idcurso, id_instructorR=idinstructor, id_actividad__in=filtro3)

    examenA = EvaluacionesCursos.objects.filter(id_cursoR=idcurso, id_instructorR=idinstructor, id_evalucionCurso__in=filtro4)

    opcion = OpcionesAlumno.objects.filter(id_alumnoR=idalumno)

    usuario = Alumno.objects.filter(id_alumno=idalumno)

    todaynoti = date.today()

    finnoti = todaynoti + timedelta(days=3)

    notificacion = NotificacionesAlumnos.objects.filter(id_alumnoR=idalumno, fecha_fin__range=[todaynoti, finnoti], statusN=0)

    numeronotificaciones = NotificacionesAlumnos.objects.filter(id_alumnoR=idalumno, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()

    #Empieza consulta de transmision
    horas = datetime.now()

    horamas = horas + timedelta(hours=1)

    horamass = horamas.time()

    horamenos = horas + timedelta(hours=-1)

    horamenoss = horamenos.time()

    cadena1 = str(horamenoss)
    cadena2 = str(horamass)

    fechahoy = date.today()

    begin = datetime.strptime(cadena1, '%H:%M:%S.%f').time()
    end = datetime.strptime(cadena2, '%H:%M:%S.%f').time()

    Ctransmision = TransmisionesVivo.objects.filter(fecha_transmision=fechahoy, hora_transmision__range=[begin, end]).order_by('hora_transmision')[:1]

    Evivo = ""

    if Ctransmision:
        Evivo = "True"
    else:
        Evivo = "False"
    #Termina Consulta Transmision

    #Filtro recientes
    idalumno = request.user.id_relacionado
    filtroR = CursoEstudiante.objects.filter(id_estudianteR=idalumno).values('id_cursoR')
    ultimo = Curso.objects.all().order_by('-fecha_registro')[:3]

    #filtro transmisiones
    conferencia = TransmisionesInstructores.objects.filter(id_instructorR=idinstructor, id_cursoR=idcurso, fecha_transmision__gte=todaynoti).order_by('fecha_completa')

    #Consulta valoracion
    valora = CursoEstudiante.objects.filter(id_estudianteR=idalumno, id_cursoR=idcurso)


    contexto = {'valoras':valora, 'conferencias':conferencia, 'ultimos':ultimo, 'cursos':curso, 'unidades':unidad, 'actividades':actividad,
    'examenes':examen, 'unidadesU':unidadU, 'actividadesA':actividadA, 'examenesA':examenA,
    'actividadesE':actividadE, 'examenesE':examenE, 'opciones':opcion, 'usuarios':usuario,
    'notificaciones':notificacion, 'numeronotificaciones':numeronotificaciones, 'Evivo':Evivo}

    opci = OpcionesAlumno.objects.get(id_alumnoR=idalumno)

    plantilla = opci.tipo_plantilla

    if plantilla == "_barra":

        return render(request, 'Alumno/Extras/Cursos/tomar_curso_barra.html', contexto)

    else:

        return render(request, 'Alumno/Extras/Cursos/tomar_curso_boton.html', contexto)




@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_estudiante, login_url='/iniciar_sesion/')
def tomar_curso_reload(request, id, id2, id3):

    request.session.set_expiry(request.session.get_expiry_age())

    idcurso = id
    idinstructor = id2
    idunidad = id3

    idalumno = request.user.id_relacionado

    curso = Curso.objects.filter(id_curso=idcurso)

    unidad = Unidades.objects.filter(id_cursoR=idcurso, id_instructorR=idinstructor)

    actividad = Actividad.objects.filter(id_cursoR=idcurso, id_instructorR=idinstructor)

    examen = EvaluacionesCursos.objects.filter(id_cursoR=idcurso, id_instructorR=idinstructor)

    unidadU = Unidades.objects.filter(id_unidad=idunidad)

    filtro3 = ActividadAlumno.objects.filter(id_cursoR=idcurso, id_alumnoR=idalumno).values('id_actividadR')

    filtro4 = EvaluacionCursosEstudiante.objects.filter(id_cursoR=idcurso, id_estudianteR=idalumno, id_instructorR=idinstructor).values('id_evaluacionCursoR')

    # Actividades y Examenes Pendientes
    actividadE = Actividad.objects.filter(id_cursoR=idcurso, id_instructorR=idinstructor).exclude(id_actividad__in=filtro3)

    examenE = EvaluacionesCursos.objects.filter(id_cursoR=idcurso, id_instructorR=idinstructor).exclude(id_evalucionCurso__in=filtro4)

    # Actividades y Examenes Entregados
    actividadA = Actividad.objects.filter(id_cursoR=idcurso, id_instructorR=idinstructor, id_actividad__in=filtro3)

    examenA = EvaluacionesCursos.objects.filter(id_cursoR=idcurso, id_instructorR=idinstructor, id_evalucionCurso__in=filtro4)

    opcion = OpcionesAlumno.objects.filter(id_alumnoR=idalumno)

    usuario = Alumno.objects.filter(id_alumno=idalumno)

    todaynoti = date.today()

    finnoti = todaynoti + timedelta(days=3)

    notificacion = NotificacionesAlumnos.objects.filter(id_alumnoR=idalumno, fecha_fin__range=[todaynoti, finnoti], statusN=0)

    numeronotificaciones = NotificacionesAlumnos.objects.filter(id_alumnoR=idalumno, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()

    #Empieza consulta de transmision
    horas = datetime.now()

    horamas = horas + timedelta(hours=1)

    horamass = horamas.time()

    horamenos = horas + timedelta(hours=-1)

    horamenoss = horamenos.time()

    cadena1 = str(horamenoss)
    cadena2 = str(horamass)

    fechahoy = date.today()

    begin = datetime.strptime(cadena1, '%H:%M:%S.%f').time()
    end = datetime.strptime(cadena2, '%H:%M:%S.%f').time()

    Ctransmision = TransmisionesVivo.objects.filter(fecha_transmision=fechahoy, hora_transmision__range=[begin, end]).order_by('hora_transmision')[:1]

    Evivo = ""

    if Ctransmision:
        Evivo = "True"
    else:
        Evivo = "False"
    #Termina Consulta Transmision

    #Filtro recientes
    idalumno = request.user.id_relacionado
    filtroR = CursoEstudiante.objects.filter(id_estudianteR=idalumno).values('id_cursoR')
    ultimo = Curso.objects.all().order_by('-fecha_registro')[:3]

    #filtro transmisiones
    conferencia = TransmisionesInstructores.objects.filter(id_instructorR=idinstructor, id_cursoR=idcurso, fecha_transmision__gte=todaynoti).order_by('fecha_completa')


    #Consulta valoracion
    valora = CursoEstudiante.objects.filter(id_estudianteR=idalumno, id_cursoR=idcurso)


    contexto = {'valoras':valora, 'conferencias':conferencia, 'ultimos':ultimo, 'cursos':curso, 'unidades':unidad, 'actividades':actividad,
    'examenes':examen, 'unidadesU':unidadU, 'actividadesA':actividadA, 'examenesA':examenA,
    'actividadesE':actividadE, 'examenesE':examenE, 'opciones':opcion, 'usuarios':usuario,
    'notificaciones':notificacion, 'numeronotificaciones':numeronotificaciones, 'Evivo':Evivo}

    opci = OpcionesAlumno.objects.get(id_alumnoR=idalumno)

    plantilla = opci.tipo_plantilla

    if plantilla == "_barra":

        return render(request, 'Alumno/Extras/Cursos/tomar_curso_barra.html', contexto)

    else:

        return render(request, 'Alumno/Extras/Cursos/tomar_curso_boton.html', contexto)



@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_estudiante, login_url='/iniciar_sesion/')
def mostrar_actividad_alumno(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    idactividad = id

    idalumno = request.user.id_relacionado

    actividad = Actividad.objects.filter(id_actividad=idactividad)

    opcion = OpcionesAlumno.objects.filter(id_alumnoR=idalumno)

    usuario = Alumno.objects.filter(id_alumno=idalumno)

    todaynoti = date.today()

    finnoti = todaynoti + timedelta(days=3)

    notificacion = NotificacionesAlumnos.objects.filter(id_alumnoR=idalumno, fecha_fin__range=[todaynoti, finnoti], statusN=0)

    numeronotificaciones = NotificacionesAlumnos.objects.filter(id_alumnoR=idalumno, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()

    #Empieza consulta de transmision
    horas = datetime.now()

    horamas = horas + timedelta(hours=1)

    horamass = horamas.time()

    horamenos = horas + timedelta(hours=-1)

    horamenoss = horamenos.time()

    cadena1 = str(horamenoss)
    cadena2 = str(horamass)

    fechahoy = date.today()

    begin = datetime.strptime(cadena1, '%H:%M:%S.%f').time()
    end = datetime.strptime(cadena2, '%H:%M:%S.%f').time()

    Ctransmision = TransmisionesVivo.objects.filter(fecha_transmision=fechahoy, hora_transmision__range=[begin, end]).order_by('hora_transmision')[:1]

    Evivo = ""

    if Ctransmision:
        Evivo = "True"
    else:
        Evivo = "False"
    #Termina Consulta Transmision

    #Filtro recientes
    idalumno = request.user.id_relacionado
    filtroR = CursoEstudiante.objects.filter(id_estudianteR=idalumno).values('id_cursoR')
    ultimo = Curso.objects.all().order_by('-fecha_registro')[:3]

    pagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    contexto = {'paginas':pagina, 'ultimos':ultimo, 'actividades':actividad, 'opciones':opcion, 'usuarios':usuario,
    'notificaciones':notificacion, 'numeronotificaciones':numeronotificaciones,
    'Evivo':Evivo}

    opci = OpcionesAlumno.objects.get(id_alumnoR=idalumno)

    plantilla = opci.tipo_plantilla

    if plantilla == "_barra":

        return render(request, 'Alumno/Extras/Cursos/mostrar_actividad_barra.html', contexto)

    else:

        return render(request, 'Alumno/Extras/Cursos/mostrar_actividad_boton.html', contexto)




@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_estudiante, login_url='/iniciar_sesion/')
def mostrar_actividad_alumno_dos(request, id, id2):

    request.session.set_expiry(request.session.get_expiry_age())

    idactividad = id

    idnotificacion = id2

    idalumno = request.user.id_relacionado

    actividad = Actividad.objects.filter(id_actividad=idactividad)

    opcion = OpcionesAlumno.objects.filter(id_alumnoR=idalumno)

    usuario = Alumno.objects.filter(id_alumno=idalumno)

    noti = NotificacionesAlumnos.objects.get(id_notificacionAlumno=idnotificacion)
    noti.statusN = 1
    noti.save()

    todaynoti = date.today()

    finnoti = todaynoti + timedelta(days=3)

    notificacion = NotificacionesAlumnos.objects.filter(id_alumnoR=idalumno, fecha_fin__range=[todaynoti, finnoti], statusN=0)

    numeronotificaciones = NotificacionesAlumnos.objects.filter(id_alumnoR=idalumno, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()

    #Empieza consulta de transmision
    horas = datetime.now()

    horamas = horas + timedelta(hours=1)

    horamass = horamas.time()

    horamenos = horas + timedelta(hours=-1)

    horamenoss = horamenos.time()

    cadena1 = str(horamenoss)
    cadena2 = str(horamass)

    fechahoy = date.today()

    begin = datetime.strptime(cadena1, '%H:%M:%S.%f').time()
    end = datetime.strptime(cadena2, '%H:%M:%S.%f').time()

    Ctransmision = TransmisionesVivo.objects.filter(fecha_transmision=fechahoy, hora_transmision__range=[begin, end]).order_by('hora_transmision')[:1]

    Evivo = ""

    if Ctransmision:
        Evivo = "True"
    else:
        Evivo = "False"
    #Termina Consulta Transmision

    #Filtro recientes
    idalumno = request.user.id_relacionado
    filtroR = CursoEstudiante.objects.filter(id_estudianteR=idalumno).values('id_cursoR')
    ultimo = Curso.objects.all().order_by('-fecha_registro')[:3]

    pagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    contexto = {'paginas':pagina, 'ultimos':ultimo, 'actividades':actividad, 'opciones':opcion, 'usuarios':usuario,
    'notificaciones':notificacion, 'numeronotificaciones':numeronotificaciones,
    'Evivo':Evivo}

    opci = OpcionesAlumno.objects.get(id_alumnoR=idalumno)

    plantilla = opci.tipo_plantilla

    if plantilla == "_barra":

        return render(request, 'Alumno/Extras/Cursos/mostrar_actividad_barra.html', contexto)

    else:

        return render(request, 'Alumno/Extras/Cursos/mostrar_actividad_boton.html', contexto)







@csrf_exempt
@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_estudiante, login_url='/iniciar_sesion/')
def entregar_actividad(request, id, id2):

    request.session.set_expiry(request.session.get_expiry_age())

    compression = zipfile.ZIP_DEFLATED

    if request.method == "POST":

        archivos = request.FILES.getlist("archivosalumno")
        comentarioalum = request.POST["comentarioalumno"]

        idactividad = id
        idcurso = id2
        idalumno = request.user.id_relacionado
        alum = Alumno.objects.get(id_alumno=idalumno)
        nombrealumno = alum.nombreA + " " + alum.apellidosA
        fecha = date.today()
        aleatorio = randint(1,10000)

        acti = Actividad.objects.get(id_actividad=idactividad)

        idinstructor = acti.id_instructorR

        idunidad = acti.id_unidadR

        nombresarchivos = []
        nombrezip = ""

        if archivos:

            for archivo in archivos:

                nombrearchivo = secure_filename(archivo.name)
                nombresarchivos.append(nombrearchivo)

                #fs = FileSystemStorage(location='ProyectoKaizen/static/media/Documentos/Alumnos')
                fs = FileSystemStorage(location= os.path.join(settings.MEDIA_ROOT+'/Documentos/Alumnos'))
                filena = fs.save(nombrearchivo, archivo)


            nombrezip = "Entrega-" + nombrealumno + "-" + str(fecha) + "-" + str(idactividad) + "-" + str(aleatorio) + ".zip"


            zf = zipfile.ZipFile(os.path.join(settings.MEDIA_ROOT+'/Documentos/Alumnos/'+ nombrezip), mode="w")

            for nombre in nombresarchivos:

                zf.write(os.path.join(settings.MEDIA_ROOT+'/Documentos/Alumnos/'+ nombre), arcname=os.path.basename(os.path.join(settings.MEDIA_ROOT+'/Documentos/Alumnos/'+ nombre)), compress_type=compression)

            zf.close()

            for nombre in nombresarchivos:

                os.remove(os.path.join(settings.MEDIA_ROOT+'/Documentos/Alumnos/' + nombre))


        aa = ActividadAlumno(id_actividadR=idactividad, id_alumnoR=idalumno, nombre_alumnoR=nombrealumno,
        fecha_entrega=fecha, nombre_archivo=nombrezip, comentario=comentarioalum, comentario_instructor="",
        calificacion=0, fecha_revisado="1999-01-01", id_cursoR=idcurso, revisado=0, id_unidadR=idunidad, no_reentrega=0)
        aa.save()

        ActA = ActividadAlumno.objects.get(id_actividadR=idactividad, id_alumnoR=idalumno, nombre_alumnoR=nombrealumno,
        fecha_entrega=fecha, nombre_archivo=nombrezip, comentario=comentarioalum, comentario_instructor="",
        calificacion=0, fecha_revisado="1999-01-01", id_cursoR=idcurso, revisado=0, id_unidadR=idunidad, no_reentrega=0)
        idactividadalumno = ActA.id_actividadAlumno


        texto = "El alumno " + nombrealumno + " entrego una actividad."

        today = date.today()

        hora = datetime.now().strftime("%I:%M:%S")

        fechafinal = today + timedelta(days=3)

        ni = NotificacionesInstructores(id_instructorR=idinstructor, mensaje_notificacion=texto,
        fecha_notificacion=today, hora_notificacion=hora, fecha_fin=fechafinal,
        id_elementoNotificacion=idactividadalumno, tipo_elementoNotificacion="ActividadE")
        ni.save()



        curso = Curso.objects.filter(id_curso=idcurso)

        unidad = Unidades.objects.filter(id_cursoR=idcurso, id_instructorR=idinstructor)

        actividad = Actividad.objects.filter(id_cursoR=idcurso, id_instructorR=idinstructor)

        examen = EvaluacionesCursos.objects.filter(id_cursoR=idcurso, id_instructorR=idinstructor)

        unidadU = Unidades.objects.filter(id_cursoR=idcurso, id_instructorR=idinstructor).order_by('id_unidad').all()[:1]

        filtro3 = ActividadAlumno.objects.filter(id_cursoR=idcurso, id_alumnoR=idalumno).values('id_actividadR')

        filtro4 = EvaluacionCursosEstudiante.objects.filter(id_cursoR=idcurso, id_estudianteR=idalumno, id_instructorR=idinstructor).values('id_evaluacionCursoR')

        # Actividades y Examenes Pendientes
        actividadE = Actividad.objects.filter(id_cursoR=idcurso, id_instructorR=idinstructor).exclude(id_actividad__in=filtro3)

        examenE = EvaluacionesCursos.objects.filter(id_cursoR=idcurso, id_instructorR=idinstructor).exclude(id_evalucionCurso__in=filtro4)

        # Actividades y Examenes Entregados
        actividadA = Actividad.objects.filter(id_cursoR=idcurso, id_instructorR=idinstructor, id_actividad__in=filtro3)

        examenA = EvaluacionesCursos.objects.filter(id_cursoR=idcurso, id_instructorR=idinstructor, id_evalucionCurso__in=filtro4)

        opcion = OpcionesAlumno.objects.filter(id_alumnoR=idalumno)

        usuario = Alumno.objects.filter(id_alumno=idalumno)

        todaynoti = date.today()

        finnoti = todaynoti + timedelta(days=3)

        notificacion = NotificacionesAlumnos.objects.filter(id_alumnoR=idalumno, fecha_fin__range=[todaynoti, finnoti], statusN=0)

        numeronotificaciones = NotificacionesAlumnos.objects.filter(id_alumnoR=idalumno, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()

        #Empieza consulta de transmision
        horas = datetime.now()

        horamas = horas + timedelta(hours=1)

        horamass = horamas.time()

        horamenos = horas + timedelta(hours=-1)

        horamenoss = horamenos.time()

        cadena1 = str(horamenoss)
        cadena2 = str(horamass)

        fechahoy = date.today()

        begin = datetime.strptime(cadena1, '%H:%M:%S.%f').time()
        end = datetime.strptime(cadena2, '%H:%M:%S.%f').time()

        Ctransmision = TransmisionesVivo.objects.filter(fecha_transmision=fechahoy, hora_transmision__range=[begin, end]).order_by('hora_transmision')[:1]

        Evivo = ""

        if Ctransmision:
            Evivo = "True"
        else:
            Evivo = "False"
        #Termina Consulta Transmision

        #Filtro recientes
        idalumno = request.user.id_relacionado
        filtroR = CursoEstudiante.objects.filter(id_estudianteR=idalumno).values('id_cursoR')
        ultimo = Curso.objects.all().order_by('-fecha_registro')[:3]

        contexto = {'ultimos':ultimo, 'cursos':curso, 'unidades':unidad, 'actividades':actividad,
        'examenes':examen, 'unidadesU':unidadU, 'actividadesA':actividadA, 'examenesA':examenA,
        'actividadesE':actividadE, 'examenesE':examenE, 'opciones':opcion, 'usuarios':usuario,
        'notificaciones':notificacion, 'numeronotificaciones':numeronotificaciones, 'Evivo':Evivo}

        opci = OpcionesAlumno.objects.get(id_alumnoR=idalumno)

        plantilla = opci.tipo_plantilla

        if plantilla == "_barra":

            return render(request, 'Alumno/Extras/Cursos/tomar_curso_barra.html', contexto)

        else:

            return render(request, 'Alumno/Extras/Cursos/tomar_curso_boton.html', contexto)





@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_estudiante, login_url='/iniciar_sesion/')
def mostrar_actividad_entregada(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    idactividad = id

    idalumno = request.user.id_relacionado

    actividad = Actividad.objects.filter(id_actividad=idactividad)

    actividadA = ActividadAlumno.objects.filter(id_actividadR=idactividad, id_alumnoR=idalumno)

    opcion = OpcionesAlumno.objects.filter(id_alumnoR=idalumno)

    usuario = Alumno.objects.filter(id_alumno=idalumno)

    todaynoti = date.today()

    finnoti = todaynoti + timedelta(days=3)

    notificacion = NotificacionesAlumnos.objects.filter(id_alumnoR=idalumno, fecha_fin__range=[todaynoti, finnoti], statusN=0)

    numeronotificaciones = NotificacionesAlumnos.objects.filter(id_alumnoR=idalumno, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()

    #Empieza consulta de transmision
    horas = datetime.now()

    horamas = horas + timedelta(hours=1)

    horamass = horamas.time()

    horamenos = horas + timedelta(hours=-1)

    horamenoss = horamenos.time()

    cadena1 = str(horamenoss)
    cadena2 = str(horamass)

    fechahoy = date.today()

    begin = datetime.strptime(cadena1, '%H:%M:%S.%f').time()
    end = datetime.strptime(cadena2, '%H:%M:%S.%f').time()

    Ctransmision = TransmisionesVivo.objects.filter(fecha_transmision=fechahoy, hora_transmision__range=[begin, end]).order_by('hora_transmision')[:1]

    Evivo = ""

    if Ctransmision:
        Evivo = "True"
    else:
        Evivo = "False"
    #Termina Consulta Transmision

    #Filtro recientes
    idalumno = request.user.id_relacionado
    filtroR = CursoEstudiante.objects.filter(id_estudianteR=idalumno).values('id_cursoR')
    ultimo = Curso.objects.all().order_by('-fecha_registro')[:3]

    contexto = {'ultimos':ultimo, 'actividades':actividad, 'actividadesA':actividadA, 'opciones':opcion, 'usuarios':usuario,
    'notificaciones':notificacion, 'numeronotificaciones':numeronotificaciones, 'Evivo':Evivo}

    opci = OpcionesAlumno.objects.get(id_alumnoR=idalumno)

    plantilla = opci.tipo_plantilla

    if plantilla == "_barra":

        return render(request, 'Alumno/Extras/Cursos/actividad_entregada_barra.html', contexto)

    else:

        return render(request, 'Alumno/Extras/Cursos/actividad_entregada_boton.html', contexto)




@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_estudiante, login_url='/iniciar_sesion/')
def mostrar_actividad_entregada_dos(request, id, id2):

    request.session.set_expiry(request.session.get_expiry_age())

    idactividad = id

    idnotificacion = id2

    idalumno = request.user.id_relacionado

    actividad = Actividad.objects.filter(id_actividad=idactividad)

    actividadA = ActividadAlumno.objects.filter(id_actividadR=idactividad, id_alumnoR=idalumno)

    opcion = OpcionesAlumno.objects.filter(id_alumnoR=idalumno)

    usuario = Alumno.objects.filter(id_alumno=idalumno)

    noti = NotificacionesAlumnos.objects.get(id_notificacionAlumno=idnotificacion)
    noti.statusN = 1
    noti.save()

    todaynoti = date.today()

    finnoti = todaynoti + timedelta(days=3)

    notificacion = NotificacionesAlumnos.objects.filter(id_alumnoR=idalumno, fecha_fin__range=[todaynoti, finnoti], statusN=0)

    numeronotificaciones = NotificacionesAlumnos.objects.filter(id_alumnoR=idalumno, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()

    #Empieza consulta de transmision
    horas = datetime.now()

    horamas = horas + timedelta(hours=1)

    horamass = horamas.time()

    horamenos = horas + timedelta(hours=-1)

    horamenoss = horamenos.time()

    cadena1 = str(horamenoss)
    cadena2 = str(horamass)

    fechahoy = date.today()

    begin = datetime.strptime(cadena1, '%H:%M:%S.%f').time()
    end = datetime.strptime(cadena2, '%H:%M:%S.%f').time()

    Ctransmision = TransmisionesVivo.objects.filter(fecha_transmision=fechahoy, hora_transmision__range=[begin, end]).order_by('hora_transmision')[:1]

    Evivo = ""

    if Ctransmision:
        Evivo = "True"
    else:
        Evivo = "False"
    #Termina Consulta Transmision

    #Filtro recientes
    idalumno = request.user.id_relacionado
    filtroR = CursoEstudiante.objects.filter(id_estudianteR=idalumno).values('id_cursoR')
    ultimo = Curso.objects.all().order_by('-fecha_registro')[:3]

    contexto = {'ultimos':ultimo, 'actividades':actividad, 'actividadesA':actividadA, 'opciones':opcion, 'usuarios':usuario,
    'notificaciones':notificacion, 'numeronotificaciones':numeronotificaciones, 'Evivo':Evivo}

    opci = OpcionesAlumno.objects.get(id_alumnoR=idalumno)

    plantilla = opci.tipo_plantilla

    if plantilla == "_barra":

        return render(request, 'Alumno/Extras/Cursos/actividad_entregada_barra.html', contexto)

    else:

        return render(request, 'Alumno/Extras/Cursos/actividad_entregada_boton.html', contexto)




@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_estudiante, login_url='/iniciar_sesion/')
def mostrar_reentregar_actividad(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    idactividad = id

    idalumno = request.user.id_relacionado

    actividad = Actividad.objects.filter(id_actividad=idactividad)

    opcion = OpcionesAlumno.objects.filter(id_alumnoR=idalumno)

    usuario = Alumno.objects.filter(id_alumno=idalumno)

    todaynoti = date.today()

    finnoti = todaynoti + timedelta(days=3)

    notificacion = NotificacionesAlumnos.objects.filter(id_alumnoR=idalumno, fecha_fin__range=[todaynoti, finnoti], statusN=0)

    numeronotificaciones = NotificacionesAlumnos.objects.filter(id_alumnoR=idalumno, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()

    #Empieza consulta de transmision
    horas = datetime.now()

    horamas = horas + timedelta(hours=1)

    horamass = horamas.time()

    horamenos = horas + timedelta(hours=-1)

    horamenoss = horamenos.time()

    cadena1 = str(horamenoss)
    cadena2 = str(horamass)

    fechahoy = date.today()

    begin = datetime.strptime(cadena1, '%H:%M:%S.%f').time()
    end = datetime.strptime(cadena2, '%H:%M:%S.%f').time()

    Ctransmision = TransmisionesVivo.objects.filter(fecha_transmision=fechahoy, hora_transmision__range=[begin, end]).order_by('hora_transmision')[:1]

    Evivo = ""

    if Ctransmision:
        Evivo = "True"
    else:
        Evivo = "False"
    #Termina Consulta Transmision

    #Filtro recientes
    idalumno = request.user.id_relacionado
    filtroR = CursoEstudiante.objects.filter(id_estudianteR=idalumno).values('id_cursoR')
    ultimo = Curso.objects.all().order_by('-fecha_registro')[:3]

    pagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    contexto = {'paginas':pagina, 'ultimos':ultimo, 'actividades':actividad, 'opciones':opcion, 'usuarios':usuario, 'notificaciones':notificacion,
    'numeronotificaciones':numeronotificaciones, 'Evivo':Evivo}

    opci = OpcionesAlumno.objects.get(id_alumnoR=idalumno)

    plantilla = opci.tipo_plantilla

    if plantilla == "_barra":

        return render(request, 'Alumno/Extras/Cursos/mostrar_reentregar_actividad_barra.html', contexto)

    else:

        return render(request, 'Alumno/Extras/Cursos/mostrar_reentregar_actividad_boton.html', contexto)




@csrf_exempt
@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_estudiante, login_url='/iniciar_sesion/')
def reentregar_actividad(request, id, id2):

    request.session.set_expiry(request.session.get_expiry_age())

    compression = zipfile.ZIP_DEFLATED

    if request.method == "POST":

        archivos = request.FILES.getlist("archivosalumno")
        comentarioalum = request.POST["comentarioalumno"]

        idactividad = id
        idcurso = id2
        idalumno = request.user.id_relacionado
        alum = Alumno.objects.get(id_alumno=idalumno)
        nombrealumno = alum.nombreA + " " + alum.apellidosA
        fecha = date.today()
        aleatorio = randint(1,10000)

        acti = Actividad.objects.get(id_actividad=idactividad)

        idinstructor = acti.id_instructorR

        idunidad = acti.id_unidadR

        acta = ActividadAlumno.objects.get(id_actividadR=idactividad, id_alumnoR=idalumno, nombre_alumnoR=nombrealumno)

        nombre_zip_guardado = acta.nombre_archivo

        nombresarchivos = []
        nombrezip = ""

        if archivos:

            for archivo in archivos:

                nombrearchivo = secure_filename(archivo.name)
                nombresarchivos.append(nombrearchivo)

                #fs = FileSystemStorage(location='ProyectoKaizen/static/media/Documentos/Alumnos')
                fs = FileSystemStorage(location= os.path.join(settings.MEDIA_ROOT+'/Documentos/Alumnos'))
                filena = fs.save(nombrearchivo, archivo)


            nombresarchivos.append(nombre_zip_guardado)
            nombrezip = "Reentrega-" + nombrealumno + "-" + str(fecha) + "-" + str(idactividad) + "-" + str(aleatorio) + ".zip"


            zf = zipfile.ZipFile(os.path.join(settings.MEDIA_ROOT+'/Documentos/Alumnos/'+ nombrezip), mode="w")

            for nombre in nombresarchivos:

                zf.write(os.path.join(settings.MEDIA_ROOT+'/Documentos/Alumnos/'+ nombre), arcname=os.path.basename(os.path.join(settings.MEDIA_ROOT+'/Documentos/Alumnos/'+ nombre)), compress_type=compression)

            zf.close()

            for nombre in nombresarchivos:

                os.remove(os.path.join(settings.MEDIA_ROOT+'/Documentos/Alumnos/' + nombre))


        aa = ActividadAlumno.objects.get(id_actividadR=idactividad, id_alumnoR=idalumno, nombre_alumnoR=nombrealumno)
        idactividadalumno = aa.id_actividadAlumno
        aa.fecha_entrega = fecha
        aa.comentario = aa.comentario + " -- " + comentarioalum
        if nombre_zip_guardado == "":

            if nombrezip == "":
                pass
            else:
                aa.nombre_archivo = nombrezip
        else:

            if nombrezip == "":
                pass
            else:
                aa.nombre_archivo = nombrezip

        aa.no_reentrega = 1
        aa.save()


        texto = "El alumno " + nombrealumno + " reentrego una actividad."

        today = date.today()

        hora = datetime.now().strftime("%I:%M:%S")

        fechafinal = today + timedelta(days=3)

        ni = NotificacionesInstructores(id_instructorR=idinstructor, mensaje_notificacion=texto,
        fecha_notificacion=today, hora_notificacion=hora, fecha_fin=fechafinal,
        id_elementoNotificacion=idactividadalumno, tipo_elementoNotificacion="ActividadE")
        ni.save()


        curso = Curso.objects.filter(id_curso=idcurso)

        unidad = Unidades.objects.filter(id_cursoR=idcurso, id_instructorR=idinstructor)

        actividad = Actividad.objects.filter(id_cursoR=idcurso, id_instructorR=idinstructor)

        examen = EvaluacionesCursos.objects.filter(id_cursoR=idcurso, id_instructorR=idinstructor)

        unidadU = Unidades.objects.filter(id_cursoR=idcurso, id_instructorR=idinstructor).order_by('id_unidad').all()[:1]

        filtro3 = ActividadAlumno.objects.filter(id_cursoR=idcurso, id_alumnoR=idalumno).values('id_actividadR')

        filtro4 = EvaluacionCursosEstudiante.objects.filter(id_cursoR=idcurso, id_estudianteR=idalumno, id_instructorR=idinstructor).values('id_evaluacionCursoR')

        # Actividades y Examenes Pendientes
        actividadE = Actividad.objects.filter(id_cursoR=idcurso, id_instructorR=idinstructor).exclude(id_actividad__in=filtro3)

        examenE = EvaluacionesCursos.objects.filter(id_cursoR=idcurso, id_instructorR=idinstructor).exclude(id_evalucionCurso__in=filtro4)

        # Actividades y Examenes Entregados
        actividadA = Actividad.objects.filter(id_cursoR=idcurso, id_instructorR=idinstructor, id_actividad__in=filtro3)

        examenA = EvaluacionesCursos.objects.filter(id_cursoR=idcurso, id_instructorR=idinstructor, id_evalucionCurso__in=filtro4)

        opcion = OpcionesAlumno.objects.filter(id_alumnoR=idalumno)

        usuario = Alumno.objects.filter(id_alumno=idalumno)

        todaynoti = date.today()

        finnoti = todaynoti + timedelta(days=3)

        notificacion = NotificacionesAlumnos.objects.filter(id_alumnoR=idalumno, fecha_fin__range=[todaynoti, finnoti], statusN=0)

        numeronotificaciones = NotificacionesAlumnos.objects.filter(id_alumnoR=idalumno, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()

        #Empieza consulta de transmision
        horas = datetime.now()

        horamas = horas + timedelta(hours=1)

        horamass = horamas.time()

        horamenos = horas + timedelta(hours=-1)

        horamenoss = horamenos.time()

        cadena1 = str(horamenoss)
        cadena2 = str(horamass)

        fechahoy = date.today()

        begin = datetime.strptime(cadena1, '%H:%M:%S.%f').time()
        end = datetime.strptime(cadena2, '%H:%M:%S.%f').time()

        Ctransmision = TransmisionesVivo.objects.filter(fecha_transmision=fechahoy, hora_transmision__range=[begin, end]).order_by('hora_transmision')[:1]

        Evivo = ""

        if Ctransmision:
            Evivo = "True"
        else:
            Evivo = "False"
        #Termina Consulta Transmision

        #Filtro recientes
        idalumno = request.user.id_relacionado
        filtroR = CursoEstudiante.objects.filter(id_estudianteR=idalumno).values('id_cursoR')
        ultimo = Curso.objects.all().order_by('-fecha_registro')[:3]

        contexto = {'ultimos':ultimo, 'cursos':curso, 'unidades':unidad, 'actividades':actividad,
        'examenes':examen, 'unidadesU':unidadU, 'actividadesA':actividadA, 'examenesA':examenA,
        'actividadesE':actividadE, 'examenesE':examenE, 'opciones':opcion, 'usuarios':usuario,
        'notificaciones':notificacion, 'numeronotificaciones':numeronotificaciones, 'Evivo':Evivo}


        opci = OpcionesAlumno.objects.get(id_alumnoR=idalumno)

        plantilla = opci.tipo_plantilla

        if plantilla == "_barra":

            return render(request, 'Alumno/Extras/Cursos/tomar_curso_barra.html', contexto)

        else:

            return render(request, 'Alumno/Extras/Cursos/tomar_curso_boton.html', contexto)






@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_estudiante, login_url='/iniciar_sesion/')
def mostrar_examen_alumno(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    idexamen = id

    idalumno = request.user.id_relacionado

    examen = EvaluacionesCursos.objects.filter(id_evalucionCurso=idexamen)

    opcion = OpcionesAlumno.objects.filter(id_alumnoR=idalumno)

    usuario = Alumno.objects.filter(id_alumno=idalumno)

    fechahoy = date.today()

    todaynoti = date.today()

    finnoti = todaynoti + timedelta(days=3)

    notificacion = NotificacionesAlumnos.objects.filter(id_alumnoR=idalumno, fecha_fin__range=[todaynoti, finnoti], statusN=0)

    numeronotificaciones = NotificacionesAlumnos.objects.filter(id_alumnoR=idalumno, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()

    #Empieza consulta de transmision
    horas = datetime.now()

    horamas = horas + timedelta(hours=1)

    horamass = horamas.time()

    horamenos = horas + timedelta(hours=-1)

    horamenoss = horamenos.time()

    cadena1 = str(horamenoss)
    cadena2 = str(horamass)

    fechahoy = date.today()

    begin = datetime.strptime(cadena1, '%H:%M:%S.%f').time()
    end = datetime.strptime(cadena2, '%H:%M:%S.%f').time()

    Ctransmision = TransmisionesVivo.objects.filter(fecha_transmision=fechahoy, hora_transmision__range=[begin, end]).order_by('hora_transmision')[:1]

    Evivo = ""

    if Ctransmision:
        Evivo = "True"
    else:
        Evivo = "False"
    #Termina Consulta Transmision

    #Filtro recientes
    idalumno = request.user.id_relacionado
    filtroR = CursoEstudiante.objects.filter(id_estudianteR=idalumno).values('id_cursoR')
    ultimo = Curso.objects.all().order_by('-fecha_registro')[:3]

    contexto = {'ultimos':ultimo, 'examenes':examen, 'opciones':opcion, 'usuarios':usuario, 'fechahoy':fechahoy,
    'notificaciones':notificacion, 'numeronotificaciones':numeronotificaciones, 'Evivo':Evivo}

    opci = OpcionesAlumno.objects.get(id_alumnoR=idalumno)

    plantilla = opci.tipo_plantilla

    if plantilla == "_barra":

        return render(request, 'Alumno/Extras/Cursos/mostrar_examen_barra.html', contexto)

    else:

        return render(request, 'Alumno/Extras/Cursos/mostrar_examen_boton.html', contexto)




@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_estudiante, login_url='/iniciar_sesion/')
def mostrar_examen_alumno_dos(request, id, id2):

    request.session.set_expiry(request.session.get_expiry_age())

    idexamen = id

    idnotificacion = id2

    idalumno = request.user.id_relacionado

    examen = EvaluacionesCursos.objects.filter(id_evalucionCurso=idexamen)

    opcion = OpcionesAlumno.objects.filter(id_alumnoR=idalumno)

    usuario = Alumno.objects.filter(id_alumno=idalumno)

    noti = NotificacionesAlumnos.objects.get(id_notificacionAlumno=idnotificacion)
    noti.statusN = 1
    noti.save()

    fechahoy = date.today()

    todaynoti = date.today()

    finnoti = todaynoti + timedelta(days=3)

    notificacion = NotificacionesAlumnos.objects.filter(id_alumnoR=idalumno, fecha_fin__range=[todaynoti, finnoti], statusN=0)

    numeronotificaciones = NotificacionesAlumnos.objects.filter(id_alumnoR=idalumno, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()

    #Empieza consulta de transmision
    horas = datetime.now()

    horamas = horas + timedelta(hours=1)

    horamass = horamas.time()

    horamenos = horas + timedelta(hours=-1)

    horamenoss = horamenos.time()

    cadena1 = str(horamenoss)
    cadena2 = str(horamass)

    fechahoy = date.today()

    begin = datetime.strptime(cadena1, '%H:%M:%S.%f').time()
    end = datetime.strptime(cadena2, '%H:%M:%S.%f').time()

    Ctransmision = TransmisionesVivo.objects.filter(fecha_transmision=fechahoy, hora_transmision__range=[begin, end]).order_by('hora_transmision')[:1]

    Evivo = ""

    if Ctransmision:
        Evivo = "True"
    else:
        Evivo = "False"
    #Termina Consulta Transmision

    #Filtro recientes
    idalumno = request.user.id_relacionado
    filtroR = CursoEstudiante.objects.filter(id_estudianteR=idalumno).values('id_cursoR')
    ultimo = Curso.objects.all().order_by('-fecha_registro')[:3]

    contexto = {'ultimos':ultimo, 'examenes':examen, 'opciones':opcion, 'usuarios':usuario, 'fechahoy':fechahoy,
    'notificaciones':notificacion, 'numeronotificaciones':numeronotificaciones, 'Evivo':Evivo}

    opci = OpcionesAlumno.objects.get(id_alumnoR=idalumno)

    plantilla = opci.tipo_plantilla

    if plantilla == "_barra":

        return render(request, 'Alumno/Extras/Cursos/mostrar_examen_barra.html', contexto)

    else:

        return render(request, 'Alumno/Extras/Cursos/mostrar_examen_boton.html', contexto)





@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_estudiante, login_url='/iniciar_sesion/')
def presentar_examen(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    idexamen = id

    ex = EvaluacionesCursos.objects.get(id_evalucionCurso=idexamen)

    idcurso = ex.id_cursoR
    idinstructor = ex.id_instructorR
    minutos = ex.tiempo_limite

    idalumno = request.user.id_relacionado

    fechahoy = date.today()


    alu = Alumno.objects.get(id_alumno=idalumno)
    nombrealumno = alu.nombreA + " " + alu.apellidosA

    ece = EvaluacionCursosEstudiante(id_evaluacionCursoR=idexamen, id_cursoR=idcurso,
    id_instructorR=idinstructor, id_estudianteR=idalumno, nombre_alumnoR=nombrealumno,
    respuestas="", puntajeE=0, resultadoE=0, fecha_contestado=fechahoy)

    ece.save()

    evaluacion = EvaluacionCursosEstudiante.objects.filter(id_evaluacionCursoR=idexamen, id_cursoR=idcurso,
    id_instructorR=idinstructor, id_estudianteR=idalumno)

    examen = EvaluacionesCursos.objects.filter(id_evalucionCurso=idexamen)

    pregunta = PreguntasEvaluacionCursos.objects.filter(id_EvaluacionCursoR=idexamen)

    aleatorio = randint(1,4)

    tiempo = minutos * 60000

    opcion = OpcionesAlumno.objects.filter(id_alumnoR=idalumno)

    usuario = Alumno.objects.filter(id_alumno=idalumno)

    todaynoti = date.today()

    finnoti = todaynoti + timedelta(days=3)

    notificacion = NotificacionesAlumnos.objects.filter(id_alumnoR=idalumno, fecha_fin__range=[todaynoti, finnoti], statusN=0)

    numeronotificaciones = NotificacionesAlumnos.objects.filter(id_alumnoR=idalumno, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()

    #Empieza consulta de transmision
    horas = datetime.now()

    horamas = horas + timedelta(hours=1)

    horamass = horamas.time()

    horamenos = horas + timedelta(hours=-1)

    horamenoss = horamenos.time()

    cadena1 = str(horamenoss)
    cadena2 = str(horamass)

    fechahoy = date.today()

    begin = datetime.strptime(cadena1, '%H:%M:%S.%f').time()
    end = datetime.strptime(cadena2, '%H:%M:%S.%f').time()

    Ctransmision = TransmisionesVivo.objects.filter(fecha_transmision=fechahoy, hora_transmision__range=[begin, end]).order_by('hora_transmision')[:1]

    Evivo = ""

    if Ctransmision:
        Evivo = "True"
    else:
        Evivo = "False"
    #Termina Consulta Transmision

    #Filtro recientes
    idalumno = request.user.id_relacionado
    filtroR = CursoEstudiante.objects.filter(id_estudianteR=idalumno).values('id_cursoR')
    ultimo = Curso.objects.all().order_by('-fecha_registro')[:3]

    contexto = {'ultimos':ultimo, 'examenes':examen, 'preguntas':pregunta, 'aleatorio':aleatorio,
    'opciones':opcion, 'usuarios':usuario, 'tiempo':tiempo, 'evaluaciones':evaluacion,
    'notificaciones':notificacion, 'numeronotificaciones':numeronotificaciones, 'Evivo':Evivo}

    opci = OpcionesAlumno.objects.get(id_alumnoR=idalumno)

    plantilla = opci.tipo_plantilla

    if plantilla == "_barra":

        return render(request, 'Alumno/Extras/Cursos/presentar_examen_barra.html', contexto)

    else:

        return render(request, 'Alumno/Extras/Cursos/presentar_examen_boton.html', contexto)




@csrf_exempt
@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_estudiante, login_url='/iniciar_sesion/')
def entregar_examen(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    if request.method == "POST":

        respuestas = []
        respuestascorrectas = []
        puntajes = []
        idrespuestas = []
        preguntas = []
        puntajeT = 0
        puntajeA = 0
        idexamenalumno = id
        cadenarespuestas = ""

        eee = EvaluacionCursosEstudiante.objects.get(id_evalucionCursoEstudiante=idexamenalumno)
        idexamen = eee.id_evaluacionCursoR

        fecha = date.today()
        idcurso = 0
        idinstructor = 0

        idalumno = request.user.id_relacionado

        alum = Alumno.objects.get(id_alumno=idalumno)

        nombrealumno = alum.nombreA + " " + alum.apellidosA

        exa = EvaluacionesCursos.objects.get(id_evalucionCurso=idexamen)

        idunidad = exa.id_unidadR


        examenes = PreguntasEvaluacionCursos.objects.filter(id_EvaluacionCursoR=idexamen)

        for examen in examenes:

            nombre = "respuesta" + str(examen.id_PreguntaEvaluacionCurso)
            respuestaC = examen.respuesta_correcta
            puntajeP = examen.valor_pregunta
            identificador = examen.id_PreguntaEvaluacionCurso
            pregunta = examen.preguntaC

            idcurso = examen.id_cursoR
            idinstructor = examen.id_instructorR

            try:
                valor = request.POST[nombre]
            except Exception as e:
                valor = ""

            respuestas.append(valor)
            respuestascorrectas.append(respuestaC)
            puntajes.append(puntajeP)
            idrespuestas.append(identificador)
            preguntas.append(pregunta)
            puntajeT = puntajeT + puntajeP



        for x in range(0,len(respuestas)):

            if respuestas[x] == respuestascorrectas[x]:

                puntajeA = puntajeA + puntajes[x]

                reca = RespuestasEvaluacionCursosEstudiante(id_evaluacionCursoR=idexamen,
                id_PreguntaEvaluacionCursoR=idrespuestas[x], id_cursoR=idcurso, id_instructorR=idinstructor,
                id_estudianteR=idalumno, pregunta=preguntas[x], valor_pregunta=puntajes[x],
                mi_respuesta=respuestas[x], respuesta_correcta=respuestascorrectas[x], es_correcta=1)
                reca.save()

            else:

                reca = RespuestasEvaluacionCursosEstudiante(id_evaluacionCursoR=idexamen,
                id_PreguntaEvaluacionCursoR=idrespuestas[x], id_cursoR=idcurso, id_instructorR=idinstructor,
                id_estudianteR=idalumno, pregunta=preguntas[x], valor_pregunta=puntajes[x],
                mi_respuesta=respuestas[x], respuesta_correcta=respuestascorrectas[x], es_correcta=0)
                reca.save()


            if cadenarespuestas == "":

                cadenarespuestas = cadenarespuestas + str(idrespuestas[x]) + " " + respuestas[x]

            else:

                cadenarespuestas = cadenarespuestas + "," + str(idrespuestas[x]) + " " + respuestas[x]


        calificacion = (puntajeA * 10)/puntajeT




        ece = EvaluacionCursosEstudiante.objects.get(id_evalucionCursoEstudiante=idexamenalumno)
        ece.respuestas=cadenarespuestas
        ece.puntajeE=puntajeA
        ece.resultadoE=calificacion
        ece.save()

        texto = "El alumno " + nombrealumno + " respondio un examen."

        today = date.today()

        hora = datetime.now().strftime("%I:%M:%S")

        fechafinal = today + timedelta(days=3)

        ni = NotificacionesInstructores(id_instructorR=idinstructor, mensaje_notificacion=texto,
        fecha_notificacion=today, hora_notificacion=hora, fecha_fin=fechafinal,
        id_elementoNotificacion=idexamen, tipo_elementoNotificacion="Examen")
        ni.save()


        curso = Curso.objects.filter(id_curso=idcurso)

        unidad = Unidades.objects.filter(id_cursoR=idcurso, id_instructorR=idinstructor)

        actividad = Actividad.objects.filter(id_cursoR=idcurso, id_instructorR=idinstructor)

        examen = EvaluacionesCursos.objects.filter(id_cursoR=idcurso, id_instructorR=idinstructor)

        unidadU = Unidades.objects.filter(id_unidad=idunidad)

        filtro3 = ActividadAlumno.objects.filter(id_cursoR=idcurso, id_alumnoR=idalumno).values('id_actividadR')

        filtro4 = EvaluacionCursosEstudiante.objects.filter(id_cursoR=idcurso, id_estudianteR=idalumno, id_instructorR=idinstructor).values('id_evaluacionCursoR')

        # Actividades y Examenes Pendientes
        actividadE = Actividad.objects.filter(id_cursoR=idcurso, id_instructorR=idinstructor).exclude(id_actividad__in=filtro3)

        examenE = EvaluacionesCursos.objects.filter(id_cursoR=idcurso, id_instructorR=idinstructor).exclude(id_evalucionCurso__in=filtro4)

        # Actividades y Examenes Entregados
        actividadA = Actividad.objects.filter(id_cursoR=idcurso, id_instructorR=idinstructor, id_actividad__in=filtro3)

        examenA = EvaluacionesCursos.objects.filter(id_cursoR=idcurso, id_instructorR=idinstructor, id_evalucionCurso__in=filtro4)

        opcion = OpcionesAlumno.objects.filter(id_alumnoR=idalumno)

        usuario = Alumno.objects.filter(id_alumno=idalumno)

        todaynoti = date.today()

        finnoti = todaynoti + timedelta(days=3)

        notificacion = NotificacionesAlumnos.objects.filter(id_alumnoR=idalumno, fecha_fin__range=[todaynoti, finnoti], statusN=0)

        numeronotificaciones = NotificacionesAlumnos.objects.filter(id_alumnoR=idalumno, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()


        #Filtro recientes
        idalumno = request.user.id_relacionado
        filtroR = CursoEstudiante.objects.filter(id_estudianteR=idalumno).values('id_cursoR')
        ultimo = Curso.objects.all().order_by('-fecha_registro')[:3]

        contexto = {'ultimos':ultimo, 'cursos':curso, 'unidades':unidad, 'actividades':actividad,
        'examenes':examen, 'unidadesU':unidadU, 'actividadesA':actividadA, 'examenesA':examenA,
        'actividadesE':actividadE, 'examenesE':examenE, 'opciones':opcion, 'usuarios':usuario,
        'notificaciones':notificacion, 'numeronotificaciones':numeronotificaciones}

        opci = OpcionesAlumno.objects.get(id_alumnoR=idalumno)

        plantilla = opci.tipo_plantilla

        if plantilla == "_barra":

            return render(request, 'Alumno/Extras/Cursos/tomar_curso_barra.html', contexto)

        else:

            return render(request, 'Alumno/Extras/Cursos/tomar_curso_boton.html', contexto)



@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_estudiante, login_url='/iniciar_sesion/')
def mostrar_examen_contestado(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    idexamen = id

    puntajeT = 0

    idalumno = request.user.id_relacionado

    examen = EvaluacionesCursos.objects.filter(id_evalucionCurso=idexamen)

    examenA = EvaluacionCursosEstudiante.objects.filter(id_evaluacionCursoR=idexamen, id_estudianteR=idalumno)

    respuesta = RespuestasEvaluacionCursosEstudiante.objects.filter(id_evaluacionCursoR=idexamen, id_estudianteR=idalumno)


    exameness = PreguntasEvaluacionCursos.objects.filter(id_EvaluacionCursoR=idexamen)

    for examenn in exameness:

        puntajeP = examenn.valor_pregunta
        puntajeT = puntajeT + puntajeP


    no_preguntas = PreguntasEvaluacionCursos.objects.filter(id_EvaluacionCursoR=idexamen).count()
    no_mis_preguntas = RespuestasEvaluacionCursosEstudiante.objects.filter(id_evaluacionCursoR=idexamen, id_estudianteR=idalumno, es_correcta=1).count()

    opcion = OpcionesAlumno.objects.filter(id_alumnoR=idalumno)

    usuario = Alumno.objects.filter(id_alumno=idalumno)

    todaynoti = date.today()

    finnoti = todaynoti + timedelta(days=3)

    notificacion = NotificacionesAlumnos.objects.filter(id_alumnoR=idalumno, fecha_fin__range=[todaynoti, finnoti], statusN=0)

    numeronotificaciones = NotificacionesAlumnos.objects.filter(id_alumnoR=idalumno, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()

    #Empieza consulta de transmision
    horas = datetime.now()

    horamas = horas + timedelta(hours=1)

    horamass = horamas.time()

    horamenos = horas + timedelta(hours=-1)

    horamenoss = horamenos.time()

    cadena1 = str(horamenoss)
    cadena2 = str(horamass)

    fechahoy = date.today()

    begin = datetime.strptime(cadena1, '%H:%M:%S.%f').time()
    end = datetime.strptime(cadena2, '%H:%M:%S.%f').time()

    Ctransmision = TransmisionesVivo.objects.filter(fecha_transmision=fechahoy, hora_transmision__range=[begin, end]).order_by('hora_transmision')[:1]

    Evivo = ""

    if Ctransmision:
        Evivo = "True"
    else:
        Evivo = "False"
    #Termina Consulta Transmision

    #Filtro recientes
    idalumno = request.user.id_relacionado
    filtroR = CursoEstudiante.objects.filter(id_estudianteR=idalumno).values('id_cursoR')
    ultimo = Curso.objects.all().order_by('-fecha_registro')[:3]

    contexto = {'ultimos':ultimo, 'examenes':examen, 'examenesA':examenA, 'respuestas':respuesta,
    'puntajeTotal':puntajeT, 'no_preguntas':no_preguntas, 'no_mis_preguntas':no_mis_preguntas,
    'opciones':opcion, 'usuarios':usuario, 'notificaciones':notificacion, 'numeronotificaciones':numeronotificaciones, 'Evivo':Evivo}


    opci = OpcionesAlumno.objects.get(id_alumnoR=idalumno)

    plantilla = opci.tipo_plantilla

    if plantilla == "_barra":

        return render(request, 'Alumno/Extras/Cursos/examen_contestado_barra.html', contexto)

    else:

        return render(request, 'Alumno/Extras/Cursos/examen_contestado_boton.html', contexto)




@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_estudiante, login_url='/iniciar_sesion/')
def mostrar_editar_perfil_alumno(request):

    request.session.set_expiry(request.session.get_expiry_age())

    idalumno = request.user.id_relacionado

    alumno = Alumno.objects.filter(id_alumno=idalumno)

    opcion = OpcionesAlumno.objects.filter(id_alumnoR=idalumno)

    usuario = Alumno.objects.filter(id_alumno=idalumno)

    #Consultas para select pais
    pais = Pais.objects.all()

    for ins in alumno:

        nombrePai = ins.paisA
        nombreEsta = ins.estadoA

    for pai in pais:

        if pai.PaisNombre == nombrePai:

            codigoPai = pai.PaisCodigo

    estado = Ciudad.objects.filter(PaisCodigo=codigoPai).values('CiudadDistrito').distinct()

    ciudad = Ciudad.objects.filter(PaisCodigo=codigoPai, CiudadDistrito=nombreEsta).values('CiudadNombre').distinct()


    #Fin

    todaynoti = date.today()

    finnoti = todaynoti + timedelta(days=3)

    notificacion = NotificacionesAlumnos.objects.filter(id_alumnoR=idalumno, fecha_fin__range=[todaynoti, finnoti], statusN=0)

    numeronotificaciones = NotificacionesAlumnos.objects.filter(id_alumnoR=idalumno, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()

    #Empieza consulta de transmision
    horas = datetime.now()

    horamas = horas + timedelta(hours=1)

    horamass = horamas.time()

    horamenos = horas + timedelta(hours=-1)

    horamenoss = horamenos.time()

    cadena1 = str(horamenoss)
    cadena2 = str(horamass)

    fechahoy = date.today()

    begin = datetime.strptime(cadena1, '%H:%M:%S.%f').time()
    end = datetime.strptime(cadena2, '%H:%M:%S.%f').time()

    Ctransmision = TransmisionesVivo.objects.filter(fecha_transmision=fechahoy, hora_transmision__range=[begin, end]).order_by('hora_transmision')[:1]

    Evivo = ""

    if Ctransmision:
        Evivo = "True"
    else:
        Evivo = "False"
    #Termina Consulta Transmision

    #Filtro recientes
    idalumno = request.user.id_relacionado
    filtroR = CursoEstudiante.objects.filter(id_estudianteR=idalumno).values('id_cursoR')
    ultimo = Curso.objects.all().order_by('-fecha_registro')[:3]

    contexto = {'codigopais':codigoPai, 'ciudades':ciudad, 'estados':estado, 'paises':pais, 'ultimos':ultimo, 'alumnos':alumno, 'opciones':opcion, 'usuarios':usuario, 'notificaciones':notificacion,
    'numeronotificaciones':numeronotificaciones, 'Evivo':Evivo}

    opci = OpcionesAlumno.objects.get(id_alumnoR=idalumno)

    plantilla = opci.tipo_plantilla

    if plantilla == "_barra":

        return render(request, 'Alumno/Extras/General/editar_perfil_barra.html', contexto)

    else:

        return render(request, 'Alumno/Extras/General/editar_perfil_boton.html', contexto)



@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_estudiante, login_url='/iniciar_sesion/')
def mostrar_estado_alumno(request, id):

    codigo = id

    codigo2 = codigo.split("_")

    codigopais = codigo2[0]

    estado = Ciudad.objects.filter(PaisCodigo=codigopais).values('CiudadDistrito').distinct()

    contexto = {'estados':estado, 'codigopais':codigopais}

    return render(request, 'Alumno/Extras/General/pais_ajax.html', contexto)



@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_estudiante, login_url='/iniciar_sesion/')
def mostrar_ciudad_alumno(request, id, id2):

    nombreestado = id

    nombreestado2 = nombreestado.replace("_", " ")

    codigopais = id2

    ciudad = Ciudad.objects.filter(PaisCodigo=codigopais, CiudadDistrito=nombreestado2).values('CiudadNombre').distinct()

    contexto = {'ciudades':ciudad}

    return render(request, 'Alumno/Extras/General/estado_ajax.html', contexto)




@csrf_exempt
@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_estudiante, login_url='/iniciar_sesion/')
def guardar_perfil_alumno(request):

    request.session.set_expiry(request.session.get_expiry_age())

    if request.method == "POST":

        try:
            imagenperfil = request.FILES["avatar"]
        except Exception as e:
            imagenperfil = ""


        nombre = request.POST["nombres"]
        apellido = request.POST["apellidos"]
        direccion = request.POST["direccion"]
        cp = request.POST["cp"]
        ciudad = request.POST["ciudad"]
        estado = request.POST["estado"]
        pais = request.POST["pais"]
        edad = request.POST["edad"]
        sexo = request.POST["sexo"]
        telefono = request.POST["telefono"]
        alergias = request.POST["alergias"]
        tiposangre = request.POST["tiposangre"]
        password = request.POST["password"]

        pais2 = pais.split("_")
        paisAG = pais2[1]


        nombreimagen = ""
        idalumno = request.user.id_relacionado

        celular = str(telefono)

        alum = Alumno.objects.get(id_alumno=idalumno)

        nombre_avatar = alum.ruta_avatar
        correo = alum.correoAL


        if imagenperfil :

            nombreimagen = secure_filename(imagenperfil.name)
            #fs = FileSystemStorage(location='ProyectoKaizen/static/media/Imagenes/Alumnos')
            fs = FileSystemStorage(location= os.path.join(settings.MEDIA_ROOT+'/Imagenes/Alumnos'))
            filenam = fs.save(nombreimagen, imagenperfil)

            if nombre_avatar == "avatar.png":

                pass

            else:

                os.remove(os.path.join(settings.MEDIA_ROOT+'/Imagenes/Alumnos/' + nombre_avatar))



        alumn = Alumno.objects.get(id_alumno=idalumno)

        alumn.nombreA = nombre
        alumn.apellidosA = apellido
        alumn.direccionA = direccion
        alumn.codigopostalA = cp
        alumn.estadoA = estado
        alumn.ciudadA = ciudad
        alumn.paisA = paisAG
        alumn.profesionA = ""
        alumn.edadA = edad
        alumn.celularA = celular
        alumn.tiposangreA = tiposangre
        alumn.alergiasA = alergias

        if nombreimagen == "":

            pass

        else:

            alumn.ruta_avatar = nombreimagen


        alumn.sexo_alumno = sexo
        alumn.save()

        if password:

            nuevacontra = make_password(password)

            usu = Usuarios.objects.get(id_relacionado=idalumno, email=correo, tipo_usuario=3)

            usu.password = nuevacontra

            usu.save()


        filtro = CursoEstudiante.objects.filter(id_estudianteR=idalumno).values('id_cursoR')

        curso = Curso.objects.filter(id_curso__in=filtro)

        valor = CursoEstudiante.objects.filter(id_estudianteR=idalumno)

        opcion = OpcionesAlumno.objects.filter(id_alumnoR=idalumno)

        usuario = Alumno.objects.filter(id_alumno=idalumno)

        todaynoti = date.today()

        finnoti = todaynoti + timedelta(days=3)

        notificacion = NotificacionesAlumnos.objects.filter(id_alumnoR=idalumno, fecha_fin__range=[todaynoti, finnoti], statusN=0)

        numeronotificaciones = NotificacionesAlumnos.objects.filter(id_alumnoR=idalumno, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()


        #Filtro recientes
        idalumno = request.user.id_relacionado
        filtroR = CursoEstudiante.objects.filter(id_estudianteR=idalumno).values('id_cursoR')
        ultimo = Curso.objects.all().order_by('-fecha_registro')[:3]

        contexto = {'ultimos':ultimo, 'cursos':curso, 'valores':valor, 'opciones':opcion, 'usuarios':usuario,
        'notificaciones':notificacion, 'numeronotificaciones':numeronotificaciones}

        opci = OpcionesAlumno.objects.get(id_alumnoR=idalumno)

        plantilla = opci.tipo_plantilla

        if plantilla == "_barra":

            return render(request, 'Alumno/Extras/Cursos/mostrar_cursos_barra.html', contexto)

        else:

            return render(request, 'Alumno/Extras/Cursos/mostrar_cursos_boton.html', contexto)



@csrf_exempt
@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_estudiante, login_url='/iniciar_sesion/')
def guardar_opciones_alumno(request):

    request.session.set_expiry(request.session.get_expiry_age())

    if request.method == "POST":

        try:
            imagenportada = request.FILES["portada"]
        except Exception as e:
            imagenportada = ""

        color = request.POST["color"]
        #clima = request.POST["clima"]
        planti = request.POST["interfaz"]

        nombreimagen = ""

        idalumno = request.user.id_relacionado

        alum = Alumno.objects.get(id_alumno=idalumno)

        nombre_portada = alum.imagen_portada


        if imagenportada :

            nombreimagen = secure_filename(imagenportada.name)
            #fs = FileSystemStorage(location='ProyectoKaizen/static/media/Imagenes/Alumnos')
            fs = FileSystemStorage(location= os.path.join(settings.MEDIA_ROOT+'/Imagenes/Alumnos'))
            filenam = fs.save(nombreimagen, imagenportada)

            if nombre_portada == "portada.jpg":

                pass

            else:
                try:
                    os.remove(os.path.join(settings.MEDIA_ROOT+'/Imagenes/Alumnos/' + nombre_portada))
                except Exception as e:
                    pass



        opci = OpcionesAlumno.objects.get(id_alumnoR=idalumno)
        opci.color_barra = color
        #opci.widget_clima = clima
        opci.tipo_plantilla = planti
        opci.save()


        alu = Alumno.objects.get(id_alumno=idalumno)

        if nombreimagen == "":

            pass

        else:

            alu.imagen_portada = nombreimagen

        alu.save()


        filtro = CursoEstudiante.objects.filter(id_estudianteR=idalumno).values('id_cursoR')

        curso = Curso.objects.filter(id_curso__in=filtro)

        valor = CursoEstudiante.objects.filter(id_estudianteR=idalumno)

        opcion = OpcionesAlumno.objects.filter(id_alumnoR=idalumno)

        usuario = Alumno.objects.filter(id_alumno=idalumno)

        todaynoti = date.today()

        finnoti = todaynoti + timedelta(days=3)

        notificacion = NotificacionesAlumnos.objects.filter(id_alumnoR=idalumno, fecha_fin__range=[todaynoti, finnoti], statusN=0)

        numeronotificaciones = NotificacionesAlumnos.objects.filter(id_alumnoR=idalumno, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()


        #Filtro recientes
        idalumno = request.user.id_relacionado
        filtroR = CursoEstudiante.objects.filter(id_estudianteR=idalumno).values('id_cursoR')
        ultimo = Curso.objects.all().order_by('-fecha_registro')[:3]

        contexto = {'ultimos':ultimo, 'cursos':curso, 'valores':valor, 'opciones':opcion, 'usuarios':usuario,
        'notificaciones':notificacion, 'numeronotificaciones':numeronotificaciones}

        opci = OpcionesAlumno.objects.get(id_alumnoR=idalumno)

        plantilla = opci.tipo_plantilla

        if plantilla == "_barra":

            return render(request, 'Alumno/Extras/Cursos/mostrar_cursos_barra.html', contexto)

        else:

            return render(request, 'Alumno/Extras/Cursos/mostrar_cursos_boton.html', contexto)



def mostrar_perfil_alumno(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    idalumno = id

    #Empieza actualizador de promedios
    actividades = ActividadAlumno.objects.filter(id_alumnoR=idalumno)
    examenes = EvaluacionCursosEstudiante.objects.filter(id_estudianteR=idalumno)

    filtro = CursoEstudiante.objects.filter(id_estudianteR=idalumno).values('id_cursoR')

    curses = Curso.objects.filter(id_curso__in=filtro)

    for curse in curses:

        idcurso = curse.id_curso
        calificaciones = []

        for actividad in actividades:

            if idcurso == actividad.id_cursoR:

                calificaciones.append(actividad.calificacion)

        for examen in examenes:

            if idcurso == examen.id_cursoR:

                calificaciones.append(examen.resultadoE)

        total_evaluaciones = len(calificaciones)
        total_calificaciones = 0
        promedio_final = 0

        if total_evaluaciones == 0:

            pass

        else:

            for x in range(0,len(calificaciones)):

                total_calificaciones = total_calificaciones + calificaciones[x]


            promedio_final = total_calificaciones/total_evaluaciones

        cursi = CursoEstudiante.objects.get(id_estudianteR=idalumno, id_cursoR=idcurso)
        cursi.promedio_curso = promedio_final
        cursi.save()
    #Termina actulizador de promedios

    curso = Curso.objects.filter(id_curso__in=filtro)

    estudianteC = CursoEstudiante.objects.filter(id_estudianteR=idalumno)

    unidad = Unidades.objects.filter(id_cursoR__in=filtro)

    usuario = Alumno.objects.filter(id_alumno=idalumno)

    contexto = {'cursos':curso, 'estudiantesC':estudianteC, 'unidades':unidad,
    'usuarios':usuario}

    return render(request, 'Alumno/Extras/General/perfil_alumno.html', contexto)



@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_estudiante, login_url='/iniciar_sesion/')
def mostrar_contenido(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    idcurso = id

    curso = Curso.objects.filter(id_curso=idcurso)

    idalumno = request.user.id_relacionado

    alumno = Alumno.objects.filter(id_alumno=idalumno)

    opcion = OpcionesAlumno.objects.filter(id_alumnoR=idalumno)

    contexto = {'alumnos':alumno, 'opciones':opcion, 'cursos':curso}

    return render(request, 'Alumno/Extras/Cursos/mostrar_contenido.html', contexto)




@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_estudiante, login_url='/iniciar_sesion/')
def mostrar_qr(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    idalumno = id

    alu = Alumno.objects.get(id_alumno=idalumno)
    nombrealumno = alu.nombreA + "-" + alu.apellidosA
    nombreqr = alu.imagen_qr

    if nombreqr == "Ninguna":

        cadena_url = "www.seiko.global/perfil_alumno/" + str(idalumno)
        imagen = qrcode.make(cadena_url)

        nombre_imagen_qr = "Codigo-QR-Mis-Cursos-" + nombrealumno + ".png"

        localizacion = os.path.join(settings.MEDIA_ROOT+'/Imagenes/Alumnos/QR/', nombre_imagen_qr)

        imagen.save(localizacion)

        alum = Alumno.objects.get(id_alumno=idalumno)
        alum.imagen_qr = nombre_imagen_qr
        alum.save()


    alumno = Alumno.objects.filter(id_alumno=idalumno)

    opcion = OpcionesAlumno.objects.filter(id_alumnoR=idalumno)

    contexto = {'alumnos':alumno, 'opciones':opcion}

    return render(request, 'Alumno/Extras/Cursos/mostrar_qr.html', contexto)


#Empiezan nuevas vistas para los mensajes entre alumnos

@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_estudiante, login_url='/iniciar_sesion/')
def mensajes_alumno_compa(request):

    request.session.set_expiry(request.session.get_expiry_age())

    idalumno = request.user.id_relacionado

    miid = idalumno

    filtro = CursoEstudiante.objects.filter(id_estudianteR=idalumno).values('id_cursoR')

    #cursos = Curso.objects.filter(id_curso__in=filtro).exclude(tipo_Curso="Linea").values('id_curso')

    cursos = Curso.objects.filter(id_curso__in=filtro).values('id_curso')

    filtroalum = CursoEstudiante.objects.filter(id_cursoR__in=cursos).exclude(id_estudianteR=idalumno).values('id_estudianteR')

    alumno = Alumno.objects.filter(id_alumno__in=filtroalum)

    opcion = OpcionesAlumno.objects.filter(id_alumnoR=idalumno)

    usuario = Alumno.objects.filter(id_alumno=idalumno)

    todaynoti = date.today()

    finnoti = todaynoti + timedelta(days=3)

    notificacion = NotificacionesAlumnos.objects.filter(id_alumnoR=idalumno, fecha_fin__range=[todaynoti, finnoti], statusN=0)

    numeronotificaciones = NotificacionesAlumnos.objects.filter(id_alumnoR=idalumno, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()

    #Empieza consulta de transmision
    horas = datetime.now()

    horamas = horas + timedelta(hours=1)

    horamass = horamas.time()

    horamenos = horas + timedelta(hours=-1)

    horamenoss = horamenos.time()

    cadena1 = str(horamenoss)
    cadena2 = str(horamass)

    fechahoy = date.today()

    begin = datetime.strptime(cadena1, '%H:%M:%S.%f').time()
    end = datetime.strptime(cadena2, '%H:%M:%S.%f').time()

    Ctransmision = TransmisionesVivo.objects.filter(fecha_transmision=fechahoy, hora_transmision__range=[begin, end]).order_by('hora_transmision')[:1]

    Evivo = ""

    if Ctransmision:
        Evivo = "True"
    else:
        Evivo = "False"
    #Termina Consulta Transmision

    #Filtro recientes
    idalumno = request.user.id_relacionado
    filtroR = CursoEstudiante.objects.filter(id_estudianteR=idalumno).values('id_cursoR')
    ultimo = Curso.objects.all().order_by('-fecha_registro')[:3]

    contexto = {'ultimos':ultimo, 'opciones':opcion, 'usuarios':usuario, 'notificaciones':notificacion,
    'numeronotificaciones':numeronotificaciones, 'alumnos':alumno, 'Evivo':Evivo}

    return render(request, 'Alumno/Extras/General/mensajes_compa.html', contexto)



@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_estudiante, login_url='/iniciar_sesion/')
def mostrar_mensajes_alumno_compa(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    idalumnoselec = id

    idalumno = request.user.id_relacionado

    miid = idalumno

    allu = Alumno.objects.get(id_alumno=idalumno)
    nombrealumno = allu.nombreA + " " + allu.apellidosA
    imagenalumno = allu.ruta_avatar

    inst = Alumno.objects.get(id_alumno=idalumnoselec)
    nombreinstructor = inst.nombreA + " " + inst.apellidosA
    imageninstructor = inst.ruta_avatar

    mensaje = MensajesUsuariosCompa.objects.filter(id_alumnoEnvio__in=[idalumno, idalumnoselec], id_alumnoDestino__in=[idalumno, idalumnoselec]).order_by('fecha')

    user = Alumno.objects.filter(id_alumno=idalumnoselec)

    filtro = CursoEstudiante.objects.filter(id_estudianteR=idalumno).values('id_cursoR')

    #cursos = Curso.objects.filter(id_curso__in=filtro).exclude(tipo_Curso="Linea").values('id_curso')

    cursos = Curso.objects.filter(id_curso__in=filtro).values('id_curso')

    filtroalum = CursoEstudiante.objects.filter(id_cursoR__in=cursos).exclude(id_estudianteR=idalumno).values('id_estudianteR')

    alumno = Alumno.objects.filter(id_alumno__in=filtroalum)

    opcion = OpcionesAlumno.objects.filter(id_alumnoR=idalumno)

    usuario = Alumno.objects.filter(id_alumno=idalumno)

    todaynoti = date.today()

    finnoti = todaynoti + timedelta(days=3)

    notificacion = NotificacionesAlumnos.objects.filter(id_alumnoR=idalumno, fecha_fin__range=[todaynoti, finnoti], statusN=0)

    numeronotificaciones = NotificacionesAlumnos.objects.filter(id_alumnoR=idalumno, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()

    #Empieza consulta de transmision
    horas = datetime.now()

    horamas = horas + timedelta(hours=1)

    horamass = horamas.time()

    horamenos = horas + timedelta(hours=-1)

    horamenoss = horamenos.time()

    cadena1 = str(horamenoss)
    cadena2 = str(horamass)

    fechahoy = date.today()

    begin = datetime.strptime(cadena1, '%H:%M:%S.%f').time()
    end = datetime.strptime(cadena2, '%H:%M:%S.%f').time()

    Ctransmision = TransmisionesVivo.objects.filter(fecha_transmision=fechahoy, hora_transmision__range=[begin, end]).order_by('hora_transmision')[:1]

    Evivo = ""

    if Ctransmision:
        Evivo = "True"
    else:
        Evivo = "False"
    #Termina Consulta Transmision

    #Filtro recientes
    idalumno = request.user.id_relacionado
    filtroR = CursoEstudiante.objects.filter(id_estudianteR=idalumno).values('id_cursoR')
    ultimo = Curso.objects.all().order_by('-fecha_registro')[:3]

    contexto = {'ultimos':ultimo, 'opciones':opcion, 'usuarios':usuario, 'notificaciones':notificacion,
    'numeronotificaciones':numeronotificaciones, 'alumnos':alumno,
    'users':user, 'mensajes':mensaje, 'nombrealumno':nombrealumno, 'imagenalumno':imagenalumno,
    'nombreinstructor':nombreinstructor, 'imageninstructor':imageninstructor, 'Evivo':Evivo, 'miid':miid}

    return render(request, 'Alumno/Extras/General/mensajes_compa.html', contexto)



@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_estudiante, login_url='/iniciar_sesion/')
def mostrar_mensajes_alumno_compa_dos(request, id, id2):

    request.session.set_expiry(request.session.get_expiry_age())

    idalumnoselec = id

    idnotificacion = id2

    idalumno = request.user.id_relacionado

    miid = idalumno

    allu = Alumno.objects.get(id_alumno=idalumno)
    nombrealumno = allu.nombreA + " " + allu.apellidosA
    imagenalumno = allu.ruta_avatar

    inst = Alumno.objects.get(id_alumno=idalumnoselec)
    nombreinstructor = inst.nombreA + " " + inst.apellidosA
    imageninstructor = inst.ruta_avatar

    mensaje = MensajesUsuariosCompa.objects.filter(id_alumnoEnvio__in=[idalumno, idalumnoselec], id_alumnoDestino__in=[idalumno, idalumnoselec]).order_by('fecha')

    user = Alumno.objects.filter(id_alumno=idalumnoselec)

    filtro = CursoEstudiante.objects.filter(id_estudianteR=idalumno).values('id_cursoR')

    #cursos = Curso.objects.filter(id_curso__in=filtro).exclude(tipo_Curso="Linea").values('id_curso')

    cursos = Curso.objects.filter(id_curso__in=filtro).values('id_curso')

    filtroalum = CursoEstudiante.objects.filter(id_cursoR__in=cursos).exclude(id_estudianteR=idalumno).values('id_estudianteR')

    alumno = Alumno.objects.filter(id_alumno__in=filtroalum)

    opcion = OpcionesAlumno.objects.filter(id_alumnoR=idalumno)

    usuario = Alumno.objects.filter(id_alumno=idalumno)

    noti = NotificacionesAlumnos.objects.get(id_notificacionAlumno=idnotificacion)
    noti.statusN = 1
    noti.save()

    todaynoti = date.today()

    finnoti = todaynoti + timedelta(days=3)

    notificacion = NotificacionesAlumnos.objects.filter(id_alumnoR=idalumno, fecha_fin__range=[todaynoti, finnoti], statusN=0)

    numeronotificaciones = NotificacionesAlumnos.objects.filter(id_alumnoR=idalumno, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()

    #Empieza consulta de transmision
    horas = datetime.now()

    horamas = horas + timedelta(hours=1)

    horamass = horamas.time()

    horamenos = horas + timedelta(hours=-1)

    horamenoss = horamenos.time()

    cadena1 = str(horamenoss)
    cadena2 = str(horamass)

    fechahoy = date.today()

    begin = datetime.strptime(cadena1, '%H:%M:%S.%f').time()
    end = datetime.strptime(cadena2, '%H:%M:%S.%f').time()

    Ctransmision = TransmisionesVivo.objects.filter(fecha_transmision=fechahoy, hora_transmision__range=[begin, end]).order_by('hora_transmision')[:1]

    Evivo = ""

    if Ctransmision:
        Evivo = "True"
    else:
        Evivo = "False"
    #Termina Consulta Transmision

    #Filtro recientes
    idalumno = request.user.id_relacionado
    filtroR = CursoEstudiante.objects.filter(id_estudianteR=idalumno).values('id_cursoR')
    ultimo = Curso.objects.all().order_by('-fecha_registro')[:3]

    contexto = {'ultimos':ultimo, 'opciones':opcion, 'usuarios':usuario, 'notificaciones':notificacion,
    'numeronotificaciones':numeronotificaciones, 'alumnos':alumno,
    'users':user, 'mensajes':mensaje, 'nombrealumno':nombrealumno, 'imagenalumno':imagenalumno,
    'nombreinstructor':nombreinstructor, 'imageninstructor':imageninstructor, 'Evivo':Evivo, 'miid':miid}

    return render(request, 'Alumno/Extras/General/mensajes_compa.html', contexto)




@csrf_exempt
@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_estudiante, login_url='/iniciar_sesion/')
def agregar_mensaje_alumno_compa(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    if request.method == "POST":

        message = request.POST["mensaje"]

        idalumnoselec = id

        idalumno = request.user.id_relacionado

        miid = idalumno

        allu = Alumno.objects.get(id_alumno=idalumno)
        nombrealumno = allu.nombreA + " " + allu.apellidosA
        imagenalumno = allu.ruta_avatar

        inst = Alumno.objects.get(id_alumno=idalumnoselec)
        nombreinstructor = inst.nombreA + " " + inst.apellidosA
        imageninstructor = inst.ruta_avatar

        fecha_hoy = datetime.now()

        horamensaje = fecha_hoy.strftime('%I:%M:%S')


        mensa = MensajesUsuariosCompa(id_alumnoEnvio=idalumno, id_alumnoDestino=idalumnoselec,
        mensaje=message, fecha=fecha_hoy, hora=horamensaje, remitente=idalumno)
        mensa.save()

        texto = "" + nombrealumno + " te envio un mensaje."

        today = date.today()

        hora = datetime.now().strftime('%I:%M:%S')

        fechafinal = today + timedelta(days=3)

        ni = NotificacionesAlumnos(id_alumnoR=idalumnoselec, mensaje_notificacion=texto,
        fecha_notificacion=today, hora_notificacion=hora, fecha_fin=fechafinal,
        id_elementoNotificacion=idalumno, tipo_elementoNotificacion="MensajeA")
        ni.save()


        mensaje = MensajesUsuariosCompa.objects.filter(id_alumnoEnvio__in=[idalumno, idalumnoselec], id_alumnoDestino__in=[idalumno, idalumnoselec]).order_by('fecha')

        user = Alumno.objects.filter(id_alumno=idalumnoselec)

        filtro = CursoEstudiante.objects.filter(id_estudianteR=idalumno).values('id_cursoR')

        #cursos = Curso.objects.filter(id_curso__in=filtro).exclude(tipo_Curso="Linea").values('id_curso')

        cursos = Curso.objects.filter(id_curso__in=filtro).values('id_curso')

        filtroalum = CursoEstudiante.objects.filter(id_cursoR__in=cursos).exclude(id_estudianteR=idalumno).values('id_estudianteR')

        alumno = Alumno.objects.filter(id_alumno__in=filtroalum)

        opcion = OpcionesAlumno.objects.filter(id_alumnoR=idalumno)

        usuario = Alumno.objects.filter(id_alumno=idalumno)

        todaynoti = date.today()

        finnoti = todaynoti + timedelta(days=3)

        notificacion = NotificacionesAlumnos.objects.filter(id_alumnoR=idalumno, fecha_fin__range=[todaynoti, finnoti], statusN=0)

        numeronotificaciones = NotificacionesAlumnos.objects.filter(id_alumnoR=idalumno, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()

        #Empieza consulta de transmision
        horas = datetime.now()

        horamas = horas + timedelta(hours=1)

        horamass = horamas.time()

        horamenos = horas + timedelta(hours=-1)

        horamenoss = horamenos.time()

        cadena1 = str(horamenoss)
        cadena2 = str(horamass)

        fechahoy = date.today()

        begin = datetime.strptime(cadena1, '%H:%M:%S.%f').time()
        end = datetime.strptime(cadena2, '%H:%M:%S.%f').time()

        Ctransmision = TransmisionesVivo.objects.filter(fecha_transmision=fechahoy, hora_transmision__range=[begin, end]).order_by('hora_transmision')[:1]

        Evivo = ""

        if Ctransmision:
            Evivo = "True"
        else:
            Evivo = "False"
        #Termina Consulta Transmision

        #Filtro recientes
        idalumno = request.user.id_relacionado
        filtroR = CursoEstudiante.objects.filter(id_estudianteR=idalumno).values('id_cursoR')
        ultimo = Curso.objects.all().order_by('-fecha_registro')[:3]

        contexto = {'ultimos':ultimo, 'opciones':opcion, 'usuarios':usuario, 'notificaciones':notificacion,
        'numeronotificaciones':numeronotificaciones, 'alumnos':alumno,
        'users':user, 'mensajes':mensaje, 'nombrealumno':nombrealumno, 'imagenalumno':imagenalumno,
        'nombreinstructor':nombreinstructor, 'imageninstructor':imageninstructor, 'Evivo':Evivo, 'miid':miid}

        return render(request, 'Alumno/Extras/General/mensajes_compa.html', contexto)




@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_estudiante, login_url='/iniciar_sesion/')
def mensajes_alumno(request):

    request.session.set_expiry(request.session.get_expiry_age())

    idalumno = request.user.id_relacionado

    filtro = CursoEstudiante.objects.filter(id_estudianteR=idalumno).values('id_instructorRC')

    instructor = Instructor.objects.filter(id_instructor__in=filtro)

    opcion = OpcionesAlumno.objects.filter(id_alumnoR=idalumno)

    usuario = Alumno.objects.filter(id_alumno=idalumno)

    todaynoti = date.today()

    finnoti = todaynoti + timedelta(days=3)

    notificacion = NotificacionesAlumnos.objects.filter(id_alumnoR=idalumno, fecha_fin__range=[todaynoti, finnoti], statusN=0)

    numeronotificaciones = NotificacionesAlumnos.objects.filter(id_alumnoR=idalumno, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()

    #Empieza consulta de transmision
    horas = datetime.now()

    horamas = horas + timedelta(hours=1)

    horamass = horamas.time()

    horamenos = horas + timedelta(hours=-1)

    horamenoss = horamenos.time()

    cadena1 = str(horamenoss)
    cadena2 = str(horamass)

    fechahoy = date.today()

    begin = datetime.strptime(cadena1, '%H:%M:%S.%f').time()
    end = datetime.strptime(cadena2, '%H:%M:%S.%f').time()

    Ctransmision = TransmisionesVivo.objects.filter(fecha_transmision=fechahoy, hora_transmision__range=[begin, end]).order_by('hora_transmision')[:1]

    Evivo = ""

    if Ctransmision:
        Evivo = "True"
    else:
        Evivo = "False"
    #Termina Consulta Transmision

    #Filtro recientes
    idalumno = request.user.id_relacionado
    filtroR = CursoEstudiante.objects.filter(id_estudianteR=idalumno).values('id_cursoR')
    ultimo = Curso.objects.all().order_by('-fecha_registro')[:3]

    contexto = {'ultimos':ultimo, 'opciones':opcion, 'usuarios':usuario, 'notificaciones':notificacion,
    'numeronotificaciones':numeronotificaciones, 'instructores':instructor, 'Evivo':Evivo}

    opci = OpcionesAlumno.objects.get(id_alumnoR=idalumno)

    plantilla = opci.tipo_plantilla

    if plantilla == "_barra":

        return render(request, 'Alumno/Extras/General/mensajes_boton.html', contexto)

    else:

        return render(request, 'Alumno/Extras/General/mensajes_boton.html', contexto)



@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_estudiante, login_url='/iniciar_sesion/')
def mostrar_mensajes_alumno(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    idinstructor = id

    idalumno = request.user.id_relacionado

    allu = Alumno.objects.get(id_alumno=idalumno)
    nombrealumno = allu.nombreA + " " + allu.apellidosA
    imagenalumno = allu.ruta_avatar

    inst = Instructor.objects.get(id_instructor=idinstructor)
    nombreinstructor = inst.nombreI + " " + inst.apellidosI
    imageninstructor = inst.ruta_imagen_perfil


    ins = Usuarios.objects.get(id_relacionado=idinstructor, tipo_usuario=2)
    idusuarioinstructor = ins.id_usuario

    alu = Usuarios.objects.get(id_relacionado=idalumno, tipo_usuario=3)
    idusuarioalumno = alu.id_usuario

    mensaje = MensajesUsuarios.objects.filter(id_alumnoR=idusuarioalumno, id_instructorR=idusuarioinstructor).order_by('fecha')


    user = Instructor.objects.filter(id_instructor=idinstructor)

    filtro = CursoEstudiante.objects.filter(id_estudianteR=idalumno).values('id_instructorRC')

    instructor = Instructor.objects.filter(id_instructor__in=filtro)

    opcion = OpcionesAlumno.objects.filter(id_alumnoR=idalumno)

    usuario = Alumno.objects.filter(id_alumno=idalumno)

    todaynoti = date.today()

    finnoti = todaynoti + timedelta(days=3)

    notificacion = NotificacionesAlumnos.objects.filter(id_alumnoR=idalumno, fecha_fin__range=[todaynoti, finnoti], statusN=0)

    numeronotificaciones = NotificacionesAlumnos.objects.filter(id_alumnoR=idalumno, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()

    #Empieza consulta de transmision
    horas = datetime.now()

    horamas = horas + timedelta(hours=1)

    horamass = horamas.time()

    horamenos = horas + timedelta(hours=-1)

    horamenoss = horamenos.time()

    cadena1 = str(horamenoss)
    cadena2 = str(horamass)

    fechahoy = date.today()

    begin = datetime.strptime(cadena1, '%H:%M:%S.%f').time()
    end = datetime.strptime(cadena2, '%H:%M:%S.%f').time()

    Ctransmision = TransmisionesVivo.objects.filter(fecha_transmision=fechahoy, hora_transmision__range=[begin, end]).order_by('hora_transmision')[:1]

    Evivo = ""

    if Ctransmision:
        Evivo = "True"
    else:
        Evivo = "False"
    #Termina Consulta Transmision

    #Filtro recientes
    idalumno = request.user.id_relacionado
    filtroR = CursoEstudiante.objects.filter(id_estudianteR=idalumno).values('id_cursoR')
    ultimo = Curso.objects.all().order_by('-fecha_registro')[:3]

    contexto = {'ultimos':ultimo, 'opciones':opcion, 'usuarios':usuario, 'notificaciones':notificacion,
    'numeronotificaciones':numeronotificaciones, 'instructores':instructor,
    'users':user, 'mensajes':mensaje, 'nombrealumno':nombrealumno, 'imagenalumno':imagenalumno,
    'nombreinstructor':nombreinstructor, 'imageninstructor':imageninstructor, 'Evivo':Evivo}

    opci = OpcionesAlumno.objects.get(id_alumnoR=idalumno)

    plantilla = opci.tipo_plantilla

    if plantilla == "_barra":

        return render(request, 'Alumno/Extras/General/mensajes_boton.html', contexto)

    else:

        return render(request, 'Alumno/Extras/General/mensajes_boton.html', contexto)




@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_estudiante, login_url='/iniciar_sesion/')
def mostrar_mensajes_alumno_dos(request, id, id2):

    request.session.set_expiry(request.session.get_expiry_age())

    idinstructor = id

    idnotificacion = id2

    idalumno = request.user.id_relacionado

    allu = Alumno.objects.get(id_alumno=idalumno)
    nombrealumno = allu.nombreA + " " + allu.apellidosA
    imagenalumno = allu.ruta_avatar

    inst = Instructor.objects.get(id_instructor=idinstructor)
    nombreinstructor = inst.nombreI + " " + inst.apellidosI
    imageninstructor = inst.ruta_imagen_perfil


    ins = Usuarios.objects.get(id_relacionado=idinstructor, tipo_usuario=2)
    idusuarioinstructor = ins.id_usuario

    alu = Usuarios.objects.get(id_relacionado=idalumno, tipo_usuario=3)
    idusuarioalumno = alu.id_usuario

    mensaje = MensajesUsuarios.objects.filter(id_alumnoR=idusuarioalumno, id_instructorR=idusuarioinstructor).order_by('fecha')


    user = Instructor.objects.filter(id_instructor=idinstructor)

    filtro = CursoEstudiante.objects.filter(id_estudianteR=idalumno).values('id_instructorRC')

    instructor = Instructor.objects.filter(id_instructor__in=filtro)

    opcion = OpcionesAlumno.objects.filter(id_alumnoR=idalumno)

    usuario = Alumno.objects.filter(id_alumno=idalumno)

    noti = NotificacionesAlumnos.objects.get(id_notificacionAlumno=idnotificacion)
    noti.statusN = 1
    noti.save()

    todaynoti = date.today()

    finnoti = todaynoti + timedelta(days=3)

    notificacion = NotificacionesAlumnos.objects.filter(id_alumnoR=idalumno, fecha_fin__range=[todaynoti, finnoti], statusN=0)

    numeronotificaciones = NotificacionesAlumnos.objects.filter(id_alumnoR=idalumno, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()

    #Empieza consulta de transmision
    horas = datetime.now()

    horamas = horas + timedelta(hours=1)

    horamass = horamas.time()

    horamenos = horas + timedelta(hours=-1)

    horamenoss = horamenos.time()

    cadena1 = str(horamenoss)
    cadena2 = str(horamass)

    fechahoy = date.today()

    begin = datetime.strptime(cadena1, '%H:%M:%S.%f').time()
    end = datetime.strptime(cadena2, '%H:%M:%S.%f').time()

    Ctransmision = TransmisionesVivo.objects.filter(fecha_transmision=fechahoy, hora_transmision__range=[begin, end]).order_by('hora_transmision')[:1]

    Evivo = ""

    if Ctransmision:
        Evivo = "True"
    else:
        Evivo = "False"
    #Termina Consulta Transmision

    #Filtro recientes
    idalumno = request.user.id_relacionado
    filtroR = CursoEstudiante.objects.filter(id_estudianteR=idalumno).values('id_cursoR')
    ultimo = Curso.objects.all().order_by('-fecha_registro')[:3]

    contexto = {'ultimos':ultimo, 'opciones':opcion, 'usuarios':usuario, 'notificaciones':notificacion,
    'numeronotificaciones':numeronotificaciones, 'instructores':instructor,
    'users':user, 'mensajes':mensaje, 'nombrealumno':nombrealumno, 'imagenalumno':imagenalumno,
    'nombreinstructor':nombreinstructor, 'imageninstructor':imageninstructor, 'Evivo':Evivo}

    opci = OpcionesAlumno.objects.get(id_alumnoR=idalumno)

    plantilla = opci.tipo_plantilla

    if plantilla == "_barra":

        return render(request, 'Alumno/Extras/General/mensajes_boton.html', contexto)

    else:

        return render(request, 'Alumno/Extras/General/mensajes_boton.html', contexto)




@csrf_exempt
@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_estudiante, login_url='/iniciar_sesion/')
def agregar_mensaje_alumno(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    if request.method == "POST":

        message = request.POST["mensaje"]


        idinstructor = id

        idalumno = request.user.id_relacionado


        allu = Alumno.objects.get(id_alumno=idalumno)
        nombrealumno = allu.nombreA + " " + allu.apellidosA
        imagenalumno = allu.ruta_avatar

        inst = Instructor.objects.get(id_instructor=idinstructor)
        nombreinstructor = inst.nombreI + " " + inst.apellidosI
        imageninstructor = inst.ruta_imagen_perfil


        ins = Usuarios.objects.get(id_relacionado=idinstructor, tipo_usuario=2)
        idusuarioinstructor = ins.id_usuario

        alu = Usuarios.objects.get(id_relacionado=idalumno, tipo_usuario=3)
        idusuarioalumno = alu.id_usuario

        fecha_hoy = datetime.now()

        horamensaje = fecha_hoy.strftime('%I:%M:%S')


        mensa = MensajesUsuarios(id_alumnoR=idusuarioalumno, id_instructorR=idusuarioinstructor,
        mensaje=message, fecha=fecha_hoy, hora=horamensaje, remitente="Alumno")
        mensa.save()

        texto = "El alumno " + nombrealumno + " le envio un mensaje."

        today = date.today()

        hora = datetime.now().strftime('%I:%M:%S')

        fechafinal = today + timedelta(days=3)

        ni = NotificacionesInstructores(id_instructorR=idinstructor, mensaje_notificacion=texto,
        fecha_notificacion=today, hora_notificacion=hora, fecha_fin=fechafinal,
        id_elementoNotificacion=idalumno, tipo_elementoNotificacion="Mensaje")
        ni.save()


        mensaje = MensajesUsuarios.objects.filter(id_alumnoR=idusuarioalumno, id_instructorR=idusuarioinstructor).order_by('fecha')


        user = Instructor.objects.filter(id_instructor=idinstructor)

        filtro = CursoEstudiante.objects.filter(id_estudianteR=idalumno).values('id_instructorRC')

        instructor = Instructor.objects.filter(id_instructor__in=filtro)

        opcion = OpcionesAlumno.objects.filter(id_alumnoR=idalumno)

        usuario = Alumno.objects.filter(id_alumno=idalumno)

        todaynoti = date.today()

        finnoti = todaynoti + timedelta(days=3)

        notificacion = NotificacionesAlumnos.objects.filter(id_alumnoR=idalumno, fecha_fin__range=[todaynoti, finnoti], statusN=0)

        numeronotificaciones = NotificacionesAlumnos.objects.filter(id_alumnoR=idalumno, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()

        #Empieza consulta de transmision
        horas = datetime.now()

        horamas = horas + timedelta(hours=1)

        horamass = horamas.time()

        horamenos = horas + timedelta(hours=-1)

        horamenoss = horamenos.time()

        cadena1 = str(horamenoss)
        cadena2 = str(horamass)

        fechahoy = date.today()

        begin = datetime.strptime(cadena1, '%H:%M:%S.%f').time()
        end = datetime.strptime(cadena2, '%H:%M:%S.%f').time()

        Ctransmision = TransmisionesVivo.objects.filter(fecha_transmision=fechahoy, hora_transmision__range=[begin, end]).order_by('hora_transmision')[:1]

        Evivo = ""

        if Ctransmision:
            Evivo = "True"
        else:
            Evivo = "False"
        #Termina Consulta Transmision

        #Filtro recientes
        idalumno = request.user.id_relacionado
        filtroR = CursoEstudiante.objects.filter(id_estudianteR=idalumno).values('id_cursoR')
        ultimo = Curso.objects.all().order_by('-fecha_registro')[:3]

        contexto = {'ultimos':ultimo, 'opciones':opcion, 'usuarios':usuario, 'notificaciones':notificacion,
        'numeronotificaciones':numeronotificaciones, 'instructores':instructor,
        'users':user, 'mensajes':mensaje, 'nombrealumno':nombrealumno, 'imagenalumno':imagenalumno,
        'nombreinstructor':nombreinstructor, 'imageninstructor':imageninstructor, 'Evivo':Evivo}

        opci = OpcionesAlumno.objects.get(id_alumnoR=idalumno)

        plantilla = opci.tipo_plantilla

        if plantilla == "_barra":

            return render(request, 'Alumno/Extras/General/mensajes_barra.html', contexto)

        else:

            return render(request, 'Alumno/Extras/General/mensajes_boton.html', contexto)




@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_estudiante, login_url='/iniciar_sesion/')
def mostrar_editar_perfil_alumno_inicial(request):

    request.session.set_expiry(request.session.get_expiry_age())

    idalumno = request.user.id_relacionado

    alumno = Alumno.objects.filter(id_alumno=idalumno)

    opcion = OpcionesAlumno.objects.filter(id_alumnoR=idalumno)

    usuario = Alumno.objects.filter(id_alumno=idalumno)

    profesion = Profesiones.objects.all()

    pais = Pais.objects.all()

    contexto = {'paises':pais, 'profesiones':profesion, 'alumnos':alumno, 'opciones':opcion, 'usuarios':usuario}

    return render(request, 'Alumno/Extras/General/editar_perfil_inicio.html', contexto)




@csrf_exempt
@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_estudiante, login_url='/iniciar_sesion/')
def guardar_perfil_alumno_inicial(request):

    request.session.set_expiry(request.session.get_expiry_age())

    if request.method == "POST":

        try:
            imagenperfil = request.FILES["avatar"]
        except Exception as e:
            imagenperfil = ""


        nombre = request.POST["nombres"]
        apellido = request.POST["apellidos"]
        cp = request.POST["cp"]
        ciudad = request.POST["ciudad"]
        estado = request.POST["estado"]
        pais = request.POST["pais"]

        edad = request.POST["edad"]
        sexo = request.POST["sexo"]
        telefono = request.POST["telefono"]
        alergias = request.POST["alergias"]
        tiposangre = request.POST["tiposangre"]

        calleS = request.POST["calle"]
        numeroCS = request.POST["numerocasa"]
        coloniaS = request.POST["colonia"]

        direccion = str(calleS) + ", " + str(numeroCS) + ", " + str(coloniaS)

        profesionuno = request.POST["profesion1"]
        profesiondos = request.POST["profesion2"]
        profesiontres = request.POST["profesion3"]
        profesioncuatro = request.POST["profesion4"]
        profesioncinco = request.POST["profesion5"]

        pais2 = pais.split("_")
        paisAG = pais2[1]


        nombreimagen = ""
        idalumno = request.user.id_relacionado

        celular = str(telefono)

        alum = Alumno.objects.get(id_alumno=idalumno)

        nombre_avatar = alum.ruta_avatar
        correo = alum.correoAL


        if imagenperfil :

            nombreimagen = secure_filename(imagenperfil.name)
            #fs = FileSystemStorage(location='ProyectoKaizen/static/media/Imagenes/Alumnos')
            fs = FileSystemStorage(location= os.path.join(settings.MEDIA_ROOT+'/Imagenes/Alumnos'))
            filenam = fs.save(nombreimagen, imagenperfil)

            if nombre_avatar == "avatar.png":

                pass

            else:

                os.remove(os.path.join(settings.MEDIA_ROOT+'/Imagenes/Alumnos/' + nombre_avatar))



        alumn = Alumno.objects.get(id_alumno=idalumno)

        alumn.nombreA = nombre
        alumn.apellidosA = apellido
        alumn.direccionA = direccion
        alumn.codigopostalA = cp
        alumn.estadoA = estado
        alumn.ciudadA = ciudad
        alumn.paisA = paisAG
        alumn.profesionA = ""
        alumn.edadA = edad
        alumn.celularA = celular
        alumn.tiposangreA = tiposangre
        alumn.alergiasA = alergias

        if nombreimagen == "":

            pass

        else:

            alumn.ruta_avatar = nombreimagen


        alumn.sexo_alumno = sexo
        alumn.save()

        if profesionuno:

            rel = RelacionProfesiones(id_profesionR=profesionuno, id_usuarioR=idalumno, tipo_usuarioR="Alummo")
            rel.save()

        if profesiondos:

            rell = RelacionProfesiones(id_profesionR=profesiondos, id_usuarioR=idalumno, tipo_usuarioR="Alummo")
            rell.save()

        if profesiontres:

            relll = RelacionProfesiones(id_profesionR=profesiontres, id_usuarioR=idalumno, tipo_usuarioR="Alummo")
            relll.save()

        if profesioncuatro:

            rellll = RelacionProfesiones(id_profesionR=profesioncuatro, id_usuarioR=idalumno, tipo_usuarioR="Alummo")
            rellll.save()

        if profesioncinco:

            relllll = RelacionProfesiones(id_profesionR=profesioncinco, id_usuarioR=idalumno, tipo_usuarioR="Alummo")
            relllll.save()

        vc = VerificarCuenta.objects.get(correo_vinculado=correo)
        vc.perfil_editado = 1
        vc.save()

        filtro = CursoEstudiante.objects.filter(id_estudianteR=idalumno).values('id_cursoR')

        curso = Curso.objects.filter(id_curso__in=filtro)

        valor = CursoEstudiante.objects.filter(id_estudianteR=idalumno)

        opcion = OpcionesAlumno.objects.filter(id_alumnoR=idalumno)

        usuario = Alumno.objects.filter(id_alumno=idalumno)

        todaynoti = date.today()

        finnoti = todaynoti + timedelta(days=3)

        notificacion = NotificacionesAlumnos.objects.filter(id_alumnoR=idalumno, fecha_fin__range=[todaynoti, finnoti], statusN=0)

        numeronotificaciones = NotificacionesAlumnos.objects.filter(id_alumnoR=idalumno, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()


        #Filtro recientes
        idalumno = request.user.id_relacionado
        filtroR = CursoEstudiante.objects.filter(id_estudianteR=idalumno).values('id_cursoR')
        ultimo = Curso.objects.all().order_by('-fecha_registro')[:3]

        contexto = {'ultimos':ultimo, 'cursos':curso, 'valores':valor, 'opciones':opcion, 'usuarios':usuario,
        'notificaciones':notificacion, 'numeronotificaciones':numeronotificaciones}

        opci = OpcionesAlumno.objects.get(id_alumnoR=idalumno)

        plantilla = opci.tipo_plantilla

        if plantilla == "_barra":

            return render(request, 'Alumno/Extras/Cursos/mostrar_cursos_barra.html', contexto)

        else:

            return render(request, 'Alumno/Extras/Cursos/mostrar_cursos_boton.html', contexto)


######################################################
######################################################
# Inician vistas para instructores

#Vistas reuniones zoom

@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_instructor, login_url='/iniciar_sesion/')
def mostrar_transmision_curso_instructor(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    idcurso = id
    idinstructor = request.user.id_relacionado

    opcion = OpcionesInstructor.objects.filter(id_instructorR=idinstructor)

    usuario = Instructor.objects.filter(id_instructor=idinstructor)


    todaynoti = date.today()

    finnoti = todaynoti + timedelta(days=3)

    notificacion = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0)

    numeronotificaciones = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()

    pagina = ElementosPagina.objects.filter(id_elementoPagina=1)



    #Consultas conferencias
    conferencia = TransmisionesInstructores.objects.filter(id_instructorR=idinstructor, id_cursoR=idcurso, fecha_transmision__gte=todaynoti).order_by('fecha_completa')

    contexto = {'conferencias':conferencia, 'paginas':pagina, 'usuarios':usuario, 'opciones':opcion,
    'notificaciones':notificacion, 'numeronotificaciones':numeronotificaciones}

    return render(request, 'Instructor/Extras/Cursos/transmisiones_curso.html', contexto)



@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_instructor, login_url='/iniciar_sesion/')
def reuniones_zoom_instructor(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    idinstructor = request.user.id_relacionado

    opcion = OpcionesInstructor.objects.filter(id_instructorR=idinstructor)

    usuario = Instructor.objects.filter(id_instructor=idinstructor)


    todaynoti = date.today()

    finnoti = todaynoti + timedelta(days=3)

    notificacion = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0)

    numeronotificaciones = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()

    pagina = ElementosPagina.objects.filter(id_elementoPagina=1)


    #Consulta Conferencia
    idconferencia = id
    conferencia = TransmisionesInstructores.objects.filter(id_transmisionInstructor=idconferencia)

    contexto = {'conferencias':conferencia, 'paginas':pagina, 'usuarios':usuario, 'opciones':opcion,
    'notificaciones':notificacion, 'numeronotificaciones':numeronotificaciones}

    return render(request, 'Instructor/Zoom/index.html', contexto)


@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_instructor, login_url='/iniciar_sesion/')
def reunion_zoom_instructor(request):

    request.session.set_expiry(request.session.get_expiry_age())

    return render(request, 'Instructor/Zoom/meeting.html')




#vistas consultas Calificaciones

@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_instructor, login_url='/iniciar_sesion/')
def mostrar_cursos_consulta_instructor(request):

    request.session.set_expiry(request.session.get_expiry_age())

    idinstructor = request.user.id_relacionado
    opcion = OpcionesInstructor.objects.filter(id_instructorR=idinstructor)

    usuario = Instructor.objects.filter(id_instructor=idinstructor)


    todaynoti = date.today()

    finnoti = todaynoti + timedelta(days=3)

    notificacion = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0)

    numeronotificaciones = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()

    pagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    filtro = CursoInstructor.objects.filter(id_instructorR=idinstructor).values('id_cursoR')

    curso = CursoInstructor.objects.filter(id_instructorR=idinstructor)

    cursoD = Curso.objects.filter(id_curso__in=filtro)

    instructor = Instructor.objects.filter(id_instructor=idinstructor)

    contexto = {'instructores':instructor, 'cursosD':cursoD, 'cursos':curso,
    'paginas':pagina, 'usuarios':usuario, 'opciones':opcion, 'notificaciones':notificacion, 'numeronotificaciones':numeronotificaciones}

    return render(request, 'Instructor/Extras/CAcademicas/cursos.html', contexto)



@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_instructor, login_url='/iniciar_sesion/')
def grupos_cursos_consulta_instructor(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    idinstructor = request.user.id_relacionado
    opcion = OpcionesInstructor.objects.filter(id_instructorR=idinstructor)

    usuario = Instructor.objects.filter(id_instructor=idinstructor)


    todaynoti = date.today()

    finnoti = todaynoti + timedelta(days=3)

    notificacion = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0)

    numeronotificaciones = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()

    pagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    idcurso = id

    filtro = GruposCursos.objects.filter(id_cursoR=idcurso, id_instructorR=idinstructor).values('id_grupoR')

    grupo = Grupos.objects.filter(id_grupo__in=filtro)

    contexto = {'idinstructor':idinstructor, 'idcurso':idcurso, 'grupos':grupo,
    'paginas':pagina, 'usuarios':usuario, 'opciones':opcion, 'notificaciones':notificacion, 'numeronotificaciones':numeronotificaciones}

    return render(request, 'Instructor/Extras/CAcademicas/grupos.html', contexto)



@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_instructor, login_url='/iniciar_sesion/')
def mostrar_alumnos_calificacion_instructor(request, id, id2):

    request.session.set_expiry(request.session.get_expiry_age())

    idinstructor = request.user.id_relacionado
    opcion = OpcionesInstructor.objects.filter(id_instructorR=idinstructor)

    usuario = Instructor.objects.filter(id_instructor=idinstructor)


    todaynoti = date.today()

    finnoti = todaynoti + timedelta(days=3)

    notificacion = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0)

    numeronotificaciones = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()

    pagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    idgrupo = id
    idcurso = id2

    filtro = GruposAlumnos.objects.filter(id_grupoR=idgrupo, id_cursoR=idcurso, id_instructorR=idinstructor).values('id_alumnoR')

    alumno = Alumno.objects.filter(id_alumno__in=filtro)

    carrera = Carreras.objects.all()

    contexto = {'idgrupo':idgrupo, 'idcurso':idcurso, 'idinstructor':idinstructor, 'carreras':carrera, 'alumnos':alumno,
    'paginas':pagina, 'usuarios':usuario, 'opciones':opcion, 'notificaciones':notificacion, 'numeronotificaciones':numeronotificaciones}

    return render(request, 'Instructor/Extras/CAcademicas/alumnos_lista.html', contexto)



@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_instructor, login_url='/iniciar_sesion/')
def mostrar_alumnos_calificacion_instructor_reload_ajax(request, id, id2, id3, id4, id5):

    request.session.set_expiry(request.session.get_expiry_age())

    estado = id
    carrera = id2
    gradoG = id3

    idgrupo = id4
    idcurso = id5
    idinstructor = request.user.id_relacionado

    filtro2 = GruposAlumnos.objects.filter(id_grupoR=idgrupo, id_cursoR=idcurso, id_instructorR=idinstructor).values('id_alumnoR')

    if estado == "Todos" and carrera == "Todos" and gradoG == "Todos":

        alumno = Alumno.objects.filter(id_alumno__in=filtro2)

    elif estado == "Todos" and carrera != "Todos" and gradoG == "Todos":

        alumno = Alumno.objects.filter(id_alumno__in=filtro2, licenciatura=carrera)

    elif estado == "Todos" and carrera == "Todos" and gradoG != "Todos":

        alumno = Alumno.objects.filter(id_alumno__in=filtro2, grado=gradoG)


    elif estado == "Todos" and carrera != "Todos" and gradoG != "Todos":

        alumno = Alumno.objects.filter(id_alumno__in=filtro2, grado=gradoG, licenciatura=carrera)


    elif estado == "Aprobados" and carrera == "Todos" and gradoG == "Todos":

        filtro = CursoEstudiante.objects.filter(id_estudianteR__in=filtro2, promedio_curso__range=[7, 10]).values('id_estudianteR')

        alumno = Alumno.objects.filter(id_alumno__in=filtro)

    elif estado == "Aprobados" and carrera != "Todos" and gradoG == "Todos":

        filtro = CursoEstudiante.objects.filter(id_estudianteR__in=filtro2, promedio_curso__range=[7, 10]).values('id_estudianteR')

        alumno = Alumno.objects.filter(id_alumno__in=filtro, licenciatura=carrera)

    elif estado == "Aprobados" and carrera == "Todos" and gradoG != "Todos":

        filtro = CursoEstudiante.objects.filter(id_estudianteR__in=filtro2, promedio_curso__range=[7, 10]).values('id_estudianteR')

        alumno = Alumno.objects.filter(id_alumno__in=filtro, grado=gradoG)


    elif estado == "Aprobados" and carrera != "Todos" and gradoG != "Todos":

        filtro = CursoEstudiante.objects.filter(id_estudianteR__in=filtro2, promedio_curso__range=[7, 10]).values('id_estudianteR')

        alumno = Alumno.objects.filter(id_alumno__in=filtro, grado=gradoG, licenciatura=carrera)


    elif estado == "Reprobados" and carrera == "Todos" and gradoG == "Todos":

        filtro = CursoEstudiante.objects.filter(id_estudianteR__in=filtro2, promedio_curso__range=[0, 6]).values('id_estudianteR')
        alumno = Alumno.objects.filter(id_alumno__in=filtro)

    elif estado == "Reprobados" and carrera != "Todos" and gradoG == "Todos":

        filtro = CursoEstudiante.objects.filter(id_estudianteR__in=filtro2, promedio_curso__range=[0, 6]).values('id_estudianteR')
        alumno = Alumno.objects.filter(id_alumno__in=filtro, licenciatura=carrera)

    elif estado == "Reprobados" and carrera == "Todos" and gradoG != "Todos":

        filtro = CursoEstudiante.objects.filter(id_estudianteR__in=filtro2, promedio_curso__range=[0, 6]).values('id_estudianteR')
        alumno = Alumno.objects.filter(id_alumno__in=filtro, grado=gradoG)


    elif estado == "Reprobados" and carrera != "Todos" and gradoG != "Todos":

        filtro = CursoEstudiante.objects.filter(id_estudianteR__in=filtro2, promedio_curso__range=[0, 6]).values('id_estudianteR')

        alumno = Alumno.objects.filter(id_alumno__in=filtro, grado=gradoG, licenciatura=carrera)



    contexto = {'alumnos':alumno}

    return render(request, 'Instructor/Extras/CAcademicas/alumnos_lista_ajax.html', contexto)




@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_instructor, login_url='/iniciar_sesion/')
def mostrar_calificaciones_alumno_instructor(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    idinstructor = request.user.id_relacionado
    opcion = OpcionesInstructor.objects.filter(id_instructorR=idinstructor)

    usuario = Instructor.objects.filter(id_instructor=idinstructor)


    todaynoti = date.today()

    finnoti = todaynoti + timedelta(days=3)

    notificacion = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0)

    numeronotificaciones = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()

    pagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    idalumno = id

    filtro = CursoEstudiante.objects.filter(id_estudianteR=idalumno).values('id_cursoR')

    total = CursoEstudiante.objects.filter(id_estudianteR=idalumno).count()

    calumno = CursoEstudiante.objects.filter(id_estudianteR=idalumno)

    suma = 0

    for valor in calumno:

        dato = valor.promedio_curso

        suma = suma + dato

    if total != 0:
        promedioGeneral = suma/total
    else:
        promedioGeneral = 0


    curso = Curso.objects.filter(id_curso__in=filtro)

    alumno = Alumno.objects.filter(id_alumno=idalumno)

    contexto = {'idalumno':idalumno, 'promedioGeneral':promedioGeneral, 'calumnos':calumno, 'cursos':curso, 'alumnos':alumno,
    'paginas':pagina, 'usuarios':usuario, 'opciones':opcion, 'notificaciones':notificacion, 'numeronotificaciones':numeronotificaciones}

    return render(request, 'Instructor/Extras/CAcademicas/alumno_materias.html', contexto)




@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_instructor, login_url='/iniciar_sesion/')
def mostrar_calificaciones_curso_instructor(request, id, id2):

    request.session.set_expiry(request.session.get_expiry_age())

    idinstructor = request.user.id_relacionado

    opcion = OpcionesInstructor.objects.filter(id_instructorR=idinstructor)

    usuario = Instructor.objects.filter(id_instructor=idinstructor)


    todaynoti = date.today()

    finnoti = todaynoti + timedelta(days=3)

    notificacion = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0)

    numeronotificaciones = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()

    pagina = ElementosPagina.objects.filter(id_elementoPagina=1)


    idalumno = id

    idcurso = id2

    actividad = Actividad.objects.filter(id_cursoR=idcurso, id_instructorR=idinstructor)

    actividadA = ActividadAlumno.objects.filter(id_alumnoR=idalumno, id_cursoR=idcurso)

    examen = EvaluacionesCursos.objects.filter(id_cursoR=idcurso, id_instructorR=idinstructor)

    examenA = EvaluacionCursosEstudiante.objects.filter(id_estudianteR=idalumno, id_cursoR=idcurso, id_instructorR=idinstructor)

    curso = Curso.objects.filter(id_curso=idcurso)

    alumno = Alumno.objects.filter(id_alumno=idalumno)

    contexto = {'paginas':pagina, 'usuarios':usuario, 'opciones':opcion, 'notificaciones':notificacion, 'numeronotificaciones':numeronotificaciones, 'actividades':actividad, 'actividadesA':actividadA, 'examenes':examen, 'examenesA':examenA, 'cursos':curso, 'alumnos':alumno}

    return render(request, 'Instructor/Extras/CAcademicas/materias_lista.html', contexto)



@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_instructor, login_url='/iniciar_sesion/')
def imprimir_lista_instructor(request, id, id2):

    request.session.set_expiry(request.session.get_expiry_age())

    idgrupo = id

    idcurso = id2

    idinstructor = request.user.id_relacionado

    gr = Grupos.objects.get(id_grupo=idgrupo)
    nombre_grupoG = gr.nombre_grupo

    emp = PaginasActivas.objects.get(id_paginaActiva=1)
    nombre_empre = emp.nombre_empresa

    filtro = GruposAlumnos.objects.filter(id_grupoR=idgrupo, id_cursoR=idcurso, id_instructorR=idinstructor).values('id_alumnoR')

    alumnos = CursoEstudiante.objects.filter(id_cursoR=idcurso, id_instructorRC=idinstructor, id_estudianteR__in=filtro)

    alumnos2 = Alumno.objects.filter(id_alumno__in=filtro).order_by("apellidosA")

    nombrearchivo = nombre_grupoG + ' - con calificaciones.xlsx'

    workbook = xlsxwriter.Workbook(os.path.join(settings.MEDIA_ROOT+'/Listas/Instructor/'+ nombrearchivo))
    worksheet = workbook.add_worksheet()

    worksheet.set_column('A:A', 4)

    merge_format = workbook.add_format({
        'bold': 1,
        'text_wrap': True,
        'align': 'center',
        'valign': 'vcenter'})

    merge_format2 = workbook.add_format({
        'bold': 1,
        'border': 1,
        'align': 'center',
        'valign': 'vcenter',
        'fg_color': 'silver'})

    merge_format3 = workbook.add_format({
        'border': 1})


    merge_format4 = workbook.add_format({
        'border': 1,
        'align': 'center'})


    imagen = os.path.join(settings.MEDIA_ROOT+'/Imagenes', "LogoKaizen.jpg")
    nombre_escuela = nombre_empre

    grupo = nombre_grupoG

    bound_width_height = (110, 110)
    resize_scale = calculate_scale(imagen, bound_width_height)
    worksheet.insert_image('B2', imagen, {'x_scale': resize_scale, 'y_scale': resize_scale})


    worksheet.merge_range('D3:G4', nombre_escuela, merge_format)
    worksheet.merge_range('D6:G6', grupo, merge_format)


    worksheet.write('A8', 'No.', merge_format2)
    worksheet.merge_range('B8:F8', 'Nombre del alumno', merge_format2)
    worksheet.merge_range('G8:H8', 'Calificacion', merge_format2)


    no_lista = 'A'

    lista = 9

    nombre1 = 'B'
    nombre2 = 'F'

    nombre = 9

    calificacion1 = 'G'
    calificacion2 = 'H'

    calificacion = 9

    contador = 1

    for alumnoD in alumnos2:

        id = alumnoD.id_alumno

        alumno = alumnoD.apellidosA + " " + alumnoD.nombreA

        for alumnoF in alumnos:

            if alumnoF.id_estudianteR == id:

                resultado = alumnoF.promedio_curso

        contador_final = contador
        lista_final = no_lista + str(lista)
        nombre_final = nombre1 + str(nombre) + ':' + nombre2 + str(nombre)
        calificacion_final = calificacion1 + str(calificacion) + ':' + calificacion2 + str(calificacion)


        worksheet.write(lista_final, contador_final, merge_format4)
        worksheet.merge_range(nombre_final, alumno, merge_format3)
        worksheet.merge_range(calificacion_final, resultado, merge_format4)

        lista = lista + 1
        nombre = nombre + 1
        calificacion = calificacion + 1
        contador = contador + 1


    workbook.close()

    #archivo = os.path.join(settings.MEDIA_ROOT+'/Listas/Administrador', nombrearchivo)
    archivo = open(os.path.join(settings.MEDIA_ROOT+'/Listas/Instructor', nombrearchivo), "rb")

    #response = HttpResponse(archivo, content_type='application/ms-excel')
    response = HttpResponse(archivo.read(), content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    response['Content-Disposition'] = 'attachment; filename=lista-con-calificaciones.xlsx'
    return(response)



@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_instructor, login_url='/iniciar_sesion/')
def imprimir_lista_sin_instructor(request, id, id2):

    request.session.set_expiry(request.session.get_expiry_age())

    idgrupo = id

    idcurso = id2

    idinstructor = request.user.id_relacionado

    gr = Grupos.objects.get(id_grupo=idgrupo)
    nombre_grupoG = gr.nombre_grupo

    emp = PaginasActivas.objects.get(id_paginaActiva=1)
    nombre_empre = emp.nombre_empresa

    filtro = GruposAlumnos.objects.filter(id_grupoR=idgrupo, id_cursoR=idcurso, id_instructorR=idinstructor).values('id_alumnoR')

    alumnos = CursoEstudiante.objects.filter(id_cursoR=idcurso, id_instructorRC=idinstructor, id_estudianteR__in=filtro)

    alumnos2 = Alumno.objects.filter(id_alumno__in=filtro).order_by("apellidosA")

    nombrearchivo = nombre_grupoG + ' - sin calificaciones.xlsx'

    workbook = xlsxwriter.Workbook(os.path.join(settings.MEDIA_ROOT+'/Listas/Instructor/'+ nombrearchivo))
    worksheet = workbook.add_worksheet()

    worksheet.set_column('A:A', 4)

    merge_format = workbook.add_format({
        'bold': 1,
        'text_wrap': True,
        'align': 'center',
        'valign': 'vcenter'})

    merge_format2 = workbook.add_format({
        'bold': 1,
        'border': 1,
        'align': 'center',
        'valign': 'vcenter',
        'fg_color': 'silver'})

    merge_format3 = workbook.add_format({
        'border': 1})


    merge_format4 = workbook.add_format({
        'border': 1,
        'align': 'center'})


    imagen = os.path.join(settings.MEDIA_ROOT+'/Imagenes', "LogoKaizen.jpg")
    nombre_escuela = nombre_empre

    grupo = nombre_grupoG

    bound_width_height = (110, 110)
    resize_scale = calculate_scale(imagen, bound_width_height)
    worksheet.insert_image('B2', imagen, {'x_scale': resize_scale, 'y_scale': resize_scale})


    worksheet.merge_range('D3:G4', nombre_escuela, merge_format)
    worksheet.merge_range('D6:G6', grupo, merge_format)


    worksheet.write('A8', 'No.', merge_format2)
    worksheet.merge_range('B8:H8', 'Nombre del alumno', merge_format2)

    no_lista = 'A'

    lista = 9

    nombre1 = 'B'
    nombre2 = 'H'

    nombre = 9

    contador = 1

    for alumnoD in alumnos2:

        alumno = alumnoD.apellidosA + " " + alumnoD.nombreA

        contador_final = contador
        lista_final = no_lista + str(lista)
        nombre_final = nombre1 + str(nombre) + ':' + nombre2 + str(nombre)

        worksheet.write(lista_final, contador_final, merge_format4)
        worksheet.merge_range(nombre_final, alumno, merge_format3)

        lista = lista + 1
        nombre = nombre + 1
        contador = contador + 1


    workbook.close()

    #archivo = os.path.join(settings.MEDIA_ROOT+'/Listas/Administrador', nombrearchivo)
    archivo = open(os.path.join(settings.MEDIA_ROOT+'/Listas/Instructor', nombrearchivo), "rb")

    #response = HttpResponse(archivo, content_type='application/ms-excel')
    response = HttpResponse(archivo.read(), content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    response['Content-Disposition'] = 'attachment; filename=lista-sin-calificaciones.xlsx'
    return(response)




## Finalizan nuevas vistas

@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_instructor, login_url='/iniciar_sesion/')
def mostrar_conferencias_instructor(request):

    request.session.set_expiry(request.session.get_expiry_age())

    idinstructor = request.user.id_relacionado

    conferencia = TransmisionesInstructores.objects.filter(id_instructorR=idinstructor)

    filtro = CursoInstructor.objects.filter(id_instructorR=idinstructor).values('id_cursoR')

    curso = Curso.objects.filter(id_curso__in=filtro)

    opcion = OpcionesInstructor.objects.filter(id_instructorR=idinstructor)

    usuario = Instructor.objects.filter(id_instructor=idinstructor)


    todaynoti = date.today()

    finnoti = todaynoti + timedelta(days=3)

    notificacion = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0)

    numeronotificaciones = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()

    pagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    contexto = {'paginas':pagina, 'usuarios':usuario, 'conferencias':conferencia, 'cursos':curso,
    'opciones':opcion, 'notificaciones':notificacion, 'numeronotificaciones':numeronotificaciones}

    return render(request, 'Instructor/Extras/Transmisiones/transmisiones.html', contexto)



@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_instructor, login_url='/iniciar_sesion/')
def mostrar_agregar_transmision_instructor(request):

    request.session.set_expiry(request.session.get_expiry_age())

    idinstructor = request.user.id_relacionado

    filtro = CursoInstructor.objects.filter(id_instructorR=idinstructor).values('id_cursoR')

    curso = Curso.objects.filter(id_curso__in=filtro)

    opcion = OpcionesInstructor.objects.filter(id_instructorR=idinstructor)

    usuario = Instructor.objects.filter(id_instructor=idinstructor)


    todaynoti = date.today()

    finnoti = todaynoti + timedelta(days=3)

    notificacion = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0)

    numeronotificaciones = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()

    pagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    fecha = str(todaynoti)

    contexto = {'paginas':pagina, 'usuarios':usuario, 'cursos':curso,
    'opciones':opcion, 'notificaciones':notificacion, 'numeronotificaciones':numeronotificaciones, 'fecha':fecha}

    return render(request, 'Instructor/Extras/Transmisiones/agregar_transmision.html', contexto)



@csrf_exempt
@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_instructor, login_url='/iniciar_sesion/')
def agregar_transmision_instructor(request):

    request.session.set_expiry(request.session.get_expiry_age())

    if request.method == "POST":

        nombreG = request.POST["nombre"]
        fechaG = request.POST["fecha"]
        horaG = request.POST["hora"]
        idcurso = request.POST["curso"]

        idreunionG = request.POST["idreunion"]
        contrareunionG = request.POST["contrareunion"]

        '''
        urlpartida = url.split("=")

        if len(urlpartida) == 1:

            urlpartida = url.split('/')

        urlvideo = urlpartida[-1]
        '''

        fechahora = str(fechaG) + " " + str(horaG)

        idinstructor = request.user.id_relacionado

        tv = TransmisionesInstructores(id_instructorR=idinstructor, id_cursoR=idcurso, nombre_transmision=nombreG,
        fecha_transmision=fechaG, hora_transmision=horaG, fecha_completa=fechahora, statusT=1, numero_reunion=idreunionG,
        contra_reunion=contrareunionG)
        tv.save()

        return redirect('/transmisiones_instructor/')



@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_instructor, login_url='/iniciar_sesion/')
def mostrar_editar_transmision_instructor(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    idtransmision = id
    idinstructor = request.user.id_relacionado

    conferencia = TransmisionesInstructores.objects.filter(id_transmisionInstructor=idtransmision)

    filtro = CursoInstructor.objects.filter(id_instructorR=idinstructor).values('id_cursoR')

    curso = Curso.objects.filter(id_curso__in=filtro)

    opcion = OpcionesInstructor.objects.filter(id_instructorR=idinstructor)

    usuario = Instructor.objects.filter(id_instructor=idinstructor)


    todaynoti = date.today()

    finnoti = todaynoti + timedelta(days=3)

    notificacion = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0)

    numeronotificaciones = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()

    pagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    fecha = str(todaynoti)

    contexto = {'paginas':pagina, 'usuarios':usuario, 'conferencias':conferencia, 'cursos':curso,
    'opciones':opcion, 'notificaciones':notificacion, 'numeronotificaciones':numeronotificaciones, 'fecha':fecha}

    return render(request, 'Instructor/Extras/Transmisiones/editar_transmision.html', contexto)


@csrf_exempt
@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_instructor, login_url='/iniciar_sesion/')
def editar_transmision_instructor(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    if request.method == "POST":

        nombreG = request.POST["nombre"]
        fechaG = request.POST["fecha"]
        horaG = request.POST["hora"]
        idcurso = request.POST["curso"]

        idreunionG = request.POST["idreunion"]
        contrareunionG = request.POST["contrareunion"]

        idtransmision = id

        '''
        urlpartida = url.split("=")

        if len(urlpartida) == 1:

            urlpartida = url.split('/')

        urlvideo = urlpartida[-1]
        '''

        fechahora = str(fechaG) + " " + str(horaG)

        idinstructor = request.user.id_relacionado

        tv = TransmisionesInstructores.objects.get(id_transmisionInstructor=idtransmision)
        tv.fecha_transmision = fechaG
        tv.hora_transmision = horaG
        tv.id_cursoR = idcurso
        tv.fecha_completa = fechahora
        tv.nombre_transmision = nombreG
        tv.numero_reunion = idreunionG
        tv.contra_reunion = contrareunionG
        tv.save()

        return redirect('/transmisiones_instructor/')



@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_instructor, login_url='/iniciar_sesion/')
def habilitar_transmision_instructor(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    idtransmision = id

    entra = TransmisionesInstructores.objects.get(id_transmisionInstructor=idtransmision)
    estado = entra.statusT

    if estado == 0:

        entra.statusT = 1
        entra.save()

    else:

        entra.statusT = 0
        entra.save()


    return redirect('/transmisiones_instructor/')



@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_instructor, login_url='/iniciar_sesion/')
def mensajes_instructor(request):

    request.session.set_expiry(request.session.get_expiry_age())

    idinstructor = request.user.id_relacionado

    filtro = CursoEstudiante.objects.filter(id_instructorRC=idinstructor).values('id_estudianteR')

    alumno = Alumno.objects.filter(id_alumno__in=filtro)

    opcion = OpcionesInstructor.objects.filter(id_instructorR=idinstructor)

    usuario = Instructor.objects.filter(id_instructor=idinstructor)

    todaynoti = date.today()

    finnoti = todaynoti + timedelta(days=3)

    notificacion = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0)

    numeronotificaciones = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()

    pagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    contexto = {'paginas':pagina, 'opciones':opcion, 'usuarios':usuario, 'notificaciones':notificacion,
    'numeronotificaciones':numeronotificaciones, 'alumnos':alumno}

    return render(request, 'Instructor/Extras/General/mensajes.html', contexto)



@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_instructor, login_url='/iniciar_sesion/')
def mostrar_mensajes_instructor(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    idalumno = id

    idinstructor = request.user.id_relacionado

    allu = Alumno.objects.get(id_alumno=idalumno)
    nombrealumno = allu.nombreA + " " + allu.apellidosA
    imagenalumno = allu.ruta_avatar

    inst = Instructor.objects.get(id_instructor=idinstructor)
    nombreinstructor = inst.nombreI + " " + inst.apellidosI
    imageninstructor = inst.ruta_imagen_perfil


    ins = Usuarios.objects.get(id_relacionado=idinstructor, tipo_usuario=2)
    idusuarioinstructor = ins.id_usuario

    alu = Usuarios.objects.get(id_relacionado=idalumno, tipo_usuario=3)
    idusuarioalumno = alu.id_usuario

    mensaje = MensajesUsuarios.objects.filter(id_alumnoR=idusuarioalumno, id_instructorR=idusuarioinstructor).order_by('fecha')


    user = Alumno.objects.filter(id_alumno=idalumno)

    filtro = CursoEstudiante.objects.filter(id_instructorRC=idinstructor).values('id_estudianteR')

    alumno = Alumno.objects.filter(id_alumno__in=filtro)

    opcion = OpcionesInstructor.objects.filter(id_instructorR=idinstructor)

    usuario = Instructor.objects.filter(id_instructor=idinstructor)

    todaynoti = date.today()

    finnoti = todaynoti + timedelta(days=3)

    notificacion = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0)

    numeronotificaciones = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()

    pagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    contexto = {'paginas':pagina, 'opciones':opcion, 'usuarios':usuario, 'notificaciones':notificacion,
    'numeronotificaciones':numeronotificaciones, 'alumnos':alumno,
    'users':user, 'mensajes':mensaje, 'nombrealumno':nombrealumno, 'imagenalumno':imagenalumno,
    'nombreinstructor':nombreinstructor, 'imageninstructor':imageninstructor}

    return render(request, 'Instructor/Extras/General/mensajes.html', contexto)



@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_instructor, login_url='/iniciar_sesion/')
def mostrar_mensajes_instructor_dos(request, id, id2):

    request.session.set_expiry(request.session.get_expiry_age())

    idalumno = id

    idnotificacion = id2

    idinstructor = request.user.id_relacionado

    allu = Alumno.objects.get(id_alumno=idalumno)
    nombrealumno = allu.nombreA + " " + allu.apellidosA
    imagenalumno = allu.ruta_avatar

    inst = Instructor.objects.get(id_instructor=idinstructor)
    nombreinstructor = inst.nombreI + " " + inst.apellidosI
    imageninstructor = inst.ruta_imagen_perfil


    ins = Usuarios.objects.get(id_relacionado=idinstructor, tipo_usuario=2)
    idusuarioinstructor = ins.id_usuario

    alu = Usuarios.objects.get(id_relacionado=idalumno, tipo_usuario=3)
    idusuarioalumno = alu.id_usuario

    mensaje = MensajesUsuarios.objects.filter(id_alumnoR=idusuarioalumno, id_instructorR=idusuarioinstructor).order_by('fecha')


    user = Alumno.objects.filter(id_alumno=idalumno)

    filtro = CursoEstudiante.objects.filter(id_instructorRC=idinstructor).values('id_estudianteR')

    alumno = Alumno.objects.filter(id_alumno__in=filtro)

    opcion = OpcionesInstructor.objects.filter(id_instructorR=idinstructor)

    usuario = Instructor.objects.filter(id_instructor=idinstructor)

    noti = NotificacionesInstructores.objects.get(id_notificacionInstructor=idnotificacion)
    noti.statusN = 1
    noti.save()

    todaynoti = date.today()

    finnoti = todaynoti + timedelta(days=3)

    notificacion = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0)

    numeronotificaciones = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()

    pagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    contexto = {'paginas':pagina, 'opciones':opcion, 'usuarios':usuario, 'notificaciones':notificacion,
    'numeronotificaciones':numeronotificaciones, 'alumnos':alumno,
    'users':user, 'mensajes':mensaje, 'nombrealumno':nombrealumno, 'imagenalumno':imagenalumno,
    'nombreinstructor':nombreinstructor, 'imageninstructor':imageninstructor}

    return render(request, 'Instructor/Extras/General/mensajes.html', contexto)





@csrf_exempt
@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_instructor, login_url='/iniciar_sesion/')
def agregar_mensaje_instructor(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    if request.method == "POST":

        message = request.POST["mensaje"]


        idalumno = id

        idinstructor = request.user.id_relacionado


        allu = Alumno.objects.get(id_alumno=idalumno)
        nombrealumno = allu.nombreA + " " + allu.apellidosA
        imagenalumno = allu.ruta_avatar

        inst = Instructor.objects.get(id_instructor=idinstructor)
        nombreinstructor = inst.nombreI + " " + inst.apellidosI
        imageninstructor = inst.ruta_imagen_perfil


        ins = Usuarios.objects.get(id_relacionado=idinstructor, tipo_usuario=2)
        idusuarioinstructor = ins.id_usuario

        alu = Usuarios.objects.get(id_relacionado=idalumno, tipo_usuario=3)
        idusuarioalumno = alu.id_usuario

        fecha_hoy = datetime.now()

        #hora = datetime.now().strftime('%I:%M:%S')

        horamensaje = fecha_hoy.strftime("%I:%M:%S")

        mensa = MensajesUsuarios(id_alumnoR=idusuarioalumno, id_instructorR=idusuarioinstructor,
        mensaje=message, fecha=fecha_hoy, hora=horamensaje, remitente="Instructor")
        mensa.save()

        texto = "Tu instructor " + nombreinstructor + " te envio un mensaje."

        today = date.today()

        hora = datetime.now().strftime('%I:%M:%S')

        fechafinal = today + timedelta(days=3)

        ni = NotificacionesAlumnos(id_alumnoR=idalumno, mensaje_notificacion=texto,
        fecha_notificacion=today, hora_notificacion=hora, fecha_fin=fechafinal, id_elementoNotificacion=idinstructor,
        tipo_elementoNotificacion="MensajeI")
        ni.save()


        mensaje = MensajesUsuarios.objects.filter(id_alumnoR=idusuarioalumno, id_instructorR=idusuarioinstructor).order_by('fecha')


        user = Alumno.objects.filter(id_alumno=idalumno)

        filtro = CursoEstudiante.objects.filter(id_instructorRC=idinstructor).values('id_estudianteR')

        alumno = Alumno.objects.filter(id_alumno__in=filtro)

        opcion = OpcionesInstructor.objects.filter(id_instructorR=idinstructor)

        usuario = Instructor.objects.filter(id_instructor=idinstructor)

        todaynoti = date.today()

        finnoti = todaynoti + timedelta(days=3)

        notificacion = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0)

        numeronotificaciones = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()

        pagina = ElementosPagina.objects.filter(id_elementoPagina=1)

        contexto = {'paginas':pagina, 'opciones':opcion, 'usuarios':usuario, 'notificaciones':notificacion,
        'numeronotificaciones':numeronotificaciones, 'alumnos':alumno,
        'users':user, 'mensajes':mensaje, 'nombrealumno':nombrealumno, 'imagenalumno':imagenalumno,
        'nombreinstructor':nombreinstructor, 'imageninstructor':imageninstructor}

        return render(request, 'Instructor/Extras/General/mensajes.html', contexto)




@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_instructor, login_url='/iniciar_sesion/')
def inicio_instructor(request):

    request.session.set_expiry(request.session.get_expiry_age())

    Afganistan = 0
    Albania = 0
    Alemania = 0
    Andorra = 0
    Angola = 0
    Antigua_y_Barbuda = 0
    Arabia_Saudita = 0
    Argelia = 0
    Argentina = 0
    Armenia = 0
    Australia = 0
    Austria = 0
    Azerbaiyan = 0
    Bahamas = 0
    Banglades = 0
    Barbados = 0
    Barein = 0
    Belgica = 0
    Belice = 0
    Benin = 0
    Bielorrusia = 0
    Birmania_Myanmar = 0
    Bolivia = 0
    Bosnia_y_Herzegovina = 0
    Botsuana = 0
    Brasil = 0
    Brunei = 0
    Bulgaria = 0
    Burkina_Faso = 0
    Burundi = 0
    Butan = 0
    Cabo_Verde = 0
    Camboya = 0
    Camerun = 0
    Canada = 0
    Catar = 0
    Chad = 0
    Chile = 0
    China = 0
    Chipre = 0
    Ciudad_del_Vaticano = 0
    Colombia = 0
    Comoras = 0
    Corea_del_Norte = 0
    Corea_del_Sur = 0
    Costa_de_Marfil = 0
    Costa_Rica = 0
    Croacia = 0
    Cuba = 0
    Dinamarca = 0
    Dominica = 0
    Ecuador = 0
    Egipto = 0
    El_Salvador = 0
    Emiratos_Arabes_Unidos = 0
    Eritrea = 0
    Eslovaquia = 0
    Eslovenia = 0
    Espana = 0
    Estados_Unidos = 0
    Estonia = 0
    Etiopia = 0
    Filipinas = 0
    Finlandia = 0
    Fiyi = 0
    Francia = 0
    Gabon = 0
    Gambia = 0
    Georgia = 0
    Ghana = 0
    Granada = 0
    Grecia = 0
    Guatemala = 0
    Guyana = 0
    Guinea = 0
    Guinea_ecuatorial = 0
    Guinea_Bisau = 0
    Haiti = 0
    Honduras = 0
    Hungria = 0
    India = 0
    Indonesia = 0
    Irak = 0
    Iran = 0
    Irlanda = 0
    Islandia = 0
    Islas_Marshall = 0
    Islas_Salomon = 0
    Israel = 0
    Italia = 0
    Jamaica = 0
    Japon = 0
    Jordania = 0
    Kazajistan = 0
    Kenia = 0
    Kirguistan = 0
    Kiribati = 0
    Kuwait = 0
    Laos = 0
    Lesoto = 0
    Letonia = 0
    Libano = 0
    Liberia = 0
    Libia = 0
    Liechtenstein = 0
    Lituania = 0
    Luxemburgo = 0
    Macedonia_del_Norte = 0
    Madagascar = 0
    Malasia = 0
    Malaui = 0
    Maldivas = 0
    Mali = 0
    Malta = 0
    Marruecos = 0
    Mauricio = 0
    Mauritania = 0
    Mexico = 0
    Micronesia = 0
    Moldavia = 0
    Monaco = 0
    Mongolia = 0
    Montenegro = 0
    Mozambique = 0
    Namibia = 0
    Nauru = 0
    Nepal = 0
    Nicaragua = 0
    Niger = 0
    Nigeria = 0
    Noruega = 0
    Nueva_Zelanda = 0
    Oman = 0
    Paises_Bajos = 0
    Pakistan = 0
    Palaos = 0
    Panama = 0
    Papua_Nueva_Guinea = 0
    Paraguay = 0
    Peru = 0
    Polonia = 0
    Portugal = 0
    Reino_Unido = 0
    Republica_Centroafricana = 0
    Republica_Checa = 0
    Republica_del_Congo = 0
    Republica_Democratica_del_Congo = 0
    Republica_Dominicana = 0
    Republica_Sudafricana = 0
    Ruanda = 0
    Rumania = 0
    Rusia = 0
    Samoa = 0
    San_Cristobal_y_Nieves = 0
    San_Marino = 0
    San_Vicente_y_las_Granadinas = 0
    Santa_Lucia = 0
    Santo_Tome_y_Principe = 0
    Senegal = 0
    Serbia = 0
    Seychelles = 0
    Sierra_Leona = 0
    Singapur = 0
    Siria = 0
    Somalia = 0
    Sri_Lanka = 0
    Suazilandia = 0
    Sudan = 0
    Sudan_del_Sur = 0
    Suecia = 0
    Suiza = 0
    Surinam = 0
    Tailandia = 0
    Tanzania = 0
    Tayikistan = 0
    Timor_Oriental = 0
    Togo = 0
    Tonga = 0
    Trinidad_y_Tobago = 0
    Tunez = 0
    Turkmenistan = 0
    Turquia = 0
    Tuvalu = 0
    Ucrania = 0
    Uganda = 0
    Uruguay = 0
    Uzbekistan = 0
    Vanuatu = 0
    Venezuela = 0
    Vietnam = 0
    Yemen = 0
    Yibuti = 0
    Zambia = 0
    Zimbabue = 0
    Chequia = 0
    Hong_Kong = 0
    Sudafrica = 0
    Taiwan = 0
    Gran_Bretana = 0

    alumnos = Alumno.objects.all()

    if alumnos:

        for alumno in alumnos:

            pais = alumno.paisA

            if pais == "Afganistan":
                Afganistan = Afganistan + 1
            elif pais == "Albania":
                Albania = Albania + 1
            elif pais == "Germany":
                Alemania = Alemania + 1
            elif pais == "Andorra":
                Andorra = Andorra + 1
            elif pais == "Angola":
                Angola = Angola + 1
            elif pais == "Antigua and Barbuda":
                Antigua_y_Barbuda = Antigua_y_Barbuda + 1
            elif pais == "Saudi Arabia":
                Arabia_Saudita = Arabia_Saudita + 1
            elif pais == "Algeria":
                Argelia = Argelia + 1
            elif pais == "Argentina":
                Argentina = Argentina + 1
            elif pais == "Armenia":
                Armenia = Armenia + 1
            elif pais == "Australia":
                Australia = Australia + 1
            elif pais == "Austria":
                Austria = Austria + 1
            elif pais == "Azerbaijan":
                Azerbaiyan = Azerbaiyan + 1
            elif pais == "Bahamas":
                Bahamas = Bahamas + 1
            elif pais == "Bangladesh":
                Banglades = Banglades + 1
            elif pais == "Barbados":
                Barbados = Barbados + 1
            elif pais == "Barein":
                Barein = Barein + 1
            elif pais == "Belgium":
                Belgica = Belgica + 1
            elif pais == "Belize":
                Belice = Belice + 1
            elif pais == "Benin":
                Benin = Benin + 1
            elif pais == "Belarus":
                Bielorrusia = Bielorrusia + 1
            elif pais == "Burna and Myanmar":
                Birmania_Myanmar =Birmania_Myanmar + 1
            elif pais == "Bolivia":
                Bolivia =Bolivia + 1
            elif pais == "Bosnia and Herzegovina":
                Bosnia_y_Herzegovina = Bosnia_y_Herzegovina + 1
            elif pais == "Botswana":
                Botsuana = Botsuana + 1
            elif pais == "Brazil":
                Brasil = Brasil  + 1
            elif pais == "Brunei":
                Brunei = Brunei + 1
            elif pais == "Bulgaria":
                Bulgaria = Bulgaria + 1
            elif pais == "Burkina Faso":
                Burkina_Faso = Burkina_Faso + 1
            elif pais == "Burundi":
                Burundi =Burundi + 1
            elif pais == "Bhutan":
                Butan = Butan + 1
            elif pais == "Cape Verde":
                Cabo_Verde = Cabo_Verde + 1
            elif pais == "Camboya":
                Camboya = Camboya + 1
            elif pais == "Camerun":
                Camerun = Camerun + 1
            elif pais == "Canada":
                Canada = Canada + 1
            elif pais == "Catar":
                Catar = Catar + 1
            elif pais == "Chad":
                Chad = Chad + 1
            elif pais == "Chile":
                Chile = Chile + 1
            elif pais == "China":
                China = China + 1
            elif pais == "Chipre":
                Chipre = Chipre + 1
            elif pais == "Ciudad del Vaticano":
                Ciudad_del_Vaticano = Ciudad_del_Vaticano + 1
            elif pais == "Colombia":
                Colombia = Colombia + 1
            elif pais == "Comoras":
                Comoras = Comoras + 1
            elif pais == "Corea del Norte":
                Corea_del_Norte = Corea_del_Norte + 1
            elif pais == "Corea del Sur":
                Corea_del_Sur = Corea_del_Sur + 1
            elif pais == "Costa de Marfil":
                Costa_de_Marfil = Costa_de_Marfil + 1
            elif pais == "Costa Rica":
                Costa_Rica = Costa_Rica + 1
            elif pais == "Croacia":
                Croacia = Croacia + 1
            elif pais == "Cuba":
                Cuba = Cuba + 1
            elif pais == "Dinamarca":
                Dinamarca = Dinamarca + 1
            elif pais == "Dominica":
                Dominica = Dominica + 1
            elif pais == "Ecuador":
                Ecuador = Ecuador + 1
            elif pais == "Egypt":
                Egipto = Egipto + 1
            elif pais == "El Salvador":
                El_Salvador = El_Salvador + 1
            elif pais == "Emiratos Arabes Unidos":
                Emiratos_Arabes_Unidos = Emiratos_Arabes_Unidos + 1
            elif pais == "Eritrea":
                Eritrea = Eritrea + 1
            elif pais == "Eslovaquia":
                Eslovaquia = Eslovaquia + 1
            elif pais == "Eslovenia":
                Eslovenia = Eslovenia + 1
            elif pais == "España":
                Espana = Espana + 1
            elif pais == "United States":
                 Estados_Unidos = Estados_Unidos + 1
            elif pais == "Estonia":
                Estonia = Estonia + 1
            elif pais == "Etiopia":
                Etiopia = Etiopia + 1
            elif pais == "Filipinas":
                Filipinas = Filipinas + 1
            elif pais == "Finlandia":
                Finlandia = Finlandia + 1
            elif pais == "Fiyi":
                Fiyi = Fiyi + 1
            elif pais == "France":
                Francia = Francia + 1
            elif pais == "Gabon":
                Gabon = Gabon + 1
            elif pais == "Gambia":
                Gambia = Gambia + 1
            elif pais == "Georgia":
                Georgia = Georgia + 1
            elif pais == "Ghana":
                Ghana = Ghana + 1
            elif pais == "Granada":
                Granada = Granada + 1
            elif pais == "Grecia":
                Grecia = Grecia + 1
            elif pais == "Guatemala":
                Guatemala = Guatemala + 1
            elif pais == "Guyana":
                Guyana = Guyana + 1
            elif pais == "Guinea":
                Guinea = Guinea + 1
            elif pais == "Guinea ecuatorial":
                Guinea_ecuatorial = Guinea_ecuatorial + 1
            elif pais == "Guinea-Bisau":
                Guinea_Bisau = Guinea_Bisau + 1
            elif pais == "Haiti":
                Haiti = Haiti + 1
            elif pais == "Honduras":
                Honduras = Honduras + 1
            elif pais == "Hungria":
                Hungria = Hungria + 1
            elif pais == "India":
                India = India + 1
            elif pais == "Indonesia":
                Indonesia = Indonesia + 1
            elif pais == "Irak":
                Irak = Irak + 1
            elif pais == "Iran":
                Iran = Iran + 1
            elif pais == "Irlanda":
                Irlanda = Irlanda + 1
            elif pais == "Islandia":
                Islandia = Islandia + 1
            elif pais == "Islas Marshall":
                Islas_Marshall = Islas_Marshall + 1
            elif pais == "Islas Salomon":
                Islas_Salomon = Islas_Salomon + 1
            elif pais == "Israel":
                Israel = Israel + 1
            elif pais == "Italy":
                Italia = Italia + 1
            elif pais == "Jamaica":
                Jamaica = Jamaica + 1
            elif pais == "Japan":
                Japon = Japon + 1
            elif pais == "Jordania":
                Jordania = Jordania + 1
            elif pais == "Kazajistan":
                Kazajistan = Kazajistan + 1
            elif pais == "Kenia":
                Kenia = Kenia + 1
            elif pais == "Kirguistan":
                Kirguistan = Kirguistan + 1
            elif pais == "Kiribati":
                Kiribati = Kiribati + 1
            elif pais == "Kuwait":
                Kuwait = Kuwait + 1
            elif pais == "Laos":
                Laos = Laos + 1
            elif pais == "Lesoto":
                Lesoto = Lesoto + 1
            elif pais == "Letonia":
                Letonia = Letonia + 1
            elif pais == "Libano":
                Libano = Libano + 1
            elif pais == "Liberia":
                Liberia = Liberia + 1
            elif pais == "Libia":
                Libia = Libia + 1
            elif pais == "Liechtenstein":
                Liechtenstein = Liechtenstein + 1
            elif pais == "Lituania":
                Lituania = Lituania + 1
            elif pais == "Luxemburgo":
                Luxemburgo = Luxemburgo + 1
            elif pais == "Macedonia del Norte":
                Macedonia_del_Norte = Macedonia_del_Norte + 1
            elif pais == "Madagascar":
                Madagascar = Madagascar + 1
            elif pais == "Malasia":
                Malasia = Malasia + 1
            elif pais == "Malaui":
                Malaui = Malaui + 1
            elif pais == "Maldivas":
                Maldivas = Maldivas + 1
            elif pais == "Mali":
                Mali = Mali + 1
            elif pais == "Malta":
                Malta = Malta + 1
            elif pais == "Marruecos":
                Marruecos = Marruecos + 1
            elif pais == "Mauricio":
                Mauricio = Mauricio + 1
            elif pais == "Mauritania":
                Mauritania = Mauritania + 1
            elif pais == "México":
                Mexico = Mexico + 1
            elif pais == "Micronesia":
                Micronesia = Micronesia + 1
            elif pais == "Moldavia":
                Moldavia = Moldavia + 1
            elif pais == "Monaco":
                Monaco = Monaco + 1
            elif pais == "Mongolia":
                Mongolia = Mongolia + 1
            elif pais == "Montenegro":
                Montenegro = Montenegro + 1
            elif pais == "Mozambique":
                Mozambique = Mozambique + 1
            elif pais == "Namibia":
                Namibia = Namibia + 1
            elif pais == "Nauru":
                Nauru = Nauru + 1
            elif pais == "Nepal":
                Nepal = Nepal + 1
            elif pais == "Nicaragua":
                Nicaragua = Nicaragua + 1
            elif pais == "Niger":
                Niger = Niger + 1
            elif pais == "Nigeria":
                Nigeria = Nigeria + 1
            elif pais == "Noruega":
                Noruega = Noruega + 1
            elif pais == "Nueva Zelanda":
                Nueva_Zelanda = Nueva_Zelanda + 1
            elif pais == "Oman":
                Oman = Oman + 1
            elif pais == "Paises Bajos":
                Paises_Bajos = Paises_Bajos + 1
            elif pais == "Pakistan":
                Pakistan = Pakistan + 1
            elif pais == "Palaos":
                Palaos = Palaos + 1
            elif pais == "Panamá":
                Panama = Panama + 1
            elif pais == "Papua Nueva Guinea":
                Papua_Nueva_Guinea = Papua_Nueva_Guinea + 1
            elif pais == "Paraguay":
                Paraguay = Paraguay + 1
            elif pais == "Perú":
                Peru = Peru + 1
            elif pais == "Poland":
                Polonia = Polonia + 1
            elif pais == "Portugal":
                Portugal = Portugal + 1
            elif pais == "Reino Unido":
                Reino_Unido = Reino_Unido + 1
            elif pais == "Republica Centroafricana":
                Republica_Centroafricana = Republica_Centroafricana + 1
            elif pais == "Republica Checa":
                Republica_Checa = Republica_Checa + 1
            elif pais == "Republica del Congo":
                Republica_del_Congo = Republica_del_Congo + 1
            elif pais == "Republica Democratica del Congo":
                Republica_Democratica_del_Congo = Republica_Democratica_del_Congo + 1
            elif pais == "Republica Dominicana":
                Republica_Dominicana = Republica_Dominicana + 1
            elif pais == "Republica Sudafricana":
                Republica_Sudafricana = Republica_Sudafricana + 1
            elif pais == "Ruanda":
                Ruanda = Ruanda + 1
            elif pais == "Rumania":
                Rumania = Rumania + 1
            elif pais == "Rusia":
                Rusia = Rusia + 1
            elif pais == "Samoa":
                Samoa = Samoa + 1
            elif pais == "San Cristobal y Nieves":
                San_Cristobal_y_Nieves = San_Cristobal_y_Nieves + 1
            elif pais == "San Marino":
                San_Marino = San_Marino + 1
            elif pais == "San Vicente y las Granadinas":
                San_Vicente_y_las_Granadinas = San_Vicente_y_las_Granadinas + 1
            elif pais == "Santa Lucia":
                Santa_Lucia = Santa_Lucia + 1
            elif pais == "Santo Tome y Principe":
                Santo_Tome_y_Principe = Santo_Tome_y_Principe + 1
            elif pais == "Senegal":
                Senegal = Senegal + 1
            elif pais == "Serbia":
                Serbia = Serbia + 1
            elif pais == "Sierra Leona":
                Sierra_Leona = Sierra_Leona + 1
            elif pais == "Seychelles":
                Seychelles = Seychelles + 1
            elif pais == "Singapur":
                Singapur = Singapur + 1
            elif pais == "Siria":
                Siria = Siria + 1
            elif pais == "Sri Lanka":
                Sri_Lanka = Sri_Lanka + 1
            elif pais == "Somalia":
                Somalia = Somalia + 1
            elif pais == "Sudan":
                Sudan = Sudan + 1
            elif pais == "Suazilandia":
                Suazilandia = Suazilandia + 1
            elif pais == "Suecia":
                Suecia = Suecia + 1
            elif pais == "Sudan":
                Sudan_del_Sur = Sudan_del_Sur + 1
            elif pais == "Suiza":
                Suiza = Suiza + 1
            elif pais == "Surinam":
                Surinam = Surinam + 1
            elif pais == "Tailandia":
                Tailandia = Tailandia + 1
            elif pais == "Tanzania":
                Tanzania = Tanzania + 1
            elif pais == "Timor Oriental":
                Timor_Oriental = Timor_Oriental + 1
            elif pais == "Tayikistan":
                Tayikistan = Tayikistan + 1
            elif pais == "Togo":
                Togo = Togo + 1
            elif pais == "Tonga":
                Tonga = Tonga + 1
            elif pais == "Trinidad and Tobago":
                Trinidad_y_Tobago = Trinidad_y_Tobago + 1
            elif pais == "Tunez":
                Tunez = Tunez + 1
            elif pais == "Turkmenistan":
                Turkmenistan = Turkmenistan + 1
            elif pais == "Turquia":
                Turquia = Turquia + 1
            elif pais == "Tuvalu":
                Tuvalu = Tuvalu + 1
            elif pais == "Ucrania":
                Ucrania = Ucrania + 1
            elif pais == "Uganda":
                Uganda = Uganda + 1
            elif pais == "Uruguay":
                Uruguay = Uruguay + 1
            elif pais == "Uzbekistan":
                Uzbekistan = Uzbekistan + 1
            elif pais == "Vanuatu":
                Vanuatu = Vanuatu + 1
            elif pais == "Venezuela":
                Venezuela = Venezuela + 1
            elif pais == "Vietnam":
                Vietnam = Vietnam + 1
            elif pais == "Yemen":
                Yemen = Yemen + 1
            elif pais == "Yibuti":
                Yibuti = Yibuti + 1
            elif pais == "Zambia":
                Zambia = Zambia + 1
            elif pais == "Zimbabue":
                Zimbabue = Zimbabue + 1
            elif pais == "Chequia":
                Chequia = Chequia + 1
            elif pais == "Hong Kong":
                Hong_Kong = Hong_Kong + 1
            elif pais == "South Africa":
                Sudafrica = Sudafrica + 1
            elif pais == "Taiwan":
                Taiwan = Taiwan + 1
            elif pais == "Gran Bretana":
                Gran_Bretana = Gran_Bretana + 1


    pais_data = {"af":Afganistan,"al":Albania,
    "dz":Argelia,"ao":Angola,"ag":Antigua_y_Barbuda,
    "ar":Argentina,"am":Armenia,"au":Australia,
    "at":Austria,"az":Azerbaiyan,"bs":Bahamas,
    "bh":Barein,"bd":Banglades,"bb":Barbados,
    "by":Bielorrusia,"be":Belgica,"bz":Belice,
    "bj":Benin,"bt":Butan,"bo":Bolivia,"ba":Bosnia_y_Herzegovina,
    "bw":Botsuana,"br":Brasil,"bn":Brunei,"bg":Bulgaria,
    "bf":Burkina_Faso,"bi":Burundi,"kh":Camboya,"cm":Camerun,
    "ca":Canada,"cv":Cabo_Verde,"cf":Republica_Centroafricana,"td":Chad,
    "cl":Chile,"cn":China,"co":Colombia,"km":Comoras,
    "cd":Republica_Democratica_del_Congo,"cg":Republica_del_Congo,"cr":Costa_Rica,"ci":Costa_de_Marfil,
    "hr":Croacia,"cy":Chipre,"cz":Chequia,"dk":Dinamarca,"dj":Yibuti,
    "dm":Dominica,"do":Republica_Dominicana,"ec":Ecuador,"eg":Egipto,
    "sv":El_Salvador,"gq":Guinea_ecuatorial,"er":Eritrea,"ee":Estonia,
    "et":Etiopia,"fj":Fiyi,"fi":Finlandia,"fr":Francia,
    "ga":Gabon,"gm":Gambia,"ge":Georgia,"de":Alemania,
    "gh":Ghana,"gr":Grecia,"gd":Granada,"gt":Guatemala,
    "gn":Guinea,"gw":Guinea_Bisau,"gy":Guyana,"ht":Haiti,
    "hn":Honduras,"hk":Hong_Kong,"hu":Hungria,
    "is":Islandia,"in":India,"id":Indonesia,
    "ir":Iran,"iq":Irak,"ie":Irlanda,"il":Israel,
    "it":Italia,"jm":Jamaica,"jp":Japon,"jo":Jordania,
    "kz":Kazajistan,"ke":Kenia,"ki":Kiribati,"kr":Corea_del_Sur,
    "kp":Corea_del_Norte,"kw":Kuwait,"kg":Kirguistan,"la":Laos,
    "lv":Letonia,"lb":Libano,"ls":Lesoto,"lr":Liberia,"ly":Libia,
    "lt":Lituania,"lu":Luxemburgo,"mk":Macedonia_del_Norte,"mg":Madagascar,"mw":Malaui,
    "my":Malasia,"mv":Maldivas,"ml":Mali,"mt":Malta,"mr":Mauritania,
    "mu":Mauricio,"mx":Mexico,"md":Moldavia,"mn":Mongolia,"me":Montenegro,
    "ma":Marruecos,"mz":Mozambique,"mm":Birmania_Myanmar,"na":Namibia,"np":Nepal,
    "nl":Paises_Bajos,"nz":Nueva_Zelanda,"ni":Nicaragua,"ne":Niger,"ng":Nigeria,
    "no":Noruega,"om":Oman,"pk":Pakistan,"pa":Panama,"pg":Papua_Nueva_Guinea,
    "py":Paraguay,"pe":Peru,"ph":Filipinas,"pl":Polonia,"pt":Portugal,
    "qa":Catar,"ro":Rumania,"ru":Rusia,"rw":Ruanda,"ws":Samoa,
    "st":Santo_Tome_y_Principe,"sa":Arabia_Saudita,"sn":Senegal,"rs":Serbia,"sc":Seychelles,"sl":Sierra_Leona,
    "sg":Singapur,"sk":Eslovaquia,"si":Eslovenia,"sb":Islas_Salomon,"za":Sudafrica,"es":Espana,
    "lk":Sri_Lanka,"kn":San_Cristobal_y_Nieves,"lc":Santa_Lucia,"vc":San_Vicente_y_las_Granadinas,"sd":Sudan,"sr":Surinam,
    "sz":Suazilandia,"se":Suecia,"ch":Suiza,"sy":Siria,"tw":Taiwan,
    "tj":Tayikistan,"tz":Tanzania,"th":Tailandia,"tl":Timor_Oriental,"tg":Togo,"to":Tonga,
    "tt":Trinidad_y_Tobago,"tn":Tunez,"tr":Turquia,"tm":Turkmenistan,"ug":Uganda,"ua":Ucrania,
    "ae":Emiratos_Arabes_Unidos,"gb":Gran_Bretana,"us":Estados_Unidos,"uy":Uruguay,"uz":Uzbekistan,
    "vu":Vanuatu,"ve":Venezuela,"vn":Vietnam,"ye":Yemen,"zm":Zambia,"zw":Zimbabue, "cu":Cuba, "so":Somalia}

    #dato = str(pais_data)
    #datos = {'todo':dat}
    #valor = id
    no_alumnos = Alumno.objects.all().count()
    no_cursos = Curso.objects.all().count()
    #Permite obtener los ultimos 4 registros de la tabla
    transaccion = Transacciones.objects.order_by('-id_transaccion').all()[:4]

    #admin = Administrador.objects.filter(id_admin=valor)

    idinstructor = request.user.id_relacionado

    opcion = OpcionesInstructor.objects.filter(id_instructorR=idinstructor)

    usuario = Instructor.objects.filter(id_instructor=idinstructor)



    todaynoti = date.today()

    finnoti = todaynoti + timedelta(days=3)

    notificacion = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0)

    numeronotificaciones = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()

    pagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    contexto = {'paginas':pagina, 'pais_data':pais_data, 'no_alumnos':no_alumnos,
    'no_cursos':no_cursos, 'transacciones':transaccion, 'opciones':opcion, 'usuarios':usuario,
    'notificaciones':notificacion, 'numeronotificaciones':numeronotificaciones}

    return render(request, 'Instructor/instructor_index.html', contexto)



@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_instructor, login_url='/iniciar_sesion/')
def mostrar_cursos_instructor(request):

    request.session.set_expiry(request.session.get_expiry_age())

    valor = request.user.id_relacionado

    filtro = CursoInstructor.objects.filter(id_instructorR=valor).values('id_cursoR')

    curso = Curso.objects.filter(id_curso__in=filtro)

    opcion = OpcionesInstructor.objects.filter(id_instructorR=valor)

    usuario = Instructor.objects.filter(id_instructor=valor)


    todaynoti = date.today()

    finnoti = todaynoti + timedelta(days=3)

    notificacion = NotificacionesInstructores.objects.filter(id_instructorR=valor, fecha_fin__range=[todaynoti, finnoti], statusN=0)

    numeronotificaciones = NotificacionesInstructores.objects.filter(id_instructorR=valor, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()

    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    pagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    contexto = {'paginas':pagina, 'cursos':curso, 'opciones':opcion, 'usuarios':usuario,
    'notificaciones':notificacion, 'numeronotificaciones':numeronotificaciones,
    'datosPagina':datoPagina}

    return render(request, 'Instructor/instructor_cursos.html', contexto)



@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_instructor, login_url='/iniciar_sesion/')
def mostrar_agregar_curso_instructor(request):

    request.session.set_expiry(request.session.get_expiry_age())

    idinstructor = request.user.id_relacionado

    opcion = OpcionesInstructor.objects.filter(id_instructorR=idinstructor)

    usuario = Instructor.objects.filter(id_instructor=idinstructor)

    todaynoti = date.today()

    finnoti = todaynoti + timedelta(days=3)

    notificacion = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0)

    numeronotificaciones = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()


    pagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    categoria = CursoCategoria.objects.all()

    fecha = str(todaynoti)

    contexto = {'categorias':categoria, 'paginas':pagina, 'opciones':opcion, 'usuarios':usuario, 'notificaciones':notificacion,
    'numeronotificaciones':numeronotificaciones, 'fecha':fecha}

    return render(request, 'Instructor/Extras/Cursos/agregar_curso.html', contexto)


@csrf_exempt
@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_instructor, login_url='/iniciar_sesion/')
def agregar_curso_instructor(request):

    request.session.set_expiry(request.session.get_expiry_age())

    if request.method == "POST":

        nombreCurso = request.POST["nombreCurso"]
        fechaInicio = request.POST["fechaInicio"]
        fechaCierre = request.POST["fechaCierre"]
        nominalum = request.POST["nomin"]
        nomaxalum = request.POST["nomax"]
        precioG = request.POST["precio"]
        tipo = request.POST["tipo"]
        descrip = request.POST["descripcion"]
        imagen = request.FILES["imagencurso"]
        video = request.POST["video"]
        duracion = request.POST["tiempo"]
        duraciontipo = request.POST["tipotiempo"]

        categoriauno = request.POST["categoria1"]
        categoriados = request.POST["categoria2"]
        categoriatres = request.POST["categoria3"]
        categoriacuatro = request.POST["categoria4"]
        categoriacinco = request.POST["categoria5"]

        aprendizajeS = request.POST["aprendizaje"]
        temarioS = request.POST["temario"]
        recursosS = request.POST["recursos"]
        requisistosS = request.POST["requisitos"]
        tareasS = request.POST["tareas"]
        leccionesS = request.POST["lecciones"]
        horasvideoS = request.POST["horasvideo"]
        tipohorarioS = request.POST["tipohorario"]
        horarioS = request.POST["horario"]

        nombreimagen = secure_filename(imagen.name)

        #fs = FileSystemStorage(location='ProyectoKaizen/static/media/Imagenes/Cursos')
        fs = FileSystemStorage(location= os.path.join(settings.MEDIA_ROOT+'/Imagenes/Cursos'))
        filenam = fs.save(nombreimagen, imagen)

        c = Curso(nombreC = nombreCurso, fecha_inicio = fechaInicio,
        fecha_cierre = fechaCierre, no_minimo_alumnos = nominalum,
        no_maximo_alumnos = nomaxalum, precio = precioG, tipo_Curso=tipo, statusC=1,
        ruta_imagen=nombreimagen, descripcion_curso=descrip, video_muestra=video,
        duracion_curso_numero=duracion, duracion_curso_tipo=duraciontipo, veces_vendido=0,
        valoracion=0, aprobado=0, es_libre=0, url_inorganico="", url_sensei="",
        aprendizaje=aprendizajeS, temario=temarioS, recursos=recursosS, requisitos=requisistosS,
        no_lecciones=leccionesS, tareas_actividades=tareasS,
        no_horas_video=horasvideoS, tipo_horario=tipohorarioS, horario=horarioS)
        c.save()

        cur = Curso.objects.get(nombreC = nombreCurso, fecha_inicio = fechaInicio,
        fecha_cierre = fechaCierre, no_minimo_alumnos = nominalum,
        no_maximo_alumnos = nomaxalum, precio = precioG, tipo_Curso=tipo)

        id_curs = cur.id_curso
        nombrecurso = cur.nombreC

        urlinorganico = "http://seiko.global/curso-inorganico/?curso=" + str(id_curs) + "&curson=" + str(nombrecurso)
        urlsensei = "http://seiko.global/curso-sensei/?curso=" + str(id_curs) + "&curson=" + str(nombrecurso)

        cur.url_inorganico = urlinorganico
        cur.url_sensei = urlsensei
        cur.save()

        if categoriauno:

            rel = Cursos_Categorias(id_curso=id_curs, id_categoria=categoriauno)
            rel.save()

        if categoriados:

            rell = Cursos_Categorias(id_curso=id_curs, id_categoria=categoriados)
            rell.save()

        if categoriatres:

            relll = Cursos_Categorias(id_curso=id_curs, id_categoria=categoriatres)
            relll.save()

        if categoriacuatro:

            rellll = Cursos_Categorias(id_curso=id_curs, id_categoria=categoriacuatro)
            rellll.save()

        if categoriacinco:

            relllll = Cursos_Categorias(id_curso=id_curs, id_categoria=categoriacinco)
            relllll.save()

        valor = request.user.id_relacionado

        rc = CursoInstructor(id_cursoR=id_curs, id_instructorR=valor)
        rc.save()

        filtro = CursoInstructor.objects.filter(id_instructorR=valor).values('id_cursoR')

        curso = Curso.objects.filter(id_curso__in=filtro)

        opcion = OpcionesInstructor.objects.filter(id_instructorR=valor)

        usuario = Instructor.objects.filter(id_instructor=valor)

        todaynoti = date.today()

        finnoti = todaynoti + timedelta(days=3)

        notificacion = NotificacionesInstructores.objects.filter(id_instructorR=valor, fecha_fin__range=[todaynoti, finnoti], statusN=0)

        numeronotificaciones = NotificacionesInstructores.objects.filter(id_instructorR=valor, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()


        pagina = ElementosPagina.objects.filter(id_elementoPagina=1)

        contexto = {'paginas':pagina, 'cursos':curso, 'opciones':opcion, 'usuarios':usuario, 'notificaciones':notificacion,
        'numeronotificaciones':numeronotificaciones}

        #return render(request, 'Instructor/instructor_cursos.html', contexto)
        return redirect('/cursos_instructor/')


@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_instructor, login_url='/iniciar_sesion/')
def mostrar_editar_curso_instructor(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    valor = id
    curso = Curso.objects.filter(id_curso=valor)

    idinstructor = request.user.id_relacionado

    opcion = OpcionesInstructor.objects.filter(id_instructorR=idinstructor)

    usuario = Instructor.objects.filter(id_instructor=idinstructor)

    todaynoti = date.today()

    finnoti = todaynoti + timedelta(days=3)

    notificacion = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0)

    numeronotificaciones = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()


    pagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    contexto = {'paginas':pagina, 'cursos':curso, 'opciones':opcion, 'usuarios':usuario, 'notificaciones':notificacion,
    'numeronotificaciones':numeronotificaciones}

    return render(request, 'Instructor/Extras/Cursos/editar_curso.html', contexto)



@csrf_exempt
@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_instructor, login_url='/iniciar_sesion/')
def editar_curso_instructor(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    if request.method == "POST":

        nombreCurso = request.POST["nombreCurso"]
        fechaInicio = request.POST["fechaInicio"]
        fechaCierre = request.POST["fechaCierre"]
        nominalum = request.POST["nomin"]
        nomaxalum = request.POST["nomax"]
        precioG = request.POST["precio"]
        tipo = request.POST["tipo"]
        descrip = request.POST["descripcion"]
        try:
            imagen = request.FILES["imagencurso"]
        except Exception as e:
            imagen = ""

        video = request.POST["video"]
        duracionnum = request.POST["tiempo"]
        duraciontipo = request.POST["tipotiempo"]

        aprendizajeS = request.POST["aprendizaje"]
        temarioS = request.POST["temario"]
        recursosS = request.POST["recursos"]
        requisistosS = request.POST["requisitos"]
        tareasS = request.POST["tareas"]
        leccionesS = request.POST["lecciones"]
        horasvideoS = request.POST["horasvideo"]
        tipohorarioS = request.POST["tipohorario"]
        horarioS = request.POST["horario"]

        if imagen:
            nombreimagen = secure_filename(imagen.name)
        else:
            nombreimagen = ""

        valor = id

        c = Curso.objects.get(id_curso=valor)

        nombreimagenGurdada = c.ruta_imagen

        c.nombreC = nombreCurso
        c.fecha_inicio = fechaInicio
        c.fecha_cierre = fechaCierre
        c.no_minimo_alumnos = nominalum
        c.no_maximo_alumnos = nomaxalum
        c.precio = precioG
        c.tipo_Curso = tipo

        if nombreimagen == "":
            pass

        elif nombreimagenGurdada == "CursoPrede.jpg":

            pass

        else:

            if os.path.exists(os.path.join(settings.MEDIA_ROOT+'/Imagenes/Cursos/' + nombreimagenGurdada)):

                os.remove(os.path.join(settings.MEDIA_ROOT+'/Imagenes/Cursos/' + nombreimagenGurdada))

        if imagen:
            #fs = FileSystemStorage(location='ProyectoKaizen/static/media/Imagenes/Cursos')
            fs = FileSystemStorage(location= os.path.join(settings.MEDIA_ROOT+'/Imagenes/Cursos'))
            filenam = fs.save(nombreimagen, imagen)
            c.ruta_imagen = nombreimagen


        c.descripcion_curso = descrip
        c.video_muestra = video
        c.duracion_curso_numero = duracionnum
        c.duracion_curso_tipo = duraciontipo
        c.aprendizaje = aprendizajeS
        c.temario = temarioS
        c.recursos = recursosS
        c.requisitos = requisistosS
        c.tareas_actividades = tareasS
        c.no_lecciones = leccionesS
        c.no_horas_video = horasvideoS
        c.tipo_horario = tipohorarioS
        c.horario = horarioS
        c.save()

        valor = request.user.id_relacionado

        filtro = CursoInstructor.objects.filter(id_instructorR=valor).values('id_cursoR')

        curso = Curso.objects.filter(id_curso__in=filtro)

        idinstructor = request.user.id_relacionado

        opcion = OpcionesInstructor.objects.filter(id_instructorR=idinstructor)

        usuario = Instructor.objects.filter(id_instructor=idinstructor)

        todaynoti = date.today()

        finnoti = todaynoti + timedelta(days=3)

        notificacion = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0)

        numeronotificaciones = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()


        pagina = ElementosPagina.objects.filter(id_elementoPagina=1)

        contexto = {'paginas':pagina, 'cursos':curso, 'opciones':opcion, 'usuarios':usuario, 'notificaciones':notificacion,
        'numeronotificaciones':numeronotificaciones}

        #return render(request, 'Instructor/instructor_cursos.html', contexto)
        return redirect('/cursos_instructor/')



@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_instructor, login_url='/iniciar_sesion/')
def mostrar_lecciones(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    valor = id

    valor2 = request.user.id_relacionado

    unidad = Unidades.objects.filter(id_cursoR=valor, id_instructorR=valor2)

    curso = Curso.objects.filter(id_curso=valor)

    opcion = OpcionesInstructor.objects.filter(id_instructorR=valor2)

    usuario = Instructor.objects.filter(id_instructor=valor2)

    todaynoti = date.today()

    finnoti = todaynoti + timedelta(days=3)

    notificacion = NotificacionesInstructores.objects.filter(id_instructorR=valor2, fecha_fin__range=[todaynoti, finnoti], statusN=0)

    numeronotificaciones = NotificacionesInstructores.objects.filter(id_instructorR=valor2, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()


    pagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    contexto = {'paginas':pagina, 'unidades':unidad, 'cursos':curso, 'opciones':opcion, 'usuarios':usuario,
    'notificaciones':notificacion, 'numeronotificaciones':numeronotificaciones}

    return render(request, 'Instructor/Extras/Cursos/mostrar_leccion.html', contexto)



@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_instructor, login_url='/iniciar_sesion/')
def mostrar_agregar_leccion(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    valor = id

    curso = Curso.objects.filter(id_curso=valor)

    idinstructor = request.user.id_relacionado

    opcion = OpcionesInstructor.objects.filter(id_instructorR=idinstructor)

    usuario = Instructor.objects.filter(id_instructor=idinstructor)

    todaynoti = date.today()

    finnoti = todaynoti + timedelta(days=3)

    notificacion = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0)

    numeronotificaciones = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()


    pagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    contexto = {'paginas':pagina, 'cursos':curso, 'opciones':opcion, 'usuarios':usuario, 'notificaciones':notificacion,
    'numeronotificaciones':numeronotificaciones}

    return render(request, 'Instructor/Extras/Cursos/agregar_leccion.html', contexto)




@csrf_exempt
@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_instructor, login_url='/iniciar_sesion/')
def agregar_leccion(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    compression = zipfile.ZIP_DEFLATED

    if request.method == "POST":

        imagenleccion = request.FILES["imagenleccion"]
        nombreleccion = request.POST["titulo"]
        urlvideo = request.POST["urlvideo"]
        archivos = request.FILES.getlist("archivosleccion")

        nombreimagen = secure_filename(imagenleccion.name)
        #fs = FileSystemStorage(location='ProyectoKaizen/static/media/Imagenes/Cursos')
        fs = FileSystemStorage(location= os.path.join(settings.MEDIA_ROOT+'/Imagenes/Cursos'))
        filenam = fs.save(nombreimagen, imagenleccion)

        nombresarchivos = []
        nombrezip = ""

        idcurso = id

        if archivos:

            for archivo in archivos:

                nombrearchivo = secure_filename(archivo.name)
                nombresarchivos.append(nombrearchivo)

                #fs = FileSystemStorage(location='ProyectoKaizen/static/media/Documentos/Instructores')
                fs = FileSystemStorage(location= os.path.join(settings.MEDIA_ROOT+'/Documentos/Instructores'))
                filena = fs.save(nombrearchivo, archivo)


            prueba = Unidades.objects.filter(nombre_unidad=nombreleccion)

            if prueba:

                cur = Curso.objects.get(id_curso=idcurso)
                nombrecurso = cur.nombreC

                nombrezip = nombreleccion + nombrecurso + ".zip"

            else:

                nombrezip = nombreleccion + ".zip"


            zf = zipfile.ZipFile(os.path.join(settings.MEDIA_ROOT+'/Documentos/Instructores/'+ nombrezip), mode="w")

            for nombre in nombresarchivos:

                zf.write(os.path.join(settings.MEDIA_ROOT+'/Documentos/Instructores/'+ nombre), arcname=os.path.basename(os.path.join(settings.MEDIA_ROOT+'/Documentos/Instructores/'+ nombre)), compress_type=compression)

            zf.close()

            for nombre in nombresarchivos:

                os.remove(os.path.join(settings.MEDIA_ROOT+'/Documentos/Instructores/' + nombre))


        idinstructor = request.user.id_relacionado

        urlpartida = urlvideo.split("=")

        if len(urlpartida) == 1:

            urlpartida = urlvideo.split('/')

        urlvideos = urlpartida[-1]

        u = Unidades(nombre_unidad=nombreleccion, statusU=1, id_cursoR=idcurso,
        id_instructorR=idinstructor, ruta_imagen_unidad=nombreimagen, url_video_unidad=urlvideos,
        ruta_arcivos=nombrezip)
        u.save()

        cur = Curso.objects.get(id_curso=idcurso)
        nombrecursoss = cur.nombreC


        texto = "Tu instructor agrego la leccion " + nombreleccion + " al curso " + nombrecursoss + "."

        today = date.today()

        hora = datetime.now().strftime("%I:%M:%S")

        fechafinal = today + timedelta(days=3)

        alumnos = CursoEstudiante.objects.filter(id_cursoR=idcurso, id_instructorRC=idinstructor)

        for alumno in alumnos:

            idalumno = alumno.id_estudianteR

            ni = NotificacionesAlumnos(id_alumnoR=idalumno, mensaje_notificacion=texto,
            fecha_notificacion=today, hora_notificacion=hora, fecha_fin=fechafinal,
            id_elementoNotificacion=1, tipo_elementoNotificacion="Leccion")
            ni.save()


        unidad = Unidades.objects.filter(id_cursoR=idcurso, id_instructorR=idinstructor)

        curso = Curso.objects.filter(id_curso=idcurso)

        opcion = OpcionesInstructor.objects.filter(id_instructorR=idinstructor)

        usuario = Instructor.objects.filter(id_instructor=idinstructor)

        todaynoti = date.today()

        finnoti = todaynoti + timedelta(days=3)

        notificacion = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0)

        numeronotificaciones = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()


        pagina = ElementosPagina.objects.filter(id_elementoPagina=1)

        contexto = {'paginas':pagina, 'unidades':unidad, 'cursos':curso, 'opciones':opcion, 'usuarios':usuario,
        'notificaciones':notificacion, 'numeronotificaciones':numeronotificaciones}

        return render(request, 'Instructor/Extras/Cursos/mostrar_leccion.html', contexto)




@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_instructor, login_url='/iniciar_sesion/')
def mostrar_editar_leccion(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    valor = id

    unidad = Unidades.objects.filter(id_unidad=valor)

    u = Unidades.objects.get(id_unidad=valor)

    idcurso = u.id_cursoR

    curso = Curso.objects.filter(id_curso=idcurso)

    idinstructor = request.user.id_relacionado

    opcion = OpcionesInstructor.objects.filter(id_instructorR=idinstructor)

    usuario = Instructor.objects.filter(id_instructor=idinstructor)

    todaynoti = date.today()

    finnoti = todaynoti + timedelta(days=3)

    notificacion = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0)

    numeronotificaciones = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()

    pagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    contexto = {'paginas':pagina, 'unidades':unidad, 'cursos':curso, 'opciones':opcion, 'usuarios':usuario,
    'notificaciones':notificacion, 'numeronotificaciones':numeronotificaciones}

    return render(request, 'Instructor/Extras/Cursos/editar_leccion.html', contexto)





@csrf_exempt
@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_instructor, login_url='/iniciar_sesion/')
def editar_leccion(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    compression = zipfile.ZIP_DEFLATED

    if request.method == "POST":

        try:
            imagenleccion = request.FILES["imagenleccion"]
        except Exception as e:
            imagenleccion = ""

        nombreleccion = request.POST["titulo"]
        urlvideo = request.POST["urlvideo"]
        archivos = request.FILES.getlist("archivosleccion")

        idunidad = id

        unida = Unidades.objects.get(id_unidad=idunidad)

        idcurso = unida.id_cursoR

        nombreimag = unida.ruta_imagen_unidad

        nombrearchi = unida.ruta_arcivos

        nombreimagen = ""


        if imagenleccion:

            nombreimagen = secure_filename(imagenleccion.name)
            #fs = FileSystemStorage(location='ProyectoKaizen/static/media/Imagenes/Cursos')
            fs = FileSystemStorage(location= os.path.join(settings.MEDIA_ROOT+'/Imagenes/Cursos'))
            filenam = fs.save(nombreimagen, imagenleccion)

            if os.path.exists(os.path.join(settings.MEDIA_ROOT+'/Imagenes/Cursos/' + nombreimag)):

                os.remove(os.path.join(settings.MEDIA_ROOT+'/Imagenes/Cursos/' + nombreimag))



        nombresarchivos = []
        nombrezip = ""



        if archivos:

            for archivo in archivos:

                nombrearchivo = secure_filename(archivo.name)
                nombresarchivos.append(nombrearchivo)

                #fs = FileSystemStorage(location='ProyectoKaizen/static/media/Documentos/Instructores')
                fs = FileSystemStorage(location= os.path.join(settings.MEDIA_ROOT+'/Documentos/Instructores'))
                filena = fs.save(nombrearchivo, archivo)


            prueba = Unidades.objects.filter(nombre_unidad=nombreleccion)

            if prueba:

                cur = Curso.objects.get(id_curso=idcurso)
                nombrecurso = cur.nombreC

                nombrezip = nombreleccion + nombrecurso + ".zip"

            else:

                nombrezip = nombreleccion + ".zip"


            zf = zipfile.ZipFile(os.path.join(settings.MEDIA_ROOT+'/Documentos/Instructores/'+ nombrezip), mode="w")

            for nombre in nombresarchivos:

                zf.write(os.path.join(settings.MEDIA_ROOT+'/Documentos/Instructores/'+ nombre), arcname=os.path.basename(os.path.join(settings.MEDIA_ROOT+'/Documentos/Instructores/'+ nombre)), compress_type=compression)

            zf.close()

            for nombre in nombresarchivos:

                os.remove(os.path.join(settings.MEDIA_ROOT+'/Documentos/Instructores/' + nombre))

            if nombrearchi:

                if os.path.exists(os.path.join(settings.MEDIA_ROOT+'/Documentos/Instructores/' + nombrearchi)):

                    os.remove(os.path.join(settings.MEDIA_ROOT+'/Documentos/Instructores/' + nombrearchi))




        idinstructor = request.user.id_relacionado

        urlpartida = urlvideo.split("=")

        if len(urlpartida) == 1:

            urlpartida = urlvideo.split('/')

        urlvideos = urlpartida[-1]

        u = Unidades.objects.get(id_unidad=idunidad)
        u.nombre_unidad = nombreleccion

        if nombreimagen == "":

            pass

        else:

            u.ruta_imagen_unidad=nombreimagen

        u.url_video_unidad = urlvideos

        if nombrezip == "":

            pass

        else:

            u.ruta_arcivos = nombrezip

        u.save()


        cur = Curso.objects.get(id_curso=idcurso)
        nombrecursoss = cur.nombreC


        texto = "Tu instructor edito la leccion " + nombreleccion + " del curso " + nombrecursoss + "."

        today = date.today()

        hora = datetime.now().strftime("%I:%M:%S")

        fechafinal = today + timedelta(days=3)

        alumnos = CursoEstudiante.objects.filter(id_cursoR=idcurso, id_instructorRC=idinstructor)

        for alumno in alumnos:

            idalumno = alumno.id_estudianteR

            ni = NotificacionesAlumnos(id_alumnoR=idalumno, mensaje_notificacion=texto,
            fecha_notificacion=today, hora_notificacion=hora, fecha_fin=fechafinal,
            id_elementoNotificacion=1, tipo_elementoNotificacion="Leccion")
            ni.save()


        unidad = Unidades.objects.filter(id_cursoR=idcurso, id_instructorR=idinstructor)

        curso = Curso.objects.filter(id_curso=idcurso)

        opcion = OpcionesInstructor.objects.filter(id_instructorR=idinstructor)

        usuario = Instructor.objects.filter(id_instructor=idinstructor)

        todaynoti = date.today()

        finnoti = todaynoti + timedelta(days=3)

        notificacion = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0)

        numeronotificaciones = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()

        pagina = ElementosPagina.objects.filter(id_elementoPagina=1)

        contexto = {'paginas':pagina, 'unidades':unidad, 'cursos':curso, 'opciones':opcion, 'usuarios':usuario,
        'notificaciones':notificacion, 'numeronotificaciones':numeronotificaciones}

        return render(request, 'Instructor/Extras/Cursos/mostrar_leccion.html', contexto)



@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_instructor, login_url='/iniciar_sesion/')
def mostrar_actividades(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    idcurso = id

    idinstructor = request.user.id_relacionado

    actividad = Actividad.objects.filter(id_cursoR=idcurso, id_instructorR=idinstructor)

    curso = Curso.objects.filter(id_curso=idcurso)

    opcion = OpcionesInstructor.objects.filter(id_instructorR=idinstructor)

    usuario = Instructor.objects.filter(id_instructor=idinstructor)

    todaynoti = date.today()

    finnoti = todaynoti + timedelta(days=3)

    notificacion = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0)

    numeronotificaciones = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()


    pagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    contexto = {'paginas':pagina, 'actividades':actividad, 'cursos':curso, 'opciones':opcion, 'usuarios':usuario,
    'notificaciones':notificacion, 'numeronotificaciones':numeronotificaciones}

    return render(request, 'Instructor/Extras/Cursos/mostrar_actividades.html', contexto)




@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_instructor, login_url='/iniciar_sesion/')
def mostrar_agregar_actividad(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    valor = id

    curso = Curso.objects.filter(id_curso=valor)

    valor2 = request.user.id_relacionado

    unidad = Unidades.objects.filter(id_cursoR=valor, id_instructorR=valor2)

    opcion = OpcionesInstructor.objects.filter(id_instructorR=valor2)

    usuario = Instructor.objects.filter(id_instructor=valor2)

    todaynoti = date.today()

    finnoti = todaynoti + timedelta(days=3)

    notificacion = NotificacionesInstructores.objects.filter(id_instructorR=valor2, fecha_fin__range=[todaynoti, finnoti], statusN=0)

    numeronotificaciones = NotificacionesInstructores.objects.filter(id_instructorR=valor2, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()


    pagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    fecha = str(todaynoti)

    contexto = {'paginas':pagina, 'cursos':curso, 'unidades':unidad, 'opciones':opcion, 'usuarios':usuario,
    'notificaciones':notificacion, 'numeronotificaciones':numeronotificaciones, 'fecha':fecha}

    return render(request, 'Instructor/Extras/Cursos/agregar_actividad.html', contexto)



@csrf_exempt
@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_instructor, login_url='/iniciar_sesion/')
def agregar_actividad(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    compression = zipfile.ZIP_DEFLATED

    if request.method == "POST":

        nombreactividad = request.POST["titulo"]
        descripcionactividad = request.POST["descripcion"]
        fechavencimiento = request.POST["fechaentrega"]
        idunidad = request.POST["unidad"]
        archivos = request.FILES.getlist("archivosactividad")
        objetivoS = request.POST["objetivo"]

        nombresarchivos = []
        nombrezip = ""
        idcurso = id

        if archivos:

            for archivo in archivos:

                nombrearchivo = secure_filename(archivo.name)
                nombresarchivos.append(nombrearchivo)

                #fs = FileSystemStorage(location='ProyectoKaizen/static/media/Documentos/Instructores')
                fs = FileSystemStorage(location= os.path.join(settings.MEDIA_ROOT+'/Documentos/Instructores'))
                filena = fs.save(nombrearchivo, archivo)


            prueba = Actividad.objects.filter(nombre_actividad=nombreactividad)

            if prueba:

                cur = Curso.objects.get(id_curso=idcurso)
                nombrecurso = cur.nombreC

                nombrezip = nombreactividad + nombrecurso +".zip"

            else:

                nombrezip = nombreactividad + ".zip"


            zf = zipfile.ZipFile(os.path.join(settings.MEDIA_ROOT+'/Documentos/Instructores/'+ nombrezip), mode="w")

            for nombre in nombresarchivos:

                zf.write(os.path.join(settings.MEDIA_ROOT+'/Documentos/Instructores/'+ nombre), arcname=os.path.basename(os.path.join(settings.MEDIA_ROOT+'/Documentos/Instructores/'+ nombre)), compress_type=compression)

            zf.close()

            for nombre in nombresarchivos:

                os.remove(os.path.join(settings.MEDIA_ROOT+'/Documentos/Instructores/' + nombre))



        idinstructor = request.user.id_relacionado

        a = Actividad(nombre_actividad=nombreactividad, descripcion=descripcionactividad,
        fecha_vencimiento=fechavencimiento, statusAC=1, id_cursoR=idcurso,
        id_unidadR=idunidad, id_instructorR=idinstructor, archivos_actividad=nombrezip, objetivo=objetivoS)
        a.save()


        cur = Curso.objects.get(id_curso=idcurso)
        nombrecursoss = cur.nombreC

        act = Actividad.objects.get(nombre_actividad=nombreactividad, descripcion=descripcionactividad,
        fecha_vencimiento=fechavencimiento, statusAC=1, id_cursoR=idcurso,
        id_unidadR=idunidad, id_instructorR=idinstructor, archivos_actividad=nombrezip, objetivo=objetivoS)
        idactividad = act.id_actividad


        texto = "Tu instructor agrego la actividad " + nombreactividad + " al curso " + nombrecursoss + "."

        today = date.today()

        hora = datetime.now().strftime("%I:%M:%S")

        fechafinal = today + timedelta(days=3)

        alumnos = CursoEstudiante.objects.filter(id_cursoR=idcurso, id_instructorRC=idinstructor)

        for alumno in alumnos:

            idalumno = alumno.id_estudianteR

            ni = NotificacionesAlumnos(id_alumnoR=idalumno, mensaje_notificacion=texto,
            fecha_notificacion=today, hora_notificacion=hora, fecha_fin=fechafinal,
            id_elementoNotificacion=idactividad, tipo_elementoNotificacion="Actividad")
            ni.save()


        actividad = Actividad.objects.filter(id_cursoR=idcurso, id_instructorR=idinstructor)

        curso = Curso.objects.filter(id_curso=idcurso)

        opcion = OpcionesInstructor.objects.filter(id_instructorR=idinstructor)

        usuario = Instructor.objects.filter(id_instructor=idinstructor)

        todaynoti = date.today()

        finnoti = todaynoti + timedelta(days=3)

        notificacion = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0)

        numeronotificaciones = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()


        pagina = ElementosPagina.objects.filter(id_elementoPagina=1)

        contexto = {'paginas':pagina, 'actividades':actividad, 'cursos':curso, 'opciones':opcion, 'usuarios':usuario,
        'notificaciones':notificacion, 'numeronotificaciones':numeronotificaciones}

        return render(request, 'Instructor/Extras/Cursos/mostrar_actividades.html', contexto)




@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_instructor, login_url='/iniciar_sesion/')
def mostrar_editar_actividad(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    idactividad = id

    actividad = Actividad.objects.filter(id_actividad=idactividad)

    a = Actividad.objects.get(id_actividad=idactividad)

    idcurso = a.id_cursoR

    curso = Curso.objects.filter(id_curso=idcurso)

    valor2 = request.user.id_relacionado

    unidad = Unidades.objects.filter(id_cursoR=idcurso, id_instructorR=valor2)

    opcion = OpcionesInstructor.objects.filter(id_instructorR=valor2)

    usuario = Instructor.objects.filter(id_instructor=valor2)

    todaynoti = date.today()

    finnoti = todaynoti + timedelta(days=3)

    notificacion = NotificacionesInstructores.objects.filter(id_instructorR=valor2, fecha_fin__range=[todaynoti, finnoti], statusN=0)

    numeronotificaciones = NotificacionesInstructores.objects.filter(id_instructorR=valor2, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()


    pagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    fecha = str(todaynoti)

    contexto = {'paginas':pagina, 'actividades':actividad, 'cursos':curso, 'unidades':unidad,
    'opciones':opcion, 'usuarios':usuario, 'notificaciones':notificacion, 'numeronotificaciones':numeronotificaciones, 'fecha':fecha}

    return render(request, 'Instructor/Extras/Cursos/editar_actividad.html', contexto)




@csrf_exempt
@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_instructor, login_url='/iniciar_sesion/')
def editar_actividad(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    compression = zipfile.ZIP_DEFLATED

    if request.method == "POST":

        nombreactividad = request.POST["titulo"]
        descripcionactividad = request.POST["descripcion"]
        fechavencimiento = request.POST["fechaentrega"]
        idunidad = request.POST["unidad"]
        archivos = request.FILES.getlist("archivosactividad")
        objetivoS = request.POST["objetivo"]

        nombresarchivos = []
        nombrezip = ""

        idactividad = id

        aa = Actividad.objects.get(id_actividad=idactividad)

        idcursos = aa.id_cursoR

        if archivos:

            for archivo in archivos:

                nombrearchivo = secure_filename(archivo.name)
                nombresarchivos.append(nombrearchivo)

                #fs = FileSystemStorage(location='ProyectoKaizen/static/media/Documentos/Instructores')
                fs = FileSystemStorage(location= os.path.join(settings.MEDIA_ROOT+'/Documentos/Instructores'))
                filena = fs.save(nombrearchivo, archivo)


            prueba = Actividad.objects.filter(nombre_actividad=nombreactividad)

            if prueba:

                curs = Curso.objects.get(id_curso=idcursos)
                nombrecurso = curs.nombreC

                nombrezip = nombreactividad + nombrecurso +".zip"

            else:

                nombrezip = nombreactividad + ".zip"


            zf = zipfile.ZipFile(os.path.join(settings.MEDIA_ROOT+'/Documentos/Instructores/'+ nombrezip), mode="w")

            for nombre in nombresarchivos:

                zf.write(os.path.join(settings.MEDIA_ROOT+'/Documentos/Instructores/'+ nombre), arcname=os.path.basename(os.path.join(settings.MEDIA_ROOT+'/Documentos/Instructores/'+ nombre)), compress_type=compression)

            zf.close()

            for nombre in nombresarchivos:

                os.remove(os.path.join(settings.MEDIA_ROOT+'/Documentos/Instructores/' + nombre))



        a = Actividad.objects.get(id_actividad=idactividad)

        idcurso = a.id_cursoR
        idinstructor = request.user.id_relacionado
        rutaarchivo = a.archivos_actividad

        a.nombre_actividad = nombreactividad
        a.descripcion = descripcionactividad
        a.fecha_vencimiento = fechavencimiento
        a.id_unidadR = idunidad

        if nombrezip != "":

            a.archivos_actividad = nombrezip

            if rutaarchivo:

                if os.path.exists(os.path.join(settings.MEDIA_ROOT+'/Documentos/Instructores/' + rutaarchivo)):

                    os.remove(os.path.join(settings.MEDIA_ROOT+'/Documentos/Instructores/' + rutaarchivo))

        a.objetivo = objetivoS
        a.save()


        cur = Curso.objects.get(id_curso=idcurso)
        nombrecursoss = cur.nombreC


        texto = "Tu instructor edito la actividad " + nombreactividad + " del curso " + nombrecursoss + "."

        today = date.today()

        hora = datetime.now().strftime("%I:%M:%S")

        fechafinal = today + timedelta(days=3)

        alumnos = CursoEstudiante.objects.filter(id_cursoR=idcurso, id_instructorRC=idinstructor)

        for alumno in alumnos:

            idalumno = alumno.id_estudianteR

            ni = NotificacionesAlumnos(id_alumnoR=idalumno, mensaje_notificacion=texto,
            fecha_notificacion=today, hora_notificacion=hora, fecha_fin=fechafinal,
            id_elementoNotificacion=idactividad, tipo_elementoNotificacion="Actividad")
            ni.save()


        actividad = Actividad.objects.filter(id_cursoR=idcurso, id_instructorR=idinstructor)

        curso = Curso.objects.filter(id_curso=idcurso)

        opcion = OpcionesInstructor.objects.filter(id_instructorR=idinstructor)

        usuario = Instructor.objects.filter(id_instructor=idinstructor)

        todaynoti = date.today()

        finnoti = todaynoti + timedelta(days=3)

        notificacion = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0)

        numeronotificaciones = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()


        pagina = ElementosPagina.objects.filter(id_elementoPagina=1)

        contexto = {'paginas':pagina, 'actividades':actividad, 'cursos':curso, 'opciones':opcion, 'usuarios':usuario,
        'notificaciones':notificacion, 'numeronotificaciones':numeronotificaciones}

        return render(request, 'Instructor/Extras/Cursos/mostrar_actividades.html', contexto)



@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_instructor, login_url='/iniciar_sesion/')
def mostrar_review_actividad(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    idactividad = id

    ac = Actividad.objects.get(id_actividad=idactividad)

    idcurso = ac.id_cursoR

    curso = Curso.objects.filter(id_curso=idcurso)

    actividad = Actividad.objects.filter(id_actividad=idactividad)

    entrega = ActividadAlumno.objects.filter(id_actividadR=idactividad)

    idinstructor = request.user.id_relacionado

    opcion = OpcionesInstructor.objects.filter(id_instructorR=idinstructor)

    usuario = Instructor.objects.filter(id_instructor=idinstructor)

    todaynoti = date.today()

    finnoti = todaynoti + timedelta(days=3)

    notificacion = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0)

    numeronotificaciones = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()


    pagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    contexto = {'paginas':pagina, 'cursos':curso, 'actividades':actividad, 'entregas':entrega,
    'opciones':opcion, 'usuarios':usuario, 'notificaciones':notificacion, 'numeronotificaciones':numeronotificaciones}

    return render(request, 'Instructor/Extras/Cursos/review_actividad.html', contexto)




@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_instructor, login_url='/iniciar_sesion/')
def mostrar_revisar_actividad(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    identrega = id

    en = ActividadAlumno.objects.get(id_actividadAlumno=identrega)

    idcurso = en.id_cursoR
    idactividad = en.id_actividadR

    curso = Curso.objects.filter(id_curso=idcurso)

    actividad = Actividad.objects.filter(id_actividad=idactividad)

    entrega = ActividadAlumno.objects.filter(id_actividadAlumno=identrega)

    idinstructor = request.user.id_relacionado

    opcion = OpcionesInstructor.objects.filter(id_instructorR=idinstructor)

    usuario = Instructor.objects.filter(id_instructor=idinstructor)

    todaynoti = date.today()

    finnoti = todaynoti + timedelta(days=3)

    notificacion = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0)

    numeronotificaciones = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()


    pagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    contexto = {'paginas':pagina, 'cursos':curso, 'actividades':actividad, 'entregas':entrega, 'opciones':opcion, 'usuarios':usuario,
    'notificaciones':notificacion, 'numeronotificaciones':numeronotificaciones}

    return render(request, 'Instructor/Extras/Cursos/revisar_actividad.html', contexto)



@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_instructor, login_url='/iniciar_sesion/')
def mostrar_revisar_actividad_dos(request, id, id2):

    request.session.set_expiry(request.session.get_expiry_age())

    identrega = id

    idnotificacion = id2

    en = ActividadAlumno.objects.get(id_actividadAlumno=identrega)

    idcurso = en.id_cursoR
    idactividad = en.id_actividadR

    curso = Curso.objects.filter(id_curso=idcurso)

    actividad = Actividad.objects.filter(id_actividad=idactividad)

    entrega = ActividadAlumno.objects.filter(id_actividadAlumno=identrega)

    idinstructor = request.user.id_relacionado

    opcion = OpcionesInstructor.objects.filter(id_instructorR=idinstructor)

    usuario = Instructor.objects.filter(id_instructor=idinstructor)

    noti = NotificacionesInstructores.objects.get(id_notificacionInstructor=idnotificacion)
    noti.statusN = 1
    noti.save()

    todaynoti = date.today()

    finnoti = todaynoti + timedelta(days=3)

    notificacion = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0)

    numeronotificaciones = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()


    pagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    contexto = {'paginas':pagina, 'cursos':curso, 'actividades':actividad, 'entregas':entrega, 'opciones':opcion, 'usuarios':usuario,
    'notificaciones':notificacion, 'numeronotificaciones':numeronotificaciones}

    return render(request, 'Instructor/Extras/Cursos/revisar_actividad.html', contexto)




@csrf_exempt
@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_instructor, login_url='/iniciar_sesion/')
def revisar_actividad(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    if request.method == "POST":

        calificacion = request.POST["calificacion"]
        comentarioins = request.POST["comentarioinstructor"]

        identrega = id

        fecharevision = date.today()

        entre = ActividadAlumno.objects.get(id_actividadAlumno=identrega)
        idcurso = entre.id_cursoR
        idactividad = entre.id_actividadR
        idalumno = entre.id_alumnoR

        entre.comentario_instructor = comentarioins
        entre.calificacion = calificacion
        entre.fecha_revisado = fecharevision
        entre.revisado = 1
        entre.save()

        cur = Curso.objects.get(id_curso=idcurso)
        nombrecursoss = cur.nombreC


        texto = "Tu instructor le asigno una calificacion a tu actividad."

        today = date.today()

        hora = datetime.now().strftime("%I:%M:%S")

        fechafinal = today + timedelta(days=3)

        ni = NotificacionesAlumnos(id_alumnoR=idalumno, mensaje_notificacion=texto,
        fecha_notificacion=today, hora_notificacion=hora, fecha_fin=fechafinal,
        id_elementoNotificacion=idactividad, tipo_elementoNotificacion="ActividadE")
        ni.save()


        curso = Curso.objects.filter(id_curso=idcurso)

        actividad = Actividad.objects.filter(id_actividad=idactividad)

        entrega = ActividadAlumno.objects.filter(id_actividadR=idactividad)

        idinstructor = request.user.id_relacionado

        opcion = OpcionesInstructor.objects.filter(id_instructorR=idinstructor)

        usuario = Instructor.objects.filter(id_instructor=idinstructor)

        todaynoti = date.today()

        finnoti = todaynoti + timedelta(days=3)

        notificacion = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0)

        numeronotificaciones = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()


        pagina = ElementosPagina.objects.filter(id_elementoPagina=1)

        contexto = {'paginas':pagina, 'cursos':curso, 'actividades':actividad, 'entregas':entrega,
        'opciones':opcion, 'usuarios':usuario, 'notificaciones':notificacion, 'numeronotificaciones':numeronotificaciones}

        return render(request, 'Instructor/Extras/Cursos/review_actividad.html', contexto)




@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_instructor, login_url='/iniciar_sesion/')
def mostrar_examenes(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    idcurso = id

    curso = Curso.objects.filter(id_curso=idcurso)

    idinstructor = request.user.id_relacionado

    examen = EvaluacionesCursos.objects.filter(id_cursoR=idcurso, id_instructorR=idinstructor)

    opcion = OpcionesInstructor.objects.filter(id_instructorR=idinstructor)

    usuario = Instructor.objects.filter(id_instructor=idinstructor)

    todaynoti = date.today()

    finnoti = todaynoti + timedelta(days=3)

    notificacion = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0)

    numeronotificaciones = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()


    pagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    contexto = {'paginas':pagina, 'cursos':curso, 'examenes':examen, 'opciones':opcion, 'usuarios':usuario,
    'notificaciones':notificacion, 'numeronotificaciones':numeronotificaciones}

    return render(request, 'Instructor/Extras/Cursos/mostrar_examenes.html', contexto)




@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_instructor, login_url='/iniciar_sesion/')
def mostrar_agregar_examen(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    idcurso = id

    idinstructor = request.user.id_relacionado

    curso = Curso.objects.filter(id_curso=idcurso)

    unidad = Unidades.objects.filter(id_cursoR=idcurso, id_instructorR=idinstructor)

    opcion = OpcionesInstructor.objects.filter(id_instructorR=idinstructor)

    usuario = Instructor.objects.filter(id_instructor=idinstructor)

    todaynoti = date.today()

    finnoti = todaynoti + timedelta(days=3)

    notificacion = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0)

    numeronotificaciones = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()


    pagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    fecha = str(todaynoti)

    contexto = {'paginas':pagina, 'cursos':curso, 'unidades':unidad, 'opciones':opcion, 'usuarios':usuario,
    'notificaciones':notificacion, 'numeronotificaciones':numeronotificaciones, 'fecha':fecha}

    return render(request, 'Instructor/Extras/Cursos/agregar_examen.html', contexto)




@csrf_exempt
@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_instructor, login_url='/iniciar_sesion/')
def agregar_examen(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    if request.method == "POST":

        tituloexamen = request.POST["titulo"]
        descripcionexamen = request.POST["descripcion"]
        fechavencimiento = request.POST["fechavencimiento"]
        idunidad = request.POST["unidadr"]
        tiempo = request.POST["tiempo"]

        idcurso = id

        idinstructor = request.user.id_relacionado

        ec = EvaluacionesCursos(id_cursoR=idcurso, id_instructorR=idinstructor, id_unidadR=idunidad,
        titulo_evaluacion=tituloexamen, descripcionE=descripcionexamen, statusEC=1, fecha_vencimientoE=fechavencimiento, tiempo_limite=tiempo)
        ec.save()


        evac = EvaluacionesCursos.objects.get(id_cursoR=idcurso, id_instructorR=idinstructor, id_unidadR=idunidad,
        titulo_evaluacion=tituloexamen, descripcionE=descripcionexamen, statusEC=1, fecha_vencimientoE=fechavencimiento)

        idevacur = evac.id_evalucionCurso

        cur = Curso.objects.get(id_curso=idcurso)
        nombrecursoss = cur.nombreC

        exa = EvaluacionesCursos.objects.get(id_cursoR=idcurso, id_instructorR=idinstructor, id_unidadR=idunidad,
        titulo_evaluacion=tituloexamen, descripcionE=descripcionexamen, statusEC=1, fecha_vencimientoE=fechavencimiento, tiempo_limite=tiempo)
        idexamen = exa.id_evalucionCurso


        texto = "Tu instructor agrego el examen " + tituloexamen + " al curso " + nombrecursoss + "."

        today = date.today()

        hora = datetime.now().strftime("%I:%M:%S")

        fechafinal = today + timedelta(days=3)

        alumnos = CursoEstudiante.objects.filter(id_cursoR=idcurso, id_instructorRC=idinstructor)

        for alumno in alumnos:

            idalumno = alumno.id_estudianteR

            ni = NotificacionesAlumnos(id_alumnoR=idalumno, mensaje_notificacion=texto,
            fecha_notificacion=today, hora_notificacion=hora, fecha_fin=fechafinal,
            id_elementoNotificacion=idexamen, tipo_elementoNotificacion="Examen")
            ni.save()



        pregunta = PreguntasEvaluacionCursos.objects.filter(id_EvaluacionCursoR=idevacur)

        examen = EvaluacionesCursos.objects.filter(id_evalucionCurso=idevacur)

        curso = Curso.objects.filter(id_curso=idcurso)

        opcion = OpcionesInstructor.objects.filter(id_instructorR=idinstructor)

        usuario = Instructor.objects.filter(id_instructor=idinstructor)

        todaynoti = date.today()

        finnoti = todaynoti + timedelta(days=3)

        notificacion = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0)

        numeronotificaciones = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()


        pagina = ElementosPagina.objects.filter(id_elementoPagina=1)

        contexto = {'paginas':pagina, 'examenes':examen, 'cursos':curso, 'preguntas':pregunta, 'opciones':opcion, 'usuarios':usuario,
        'notificaciones':notificacion, 'numeronotificaciones':numeronotificaciones}

        return render(request, 'Instructor/Extras/Cursos/agregar_preguntas.html', contexto)




@csrf_exempt
@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_instructor, login_url='/iniciar_sesion/')
def agregar_pregunta(request, id, id2):

    request.session.set_expiry(request.session.get_expiry_age())

    if request.method == "POST":

        pregunta = request.POST["pregunta"]
        respuestacorrecta = request.POST["respuestacorrecta"]
        respuestauno = request.POST["respuestauno"]
        respuestados = request.POST["respuestados"]
        respuestatres = request.POST["respuestatres"]
        puntaje = request.POST["puntaje"]

        idexamen = id
        idcurso = id2

        idinstructor = request.user.id_relacionado

        p = PreguntasEvaluacionCursos(id_EvaluacionCursoR=idexamen, id_cursoR=idcurso,
        id_instructorR=idinstructor, preguntaC=pregunta, valor_pregunta=puntaje,
        respuesta_uno=respuestauno, respuesta_dos=respuestados, respuesta_tres=respuestatres,
        respuesta_correcta=respuestacorrecta)
        p.save()


        pregunta = PreguntasEvaluacionCursos.objects.filter(id_EvaluacionCursoR=idexamen)

        examen = EvaluacionesCursos.objects.filter(id_evalucionCurso=idexamen)

        curso = Curso.objects.filter(id_curso=idcurso)

        opcion = OpcionesInstructor.objects.filter(id_instructorR=idinstructor)

        usuario = Instructor.objects.filter(id_instructor=idinstructor)

        todaynoti = date.today()

        finnoti = todaynoti + timedelta(days=3)

        notificacion = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0)

        numeronotificaciones = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()


        pagina = ElementosPagina.objects.filter(id_elementoPagina=1)

        contexto = {'paginas':pagina, 'examenes':examen, 'cursos':curso, 'preguntas':pregunta, 'opciones':opcion, 'usuarios':usuario,
        'notificaciones':notificacion, 'numeronotificaciones':numeronotificaciones}

        return render(request, 'Instructor/Extras/Cursos/agregar_preguntas.html', contexto)




@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_instructor, login_url='/iniciar_sesion/')
def mostrar_editar_pregunta(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    idpregunta = id

    pregunta = PreguntasEvaluacionCursos.objects.filter(id_PreguntaEvaluacionCurso=idpregunta)

    contexto = {'preguntas':pregunta}

    return render(request, 'Instructor/Extras/Cursos/editar_pregunta.html', contexto)




@csrf_exempt
@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_instructor, login_url='/iniciar_sesion/')
def editar_pregunta(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    if request.method == "POST":

        pregunta = request.POST["pregunta"]
        respuestacorrecta = request.POST["respuestacorrecta"]
        respuestauno = request.POST["respuestauno"]
        respuestados = request.POST["respuestados"]
        respuestatres = request.POST["respuestatres"]
        puntaje = request.POST["puntaje"]

        idpregunta = id

        idinstructor = request.user.id_relacionado

        p = PreguntasEvaluacionCursos.objects.get(id_PreguntaEvaluacionCurso=idpregunta)
        idexamen = p.id_EvaluacionCursoR
        idcurso = p.id_cursoR

        p.preguntaC = pregunta
        p.valor_pregunta = puntaje
        p.respuesta_uno = respuestauno
        p.respuesta_dos = respuestados
        p.respuesta_tres = respuestatres
        p.respuesta_correcta = respuestacorrecta
        p.save()


        pregunta = PreguntasEvaluacionCursos.objects.filter(id_EvaluacionCursoR=idexamen)

        examen = EvaluacionesCursos.objects.filter(id_evalucionCurso=idexamen)

        curso = Curso.objects.filter(id_curso=idcurso)

        opcion = OpcionesInstructor.objects.filter(id_instructorR=idinstructor)

        usuario = Instructor.objects.filter(id_instructor=idinstructor)

        todaynoti = date.today()

        finnoti = todaynoti + timedelta(days=3)

        notificacion = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0)

        numeronotificaciones = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()


        pagina = ElementosPagina.objects.filter(id_elementoPagina=1)

        contexto = {'paginas':pagina, 'examenes':examen, 'cursos':curso, 'preguntas':pregunta, 'opciones':opcion,
        'usuarios':usuario, 'notificaciones':notificacion, 'numeronotificaciones':numeronotificaciones}

        return render(request, 'Instructor/Extras/Cursos/agregar_preguntas.html', contexto)




@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_instructor, login_url='/iniciar_sesion/')
def mostrar_editar_examen(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    idexamen = id

    idinstructor = request.user.id_relacionado

    e = EvaluacionesCursos.objects.get(id_evalucionCurso=idexamen)
    idcurso = e.id_cursoR

    curso = Curso.objects.filter(id_curso=idcurso)

    unidad = Unidades.objects.filter(id_cursoR=idcurso, id_instructorR=idinstructor)

    examen = EvaluacionesCursos.objects.filter(id_evalucionCurso=idexamen)

    opcion = OpcionesInstructor.objects.filter(id_instructorR=idinstructor)

    usuario = Instructor.objects.filter(id_instructor=idinstructor)

    todaynoti = date.today()

    finnoti = todaynoti + timedelta(days=3)

    notificacion = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0)

    numeronotificaciones = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()


    pagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    fecha = str(todaynoti)

    contexto = {'paginas':pagina, 'cursos':curso, 'unidades':unidad, 'examenes':examen, 'opciones':opcion, 'usuarios':usuario,
    'notificaciones':notificacion, 'numeronotificaciones':numeronotificaciones, 'fecha':fecha}

    return render(request, 'Instructor/Extras/Cursos/editar_examen.html', contexto)




@csrf_exempt
@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_instructor, login_url='/iniciar_sesion/')
def editar_examen(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    if request.method == "POST":

        tituloexamen = request.POST["titulo"]
        descripcionexamen = request.POST["descripcion"]
        fechavencimiento = request.POST["fechavencimiento"]
        idunidad = request.POST["unidadr"]

        idexamen = id

        idinstructor = request.user.id_relacionado

        ex = EvaluacionesCursos.objects.get(id_evalucionCurso=idexamen)
        idcurso = ex.id_cursoR

        ex.titulo_evaluacion = tituloexamen
        ex.descripcionE = descripcionexamen
        ex.fecha_vencimientoE = fechavencimiento
        ex.id_unidadR = idunidad
        ex.save()

        cur = Curso.objects.get(id_curso=idcurso)
        nombrecursoss = cur.nombreC


        texto = "Tu instructor edito el examen " + tituloexamen + " del curso " + nombrecursoss + "."

        today = date.today()

        hora = datetime.now().strftime("%I:%M:%S")

        fechafinal = today + timedelta(days=3)

        alumnos = CursoEstudiante.objects.filter(id_cursoR=idcurso, id_instructorRC=idinstructor)

        for alumno in alumnos:

            idalumno = alumno.id_estudianteR

            ni = NotificacionesAlumnos(id_alumnoR=idalumno, mensaje_notificacion=texto,
            fecha_notificacion=today, hora_notificacion=hora, fecha_fin=fechafinal,
            id_elementoNotificacion=idexamen, tipo_elementoNotificacion="Examen")
            ni.save()


        curso = Curso.objects.filter(id_curso=idcurso)

        examen = EvaluacionesCursos.objects.filter(id_cursoR=idcurso, id_instructorR=idinstructor)

        opcion = OpcionesInstructor.objects.filter(id_instructorR=idinstructor)

        usuario = Instructor.objects.filter(id_instructor=idinstructor)

        todaynoti = date.today()

        finnoti = todaynoti + timedelta(days=3)

        notificacion = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0)

        numeronotificaciones = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()


        pagina = ElementosPagina.objects.filter(id_elementoPagina=1)

        contexto = {'paginas':pagina, 'cursos':curso, 'examenes':examen, 'opciones':opcion, 'usuarios':usuario,
        'notificaciones':notificacion, 'numeronotificaciones':numeronotificaciones}

        return render(request, 'Instructor/Extras/Cursos/mostrar_examenes.html', contexto)




@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_instructor, login_url='/iniciar_sesion/')
def mostrar_preguntas(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    idexamen = id

    idinstructor = request.user.id_relacionado

    evac = EvaluacionesCursos.objects.get(id_evalucionCurso=idexamen)

    idcurso = evac.id_cursoR

    pregunta = PreguntasEvaluacionCursos.objects.filter(id_EvaluacionCursoR=idexamen)

    examen = EvaluacionesCursos.objects.filter(id_evalucionCurso=idexamen)

    curso = Curso.objects.filter(id_curso=idcurso)

    opcion = OpcionesInstructor.objects.filter(id_instructorR=idinstructor)

    usuario = Instructor.objects.filter(id_instructor=idinstructor)

    todaynoti = date.today()

    finnoti = todaynoti + timedelta(days=3)

    notificacion = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0)

    numeronotificaciones = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()


    pagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    contexto = {'paginas':pagina, 'examenes':examen, 'cursos':curso, 'preguntas':pregunta, 'opciones':opcion, 'usuarios':usuario,
    'notificaciones':notificacion, 'numeronotificaciones':numeronotificaciones}

    return render(request, 'Instructor/Extras/Cursos/agregar_preguntas.html', contexto)




@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_instructor, login_url='/iniciar_sesion/')
def mostrar_revision_examen(request, id, id2):

    request.session.set_expiry(request.session.get_expiry_age())

    idalumno = id

    idexamen = id2

    puntajeT = 0

    examen = EvaluacionesCursos.objects.filter(id_evalucionCurso=idexamen)

    exa = EvaluacionesCursos.objects.get(id_evalucionCurso=idexamen)

    idcurso = exa.id_cursoR
    curso = Curso.objects.filter(id_curso=idcurso)

    examenA = EvaluacionCursosEstudiante.objects.filter(id_evaluacionCursoR=idexamen, id_estudianteR=idalumno)

    respuesta = RespuestasEvaluacionCursosEstudiante.objects.filter(id_evaluacionCursoR=idexamen, id_estudianteR=idalumno)

    exameness = PreguntasEvaluacionCursos.objects.filter(id_EvaluacionCursoR=idexamen)

    for examenn in exameness:

        puntajeP = examenn.valor_pregunta
        puntajeT = puntajeT + puntajeP


    no_preguntas = PreguntasEvaluacionCursos.objects.filter(id_EvaluacionCursoR=idexamen).count()
    no_mis_preguntas = RespuestasEvaluacionCursosEstudiante.objects.filter(id_evaluacionCursoR=idexamen, id_estudianteR=idalumno, es_correcta=1).count()

    #Instructor
    idinstructor = request.user.id_relacionado

    opcion = OpcionesInstructor.objects.filter(id_instructorR=idinstructor)

    usuario = Instructor.objects.filter(id_instructor=idinstructor)

    todaynoti = date.today()

    finnoti = todaynoti + timedelta(days=3)

    notificacion = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0)

    numeronotificaciones = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()


    pagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    contexto = {'idexamen':idexamen, 'paginas':pagina, 'cursos':curso, 'opciones':opcion, 'usuarios':usuario,
    'notificaciones':notificacion, 'numeronotificaciones':numeronotificaciones, 'examenes':examen, 'examenesA':examenA, 'respuestas':respuesta,
    'puntajeTotal':puntajeT, 'no_preguntas':no_preguntas, 'no_mis_preguntas':no_mis_preguntas}

    return render(request, 'Instructor/Extras/Cursos/detalles_examen.html', contexto)



@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_instructor, login_url='/iniciar_sesion/')
def mostrar_review_examen(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    idexamen = id

    ac = EvaluacionesCursos.objects.get(id_evalucionCurso=idexamen)

    idcurso = ac.id_cursoR

    curso = Curso.objects.filter(id_curso=idcurso)

    examen = EvaluacionesCursos.objects.filter(id_evalucionCurso=idexamen)

    entrega = EvaluacionCursosEstudiante.objects.filter(id_evaluacionCursoR=idexamen)

    idinstructor = request.user.id_relacionado

    opcion = OpcionesInstructor.objects.filter(id_instructorR=idinstructor)

    usuario = Instructor.objects.filter(id_instructor=idinstructor)

    todaynoti = date.today()

    finnoti = todaynoti + timedelta(days=3)

    notificacion = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0)

    numeronotificaciones = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()


    pagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    contexto = {'paginas':pagina, 'cursos':curso, 'examenes':examen, 'entregas':entrega, 'opciones':opcion, 'usuarios':usuario,
    'notificaciones':notificacion, 'numeronotificaciones':numeronotificaciones}

    return render(request, 'Instructor/Extras/Cursos/review_examen.html', contexto)


@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_instructor, login_url='/iniciar_sesion/')
def mostrar_review_examen_dos(request, id, id2):

    request.session.set_expiry(request.session.get_expiry_age())

    idexamen = id

    idnotificacion = id2

    ac = EvaluacionesCursos.objects.get(id_evalucionCurso=idexamen)

    idcurso = ac.id_cursoR

    curso = Curso.objects.filter(id_curso=idcurso)

    examen = EvaluacionesCursos.objects.filter(id_evalucionCurso=idexamen)

    entrega = EvaluacionCursosEstudiante.objects.filter(id_evaluacionCursoR=idexamen)

    idinstructor = request.user.id_relacionado

    opcion = OpcionesInstructor.objects.filter(id_instructorR=idinstructor)

    usuario = Instructor.objects.filter(id_instructor=idinstructor)

    noti = NotificacionesInstructores.objects.get(id_notificacionInstructor=idnotificacion)
    noti.statusN = 1
    noti.save()

    todaynoti = date.today()

    finnoti = todaynoti + timedelta(days=3)

    notificacion = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0)

    numeronotificaciones = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()


    pagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    contexto = {'paginas':pagina, 'cursos':curso, 'examenes':examen, 'entregas':entrega, 'opciones':opcion, 'usuarios':usuario,
    'notificaciones':notificacion, 'numeronotificaciones':numeronotificaciones}

    return render(request, 'Instructor/Extras/Cursos/review_examen.html', contexto)





@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_instructor, login_url='/iniciar_sesion/')
def mostrar_asistencia(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    idcurso = id

    idinstructor = request.user.id_relacionado

    curso = Curso.objects.filter(id_curso=idcurso)

    asistencia = CursoEstudiante.objects.filter(id_cursoR=idcurso, id_instructorRC=idinstructor)

    opcion = OpcionesInstructor.objects.filter(id_instructorR=idinstructor)

    usuario = Instructor.objects.filter(id_instructor=idinstructor)

    todaynoti = date.today()

    finnoti = todaynoti + timedelta(days=3)

    notificacion = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0)

    numeronotificaciones = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()


    pagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    contexto = {'paginas':pagina, 'cursos':curso, 'asistencias':asistencia, 'opciones':opcion, 'usuarios':usuario,
    'notificaciones':notificacion, 'numeronotificaciones':numeronotificaciones}

    return render(request, 'Instructor/Extras/Cursos/mostrar_asistencias.html', contexto)




@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_instructor, login_url='/iniciar_sesion/')
def mostrar_pasar_asistencia(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    idcurso = id

    idinstructor = request.user.id_relacionado

    curso = Curso.objects.filter(id_curso=idcurso)

    alumno = CursoEstudiante.objects.filter(id_cursoR=idcurso, id_instructorRC=idinstructor)

    opcion = OpcionesInstructor.objects.filter(id_instructorR=idinstructor)

    usuario = Instructor.objects.filter(id_instructor=idinstructor)

    todaynoti = date.today()

    finnoti = todaynoti + timedelta(days=3)

    notificacion = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0)

    numeronotificaciones = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()

    pagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    contexto = {'paginas':pagina, 'cursos':curso, 'alumnos':alumno, 'opciones':opcion, 'usuarios':usuario,
    'notificaciones':notificacion, 'numeronotificaciones':numeronotificaciones}

    return render(request, 'Instructor/Extras/Cursos/pasar_asistencia.html', contexto)




@csrf_exempt
@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_instructor, login_url='/iniciar_sesion/')
def agregar_asistencia(request, id):

    request.session.set_expiry(request.session.get_expiry_age())

    if request.method == "POST":

        datos = request.POST.getlist("datos")

        idcurso = id
        idinstructor = request.user.id_relacionado
        fecha = date.today()

        for dato in datos:

            cadena = dato.split(",")

            asis = Asistencias(id_cursoR=idcurso, id_instructorR=idinstructor,
            id_alumnoR=int(cadena[0]), nombre_alumnoR=cadena[1], valor_asistencia=cadena[2],
            fecha_asistencia=fecha)
            asis.save()


        curso = Curso.objects.filter(id_curso=idcurso)

        asistencia = CursoEstudiante.objects.filter(id_cursoR=idcurso, id_instructorRC=idinstructor)

        opcion = OpcionesInstructor.objects.filter(id_instructorR=idinstructor)

        usuario = Instructor.objects.filter(id_instructor=idinstructor)

        todaynoti = date.today()

        finnoti = todaynoti + timedelta(days=3)

        notificacion = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0)

        numeronotificaciones = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()


        pagina = ElementosPagina.objects.filter(id_elementoPagina=1)

        contexto = {'paginas':pagina, 'cursos':curso, 'asistencias':asistencia, 'opciones':opcion, 'usuarios':usuario,
        'notificaciones':notificacion, 'numeronotificaciones':numeronotificaciones}

        return render(request, 'Instructor/Extras/Cursos/mostrar_asistencias.html', contexto)



@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_instructor, login_url='/iniciar_sesion/')
def mostrar_asistencia_alumno(request, id, id2):

    request.session.set_expiry(request.session.get_expiry_age())

    idestudiante = id
    idcurso = id2

    noasistencias = 0
    nofaltas = 0
    noretardos = 0

    asistencia = Asistencias.objects.filter(id_cursoR=idcurso, id_alumnoR=idestudiante)

    for asiste in asistencia:

        tipo = asiste.valor_asistencia

        if tipo == "Asistencia":

            noasistencias = noasistencias + 1

        elif tipo == "Falta":

            nofaltas = nofaltas + 1

        else:

            noretardos = noretardos + 1


    curso = Curso.objects.filter(id_curso=idcurso)

    idinstructor = request.user.id_relacionado

    opcion = OpcionesInstructor.objects.filter(id_instructorR=idinstructor)

    usuario = Instructor.objects.filter(id_instructor=idinstructor)

    todaynoti = date.today()

    finnoti = todaynoti + timedelta(days=3)

    notificacion = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0)

    numeronotificaciones = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()


    pagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    contexto = {'paginas':pagina, 'cursos':curso, 'asistencias':asistencia, 'noasistencias':noasistencias,
    'nofaltas':nofaltas, 'noretardos':noretardos, 'opciones':opcion, 'usuarios':usuario,
    'notificaciones':notificacion, 'numeronotificaciones':numeronotificaciones}


    return render(request, 'Instructor/Extras/Cursos/asistencias_alumno.html', contexto)




@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_instructor, login_url='/iniciar_sesion/')
def mostrar_editar_perfil_instructor(request):

    request.session.set_expiry(request.session.get_expiry_age())

    idinstructor = request.user.id_relacionado

    instructor = Instructor.objects.filter(id_instructor=idinstructor)

    opcion = OpcionesInstructor.objects.filter(id_instructorR=idinstructor)

    usuario = Instructor.objects.filter(id_instructor=idinstructor)

    pais = Pais.objects.all()

    for ins in instructor:

        nombrePai = ins.paisI
        nombreEsta = ins.estadoI

    for pai in pais:

        if pai.PaisNombre == nombrePai:

            codigoPai = pai.PaisCodigo

    estado = Ciudad.objects.filter(PaisCodigo=codigoPai).values('CiudadDistrito').distinct()

    ciudad = Ciudad.objects.filter(PaisCodigo=codigoPai, CiudadDistrito=nombreEsta).values('CiudadNombre').distinct()


    todaynoti = date.today()

    finnoti = todaynoti + timedelta(days=3)

    notificacion = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0)

    numeronotificaciones = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()


    pagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    contexto = {'codigopais':codigoPai, 'ciudades':ciudad, 'estados':estado, 'paises':pais, 'paginas':pagina, 'instructores':instructor, 'opciones':opcion, 'usuarios':usuario,
    'notificaciones':notificacion, 'numeronotificaciones':numeronotificaciones}

    return render(request, 'Instructor/Extras/General/editar_perfil.html', contexto)



@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_instructor, login_url='/iniciar_sesion/')
def mostrar_estado_instructor(request, id):

    codigo = id

    codigo2 = codigo.split("_")

    codigopais = codigo2[0]

    estado = Ciudad.objects.filter(PaisCodigo=codigopais).values('CiudadDistrito').distinct()

    contexto = {'estados':estado, 'codigopais':codigopais}

    return render(request, 'Instructor/Extras/General/pais_ajax.html', contexto)



@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_instructor, login_url='/iniciar_sesion/')
def mostrar_ciudad_instructor(request, id, id2):

    nombreestado = id

    nombreestado2 = nombreestado.replace("_", " ")

    codigopais = id2

    ciudad = Ciudad.objects.filter(PaisCodigo=codigopais, CiudadDistrito=nombreestado2).values('CiudadNombre').distinct()

    contexto = {'ciudades':ciudad}

    return render(request, 'Instructor/Extras/General/estado_ajax.html', contexto)



@csrf_exempt
@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_instructor, login_url='/iniciar_sesion/')
def guardar_perfil_instructor(request):

    request.session.set_expiry(request.session.get_expiry_age())

    if request.method == "POST":

        try:
            imagenperfil = request.FILES["avatar"]
        except Exception as e:
            imagenperfil = ""


        nombre = request.POST["nombres"]
        apellido = request.POST["apellidos"]
        direccion = request.POST["direccion"]
        cp = request.POST["cp"]
        ciudad = request.POST["ciudad"]
        estado = request.POST["estado"]
        pais = request.POST["pais"]
        #profesion = request.POST["profesion"]
        edad = request.POST["edad"]
        sexo = request.POST["sexo"]
        telefono = request.POST["telefono"]
        estudios = request.POST["estudios"]
        experienciaprofe = request.POST["experienciap"]
        experienciainstruc = request.POST["experienciai"]
        password = request.POST["password"]

        pais2 = pais.split("_")
        paisIG = pais2[1]

        nombreimagen = ""
        idinstructor = request.user.id_relacionado

        celular = str(telefono)

        alum = Instructor.objects.get(id_instructor=idinstructor)

        nombre_avatar = alum.ruta_imagen_perfil
        correo = alum.correoI


        if imagenperfil :

            nombreimagen = secure_filename(imagenperfil.name)
            #fs = FileSystemStorage(location='ProyectoKaizen/static/media/Imagenes/Instructores')
            fs = FileSystemStorage(location= os.path.join(settings.MEDIA_ROOT+'/Imagenes/Instructores'))
            filenam = fs.save(nombreimagen, imagenperfil)

            if nombre_avatar == "avatar.png":

                pass

            else:

                os.remove(os.path.join(settings.MEDIA_ROOT+'/Imagenes/Instructores/' + nombre_avatar))



        alumn = Instructor.objects.get(id_instructor=idinstructor)

        alumn.nombreI = nombre
        alumn.apellidosI = apellido
        alumn.direccionI = direccion
        alumn.codigopostalI = cp
        alumn.estadoI = estado
        alumn.ciudadI = ciudad
        alumn.paisI = paisIG
        alumn.estudiosI = estudios
        alumn.profesionI = ""
        alumn.edadI = edad
        alumn.celularI = celular
        alumn.experienciaP = experienciaprofe
        alumn.experienciaI =experienciainstruc

        if nombreimagen == "":

            pass

        else:

            alumn.ruta_imagen_perfil = nombreimagen


        alumn.sexo_instructor = sexo
        alumn.save()

        if password:

            nuevacontra = make_password(password)

            usu = Usuarios.objects.get(id_relacionado=idinstructor, email=correo, tipo_usuario=2)

            usu.password = nuevacontra

            usu.save()


        valor = request.user.id_relacionado

        filtro = CursoInstructor.objects.filter(id_instructorR=valor).values('id_cursoR')

        curso = Curso.objects.filter(id_curso__in=filtro)

        opcion = OpcionesInstructor.objects.filter(id_instructorR=valor)

        usuario = Instructor.objects.filter(id_instructor=valor)

        todaynoti = date.today()

        finnoti = todaynoti + timedelta(days=3)

        notificacion = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0)

        numeronotificaciones = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()


        pagina = ElementosPagina.objects.filter(id_elementoPagina=1)

        contexto = {'paginas':pagina, 'cursos':curso, 'opciones':opcion, 'usuarios':usuario, 'notificaciones':notificacion,
        'numeronotificaciones':numeronotificaciones}

        #return render(request, 'Instructor/instructor_cursos.html', contexto)
        return redirect('/inicio_instructor/')



@csrf_exempt
@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_instructor, login_url='/iniciar_sesion/')
def guardar_opciones_instructor(request):

    request.session.set_expiry(request.session.get_expiry_age())

    if request.method == "POST":

        try:
            imagenportada = request.FILES["portada"]
        except Exception as e:
            imagenportada = ""

        color = request.POST["color"]
        #clima = request.POST["clima"]

        nombreimagen = ""

        idinstructor = request.user.id_relacionado

        alum = Instructor.objects.get(id_instructor=idinstructor)

        nombre_portada = alum.imagen_portada


        if imagenportada :

            nombreimagen = secure_filename(imagenportada.name)
            #fs = FileSystemStorage(location='ProyectoKaizen/static/media/Imagenes/Instructores')
            fs = FileSystemStorage(location= os.path.join(settings.MEDIA_ROOT+'/Imagenes/Instructores'))
            filenam = fs.save(nombreimagen, imagenportada)

            if nombre_portada == "portada.jpg":

                pass

            else:

                try:
                    os.remove(os.path.join(settings.MEDIA_ROOT+'/Imagenes/Instructores/' + nombre_portada))
                except Exception as e:
                    pass



        opci = OpcionesInstructor.objects.get(id_instructorR=idinstructor)
        opci.color_barra = color
        #opci.widget_clima = clima
        opci.save()


        alu = Instructor.objects.get(id_instructor=idinstructor)

        if nombreimagen == "":

            pass

        else:

            alu.imagen_portada = nombreimagen

        alu.save()


        valor = request.user.id_relacionado

        filtro = CursoInstructor.objects.filter(id_instructorR=valor).values('id_cursoR')

        curso = Curso.objects.filter(id_curso__in=filtro)

        opcion = OpcionesInstructor.objects.filter(id_instructorR=valor)

        usuario = Instructor.objects.filter(id_instructor=valor)

        todaynoti = date.today()

        finnoti = todaynoti + timedelta(days=3)

        notificacion = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0)

        numeronotificaciones = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()


        pagina = ElementosPagina.objects.filter(id_elementoPagina=1)

        contexto = {'paginas':pagina, 'cursos':curso, 'opciones':opcion, 'usuarios':usuario, 'notificaciones':notificacion,
        'numeronotificaciones':numeronotificaciones}

        #return render(request, 'Instructor/instructor_cursos.html', contexto)
        return redirect('/inicio_instructor/')



@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_instructor, login_url='/iniciar_sesion/')
def mostrar_pagos_instructor(request):

    request.session.set_expiry(request.session.get_expiry_age())

    idinstructor = request.user.id_relacionado

    fecha = date.today()

    anioo = fecha.year
    mes = fecha.month

    movimientos = MovimientosInstructor.objects.filter(id_instructorR=idinstructor, fecha_movimiento__year=anioo, fecha_movimiento__month=mes)

    total = 0
    descuento = 0
    devolucion = 0
    ganancias = 0
    contaPagado = 0
    contanoPagado = 0
    estado = ""

    for movimiento in movimientos:

        total = total + movimiento.cantidad_total
        descuento = descuento + movimiento.descuento_aplicado
        devuel = movimiento.devuelto
        esta = movimiento.estado

        if devuel == 0:

            ganancias = ganancias + movimiento.total_ganado

        else:

            devolucion = devolucion + movimiento.total_ganado

        if esta == 0:

            contanoPagado = contanoPagado + 1

        else:

            contaPagado = contaPagado + 1


    if contanoPagado != 0:

        estado = "NoPagado"

    elif contaPagado != 0:

        estado = "Pagado"

    anios = []

    instruc = Instructor.objects.get(id_instructor=idinstructor)
    fecharegistro = instruc.fecha_registro

    ano = fecharegistro.year

    totalanio = int(anioo) - int(ano)

    val = int(ano)
    anios.append(val)

    for i in range(totalanio):

        val = val + 1
        anios.append(val)


    opcion = OpcionesInstructor.objects.filter(id_instructorR=idinstructor)

    usuario = Instructor.objects.filter(id_instructor=idinstructor)

    todaynoti = date.today()

    finnoti = todaynoti + timedelta(days=3)

    notificacion = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0)

    numeronotificaciones = NotificacionesInstructores.objects.filter(id_instructorR=idinstructor, fecha_fin__range=[todaynoti, finnoti], statusN=0).count()


    pagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    contexto = {'paginas':pagina, 'totalmes':total, 'descuentosmes':descuento, 'devolucionesmes':devolucion,
    'ganaciasmes':ganancias, 'estado':estado, 'aniobusqueda':anioo, 'mesbusqueda':mes,
    'idinstructor':idinstructor, 'anios':anios, 'opciones':opcion, 'usuarios':usuario,
    'notificaciones':notificacion, 'numeronotificaciones':numeronotificaciones}


    return render(request, 'Instructor/Extras/Pagos/pagos_instructor.html', contexto)


@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_instructor, login_url='/iniciar_sesion/')
def mostrar_pagos_instructor_ajax(request, id, id2):

    request.session.set_expiry(request.session.get_expiry_age())

    idinstructor = request.user.id_relacionado
    anioo = id
    mes = id2

    movimientos = MovimientosInstructor.objects.filter(id_instructorR=idinstructor, fecha_movimiento__year=anioo, fecha_movimiento__month=mes)

    total = 0
    descuento = 0
    devolucion = 0
    ganancias = 0
    contaPagado = 0
    contanoPagado = 0
    estado = ""

    for movimiento in movimientos:

        total = total + movimiento.cantidad_total
        descuento = descuento + movimiento.descuento_aplicado
        devuel = movimiento.devuelto
        esta = movimiento.estado

        if devuel == 0:

            ganancias = ganancias + movimiento.total_ganado

        else:

            devolucion = devolucion + movimiento.total_ganado

        if esta == 0:

            contanoPagado = contanoPagado + 1

        else:

            contaPagado = contaPagado + 1


    if contanoPagado != 0:

        estado = "NoPagado"

    elif contaPagado != 0:

        estado = "Pagado"

    anios = []

    instruc = Instructor.objects.get(id_instructor=idinstructor)
    fecharegistro = instruc.fecha_registro

    ano = fecharegistro.year

    fecha = date.today()

    anis = fecha.year

    totalanio = int(anis) - int(ano)

    val = int(ano)
    anios.append(val)

    for i in range(totalanio):

        val = val + 1
        anios.append(val)


    contexto = {'totalmes':total, 'descuentosmes':descuento, 'devolucionesmes':devolucion,
    'ganaciasmes':ganancias, 'estado':estado, 'aniobusqueda':anioo, 'mesbusqueda':mes,
    'idinstructor':idinstructor, 'anios':anios}


    return render(request, 'Instructor/Extras/Pagos/pagos_instructor_ajax.html', contexto)





# inicio vista Principal

def mostrar_inicio_sesion(request):

    return render(request, "Principal/iniciar_sesion.html")


def mostrar_registro_usuario(request):

    return render(request, 'Principal/registrarse.html')



def mostrar_inicio_sesion_registro(request):

    mensaje = "Verificacion de codigo correcto, inicia sesión."
    contexto = {'mensaje':mensaje}

    return render(request, 'Principal/iniciar_sesion_registro.html', contexto)


def mostrar_ingresar_codigo(request):

    mensaje = "Ingresa el código de 10 dígitos que se envió al correo que ingresaste al registrarte."
    contexto = {'mensaje':mensaje}

    return render(request, 'Principal/solicitud_codigo.html', contexto)


def mostrar_recuperar_contra(request):

    return render(request, 'Principal/contra_olvidada.html')


@csrf_exempt
def procesar_registro(request):

    if request.method == "POST":

        correo = request.POST["email"]
        contrasena = request.POST["password"]
        contrasena2 = request.POST["password2"]

        mensaje = ""

        if contrasena == contrasena2:

            filtro1 = Alumno.objects.filter(correoAL=correo)

            if filtro1:

                mensaje = "El correo ya está registrado, trata de iniciar sesión."
                contexto = {'mensaje':mensaje}

                return render(request, 'Principal/registrarse_error.html', contexto)

            else:

                partir = correo.split('@')

                if partir[1] == "mailinator.com" or partir[1] == "yopmail.com" or partir[1] == "twzhhq.online" or partir[1] == "maildrop.cc":

                    mensaje = "El correo que ingresaste no es válido."

                    contexto = {'mensaje':mensaje}

                    return render(request, 'Principal/registrarse_error.html', contexto)

                else:

                    chars = string.ascii_uppercase + string.digits
                    size = 10

                    codigoleatorio = ''.join(random.choice(chars) for _ in range(size))

                    texto = 'Este es tu código de registro ' + str(codigoleatorio) + ', es válido por 30 días.'

                    #### Codigo MANDRILL #####
                    #MANDRILL_API_KEY = 'Ya4SqTK0tCvIEq1MSZ7NtQ'
                    #mandrill_client = mandrill.Mandrill(MANDRILL_API_KEY)
                    #message = { 'from_email': 'hola@kaizen.lat',
                      #'from_name': 'Kaizen Latinoamerica',
                      #'to': [{
                        #'email': correo,
                        #'name': 'Usuario',
                        #'type': 'to'
                       #}],
                      #'subject': "Codigo de Registro",
                     # 'text': texto
                    #}

                    #result = mandrill_client.messages.send(message = message)
                    # result is a dict with metadata about the sent message, including
                    # if it was successfully sent
                    #print(result)

                    ###### Termina codigo MANDRILL ######

                    ##### Script nuevo correos ######

                    #send_mail(
                    #    'Codigo de Registro',
                    #    texto,
                    #    'hola@kaizen.page',
                    #    [correo],
                    #    fail_silently=False,
                    #)

                    # import file with html content
                    html_version = 'Principal/email_registro.html'

                    html_message = render_to_string(html_version, { 'context': codigoleatorio, })

                    message = EmailMessage('Código de Registro', html_message, 'hola@seiko.dev', [correo])
                    message.content_subtype = 'html'
                    message.send()


                    al = Alumno(nombreA="", apellidosA="", direccionA="", codigopostalA="",
                    estadoA="", ciudadA="", paisA="", profesionA="", edadA=18, celularA="", tiposangreA="",
                    alergiasA="", nombreT="", apellidosT="", direccionT="", codigopostalT="", estadoT="",
                    ciudadT="", paisT="", profesionT="", edadT=0, celularT=0, statusAL=1, correoAL=correo,
                    ruta_avatar="avatar.png", sexo_alumno="Otro", imagen_portada="portada.jpg", imagen_qr="Ninguna")
                    al.save()

                    alal = Alumno.objects.get(correoAL=correo)
                    idalumno = alal.id_alumno

                    opcio = OpcionesAlumno(id_alumnoR=idalumno, color_barra="#01A1DD", tipo_plantilla="_barra",
                    widget_clima=1, widget_juego_cartas=0, widget_juego_tetris=0)
                    opcio.save()

                    contra = make_password(contrasena2)

                    usus = Usuarios(email=correo, password=contra, tipo_usuario=3,
                    id_relacionado=idalumno, is_active=1)
                    usus.save()

                    hoy = date.today()

                    caduca = hoy + timedelta(days=30)

                    vc = VerificarCuenta(correo_vinculado=correo, fecha_creacion=hoy,
                    fecha_limite=caduca, codigo=codigoleatorio, verificado=0, perfil_editado=0)
                    vc.save()

                    #mensaje = "Registro completo, inicia sesion."
                    #contexto = {'mensaje':mensaje}
                    #return render(request, 'Principal/iniciar_sesion_registro.html', contexto)
                    return redirect('/solicitar_codigo/')

        else:

            mensaje = "Las contraseñas no coinciden."

            contexto = {'mensaje':mensaje}

            return render(request, 'Principal/registrarse_error.html', contexto)



@csrf_exempt
def procesar_codigo(request):

    if request.method == "POST":

        correo = request.POST["email"]
        codigoG = request.POST["codigo"]

        mensaje = ""

        verificacion = VerificarCuenta.objects.get(correo_vinculado=correo, codigo=codigoG)

        if verificacion:

            verificacion.verificado = 1
            verificacion.save()

            mansaje = "Verificacion de codigo correcto. Inicia sesión."
            contexto = {'mensaje':mensaje}

            return redirect('/registro_exitoso/')

        else:

            mensaje = "El correo o código no son correctos, o el registro previo caduco."
            contexto = {'mensaje':mensaje}

            return render(request, 'Principal/solicitud_codigo_error.html', contexto)



def mostrar_error_contra_olvidada(request):

    mensaje = "No tenemos registrado el correo que ingresaste."

    contexto = {'mensaje':mensaje}

    return render(request, 'Principal/contra_olvidada_error.html', contexto)


@csrf_exempt
def procesar_olvido_contra(request):

    if request.method == "POST":

        correo = request.POST["email"]

        mensaje = ""

        verificar = Alumno.objects.get(correoAL=correo)

        if verificar:

            chars = string.ascii_uppercase + string.digits
            size = 10

            codigoleatorio = ''.join(random.choice(chars) for _ in range(size))

            texto = 'Este es tu código para restablecer tu contraseña: ' + str(codigoleatorio) + ', es valido por 24 horas.'

            ###### Codigo MANDRILL
            #MANDRILL_API_KEY = 'Ya4SqTK0tCvIEq1MSZ7NtQ'
            #mandrill_client = mandrill.Mandrill(MANDRILL_API_KEY)
            #message = { 'from_email': 'hola@kaizen.lat',
              #'from_name': 'Kaizen Latinoamerica',
              #'to': [{
                #'email': correo,
                #'name': 'Usuario',
                #'type': 'to'
               #}],
              #'subject': "Codigo de Recuperacion de Contraseña",
              #'text': texto
            #}

            #result = mandrill_client.messages.send(message = message)
            # result is a dict with metadata about the sent message, including
            # if it was successfully sent
            #print(result)

            ##### Termina Codigo MANDRILL #####

            #send_mail(
            #    'Codigo para Cambio de Contraseña',
            #    texto,
            #    'hola@kaizen.page',
            #    [correo],
            #    fail_silently=False,
            #)

            # import file with html content
            html_version = 'Principal/email_contra.html'

            html_message = render_to_string(html_version, { 'context': codigoleatorio, })

            message = EmailMessage('Restablecer Contraseña', html_message, 'hola@seiko.dev', [correo])
            message.content_subtype = 'html'
            message.send()


            hoy = date.today()

            caduca = hoy + timedelta(days=1)

            cc = CambiarContra(correo_vinculado=correo, fecha_creacion=hoy,
            fecha_limite=caduca, codigo=codigoleatorio, usado=0)
            cc.save()

            return redirect('/solicitar_codigo_contra/')


        else:

            return redirect('/error_contra_olvidada/')


def mostrar_ingresar_codigo_contra(request):

    mensaje = "Ingresa el código de 10 dígitos que se envió al correo que ingresaste."
    contexto = {'mensaje':mensaje}

    return render(request, 'Principal/solicitud_codigo_contra.html', contexto)


@csrf_exempt
def procesar_codigo_contra(request):

    if request.method == "POST":

        correo = request.POST["email"]
        codigoG = request.POST["codigo"]

        mensaje = ""

        verificacion = CambiarContra.objects.get(correo_vinculado=correo, codigo=codigoG, usado=0)

        if verificacion:

            verificacion.usado = 1
            verificacion.save()

            mansaje = "Verificacion de codigo correcto. Ingresa una nueva contraseña, por seguridad ingresa nuevamente tu correo."
            contexto = {'mensaje':mensaje}

            return render(request, 'Principal/cambiar_contra.html', contexto)

        else:

            mensaje = "El correo o código no son correctos, el código ya caduco o ya intentaste restablecer tu contraseña y hubo un error."
            contexto = {'mensaje':mensaje}

            return render(request, 'Principal/solicitud_codigo_contra_error.html', contexto)



@csrf_exempt
def cambiar_contra(request):

    if request.method == "POST":

        correo = request.POST["email"]
        contrasena = request.POST["password"]

        mensaje = ""

        verificar = Usuarios.objects.get(email=correo)

        if verificar:

            nuevacontra = make_password(contrasena)

            usu = Usuarios.objects.get(email=correo, tipo_usuario=3)

            usu.password = nuevacontra

            usu.save()

            return redirect('/contra_cambiada/')

        else:

            return redirect('/error_cambio_contra/')


def error_cambio_contra(request):

    mensaje = "El correo que ingresaste no es correcto, solicita otro cambio de contraseña."

    contexto = {'mensaje':mensaje}

    return render(request, 'Principal/error_cambio_contra.html', contexto)


def contra_cambiada(request):

    mensaje = "Contraseña cambiada con éxito, inicia sesión con tu nueva contraseña."

    contexto = {'mensaje':mensaje}

    return render(request, 'Principal/iniciar_sesion_cambio.html', contexto)


@csrf_exempt
def procesar_sesion(request):

    if request.method == "POST":

        usuario = request.POST["email"]
        contra = request.POST["password"]

        mensaje = ""

        user = authenticate(username=usuario, password=contra)

        if user is not None:

            valor = "False"
            my_old_sessions = Session.objects.all()
            #cur_session_key = user.get_profile().session_key
            for row in my_old_sessions:
                if row.get_decoded().get('_auth_user_id', None) == str(user.id_usuario):

                    fecha = datetime.now()
                    fechahoy = datetime.now() + timedelta(hours=5)

                    print(str(fechahoy))
                    print(str(row.expire_date))
                    print(str(user.ultima_actualizacion))

                    if str(row.expire_date) > str(fechahoy):

                        if str(user.ultima_actualizacion) > str(fechahoy):
                            valor = "True"
                            break
                        else:
                            valor = "False"
                            row.delete()
                            break

                    elif str(row.expire_date) < str(fechahoy):

                        valor = "False"
                        row.delete()
                        break


            if user.is_active == 1:

                if user.tipo_usuario == 1:

                    if valor == "False":

                        login(request, user)

                        correo = user.email
                        fecha_actual = datetime.now()
                        actu = fecha_actual + timedelta(seconds=90)

                        ses = Usuarios.objects.get(email=correo)
                        ses.ultima_actualizacion = actu
                        ses.save()

                        request.session.set_expiry(1200)
                        return redirect('/inicio_admin/')
                        #return render(request, 'Admin/inicio_sesion.html')

                    else:

                        mensaje = "Este usuario ya tiene una sesión iniciada."

                        contexto = {'mensaje':mensaje}

                        return render(request, 'Principal/iniciar_sesion_error.html', contexto)

                elif user.tipo_usuario == 2:

                    if valor == "False":

                        login(request, user)

                        correo = user.email
                        fecha_actual = datetime.now()
                        actu = fecha_actual + timedelta(seconds=90)

                        ses = Usuarios.objects.get(email=correo)
                        ses.ultima_actualizacion = actu
                        ses.save()

                        request.session.set_expiry(1200)
                        return redirect('/inicio_instructor/')
                        #return render(request, 'Instructor/instructor_index.html', contexto)

                    else:

                        mensaje = "Este usuario ya tiene una sesión iniciada."

                        contexto = {'mensaje':mensaje}

                        return render(request, 'Principal/iniciar_sesion_error.html', contexto)


                elif user.tipo_usuario == 3:

                    if valor == "False":

                        verificacion = VerificarCuenta.objects.get(correo_vinculado=usuario)
                        vefica = verificacion.verificado
                        perfil = verificacion.perfil_editado

                        if vefica == 0:

                            return redirect('/solicitar_codigo/')

                        else:

                            if perfil == 0:

                                login(request, user)

                                correo = user.email
                                fecha_actual = datetime.now()
                                actu = fecha_actual + timedelta(seconds=90)

                                ses = Usuarios.objects.get(email=correo)
                                ses.ultima_actualizacion = actu
                                ses.save()

                                request.session.set_expiry(1200)
                                return redirect('/editar_perfil_inicial/')

                            else:

                                login(request, user)

                                correo = user.email
                                fecha_actual = datetime.now()
                                actu = fecha_actual + timedelta(seconds=90)

                                ses = Usuarios.objects.get(email=correo)
                                ses.ultima_actualizacion = actu
                                ses.save()

                                request.session.set_expiry(1200)
                                return redirect('/inicio_alumno/')

                    else:

                        mensaje = "Este usuario ya tiene una sesión iniciada."

                        contexto = {'mensaje':mensaje}

                        return render(request, 'Principal/iniciar_sesion_error.html', contexto)

            else:

                mensaje = "Tu cuenta no esta activa."

                contexto = {'mensaje':mensaje}

                return render(request, 'Principal/iniciar_sesion_error.html', contexto)

        else:

            mensaje = "Usuario o contraseña incorrectos."

            contexto = {'mensaje':mensaje}

            return render(request, 'Principal/iniciar_sesion_error.html', contexto)


def mostrar_emisiones(request):

    id_usuario =  ""
    tipo_usuario = ""
    autenticado = ""
    cursos_lista_deseos = 0
    if request.user.is_authenticated:
        autenticado = "authenticated"
        if request.user.tipo_usuario == 3:
            id_usuario =  str(request.user.id_relacionado)
            tipo_usuario = str(request.user.tipo_usuario)
            lista_deseos_consulta = Lista_Deseos.objects.filter(id_alumno=id_usuario, statusLD=1)
            cursos_lista_deseos = lista_deseos_consulta.count()
        else:
            id_usuario =  ""
            tipo_usuario = ""

    moneda(request)
    verificar_moneda(request)

    valor_moneda = request.session['moneda']

    moneda_valor = Moneda.objects.filter(nombre_moneda=valor_moneda)
    valor = moneda_valor[0].equivalente_peso_mx
    nomenclatura = moneda_valor[0].nomencaltura

    cursos_recientes_slider = Curso.objects.order_by('-fecha_registro').filter(statusC=1)[:10]

    categorias_cursos = CursoCategoria.objects.all()
    monedas = Moneda.objects.filter(statusM=1)

    entradas_blog_footer = EntradasBlog.objects.order_by('-fecha_posteo')[:3]


    #Empieza consulta de transmision
    horas = datetime.now()

    horamas = horas + timedelta(hours=1)

    horamass = horamas.time()

    horamenos = horas + timedelta(hours=-1)

    horamenoss = horamenos.time()

    cadena1 = str(horamenoss)
    cadena2 = str(horamass)

    fechahoy = date.today()

    begin = datetime.strptime(cadena1, '%H:%M:%S.%f').time()
    end = datetime.strptime(cadena2, '%H:%M:%S.%f').time()

    Ctransmision = TransmisionesVivo.objects.filter(fecha_transmision=fechahoy, hora_transmision__range=[begin, end]).order_by('hora_transmision')[:1]

    Evivo = ""

    if Ctransmision:
        Evivo = "True"
    else:
        Evivo = "False"
    #Termina Consulta Transmision



    if request.user.is_authenticated:
        autenticado = "True"

    else:
        autenticado = "False"

    op = OpcionesTransmisiones.objects.get(id_opcionTransmision=1)
    opcion = op.dominio

    todaynoti = date.today()

    horas = datetime.now()

    horamas = horas + timedelta(hours=5)

    horamass = horamas.time()

    horamenos = horas

    horamenoss = horamenos.time()

    cadena1 = str(horamenoss)
    cadena2 = str(horamass)

    fechados = todaynoti + timedelta(days=2)

    begin = datetime.strptime(cadena1, '%H:%M:%S.%f').time()
    end = datetime.strptime(cadena2, '%H:%M:%S.%f').time()

    try:
        transmision = TransmisionesVivo.objects.filter(fecha_transmision=todaynoti, hora_transmision__range=[begin, end]).order_by('hora_transmision')[:1]

    except Exception as e:
        transmision = ""

    conferencia = TransmisionesVivo.objects.filter(fecha_transmision=todaynoti, hora_transmision__range=[begin, end]).order_by('hora_transmision')
    recurso = TransmisionesVivo.objects.filter(fecha_transmision=todaynoti, hora_transmision__range=[begin, end]).order_by('hora_transmision')[:1]

    if conferencia:
        pass

    else:
        conferencia = TransmisionesVivo.objects.filter(fecha_transmision__range=[todaynoti, fechados]).order_by('fecha_transmision')
        recurso = TransmisionesVivo.objects.filter(fecha_transmision__range=[todaynoti, fechados]).order_by('fecha_transmision')[:1]



    contexto = {'transmisiones':transmision, 'conferencias':conferencia,
        'recursos':recurso, 'autenticado':autenticado, 'opcion':opcion,
        'categorias': categorias_cursos,'authenticate': autenticado,
        'user': id_usuario, 'type_user': tipo_usuario, 'num_cursos_lista' : cursos_lista_deseos,
        'nomenclatura': nomenclatura, 'Monedas': monedas, 'MonedaSeleccionada':valor_moneda,
        'cursos_recientes_slider': cursos_recientes_slider, 'valor': valor,'entradas_blog_footer': entradas_blog_footer,
        'Evivo': Evivo}

    return render(request, 'Principal/emisiones_principal.html', contexto)


def emisiones_anteriores_principal(request):

    id_usuario =  ""
    tipo_usuario = ""
    autenticado = ""
    cursos_lista_deseos = 0
    if request.user.is_authenticated:
        autenticado = "authenticated"
        if request.user.tipo_usuario == 3:
            id_usuario =  str(request.user.id_relacionado)
            tipo_usuario = str(request.user.tipo_usuario)
            lista_deseos_consulta = Lista_Deseos.objects.filter(id_alumno=id_usuario, statusLD=1)
            cursos_lista_deseos = lista_deseos_consulta.count()
        else:
            id_usuario =  ""
            tipo_usuario = ""

    moneda(request)
    verificar_moneda(request)

    valor_moneda = request.session['moneda']

    moneda_valor = Moneda.objects.filter(nombre_moneda=valor_moneda)
    valor = moneda_valor[0].equivalente_peso_mx
    nomenclatura = moneda_valor[0].nomencaltura

    cursos_recientes_slider = Curso.objects.order_by('-fecha_registro').filter(statusC=1)[:10]

    categorias_cursos = CursoCategoria.objects.all()
    monedas = Moneda.objects.filter(statusM=1)

    entradas_blog_footer = EntradasBlog.objects.order_by('-fecha_posteo')[:3]

    #Empieza consulta de transmision
    horas = datetime.now()

    horamas = horas + timedelta(hours=1)

    horamass = horamas.time()

    horamenos = horas + timedelta(hours=-1)

    horamenoss = horamenos.time()

    cadena1 = str(horamenoss)
    cadena2 = str(horamass)

    fechahoy = date.today()

    begin = datetime.strptime(cadena1, '%H:%M:%S.%f').time()
    end = datetime.strptime(cadena2, '%H:%M:%S.%f').time()

    Ctransmision = TransmisionesVivo.objects.filter(fecha_transmision=fechahoy, hora_transmision__range=[begin, end]).order_by('hora_transmision')[:1]

    Evivo = ""

    if Ctransmision:
        Evivo = "True"
    else:
        Evivo = "False"
    #Termina Consulta Transmision



    todaynoti = date.today()

    fechauno = todaynoti + timedelta(days=-1825)
    fechados = todaynoti + timedelta(days=-1)

    conferenciad = TransmisionesVivo.objects.filter(fecha_transmision__range=[fechauno, fechados]).order_by('-fecha_completa')
    paginator = Paginator(conferenciad, 6)

    page_number = request.GET.get('page')
    conferencia = paginator.get_page(page_number)


    contexto = {'conferencias':conferencia,'categorias': categorias_cursos,'authenticate': autenticado,
        'user': id_usuario, 'type_user': tipo_usuario, 'num_cursos_lista' : cursos_lista_deseos,
        'nomenclatura': nomenclatura, 'Monedas': monedas, 'MonedaSeleccionada':valor_moneda,
        'cursos_recientes_slider': cursos_recientes_slider, 'valor': valor,'entradas_blog_footer': entradas_blog_footer,
        'Evivo': Evivo}

    return render(request, 'Principal/emisiones_anteriores_principal.html', contexto)


def mostrar_video_principal(request, id):

    id_usuario =  ""
    tipo_usuario = ""
    autenticado = ""
    cursos_lista_deseos = 0
    if request.user.is_authenticated:
        autenticado = "authenticated"
        if request.user.tipo_usuario == 3:
            id_usuario =  str(request.user.id_relacionado)
            tipo_usuario = str(request.user.tipo_usuario)
            lista_deseos_consulta = Lista_Deseos.objects.filter(id_alumno=id_usuario, statusLD=1)
            cursos_lista_deseos = lista_deseos_consulta.count()
        else:
            id_usuario =  ""
            tipo_usuario = ""

    moneda(request)
    verificar_moneda(request)

    valor_moneda = request.session['moneda']

    moneda_valor = Moneda.objects.filter(nombre_moneda=valor_moneda)
    valor = moneda_valor[0].equivalente_peso_mx
    nomenclatura = moneda_valor[0].nomencaltura

    cursos_recientes_slider = Curso.objects.order_by('-fecha_registro').filter(statusC=1)[:10]

    categorias_cursos = CursoCategoria.objects.all()
    monedas = Moneda.objects.filter(statusM=1)

    entradas_blog_footer = EntradasBlog.objects.order_by('-fecha_posteo')[:3]




    idtransmision = id

    transmision = TransmisionesVivo.objects.filter(id_transmision=idtransmision)

    if request.user.is_authenticated:
        autenticado = "True"

    else:
        autenticado = "False"


    #Empieza consulta de transmision
    horas = datetime.now()

    horamas = horas + timedelta(hours=1)

    horamass = horamas.time()

    horamenos = horas + timedelta(hours=-1)

    horamenoss = horamenos.time()

    cadena1 = str(horamenoss)
    cadena2 = str(horamass)

    fechahoy = date.today()

    begin = datetime.strptime(cadena1, '%H:%M:%S.%f').time()
    end = datetime.strptime(cadena2, '%H:%M:%S.%f').time()

    Ctransmision = TransmisionesVivo.objects.filter(fecha_transmision=fechahoy, hora_transmision__range=[begin, end]).order_by('hora_transmision')[:1]

    Evivo = ""

    if Ctransmision:
        Evivo = "True"
    else:
        Evivo = "False"
    #Termina Consulta Transmision


    contexto = {'transmisiones':transmision, 'autenticado':autenticado,
        'categorias': categorias_cursos,'authenticate': autenticado,
        'user': id_usuario, 'type_user': tipo_usuario, 'num_cursos_lista' : cursos_lista_deseos,
        'nomenclatura': nomenclatura, 'Monedas': monedas, 'MonedaSeleccionada':valor_moneda,
        'cursos_recientes_slider': cursos_recientes_slider, 'valor': valor,'entradas_blog_footer': entradas_blog_footer,
        'Evivo':Evivo}

    return render(request, 'Principal/mostrar_video_principal.html', contexto)






def moneda(request):
    if request.session.has_key('moneda'):
        pass
    else:
        request.session['moneda'] = "Dólar estadounidense"




def formato_moneda(curso_precio, valor, nomenclatura):
    precio_curso_convertir = float(curso_precio)  * float(valor)
    redondear = round(precio_curso_convertir)
    precio_comas = ""
    if nomenclatura in 'EUR':
        precio_comas_coma = '{:,}'.format(redondear)
        precio_comas = precio_comas_coma.replace(',','.')


    else:
        precio_comas = '{:,}'.format(redondear)

    return precio_comas



def verificar_moneda(request):
    valor_moneda_verificar = request.session['moneda']

    moneda_verificar_buscar = Moneda.objects.filter(nombre_moneda=valor_moneda_verificar)

    if moneda_verificar_buscar:
        hora = moneda_verificar_buscar[0].hora_actualizar
        fecha = moneda_verificar_buscar[0].fecha_actualizar
        date_time_str = str(fecha)+' '+str(hora.hour)+':'+str(hora.minute)+':'+str(hora.second)
        date_time_obj = dt.datetime.strptime(date_time_str, '%Y-%m-%d %H:%M:%S')

        mas_4h = date_time_obj + timedelta(hours=4)

        date = dt.datetime.now()

        if fecha == date.date():

            if date >= mas_4h:
                api_key = 'GF3SFCZCOCGIHSGA'

                base_url = 'https://www.alphavantage.co/query?function=CURRENCY_EXCHANGE_RATE'
                from_c = 'MXN'
                to_c = moneda_verificar_buscar[0].nomencaltura
                main_url = base_url + '&from_currency=' + from_c + '&to_currency='+ to_c + '&apikey=' + api_key
                response = requests.get(main_url)
                result = response.json()
                key = result['Realtime Currency Exchange Rate']
                rate = key['5. Exchange Rate']
                Moneda.objects.filter(id_moneda=moneda_verificar_buscar[0].id_moneda).update(equivalente_peso_mx=rate, fecha_actualizar=date, hora_actualizar=date)
                request.session['moneda'] = moneda_verificar_buscar[0].nombre_moneda
        else:
            api_key = 'GF3SFCZCOCGIHSGA'

            base_url = 'https://www.alphavantage.co/query?function=CURRENCY_EXCHANGE_RATE'
            from_c = 'MXN'
            to_c = moneda_verificar_buscar[0].nomencaltura
            main_url = base_url + '&from_currency=' + from_c + '&to_currency='+ to_c + '&apikey=' + api_key
            response = requests.get(main_url)
            result = response.json()
            key = result['Realtime Currency Exchange Rate']
            rate = key['5. Exchange Rate']
            Moneda.objects.filter(id_moneda=moneda_verificar_buscar[0].id_moneda).update(equivalente_peso_mx=rate, fecha_actualizar=date, hora_actualizar=date)
            request.session['moneda'] = moneda_verificar_buscar[0].nombre_moneda




def mostrar_pagina_principal(request):

    id_usuario =  ""
    tipo_usuario = ""
    autenticado = ""
    cursos_lista_deseos = 0
    if request.user.is_authenticated:
        autenticado = "authenticated"
        if request.user.tipo_usuario == 3:
            id_usuario =  str(request.user.id_relacionado)
            tipo_usuario = str(request.user.tipo_usuario)
            lista_deseos_consulta = Lista_Deseos.objects.filter(id_alumno=id_usuario, statusLD=1)
            cursos_lista_deseos = lista_deseos_consulta.count()
        else:
            id_usuario =  ""
            tipo_usuario = ""

    moneda(request)
    verificar_moneda(request)

    valor_moneda = request.session['moneda']

    moneda_valor = Moneda.objects.filter(nombre_moneda=valor_moneda)
    valor = moneda_valor[0].equivalente_peso_mx
    nomenclatura = moneda_valor[0].nomencaltura

    opcion = ElementosPagina.objects.get(id_elementoPagina=1)
    apro = opcion.aprobacion_cursos

    if apro == 1:
        cursos_recientes_slider = Curso.objects.order_by('-fecha_registro').filter(statusC=1, aprobado=1)[:10]
    else:
        cursos_recientes_slider = Curso.objects.order_by('-fecha_registro').filter(statusC=1)[:10]


    entradas_blog = EntradasBlog.objects.order_by('-fecha_posteo')[:10]

    entradas_blog_footer = EntradasBlog.objects.order_by('-fecha_posteo')[:3]

    #Empieza consulta de transmision
    horas = datetime.now()

    horamas = horas + timedelta(hours=1)

    horamass = horamas.time()

    horamenos = horas + timedelta(hours=-1)

    horamenoss = horamenos.time()

    cadena1 = str(horamenoss)
    cadena2 = str(horamass)

    fechahoy = date.today()

    begin = datetime.strptime(cadena1, '%H:%M:%S.%f').time()
    end = datetime.strptime(cadena2, '%H:%M:%S.%f').time()

    Ctransmision = TransmisionesVivo.objects.filter(fecha_transmision=fechahoy, hora_transmision__range=[begin, end]).order_by('hora_transmision')[:1]

    Evivo = ""

    if Ctransmision:
        Evivo = "True"
    else:
        Evivo = "False"
    #Termina Consulta Transmision


    if apro == 1:
        lanzamientos_consulta = Curso.objects.order_by('-fecha_registro').filter(statusC=1, aprobado=1)[:30]
    else:
        lanzamientos_consulta = Curso.objects.order_by('-fecha_registro').filter(statusC=1)[:30]
    lanzamientos = []
    if lanzamientos_consulta:
        for lanzamiento_consulta in lanzamientos_consulta:
            consulta_instructor_curso = CursoInstructor.objects.filter(id_cursoR = lanzamiento_consulta.id_curso)

            if consulta_instructor_curso:

                id_instructor = consulta_instructor_curso[0].id_instructorR
                datos_instructor = Instructor.objects.get(id_instructor=id_instructor)
                nombre_instructor_curso = datos_instructor.nombreI + " " + datos_instructor.apellidosI
                valor_conventir =  formato_moneda(lanzamiento_consulta.precio, valor, nomenclatura)

                lanzamientos.append((lanzamiento_consulta.id_curso, lanzamiento_consulta.nombreC, valor_conventir,lanzamiento_consulta.tipo_Curso, lanzamiento_consulta.ruta_imagen,
                    lanzamiento_consulta.descripcion_curso, nomenclatura, nombre_instructor_curso))
                #id_curso,nombreC,fecha_inicio,fecha_cierre,no_minimo_alumnos,no_maximo_alumnos,precio,tipo_Curso,statusC,ruta_imagen,descripcion_curso,video_muestra,fecha_registro,hora_registro,duracion_curso_numero,duracion_curso_tipo,valoracion,veces_vendido
        #lanzamientos = Curso.objects.order_by('-fecha_registro').filter(statusC=1)[:30]

    categorias_cursos = CursoCategoria.objects.all()

    categoriasm = CursoCategoria.objects.order_by('-fecha_completa').filter(statusC=1)[:8]

    cantidad_categorias = categorias_cursos.count()
    categorias_cursos_muestra = ""

    if cantidad_categorias == 4:
        categorias_cursos_muestra = CursoCategoria.objects.all()
    elif cantidad_categorias > 8:
        # Curso.objects.order_by('fecha_registro').filter(statusC=1)[:8]
        categorias_cursos_muestra = CursoCategoria.objects.order_by('-fecha_completa').filter(statusC=1)[:8]

    if apro == 1:
        cursos_recientes_consulta = Curso.objects.order_by('-fecha_registro').filter(statusC=1, aprobado=1)[:20]
    else:
        cursos_recientes_consulta = Curso.objects.order_by('-fecha_registro').filter(statusC=1)[:20]

    cursos_recientes = []

    if cursos_recientes_consulta:
        for curso_reciente_consulta in cursos_recientes_consulta:
            consulta_instructor_curso = CursoInstructor.objects.filter(id_cursoR = curso_reciente_consulta.id_curso)

            if consulta_instructor_curso:

                id_instructor = consulta_instructor_curso[0].id_instructorR
                datos_instructor = Instructor.objects.get(id_instructor=id_instructor)
                nombre_instructor_curso = datos_instructor.nombreI + " " + datos_instructor.apellidosI

                valor_conventir_reciente =  formato_moneda(curso_reciente_consulta.precio, valor, nomenclatura)

                cursos_recientes.append((curso_reciente_consulta.id_curso, curso_reciente_consulta.nombreC, valor_conventir_reciente,curso_reciente_consulta.tipo_Curso, curso_reciente_consulta.ruta_imagen,
                    curso_reciente_consulta.descripcion_curso, nomenclatura, nombre_instructor_curso))


    cursos_mejor_valorados_consulta = Curso.objects.filter(valoracion=5, statusC=1, aprobado=1)
    cursos_mejor_valorados = []

    if cursos_mejor_valorados_consulta:
        for cursos_mejor_valorado_consulta in cursos_mejor_valorados_consulta:

            consulta_instructor_curso = CursoInstructor.objects.filter(id_cursoR = curso_reciente_consulta.id_curso)

            if consulta_instructor_curso:

                id_instructor = consulta_instructor_curso[0].id_instructorR
                datos_instructor = Instructor.objects.get(id_instructor=id_instructor)
                nombre_instructor_curso = datos_instructor.nombreI + " " + datos_instructor.apellidosI

                valor_conventir_valorado =  formato_moneda(cursos_mejor_valorado_consulta.precio, valor, nomenclatura)

                cursos_mejor_valorados.append((cursos_mejor_valorado_consulta.id_curso, cursos_mejor_valorado_consulta.nombreC, valor_conventir_valorado, cursos_mejor_valorado_consulta.tipo_Curso, cursos_mejor_valorado_consulta.ruta_imagen,
                    cursos_mejor_valorado_consulta.descripcion_curso, nomenclatura, cursos_mejor_valorado_consulta.valoracion, nombre_instructor_curso))

    if apro == 1:
        cursos_mas_adquiridos_consulta = Curso.objects.order_by('-veces_vendido').filter(statusC=1, aprobado=1)[:20]
    else:
        cursos_mas_adquiridos_consulta = Curso.objects.order_by('-veces_vendido').filter(statusC=1)[:20]
    cursos_mas_adquiridos = []
    if cursos_mas_adquiridos_consulta:
        for cursos_mas_adquirido_consulta in cursos_mas_adquiridos_consulta:
            consulta_instructor_curso = CursoInstructor.objects.filter(id_cursoR = curso_reciente_consulta.id_curso)

            if consulta_instructor_curso:

                id_instructor = consulta_instructor_curso[0].id_instructorR
                datos_instructor = Instructor.objects.get(id_instructor=id_instructor)
                nombre_instructor_curso = datos_instructor.nombreI + " " + datos_instructor.apellidosI

                valor_conventir_mas_adquirido =  formato_moneda(cursos_mas_adquirido_consulta.precio, valor, nomenclatura)

                cursos_mas_adquiridos.append((cursos_mas_adquirido_consulta.id_curso, cursos_mas_adquirido_consulta.nombreC, valor_conventir_mas_adquirido, cursos_mas_adquirido_consulta.tipo_Curso, cursos_mas_adquirido_consulta.ruta_imagen,
                    cursos_mas_adquirido_consulta.descripcion_curso, nomenclatura, cursos_mas_adquirido_consulta.veces_vendido, nombre_instructor_curso))



    monedas = Moneda.objects.filter(statusM=1)

    contexto = {'categorias': categorias_cursos, 'categoriasm':categoriasm,'cursos_recientes': cursos_recientes,
    'mejor_valorados': cursos_mejor_valorados, 'mas_adquiridos':cursos_mas_adquiridos, 'lanzamientos': lanzamientos,
    'categorias_muestra': categorias_cursos_muestra, 'authenticate': autenticado,
    'user': id_usuario, 'type_user': tipo_usuario, 'num_cursos_lista' : cursos_lista_deseos,
    'nomenclatura': nomenclatura,'Monedas': monedas, 'MonedaSeleccionada':valor_moneda,
    'cursos_recientes_slider':cursos_recientes_slider, 'valor': valor,'entradas_blog_footer': entradas_blog_footer, 'entradas_blog': entradas_blog,
    'Evivo': Evivo}

    return render(request, 'Principal/index.html', contexto)

def buscar_cursos(request):
    if request.method == "GET":
        curso_nom = request.GET['search']

        id_usuario =  ""
        tipo_usuario = ""
        autenticado = ""
        cursos_lista_deseos = 0
        if request.user.is_authenticated:
            autenticado = "authenticated"
            if request.user.tipo_usuario == 3:
                id_usuario =  str(request.user.id_relacionado)
                tipo_usuario = str(request.user.tipo_usuario)
                lista_deseos_consulta = Lista_Deseos.objects.filter(id_alumno=id_usuario, statusLD=1)
                cursos_lista_deseos = lista_deseos_consulta.count()
            else:
                id_usuario =  ""
                tipo_usuario = ""

        moneda(request)
        verificar_moneda(request)

        valor_moneda = request.session['moneda']

        moneda_valor = Moneda.objects.filter(nombre_moneda=valor_moneda)
        valor = moneda_valor[0].equivalente_peso_mx
        nomenclatura = moneda_valor[0].nomencaltura

        opcion = ElementosPagina.objects.get(id_elementoPagina=1)
        apro = opcion.aprobacion_cursos

        if apro == 1:
            cursos_recientes_slider = Curso.objects.order_by('-fecha_registro').filter(statusC=1, aprobado=1)[:10]
        else:
            cursos_recientes_slider = Curso.objects.order_by('-fecha_registro').filter(statusC=1)[:10]

        categorias_cursos = CursoCategoria.objects.all()
        monedas = Moneda.objects.filter(statusM=1)


        entradas_blog_footer = EntradasBlog.objects.order_by('-fecha_posteo')[:3]

        #Empieza consulta de transmision
        horas = datetime.now()

        horamas = horas + timedelta(hours=1)

        horamass = horamas.time()

        horamenos = horas + timedelta(hours=-1)

        horamenoss = horamenos.time()

        cadena1 = str(horamenoss)
        cadena2 = str(horamass)

        fechahoy = date.today()

        begin = datetime.strptime(cadena1, '%H:%M:%S.%f').time()
        end = datetime.strptime(cadena2, '%H:%M:%S.%f').time()

        Ctransmision = TransmisionesVivo.objects.filter(fecha_transmision=fechahoy, hora_transmision__range=[begin, end]).order_by('hora_transmision')[:1]

        Evivo = ""

        if Ctransmision:
            Evivo = "True"
        else:
            Evivo = "False"
        #Termina Consulta Transmision




        if 'category_id' in request.GET:
            id_categoria = request.GET['category_id']
        else:
            id_categoria = 0

        if 'descripcion' in request.GET:
            descripcion = request.GET['descripcion']
        else:
            descripcion = 0

        if int(id_categoria) == 0:

            if int(descripcion) == 0:
                if apro == 1:
                    buscar_todos_cursos = Curso.objects.filter(nombreC__icontains=curso_nom, statusC=1, aprobado=1)
                else:
                    buscar_todos_cursos = Curso.objects.filter(nombreC__icontains=curso_nom, statusC=1)
            else:
                if apro == 1:
                    buscar_todos_cursos = Curso.objects.filter(descripcion_curso__icontains=curso_nom, statusC=1, aprobado=1)
                else:
                    buscar_todos_cursos = Curso.objects.filter(descripcion_curso__icontains=curso_nom, statusC=1)

            info_curso = []
            if buscar_todos_cursos:
                for curso in buscar_todos_cursos:
                    consulta_instructor_curso = CursoInstructor.objects.filter(id_cursoR = curso.id_curso)

                    if consulta_instructor_curso:

                        id_instructor = consulta_instructor_curso[0].id_instructorR
                        datos_instructor = Instructor.objects.get(id_instructor=id_instructor)
                        nombre_instructor_curso = datos_instructor.nombreI + " " + datos_instructor.apellidosI

                        valor_cambio_cursos = formato_moneda(curso.precio, valor, nomenclatura)
                        info_curso.append((curso.id_curso, curso.nombreC, valor_cambio_cursos, curso.ruta_imagen, curso.descripcion_curso, curso.tipo_Curso, nomenclatura,
                            nombre_instructor_curso))

            paginacion_todos_cursos = Paginator(info_curso, 3)

            pagina_num = request.GET.get('page')

            page = paginacion_todos_cursos.get_page(pagina_num)

            contexto = {'cursos_relacionados': page, 'buscado': curso_nom, 'categoria': id_categoria,'cursos_count': paginacion_todos_cursos.count, 'paginas': paginacion_todos_cursos.num_pages,
            'categorias': categorias_cursos,'authenticate': autenticado,
            'user': id_usuario, 'type_user': tipo_usuario, 'num_cursos_lista' : cursos_lista_deseos,
            'Monedas': monedas, 'MonedaSeleccionada':valor_moneda, 'nomenclatura': nomenclatura,
            'cursos_recientes_slider': cursos_recientes_slider, 'valor': valor,'entradas_blog_footer': entradas_blog_footer,
            'Evivo': Evivo}
        else:

            buscar_todos_cursos = Cursos_Categorias.objects.filter(id_categoria=id_categoria)


            info_curso = []
            for curso in buscar_todos_cursos:

                if int(descripcion) == 0:
                    if apro == 1:
                        curso_enc = Curso.objects.filter(id_curso=curso.id_curso, nombreC__icontains=curso_nom,statusC=1, aprobado=1)
                    else:
                        curso_enc = Curso.objects.filter(id_curso=curso.id_curso, nombreC__icontains=curso_nom,statusC=1)
                else:
                    if apro == 1:
                        curso_enc = Curso.objects.filter(id_curso=curso.id_curso, descripcion_curso__icontains=curso_nom,statusC=1, aprobado=1)
                    else:
                        curso_enc = Curso.objects.filter(id_curso=curso.id_curso, descripcion_curso__icontains=curso_nom,statusC=1)



                if curso_enc:

                    consulta_instructor_curso = CursoInstructor.objects.filter(id_cursoR = curso_enc[0].id_curso)

                    if consulta_instructor_curso:

                        id_instructor = consulta_instructor_curso[0].id_instructorR
                        datos_instructor = Instructor.objects.get(id_instructor=id_instructor)
                        nombre_instructor_curso = datos_instructor.nombreI + " " + datos_instructor.apellidosI

                        valor_cambio_cursos = formato_moneda(curso_enc[0].precio, valor, nomenclatura)
                        info_curso.append((curso_enc[0].id_curso, curso_enc[0].nombreC, valor_cambio_cursos, curso_enc[0].ruta_imagen, curso_enc[0].descripcion_curso, curso_enc[0].tipo_Curso, nomenclatura, nombre_instructor_curso))




            paginacion_todos_cursos = Paginator(info_curso, 3)

            pagina_num = request.GET.get('page')

            page = paginacion_todos_cursos.get_page(pagina_num)

            contexto = {'cursos_relacionados': page, 'buscado': curso_nom, 'categoria': id_categoria,'cursos_count': paginacion_todos_cursos.count, 'paginas': paginacion_todos_cursos.num_pages,
            'categorias': categorias_cursos,'authenticate': autenticado,
            'user': id_usuario, 'type_user': tipo_usuario, 'num_cursos_lista' : cursos_lista_deseos,
            'Monedas': monedas, 'MonedaSeleccionada':valor_moneda, 'nomenclatura': nomenclatura,
            'cursos_recientes_slider': cursos_recientes_slider, 'valor': valor,'entradas_blog_footer': entradas_blog_footer,
            'Evivo': Evivo}

    return render(request, 'Principal/search-courses.html', contexto)





def info_curso(request):

    if request.method == "GET":
        id_curso = request.GET['curso']


        id_usuario =  ""
        tipo_usuario = ""
        autenticado = ""
        cursos_lista_deseos = 0
        if request.user.is_authenticated:
            autenticado = "authenticated"
            if request.user.tipo_usuario == 3:
                id_usuario =  str(request.user.id_relacionado)
                tipo_usuario = str(request.user.tipo_usuario)
                lista_deseos_consulta = Lista_Deseos.objects.filter(id_alumno=id_usuario, statusLD=1)
                cursos_lista_deseos = lista_deseos_consulta.count()
            else:
                id_usuario =  ""
                tipo_usuario = ""

        moneda(request)
        verificar_moneda(request)

        valor_moneda = request.session['moneda']

        moneda_valor = Moneda.objects.filter(nombre_moneda=valor_moneda)
        valor = moneda_valor[0].equivalente_peso_mx
        nomenclatura = moneda_valor[0].nomencaltura

        categorias_cursos = CursoCategoria.objects.all()

        opcion = ElementosPagina.objects.get(id_elementoPagina=1)
        apro = opcion.aprobacion_cursos

        if apro == 1:
            info_curso_con = Curso.objects.filter(id_curso=id_curso,statusC=1, aprobado=1)
        else:
            info_curso_con = Curso.objects.filter(id_curso=id_curso,statusC=1)
        id_curso_result = info_curso_con[0].id_curso

        monedas = Moneda.objects.filter(statusM=1)

        valor_conventir_curso = formato_moneda(info_curso_con[0].precio, valor, nomenclatura)

        consulta_instructor_curso = CursoInstructor.objects.filter(id_cursoR = info_curso_con[0].id_curso)
        nombre_instructor_curso_info = ""
        estudios_instructor = ""
        experiencia_instructor = ""

        if consulta_instructor_curso:
            id_instructor = consulta_instructor_curso[0].id_instructorR
            datos_instructor = Instructor.objects.get(id_instructor=id_instructor)
            nombre_instructor_curso_info = datos_instructor.nombreI + " " + datos_instructor.apellidosI
            estudios_instructor = datos_instructor.estudiosI
            experiencia_instructor = datos_instructor.experienciaI

        if apro == 1:
            cursos_recientes_slider = Curso.objects.order_by('-fecha_registro').filter(statusC=1, aprobado=1)[:10]
        else:
            cursos_recientes_slider = Curso.objects.order_by('-fecha_registro').filter(statusC=1)[:10]

        entradas_blog_footer = EntradasBlog.objects.order_by('-fecha_posteo')[:3]

        #Empieza consulta de transmision
        horas = datetime.now()

        horamas = horas + timedelta(hours=1)

        horamass = horamas.time()

        horamenos = horas + timedelta(hours=-1)

        horamenoss = horamenos.time()

        cadena1 = str(horamenoss)
        cadena2 = str(horamass)

        fechahoy = date.today()

        begin = datetime.strptime(cadena1, '%H:%M:%S.%f').time()
        end = datetime.strptime(cadena2, '%H:%M:%S.%f').time()

        Ctransmision = TransmisionesVivo.objects.filter(fecha_transmision=fechahoy, hora_transmision__range=[begin, end]).order_by('hora_transmision')[:1]

        Evivo = ""

        if Ctransmision:
            Evivo = "True"
        else:
            Evivo = "False"
        #Termina Consulta Transmision

        if apro == 1:
            recomendacion_mas_valorados_consulta = Curso.objects.filter(valoracion=5, statusC=1, aprobado=1)[:5]
        else:
            recomendacion_mas_valorados_consulta = Curso.objects.filter(valoracion=5, statusC=1)[:5]
        recomendacion_mas_valorados = []

        if recomendacion_mas_valorados_consulta:
            for recomendacion_mas_valorado_consulta in recomendacion_mas_valorados_consulta:

                consulta_instructor_curso = CursoInstructor.objects.filter(id_cursoR = recomendacion_mas_valorado_consulta.id_curso)

                if consulta_instructor_curso:

                    id_instructor = consulta_instructor_curso[0].id_instructorR
                    datos_instructor = Instructor.objects.get(id_instructor=id_instructor)
                    nombre_instructor_curso = datos_instructor.nombreI + " " + datos_instructor.apellidosI

                    valor_conventir_recomendado_valorado =  formato_moneda(recomendacion_mas_valorado_consulta.precio, valor, nomenclatura)

                    recomendacion_mas_valorados.append((recomendacion_mas_valorado_consulta.id_curso, recomendacion_mas_valorado_consulta.nombreC,
                        valor_conventir_recomendado_valorado, recomendacion_mas_valorado_consulta.tipo_Curso, recomendacion_mas_valorado_consulta.ruta_imagen,
                        recomendacion_mas_valorado_consulta.descripcion_curso, nomenclatura, nombre_instructor_curso))



        categorias_curso = Cursos_Categorias.objects.filter(id_curso=id_curso_result)
        if categorias_curso:
            if categorias_curso.count() == 1:
                cursos = Cursos_Categorias.objects.filter(id_categoria=categorias_curso[0].id_categoria)
                recomendacion_categoria = []
                resultados_curso = []

                for curso in  cursos:
                    if apro == 1:
                        activo_curso = Curso.objects.get(id_curso=curso.id_curso, statusC=1, aprobado=1)
                    else:
                        activo_curso = Curso.objects.get(id_curso=curso.id_curso, statusC=1)
                    if activo_curso:
                        if int(activo_curso.id_curso) == int(id_curso):
                            pass
                        else:
                            consulta_instructor_curso = CursoInstructor.objects.filter(id_cursoR = activo_curso.id_curso)

                            if consulta_instructor_curso:

                                id_instructor = consulta_instructor_curso[0].id_instructorR
                                datos_instructor = Instructor.objects.get(id_instructor=id_instructor)
                                nombre_instructor_curso = datos_instructor.nombreI + " " + datos_instructor.apellidosI

                                precio_moneda = formato_moneda(activo_curso.precio, valor, nomenclatura)
                                resultados_curso.append((activo_curso.id_curso, activo_curso.nombreC, precio_moneda, activo_curso.ruta_imagen, activo_curso.descripcion_curso,
                                    nomenclatura, activo_curso.tipo_Curso, nombre_instructor_curso))

                numero_resultado = len(resultados_curso)

                if apro == 1:
                    recomendacion_fecha_nuevos_consulta = Curso.objects.order_by('-fecha_registro').filter(statusC=1, aprobado=1)[:5]
                else:
                    recomendacion_fecha_nuevos_consulta = Curso.objects.order_by('-fecha_registro').filter(statusC=1)[:5]
                recomendacion_fecha_nuevos = []

                if recomendacion_fecha_nuevos_consulta:
                    for recomendacion_fecha_nuevo_consulta in recomendacion_fecha_nuevos_consulta:
                        consulta_instructor_curso = CursoInstructor.objects.filter(id_cursoR = recomendacion_fecha_nuevo_consulta.id_curso)

                        if consulta_instructor_curso:

                            id_instructor = consulta_instructor_curso[0].id_instructorR
                            datos_instructor = Instructor.objects.get(id_instructor=id_instructor)
                            nombre_instructor_curso = datos_instructor.nombreI + " " + datos_instructor.apellidosI

                            valor_conventir_recomendado_fecha =  formato_moneda(recomendacion_fecha_nuevo_consulta.precio, valor, nomenclatura)

                            recomendacion_fecha_nuevos.append((recomendacion_fecha_nuevo_consulta.id_curso, recomendacion_fecha_nuevo_consulta.nombreC,
                                valor_conventir_recomendado_fecha, recomendacion_fecha_nuevo_consulta.tipo_Curso, recomendacion_fecha_nuevo_consulta.ruta_imagen,
                                recomendacion_fecha_nuevo_consulta.descripcion_curso, nomenclatura,  nombre_instructor_curso))

                if numero_resultado > 5:
                    cursos_escoger = []
                    escoger_lleno = 0

                    while escoger_lleno == 0:
                        numero = random.randint(0, numero_resultado - 1)
                        if len(cursos_escoger) < 6:
                            if numero in cursos_escoger:
                                pass
                            else:
                                cursos_escoger.append(numero)
                        else:

                            for i in cursos_escoger:
                                recomendacion_categoria.append((resultados_curso[i][0], resultados_curso[i][1], resultados_curso[i][2], resultados_curso[i][3], resultados_curso[i][4], resultados_curso[i][5], resultados_curso[i][6]))

                            escoger_lleno = 1

                    contexto = {'curso_result': info_curso_con[0], "recomendado_fecha": recomendacion_fecha_nuevos, "recomendado_categoria": recomendacion_categoria,
                    'precio_curso': valor_conventir_curso, 'nomenclatura': nomenclatura, 'mas_valorados': recomendacion_mas_valorados, 'categorias': categorias_cursos,'authenticate': autenticado,
                    'user': id_usuario, 'type_user': tipo_usuario, 'num_cursos_lista' : cursos_lista_deseos, 'nombre_instructor_curso_info':nombre_instructor_curso_info,
                    'estudios_instructor':estudios_instructor, 'experiencia_instructor':experiencia_instructor, 'Monedas': monedas, 'MonedaSeleccionada':valor_moneda, 'cursos_recientes_slider': cursos_recientes_slider, 'valor': valor,
                    'entradas_blog_footer': entradas_blog_footer, 'Evivo': Evivo}


                else:
                    contexto = {'curso_result': info_curso_con[0], "recomendado_fecha": recomendacion_fecha_nuevos, "recomendado_categoria": resultados_curso,
                    'precio_curso': valor_conventir_curso, 'nomenclatura': nomenclatura, 'mas_valorados': recomendacion_mas_valorados, 'categorias': categorias_cursos,'authenticate': autenticado,
                    'user': id_usuario, 'type_user': tipo_usuario, 'num_cursos_lista' : cursos_lista_deseos, 'nombre_instructor_curso_info':nombre_instructor_curso_info,
                    'estudios_instructor':estudios_instructor, 'experiencia_instructor':experiencia_instructor, 'Monedas': monedas, 'MonedaSeleccionada':valor_moneda, 'cursos_recientes_slider': cursos_recientes_slider, 'valor': valor,
                    'entradas_blog_footer': entradas_blog_footer, 'Evivo': Evivo}

            elif categorias_curso.count() > 1:
                numero_resultados = categorias_curso.count() - 1

                categoria = random.randint(0, numero_resultados)

                cursos = Cursos_Categorias.objects.filter(id_categoria=categorias_curso[categoria].id_categoria)
                recomendacion_categoria = []
                resultados_curso = []

                for curso in  cursos:
                    if apro == 1:
                        activo_curso = Curso.objects.get(id_curso=curso.id_curso, statusC=1, aprobado=1)
                    else:
                        activo_curso = Curso.objects.get(id_curso=curso.id_curso, statusC=1)
                    if activo_curso:
                        if int(activo_curso.id_curso) == int(id_curso):
                            pass
                        else:
                            consulta_instructor_curso = CursoInstructor.objects.filter(id_cursoR = activo_curso.id_curso)

                            if consulta_instructor_curso:

                                id_instructor = consulta_instructor_curso[0].id_instructorR
                                datos_instructor = Instructor.objects.get(id_instructor=id_instructor)
                                nombre_instructor_curso = datos_instructor.nombreI + " " + datos_instructor.apellidosI

                                precio_moneda = formato_moneda(activo_curso.precio, valor, nomenclatura)

                                resultados_curso.append((activo_curso.id_curso, activo_curso.nombreC, precio_moneda, activo_curso.ruta_imagen, activo_curso.descripcion_curso,
                                    nomenclatura, activo_curso.tipo_Curso, nombre_instructor_curso))

                numero_resultado = len(resultados_curso)

                if apro == 1:
                    recomendacion_fecha_nuevos_consulta = Curso.objects.order_by('-fecha_registro').filter(statusC=1, aprobado=1)[:5]
                else:
                    recomendacion_fecha_nuevos_consulta = Curso.objects.order_by('-fecha_registro').filter(statusC=1)[:5]
                recomendacion_fecha_nuevos = []

                if recomendacion_fecha_nuevos_consulta:
                    for recomendacion_fecha_nuevo_consulta in recomendacion_fecha_nuevos_consulta:
                        consulta_instructor_curso = CursoInstructor.objects.filter(id_cursoR = recomendacion_fecha_nuevo_consulta.id_curso)

                        if consulta_instructor_curso:

                            id_instructor = consulta_instructor_curso[0].id_instructorR
                            datos_instructor = Instructor.objects.get(id_instructor=id_instructor)
                            nombre_instructor_curso = datos_instructor.nombreI + " " + datos_instructor.apellidosI

                            valor_conventir_recomendado_fecha =  formato_moneda(recomendacion_fecha_nuevo_consulta.precio, valor, nomenclatura)

                            recomendacion_fecha_nuevos.append((recomendacion_fecha_nuevo_consulta.id_curso, recomendacion_fecha_nuevo_consulta.nombreC,
                                valor_conventir_recomendado_fecha, recomendacion_fecha_nuevo_consulta.tipo_Curso, recomendacion_fecha_nuevo_consulta.ruta_imagen,
                                recomendacion_fecha_nuevo_consulta.descripcion_curso, nomenclatura, nombre_instructor_curso))

                if numero_resultado > 5:
                    cursos_escoger = []
                    escoger_lleno = 0

                    while escoger_lleno == 0:
                        numero = random.randint(0, numero_resultado - 1)
                        if len(cursos_escoger) < 6:
                            if numero in cursos_escoger:
                                pass
                            else:
                                cursos_escoger.append(numero)
                        else:

                            for i in cursos_escoger:

                                recomendacion_categoria.append((resultados_curso[i][0], resultados_curso[i][1], resultados_curso[i][2], resultados_curso[i][3], resultados_curso[i][4], resultados_curso[i][5], resultados_curso[i][5]))

                            escoger_lleno = 1

                    contexto = {'curso_result': info_curso_con[0], "recomendado_fecha": recomendacion_fecha_nuevos, "recomendado_categoria": recomendacion_categoria,
                    'precio_curso': valor_conventir_curso, 'nomenclatura': nomenclatura, 'mas_valorados': recomendacion_mas_valorados, 'categorias': categorias_cursos,'authenticate': autenticado,
                    'user': id_usuario, 'type_user': tipo_usuario, 'num_cursos_lista' : cursos_lista_deseos, 'nombre_instructor_curso_info':nombre_instructor_curso_info,
                    'estudios_instructor':estudios_instructor, 'experiencia_instructor':experiencia_instructor, 'Monedas': monedas, 'MonedaSeleccionada':valor_moneda, 'cursos_recientes_slider': cursos_recientes_slider, 'valor': valor,
                    'entradas_blog_footer': entradas_blog_footer, 'Evivo': Evivo}


                else:
                    contexto = {'curso_result': info_curso_con[0], "recomendado_fecha": recomendacion_fecha_nuevos, "recomendado_categoria": resultados_curso,
                    'precio_curso': valor_conventir_curso, 'nomenclatura': nomenclatura, 'mas_valorados': recomendacion_mas_valorados, 'categorias': categorias_cursos,'authenticate': autenticado,
                    'user': id_usuario, 'type_user': tipo_usuario, 'num_cursos_lista' : cursos_lista_deseos, 'nombre_instructor_curso_info':nombre_instructor_curso_info,
                    'estudios_instructor':estudios_instructor, 'experiencia_instructor':experiencia_instructor, 'Monedas': monedas, 'MonedaSeleccionada':valor_moneda, 'cursos_recientes_slider': cursos_recientes_slider, 'valor': valor,
                    'entradas_blog_footer': entradas_blog_footer, 'Evivo': Evivo}
        else:

            if apro == 1:
                recomendacion_fecha_nuevos_consulta = Curso.objects.order_by('-fecha_registro').filter(statusC=1, aprobado=1)[:5]
            else:
                recomendacion_fecha_nuevos_consulta = Curso.objects.order_by('-fecha_registro').filter(statusC=1)[:5]
            recomendacion_fecha_nuevos = []

            if recomendacion_fecha_nuevos_consulta:
                for recomendacion_fecha_nuevo_consulta in recomendacion_fecha_nuevos_consulta:
                    consulta_instructor_curso = CursoInstructor.objects.filter(id_cursoR = recomendacion_fecha_nuevo_consulta.id_curso)

                    if consulta_instructor_curso:

                        id_instructor = consulta_instructor_curso[0].id_instructorR
                        datos_instructor = Instructor.objects.get(id_instructor=id_instructor)
                        nombre_instructor_curso = datos_instructor.nombreI + " " + datos_instructor.apellidosI

                        valor_conventir_recomendado_fecha =  formato_moneda(recomendacion_fecha_nuevo_consulta.precio, valor, nomenclatura)

                        recomendacion_fecha_nuevos.append((recomendacion_fecha_nuevo_consulta.id_curso, recomendacion_fecha_nuevo_consulta.nombreC,
                            valor_conventir_recomendado_fecha, recomendacion_fecha_nuevo_consulta.tipo_Curso, recomendacion_fecha_nuevo_consulta.ruta_imagen,
                            recomendacion_fecha_nuevo_consulta.descripcion_curso, nomenclatura, nombre_instructor_curso))

            recomendacion_categoria = ""

            contexto = {'curso_result': info_curso_con[0], "recomendado_fecha": recomendacion_fecha_nuevos, "recomendado_categoria": recomendacion_categoria,
            'precio_curso': valor_conventir_curso, 'nomenclatura': nomenclatura, 'mas_valorados': recomendacion_mas_valorados, 'categorias': categorias_cursos,'authenticate': autenticado,
            'user': id_usuario, 'type_user': tipo_usuario, 'num_cursos_lista' : cursos_lista_deseos, 'nombre_instructor_curso_info':nombre_instructor_curso_info,
            'estudios_instructor':estudios_instructor, 'experiencia_instructor':experiencia_instructor, 'Monedas': monedas, 'MonedaSeleccionada':valor_moneda, 'cursos_recientes_slider': cursos_recientes_slider, 'valor': valor,
            'entradas_blog_footer': entradas_blog_footer, 'Evivo': Evivo}


    return render(request, 'Principal/curso-info.html', contexto)



def curso_inorganico(request):

    if request.method == "GET":
        id_curso = request.GET['curso']
        nombre_curso = request.GET['curson']

        id_usuario =  ""
        tipo_usuario = ""
        autenticado = ""
        cursos_lista_deseos = 0
        if request.user.is_authenticated:
            autenticado = "authenticated"
            if request.user.tipo_usuario == 3:
                id_usuario =  str(request.user.id_relacionado)
                tipo_usuario = str(request.user.tipo_usuario)
                lista_deseos_consulta = Lista_Deseos.objects.filter(id_alumno=id_usuario, statusLD=1)
                cursos_lista_deseos = lista_deseos_consulta.count()
            else:
                id_usuario =  ""
                tipo_usuario = ""

        moneda(request)
        verificar_moneda(request)

        valor_moneda = request.session['moneda']

        moneda_valor = Moneda.objects.filter(nombre_moneda=valor_moneda)
        valor = moneda_valor[0].equivalente_peso_mx
        nomenclatura = moneda_valor[0].nomencaltura

        categorias_cursos = CursoCategoria.objects.all()

        opcion = ElementosPagina.objects.get(id_elementoPagina=1)
        apro = opcion.aprobacion_cursos

        if apro == 1:
            info_curso_con = Curso.objects.filter(id_curso=id_curso,statusC=1, aprobado=1)
        else:
            info_curso_con = Curso.objects.filter(id_curso=id_curso,statusC=1)
        id_curso_result = info_curso_con[0].id_curso

        monedas = Moneda.objects.filter(statusM=1)

        valor_conventir_curso = formato_moneda(info_curso_con[0].precio, valor, nomenclatura)

        consulta_instructor_curso = CursoInstructor.objects.filter(id_cursoR = info_curso_con[0].id_curso)
        nombre_instructor_curso_info = ""
        estudios_instructor = ""
        experiencia_instructor = ""

        if consulta_instructor_curso:
            id_instructor = consulta_instructor_curso[0].id_instructorR
            datos_instructor = Instructor.objects.get(id_instructor=id_instructor)
            nombre_instructor_curso_info = datos_instructor.nombreI + " " + datos_instructor.apellidosI
            estudios_instructor = datos_instructor.estudiosI
            experiencia_instructor = datos_instructor.experienciaI

        if apro == 1:
            cursos_recientes_slider = Curso.objects.order_by('-fecha_registro').filter(statusC=1, aprobado=1)[:10]
        else:
            cursos_recientes_slider = Curso.objects.order_by('-fecha_registro').filter(statusC=1)[:10]

        entradas_blog_footer = EntradasBlog.objects.order_by('-fecha_posteo')[:3]


        #Empieza consulta de transmision
        horas = datetime.now()

        horamas = horas + timedelta(hours=1)

        horamass = horamas.time()

        horamenos = horas + timedelta(hours=-1)

        horamenoss = horamenos.time()

        cadena1 = str(horamenoss)
        cadena2 = str(horamass)

        fechahoy = date.today()

        begin = datetime.strptime(cadena1, '%H:%M:%S.%f').time()
        end = datetime.strptime(cadena2, '%H:%M:%S.%f').time()

        Ctransmision = TransmisionesVivo.objects.filter(fecha_transmision=fechahoy, hora_transmision__range=[begin, end]).order_by('hora_transmision')[:1]

        Evivo = ""

        if Ctransmision:
            Evivo = "True"
        else:
            Evivo = "False"
        #Termina Consulta Transmision

        if apro == 1:
            recomendacion_mas_valorados_consulta = Curso.objects.filter(valoracion=5, statusC=1, aprobado=1)[:5]
        else:
            recomendacion_mas_valorados_consulta = Curso.objects.filter(valoracion=5, statusC=1)[:5]
        recomendacion_mas_valorados = []

        if recomendacion_mas_valorados_consulta:
            for recomendacion_mas_valorado_consulta in recomendacion_mas_valorados_consulta:

                consulta_instructor_curso = CursoInstructor.objects.filter(id_cursoR = recomendacion_mas_valorado_consulta.id_curso)

                if consulta_instructor_curso:
                    id_instructor = consulta_instructor_curso[0].id_instructorR
                    datos_instructor = Instructor.objects.get(id_instructor=id_instructor)
                    nombre_instructor_curso = datos_instructor.nombreI + " " + datos_instructor.apellidosI

                    valor_conventir_recomendado_valorado =  formato_moneda(recomendacion_mas_valorado_consulta.precio, valor, nomenclatura)

                    recomendacion_mas_valorados.append((recomendacion_mas_valorado_consulta.id_curso, recomendacion_mas_valorado_consulta.nombreC,
                        valor_conventir_recomendado_valorado, recomendacion_mas_valorado_consulta.tipo_Curso, recomendacion_mas_valorado_consulta.ruta_imagen,
                        recomendacion_mas_valorado_consulta.descripcion_curso, nomenclatura, nombre_instructor_curso))



        categorias_curso = Cursos_Categorias.objects.filter(id_curso=id_curso_result)
        if categorias_curso:
            if categorias_curso.count() == 1:
                cursos = Cursos_Categorias.objects.filter(id_categoria=categorias_curso[0].id_categoria)
                recomendacion_categoria = []
                resultados_curso = []

                for curso in cursos:
                    if apro == 1:
                        activo_curso = Curso.objects.get(id_curso=curso.id_curso, statusC=1, aprobado=1)
                    else:
                        activo_curso = Curso.objects.get(id_curso=curso.id_curso, statusC=1)
                    if activo_curso:
                        if int(activo_curso.id_curso) == int(id_curso):
                            pass
                        else:
                            consulta_instructor_curso = CursoInstructor.objects.filter(id_cursoR = activo_curso.id_curso)

                            if consulta_instructor_curso:
                                id_instructor = consulta_instructor_curso[0].id_instructorR
                                datos_instructor = Instructor.objects.get(id_instructor=id_instructor)
                                nombre_instructor_curso = datos_instructor.nombreI + " " + datos_instructor.apellidosI

                                precio_moneda = formato_moneda(activo_curso.precio, valor, nomenclatura)
                                resultados_curso.append((activo_curso.id_curso, activo_curso.nombreC, precio_moneda, activo_curso.ruta_imagen, activo_curso.descripcion_curso,
                                    nomenclatura, nombre_instructor_curso))

                numero_resultado = len(resultados_curso)

                if apro == 1:
                    recomendacion_fecha_nuevos_consulta = Curso.objects.order_by('-fecha_registro').filter(statusC=1, aprobado=1)[:5]
                else:
                    recomendacion_fecha_nuevos_consulta = Curso.objects.order_by('-fecha_registro').filter(statusC=1)[:5]
                recomendacion_fecha_nuevos = []

                if recomendacion_fecha_nuevos_consulta:
                    for recomendacion_fecha_nuevo_consulta in recomendacion_fecha_nuevos_consulta:
                        consulta_instructor_curso = CursoInstructor.objects.filter(id_cursoR = recomendacion_fecha_nuevo_consulta.id_curso)

                        if consulta_instructor_curso:
                            id_instructor = consulta_instructor_curso[0].id_instructorR
                            datos_instructor = Instructor.objects.get(id_instructor=id_instructor)
                            nombre_instructor_curso = datos_instructor.nombreI + " " + datos_instructor.apellidosI

                            valor_conventir_recomendado_fecha =  formato_moneda(recomendacion_fecha_nuevo_consulta.precio, valor, nomenclatura)

                            recomendacion_fecha_nuevos.append((recomendacion_fecha_nuevo_consulta.id_curso, recomendacion_fecha_nuevo_consulta.nombreC,
                                valor_conventir_recomendado_fecha, recomendacion_fecha_nuevo_consulta.tipo_Curso, recomendacion_fecha_nuevo_consulta.ruta_imagen,
                                recomendacion_fecha_nuevo_consulta.descripcion_curso, nomenclatura, nombre_instructor_curso))

                if numero_resultado > 5:
                    cursos_escoger = []
                    escoger_lleno = 0

                    while escoger_lleno == 0:
                        numero = random.randint(0, numero_resultado - 1)
                        if len(cursos_escoger) < 6:
                            if numero in cursos_escoger:
                                pass
                            else:
                                cursos_escoger.append(numero)
                        else:

                            for i in cursos_escoger:
                                recomendacion_categoria.append((resultados_curso[i][0], resultados_curso[i][1], resultados_curso[i][2], resultados_curso[i][3], resultados_curso[i][4], resultados_curso[i][5], resultados_curso[i][6]))

                            escoger_lleno = 1

                    contexto = {'curso_result': info_curso_con[0], "recomendado_fecha": recomendacion_fecha_nuevos, "recomendado_categoria": recomendacion_categoria,
                    'precio_curso': valor_conventir_curso, 'nomenclatura': nomenclatura, 'mas_valorados': recomendacion_mas_valorados, 'categorias': categorias_cursos,'authenticate': autenticado,
                    'user': id_usuario, 'type_user': tipo_usuario, 'num_cursos_lista' : cursos_lista_deseos, 'nombre_instructor_curso_info': nombre_instructor_curso_info,
                    'estudios_instructor':estudios_instructor, 'experiencia_instructor':experiencia_instructor, 'Monedas': monedas, 'MonedaSeleccionada':valor_moneda, 'cursos_recientes_slider': cursos_recientes_slider, 'valor': valor,
                    'entradas_blog_footer': entradas_blog_footer, 'Evivo': Evivo}


                else:
                    contexto = {'curso_result': info_curso_con[0], "recomendado_fecha": recomendacion_fecha_nuevos, "recomendado_categoria": resultados_curso,
                    'precio_curso': valor_conventir_curso, 'nomenclatura': nomenclatura, 'mas_valorados': recomendacion_mas_valorados, 'categorias': categorias_cursos,'authenticate': autenticado,
                    'user': id_usuario, 'type_user': tipo_usuario, 'num_cursos_lista' : cursos_lista_deseos, 'nombre_instructor_curso_info': nombre_instructor_curso_info,
                    'estudios_instructor':estudios_instructor, 'experiencia_instructor':experiencia_instructor, 'Monedas': monedas, 'MonedaSeleccionada':valor_moneda, 'cursos_recientes_slider': cursos_recientes_slider, 'valor': valor,
                    'entradas_blog_footer': entradas_blog_footer, 'Evivo': Evivo}

            elif categorias_curso.count() > 1:
                numero_resultados = categorias_curso.count() - 1

                categoria = random.randint(0, numero_resultados)

                cursos = Cursos_Categorias.objects.filter(id_categoria=categorias_curso[categoria].id_categoria)
                recomendacion_categoria = []
                resultados_curso = []

                for curso in  cursos:
                    if apro == 1:
                        activo_curso = Curso.objects.get(id_curso=curso.id_curso, statusC=1, aprobado=1)
                    else:
                        activo_curso = Curso.objects.get(id_curso=curso.id_curso, statusC=1)
                    if activo_curso:
                        if int(activo_curso.id_curso) == int(id_curso):
                            pass
                        else:
                            consulta_instructor_curso = CursoInstructor.objects.filter(id_cursoR = activo_curso.id_curso)

                            if consulta_instructor_curso:
                                id_instructor = consulta_instructor_curso[0].id_instructorR
                                datos_instructor = Instructor.objects.get(id_instructor=id_instructor)
                                nombre_instructor_curso = datos_instructor.nombreI + " " + datos_instructor.apellidosI

                                precio_moneda = formato_moneda(activo_curso.precio, valor, nomenclatura)

                                resultados_curso.append((activo_curso.id_curso, activo_curso.nombreC, precio_moneda, activo_curso.ruta_imagen, activo_curso.descripcion_curso,
                                    nomenclatura, activo_curso.tipo_Curso, nombre_instructor_curso))

                numero_resultado = len(resultados_curso)

                if apro == 1:
                    recomendacion_fecha_nuevos_consulta = Curso.objects.order_by('-fecha_registro').filter(statusC=1, aprobado=1)[:5]
                else:
                    recomendacion_fecha_nuevos_consulta = Curso.objects.order_by('-fecha_registro').filter(statusC=1)[:5]
                recomendacion_fecha_nuevos = []

                if recomendacion_fecha_nuevos_consulta:
                    for recomendacion_fecha_nuevo_consulta in recomendacion_fecha_nuevos_consulta:

                        consulta_instructor_curso = CursoInstructor.objects.filter(id_cursoR = recomendacion_fecha_nuevo_consulta.id_curso)

                        if consulta_instructor_curso:
                            id_instructor = consulta_instructor_curso[0].id_instructorR
                            datos_instructor = Instructor.objects.get(id_instructor=id_instructor)
                            nombre_instructor_curso = datos_instructor.nombreI + " " + datos_instructor.apellidosI

                            valor_conventir_recomendado_fecha =  formato_moneda(recomendacion_fecha_nuevo_consulta.precio, valor, nomenclatura)

                            recomendacion_fecha_nuevos.append((recomendacion_fecha_nuevo_consulta.id_curso, recomendacion_fecha_nuevo_consulta.nombreC,
                                valor_conventir_recomendado_fecha, recomendacion_fecha_nuevo_consulta.tipo_Curso, recomendacion_fecha_nuevo_consulta.ruta_imagen,
                                recomendacion_fecha_nuevo_consulta.descripcion_curso, nomenclatura, nombre_instructor_curso))

                if numero_resultado > 5:
                    cursos_escoger = []
                    escoger_lleno = 0

                    while escoger_lleno == 0:
                        numero = random.randint(0, numero_resultado - 1)
                        if len(cursos_escoger) < 6:
                            if numero in cursos_escoger:
                                pass
                            else:
                                cursos_escoger.append(numero)
                        else:

                            for i in cursos_escoger:
                                recomendacion_categoria.append((resultados_curso[i][0], resultados_curso[i][1], resultados_curso[i][2], resultados_curso[i][3], resultados_curso[i][4], resultados_curso[i][5], resultados_curso[i][6]))

                            escoger_lleno = 1

                    contexto = {'curso_result': info_curso_con[0], "recomendado_fecha": recomendacion_fecha_nuevos, "recomendado_categoria": recomendacion_categoria,
                    'precio_curso': valor_conventir_curso, 'nomenclatura': nomenclatura, 'mas_valorados': recomendacion_mas_valorados, 'categorias': categorias_cursos,'authenticate': autenticado,
                    'user': id_usuario, 'type_user': tipo_usuario, 'num_cursos_lista' : cursos_lista_deseos, 'nombre_instructor_curso_info': nombre_instructor_curso_info,
                    'estudios_instructor':estudios_instructor, 'experiencia_instructor':experiencia_instructor, 'Monedas': monedas, 'MonedaSeleccionada':valor_moneda, 'cursos_recientes_slider': cursos_recientes_slider, 'valor': valor,
                    'entradas_blog_footer': entradas_blog_footer, 'Evivo': Evivo}


                else:
                    contexto = {'curso_result': info_curso_con[0], "recomendado_fecha": recomendacion_fecha_nuevos, "recomendado_categoria": resultados_curso,
                    'precio_curso': valor_conventir_curso, 'nomenclatura': nomenclatura, 'mas_valorados': recomendacion_mas_valorados, 'categorias': categorias_cursos,'authenticate': autenticado,
                    'user': id_usuario, 'type_user': tipo_usuario, 'num_cursos_lista' : cursos_lista_deseos, 'nombre_instructor_curso_info': nombre_instructor_curso_info,
                    'estudios_instructor':estudios_instructor, 'experiencia_instructor':experiencia_instructor, 'Monedas': monedas, 'MonedaSeleccionada':valor_moneda, 'cursos_recientes_slider': cursos_recientes_slider, 'valor': valor,
                    'entradas_blog_footer': entradas_blog_footer, 'Evivo': Evivo}
        else:
            if apro == 1:
                recomendacion_fecha_nuevos_consulta = Curso.objects.order_by('-fecha_registro').filter(statusC=1, aprobado=1)[:5]
            else:
                recomendacion_fecha_nuevos_consulta = Curso.objects.order_by('-fecha_registro').filter(statusC=1)[:5]
            recomendacion_fecha_nuevos = []

            if recomendacion_fecha_nuevos_consulta:
                for recomendacion_fecha_nuevo_consulta in recomendacion_fecha_nuevos_consulta:

                    consulta_instructor_curso = CursoInstructor.objects.filter(id_cursoR = recomendacion_fecha_nuevo_consulta.id_curso)

                    if consulta_instructor_curso:
                        id_instructor = consulta_instructor_curso[0].id_instructorR
                        datos_instructor = Instructor.objects.get(id_instructor=id_instructor)
                        nombre_instructor_curso = datos_instructor.nombreI + " " + datos_instructor.apellidosI

                        valor_conventir_recomendado_fecha =  formato_moneda(recomendacion_fecha_nuevo_consulta.precio, valor, nomenclatura)

                        recomendacion_fecha_nuevos.append((recomendacion_fecha_nuevo_consulta.id_curso, recomendacion_fecha_nuevo_consulta.nombreC,
                            valor_conventir_recomendado_fecha, recomendacion_fecha_nuevo_consulta.tipo_Curso, recomendacion_fecha_nuevo_consulta.ruta_imagen,
                            recomendacion_fecha_nuevo_consulta.descripcion_curso, nomenclatura, nombre_instructor_curso))

            recomendacion_categoria = ""

            contexto = {'curso_result': info_curso_con[0], "recomendado_fecha": recomendacion_fecha_nuevos, "recomendado_categoria": recomendacion_categoria,
            'precio_curso': valor_conventir_curso, 'nomenclatura': nomenclatura, 'mas_valorados': recomendacion_mas_valorados, 'categorias': categorias_cursos,'authenticate': autenticado,
            'user': id_usuario, 'type_user': tipo_usuario, 'num_cursos_lista' : cursos_lista_deseos, 'nombre_instructor_curso_info': nombre_instructor_curso_info,
            'estudios_instructor':estudios_instructor, 'experiencia_instructor':experiencia_instructor, 'Monedas': monedas, 'MonedaSeleccionada':valor_moneda, 'cursos_recientes_slider': cursos_recientes_slider, 'valor': valor,
            'entradas_blog_footer': entradas_blog_footer, 'Evivo': Evivo}


    return render(request, 'Principal/curso-inorganico.html', contexto)






def curso_sensei(request):

    if request.method == "GET":
        id_curso = request.GET['curso']
        nombre_curso = request.GET['curson']

        id_usuario =  ""
        tipo_usuario = ""
        autenticado = ""
        cursos_lista_deseos = 0
        if request.user.is_authenticated:
            autenticado = "authenticated"
            if request.user.tipo_usuario == 3:
                id_usuario =  str(request.user.id_relacionado)
                tipo_usuario = str(request.user.tipo_usuario)
                lista_deseos_consulta = Lista_Deseos.objects.filter(id_alumno=id_usuario, statusLD=1)
                cursos_lista_deseos = lista_deseos_consulta.count()
            else:
                id_usuario =  ""
                tipo_usuario = ""

        moneda(request)
        verificar_moneda(request)

        valor_moneda = request.session['moneda']

        moneda_valor = Moneda.objects.filter(nombre_moneda=valor_moneda)
        valor = moneda_valor[0].equivalente_peso_mx
        nomenclatura = moneda_valor[0].nomencaltura

        categorias_cursos = CursoCategoria.objects.all()

        opcion = ElementosPagina.objects.get(id_elementoPagina=1)
        apro = opcion.aprobacion_cursos

        if apro == 1:
            info_curso_con = Curso.objects.filter(id_curso=id_curso,statusC=1, aprobado=1)
        else:
            info_curso_con = Curso.objects.filter(id_curso=id_curso,statusC=1)

        id_curso_result = info_curso_con[0].id_curso

        monedas = Moneda.objects.filter(statusM=1)

        valor_conventir_curso = formato_moneda(info_curso_con[0].precio, valor, nomenclatura)

        consulta_instructor_curso = CursoInstructor.objects.filter(id_cursoR = info_curso_con[0].id_curso)
        nombre_instructor_curso_info = ""
        estudios_instructor = ""
        experiencia_instructor = ""

        if consulta_instructor_curso:
            id_instructor = consulta_instructor_curso[0].id_instructorR
            datos_instructor = Instructor.objects.get(id_instructor=id_instructor)
            nombre_instructor_curso_info = datos_instructor.nombreI + " " + datos_instructor.apellidosI
            estudios_instructor = datos_instructor.estudiosI
            experiencia_instructor = datos_instructor.experienciaI

        if apro == 1:
            cursos_recientes_slider = Curso.objects.order_by('-fecha_registro').filter(statusC=1, aprobado=1)[:10]
        else:
            cursos_recientes_slider = Curso.objects.order_by('-fecha_registro').filter(statusC=1)[:10]

        entradas_blog_footer = EntradasBlog.objects.order_by('-fecha_posteo')[:3]


        #Empieza consulta de transmision
        horas = datetime.now()

        horamas = horas + timedelta(hours=1)

        horamass = horamas.time()

        horamenos = horas + timedelta(hours=-1)

        horamenoss = horamenos.time()

        cadena1 = str(horamenoss)
        cadena2 = str(horamass)

        fechahoy = date.today()

        begin = datetime.strptime(cadena1, '%H:%M:%S.%f').time()
        end = datetime.strptime(cadena2, '%H:%M:%S.%f').time()

        Ctransmision = TransmisionesVivo.objects.filter(fecha_transmision=fechahoy, hora_transmision__range=[begin, end]).order_by('hora_transmision')[:1]

        Evivo = ""

        if Ctransmision:
            Evivo = "True"
        else:
            Evivo = "False"
        #Termina Consulta Transmision

        if apro == 1:
            recomendacion_mas_valorados_consulta = Curso.objects.filter(valoracion=5, statusC=1, aprobado=1)[:5]
        else:
            recomendacion_mas_valorados_consulta = Curso.objects.filter(valoracion=5, statusC=1)[:5]
        recomendacion_mas_valorados = []

        if recomendacion_mas_valorados_consulta:
            for recomendacion_mas_valorado_consulta in recomendacion_mas_valorados_consulta:
                consulta_instructor_curso = CursoInstructor.objects.filter(id_cursoR = recomendacion_mas_valorado_consulta.id_curso)

                if consulta_instructor_curso:
                    id_instructor = consulta_instructor_curso[0].id_instructorR
                    datos_instructor = Instructor.objects.get(id_instructor=id_instructor)
                    nombre_instructor_curso = datos_instructor.nombreI + " " + datos_instructor.apellidosI

                    valor_conventir_recomendado_valorado =  formato_moneda(recomendacion_mas_valorado_consulta.precio, valor, nomenclatura)

                    recomendacion_mas_valorados.append((recomendacion_mas_valorado_consulta.id_curso, recomendacion_mas_valorado_consulta.nombreC,
                        valor_conventir_recomendado_valorado, recomendacion_mas_valorado_consulta.tipo_Curso, recomendacion_mas_valorado_consulta.ruta_imagen,
                        recomendacion_mas_valorado_consulta.descripcion_curso, nomenclatura, nombre_instructor_curso))



        categorias_curso = Cursos_Categorias.objects.filter(id_curso=id_curso_result)
        if categorias_curso:
            if categorias_curso.count() == 1:
                cursos = Cursos_Categorias.objects.filter(id_categoria=categorias_curso[0].id_categoria)
                recomendacion_categoria = []
                resultados_curso = []

                for curso in  cursos:
                    if apro == 1:
                        activo_curso = Curso.objects.get(id_curso=curso.id_curso, statusC=1, aprobado=1)
                    else:
                        activo_curso = Curso.objects.get(id_curso=curso.id_curso, statusC=1)
                    if activo_curso:
                        if int(activo_curso.id_curso) == int(id_curso):
                            pass
                        else:
                            consulta_instructor_curso = CursoInstructor.objects.filter(id_cursoR = activo_curso.id_curso)

                            if consulta_instructor_curso:
                                id_instructor = consulta_instructor_curso[0].id_instructorR
                                datos_instructor = Instructor.objects.get(id_instructor=id_instructor)
                                nombre_instructor_curso = datos_instructor.nombreI + " " + datos_instructor.apellidosI

                                precio_moneda = formato_moneda(activo_curso.precio, valor, nomenclatura)
                                resultados_curso.append((activo_curso.id_curso, activo_curso.nombreC, precio_moneda, activo_curso.ruta_imagen, activo_curso.descripcion_curso,
                                    nomenclatura, activo_curso.tipo_Curso, nombre_instructor_curso))

                numero_resultado = len(resultados_curso)

                if apro == 1:
                    recomendacion_fecha_nuevos_consulta = Curso.objects.order_by('-fecha_registro').filter(statusC=1, aprobado=1)[:5]
                else:
                    recomendacion_fecha_nuevos_consulta = Curso.objects.order_by('-fecha_registro').filter(statusC=1)[:5]
                recomendacion_fecha_nuevos = []

                if recomendacion_fecha_nuevos_consulta:
                    for recomendacion_fecha_nuevo_consulta in recomendacion_fecha_nuevos_consulta:

                        consulta_instructor_curso = CursoInstructor.objects.filter(id_cursoR = recomendacion_fecha_nuevo_consulta.id_curso)

                        if consulta_instructor_curso:
                            id_instructor = consulta_instructor_curso[0].id_instructorR
                            datos_instructor = Instructor.objects.get(id_instructor=id_instructor)
                            nombre_instructor_curso = datos_instructor.nombreI + " " + datos_instructor.apellidosI

                            valor_conventir_recomendado_fecha =  formato_moneda(recomendacion_fecha_nuevo_consulta.precio, valor, nomenclatura)

                            recomendacion_fecha_nuevos.append((recomendacion_fecha_nuevo_consulta.id_curso, recomendacion_fecha_nuevo_consulta.nombreC,
                                valor_conventir_recomendado_fecha, recomendacion_fecha_nuevo_consulta.tipo_Curso, recomendacion_fecha_nuevo_consulta.ruta_imagen,
                                recomendacion_fecha_nuevo_consulta.descripcion_curso, nomenclatura, nombre_instructor_curso))

                if numero_resultado > 5:
                    cursos_escoger = []
                    escoger_lleno = 0

                    while escoger_lleno == 0:
                        numero = random.randint(0, numero_resultado - 1)
                        if len(cursos_escoger) < 6:
                            if numero in cursos_escoger:
                                pass
                            else:
                                cursos_escoger.append(numero)
                        else:

                            for i in cursos_escoger:
                                recomendacion_categoria.append((resultados_curso[i][0], resultados_curso[i][1], resultados_curso[i][2], resultados_curso[i][3], resultados_curso[i][4], resultados_curso[i][5], resultados_curso[i][6]))

                            escoger_lleno = 1

                    contexto = {'curso_result': info_curso_con[0], "recomendado_fecha": recomendacion_fecha_nuevos, "recomendado_categoria": recomendacion_categoria,
                    'precio_curso': valor_conventir_curso, 'nomenclatura': nomenclatura, 'mas_valorados': recomendacion_mas_valorados, 'categorias': categorias_cursos,'authenticate': autenticado,
                    'user': id_usuario, 'type_user': tipo_usuario, 'num_cursos_lista' : cursos_lista_deseos, 'nombre_instructor_curso_info':nombre_instructor_curso_info,
                    'estudios_instructor':estudios_instructor, 'experiencia_instructor':experiencia_instructor, 'Monedas': monedas, 'MonedaSeleccionada':valor_moneda, 'cursos_recientes_slider': cursos_recientes_slider, 'valor': valor,
                    'entradas_blog_footer': entradas_blog_footer, 'Evivo': Evivo}


                else:
                    contexto = {'curso_result': info_curso_con[0], "recomendado_fecha": recomendacion_fecha_nuevos, "recomendado_categoria": resultados_curso,
                    'precio_curso': valor_conventir_curso, 'nomenclatura': nomenclatura, 'mas_valorados': recomendacion_mas_valorados, 'categorias': categorias_cursos,'authenticate': autenticado,
                    'user': id_usuario, 'type_user': tipo_usuario, 'num_cursos_lista' : cursos_lista_deseos, 'nombre_instructor_curso_info':nombre_instructor_curso_info,
                    'estudios_instructor':estudios_instructor, 'experiencia_instructor':experiencia_instructor, 'Monedas': monedas, 'MonedaSeleccionada':valor_moneda, 'cursos_recientes_slider': cursos_recientes_slider, 'valor': valor,
                    'entradas_blog_footer': entradas_blog_footer, 'Evivo': Evivo}

            elif categorias_curso.count() > 1:
                numero_resultados = categorias_curso.count() - 1

                categoria = random.randint(0, numero_resultados)

                cursos = Cursos_Categorias.objects.filter(id_categoria=categorias_curso[categoria].id_categoria)
                recomendacion_categoria = []
                resultados_curso = []

                for curso in  cursos:
                    if apro == 1:
                        activo_curso = Curso.objects.get(id_curso=curso.id_curso, statusC=1, aprobado=1)
                    else:
                        activo_curso = Curso.objects.get(id_curso=curso.id_curso, statusC=1)
                    if activo_curso:
                        if int(activo_curso.id_curso) == int(id_curso):
                            pass
                        else:
                            consulta_instructor_curso = CursoInstructor.objects.filter(id_cursoR = activo_curso.id_curso)

                            if consulta_instructor_curso:
                                id_instructor = consulta_instructor_curso[0].id_instructorR
                                datos_instructor = Instructor.objects.get(id_instructor=id_instructor)
                                nombre_instructor_curso = datos_instructor.nombreI + " " + datos_instructor.apellidosI

                                precio_moneda = formato_moneda(activo_curso.precio, valor, nomenclatura)

                                resultados_curso.append((activo_curso.id_curso, activo_curso.nombreC, precio_moneda, activo_curso.ruta_imagen, activo_curso.descripcion_curso,
                                    nomenclatura, activo_curso.tipo_Curso, nombre_instructor_curso))

                numero_resultado = len(resultados_curso)

                if apro == 1:
                    recomendacion_fecha_nuevos_consulta = Curso.objects.order_by('-fecha_registro').filter(statusC=1, aprobado=1)[:5]
                else:
                    recomendacion_fecha_nuevos_consulta = Curso.objects.order_by('-fecha_registro').filter(statusC=1)[:5]
                recomendacion_fecha_nuevos = []

                if recomendacion_fecha_nuevos_consulta:
                    for recomendacion_fecha_nuevo_consulta in recomendacion_fecha_nuevos_consulta:
                        consulta_instructor_curso = CursoInstructor.objects.filter(id_cursoR = recomendacion_fecha_nuevo_consulta.id_curso)

                        if consulta_instructor_curso:
                            id_instructor = consulta_instructor_curso[0].id_instructorR
                            datos_instructor = Instructor.objects.get(id_instructor=id_instructor)
                            nombre_instructor_curso = datos_instructor.nombreI + " " + datos_instructor.apellidosI

                            valor_conventir_recomendado_fecha =  formato_moneda(recomendacion_fecha_nuevo_consulta.precio, valor, nomenclatura)

                            recomendacion_fecha_nuevos.append((recomendacion_fecha_nuevo_consulta.id_curso, recomendacion_fecha_nuevo_consulta.nombreC,
                                valor_conventir_recomendado_fecha, recomendacion_fecha_nuevo_consulta.tipo_Curso, recomendacion_fecha_nuevo_consulta.ruta_imagen,
                                recomendacion_fecha_nuevo_consulta.descripcion_curso, nomenclatura, nombre_instructor_curso))

                if numero_resultado > 5:
                    cursos_escoger = []
                    escoger_lleno = 0

                    while escoger_lleno == 0:
                        numero = random.randint(0, numero_resultado - 1)
                        if len(cursos_escoger) < 6:
                            if numero in cursos_escoger:
                                pass
                            else:
                                cursos_escoger.append(numero)
                        else:

                            for i in cursos_escoger:
                                recomendacion_categoria.append((resultados_curso[i][0], resultados_curso[i][1], resultados_curso[i][2], resultados_curso[i][3], resultados_curso[i][4], resultados_curso[i][5], resultados_curso[i][6]))

                            escoger_lleno = 1

                    contexto = {'curso_result': info_curso_con[0], "recomendado_fecha": recomendacion_fecha_nuevos, "recomendado_categoria": recomendacion_categoria,
                    'precio_curso': valor_conventir_curso, 'nomenclatura': nomenclatura, 'mas_valorados': recomendacion_mas_valorados, 'categorias': categorias_cursos,'authenticate': autenticado,
                    'user': id_usuario, 'type_user': tipo_usuario, 'num_cursos_lista' : cursos_lista_deseos, 'nombre_instructor_curso_info':nombre_instructor_curso_info,
                    'estudios_instructor':estudios_instructor, 'experiencia_instructor':experiencia_instructor, 'Monedas': monedas, 'MonedaSeleccionada':valor_moneda, 'cursos_recientes_slider': cursos_recientes_slider, 'valor': valor,
                    'entradas_blog_footer': entradas_blog_footer, 'Evivo': Evivo}


                else:
                    contexto = {'curso_result': info_curso_con[0], "recomendado_fecha": recomendacion_fecha_nuevos, "recomendado_categoria": resultados_curso,
                    'precio_curso': valor_conventir_curso, 'nomenclatura': nomenclatura, 'mas_valorados': recomendacion_mas_valorados, 'categorias': categorias_cursos,'authenticate': autenticado,
                    'user': id_usuario, 'type_user': tipo_usuario, 'num_cursos_lista' : cursos_lista_deseos, 'nombre_instructor_curso_info':nombre_instructor_curso_info,
                    'estudios_instructor':estudios_instructor, 'experiencia_instructor':experiencia_instructor, 'Monedas': monedas, 'MonedaSeleccionada':valor_moneda, 'cursos_recientes_slider': cursos_recientes_slider, 'valor': valor,
                    'entradas_blog_footer': entradas_blog_footer, 'Evivo': Evivo}
        else:

            if apro == 1:
                recomendacion_fecha_nuevos_consulta = Curso.objects.order_by('-fecha_registro').filter(statusC=1, aprobado=1)[:5]
            else:
                recomendacion_fecha_nuevos_consulta = Curso.objects.order_by('-fecha_registro').filter(statusC=1)[:5]
            recomendacion_fecha_nuevos = []

            if recomendacion_fecha_nuevos_consulta:
                for recomendacion_fecha_nuevo_consulta in recomendacion_fecha_nuevos_consulta:
                    consulta_instructor_curso = CursoInstructor.objects.filter(id_cursoR = recomendacion_fecha_nuevo_consulta.id_curso)

                    if consulta_instructor_curso:
                        id_instructor = consulta_instructor_curso[0].id_instructorR
                        datos_instructor = Instructor.objects.get(id_instructor=id_instructor)
                        nombre_instructor_curso = datos_instructor.nombreI + " " + datos_instructor.apellidosI

                        valor_conventir_recomendado_fecha =  formato_moneda(recomendacion_fecha_nuevo_consulta.precio, valor, nomenclatura)

                        recomendacion_fecha_nuevos.append((recomendacion_fecha_nuevo_consulta.id_curso, recomendacion_fecha_nuevo_consulta.nombreC,
                            valor_conventir_recomendado_fecha, recomendacion_fecha_nuevo_consulta.tipo_Curso, recomendacion_fecha_nuevo_consulta.ruta_imagen,
                            recomendacion_fecha_nuevo_consulta.descripcion_curso, nomenclatura, nombre_instructor_curso))

            recomendacion_categoria = ""

            contexto = {'curso_result': info_curso_con[0], "recomendado_fecha": recomendacion_fecha_nuevos, "recomendado_categoria": recomendacion_categoria,
            'precio_curso': valor_conventir_curso, 'nomenclatura': nomenclatura, 'mas_valorados': recomendacion_mas_valorados, 'categorias': categorias_cursos,'authenticate': autenticado,
            'user': id_usuario, 'type_user': tipo_usuario, 'num_cursos_lista' : cursos_lista_deseos, 'nombre_instructor_curso_info':nombre_instructor_curso_info,
            'estudios_instructor':estudios_instructor, 'experiencia_instructor':experiencia_instructor, 'Monedas': monedas, 'MonedaSeleccionada':valor_moneda, 'cursos_recientes_slider': cursos_recientes_slider, 'valor': valor,
            'entradas_blog_footer': entradas_blog_footer, 'Evivo': Evivo}


    return render(request, 'Principal/curso-sensei.html', contexto)




def todos_cursos(request):

    id_usuario =  ""
    tipo_usuario = ""
    autenticado = ""
    cursos_lista_deseos = 0
    if request.user.is_authenticated:
        autenticado = "authenticated"
        if request.user.tipo_usuario == 3:
            id_usuario =  str(request.user.id_relacionado)
            tipo_usuario = str(request.user.tipo_usuario)
            lista_deseos_consulta = Lista_Deseos.objects.filter(id_alumno=id_usuario, statusLD=1)
            cursos_lista_deseos = lista_deseos_consulta.count()
        else:
            id_usuario =  ""
            tipo_usuario = ""

    moneda(request)
    verificar_moneda(request)

    valor_moneda = request.session['moneda']

    moneda_valor = Moneda.objects.filter(nombre_moneda=valor_moneda)
    valor = moneda_valor[0].equivalente_peso_mx
    nomenclatura = moneda_valor[0].nomencaltura

    opcion = ElementosPagina.objects.get(id_elementoPagina=1)
    apro = opcion.aprobacion_cursos

    if apro == 1:
        cursos_recientes_slider = Curso.objects.order_by('-fecha_registro').filter(statusC=1, aprobado=1)[:10]
    else:
        cursos_recientes_slider = Curso.objects.order_by('-fecha_registro').filter(statusC=1)[:10]

    categorias_cursos = CursoCategoria.objects.all()
    monedas = Moneda.objects.filter(statusM=1)

    entradas_blog_footer = EntradasBlog.objects.order_by('-fecha_posteo')[:3]

    #Empieza consulta de transmision
    horas = datetime.now()

    horamas = horas + timedelta(hours=1)

    horamass = horamas.time()

    horamenos = horas + timedelta(hours=-1)

    horamenoss = horamenos.time()

    cadena1 = str(horamenoss)
    cadena2 = str(horamass)

    fechahoy = date.today()

    begin = datetime.strptime(cadena1, '%H:%M:%S.%f').time()
    end = datetime.strptime(cadena2, '%H:%M:%S.%f').time()

    Ctransmision = TransmisionesVivo.objects.filter(fecha_transmision=fechahoy, hora_transmision__range=[begin, end]).order_by('hora_transmision')[:1]

    Evivo = ""

    if Ctransmision:
        Evivo = "True"
    else:
        Evivo = "False"
    #Termina Consulta Transmision

    cursos = []

    if apro == 1:
        cursos_consulta = Curso.objects.filter(statusC=1, aprobado=1)
    else:
        cursos_consulta = Curso.objects.filter(statusC=1)
    if cursos_consulta:
        for curso_consulta in cursos_consulta:
            consulta_instructor_curso = CursoInstructor.objects.filter(id_cursoR = curso_consulta.id_curso)

            if consulta_instructor_curso:
                id_instructor = consulta_instructor_curso[0].id_instructorR
                datos_instructor = Instructor.objects.get(id_instructor=id_instructor)
                nombre_instructor_curso = datos_instructor.nombreI + " " + datos_instructor.apellidosI

                valor_conventir_curso =  formato_moneda(curso_consulta.precio, valor, nomenclatura)

                cursos.append((curso_consulta.id_curso, curso_consulta.nombreC,
                    valor_conventir_curso, curso_consulta.tipo_Curso, curso_consulta.ruta_imagen,
                    curso_consulta.descripcion_curso, nomenclatura, nombre_instructor_curso))

    paginacion_todos_cursos = Paginator(cursos, 10)

    pagina_num = request.GET.get('page')

    page = paginacion_todos_cursos.get_page(pagina_num)

    contexto = {'TCursos': page, 'cursos_count': paginacion_todos_cursos.count, 'paginas': paginacion_todos_cursos.num_pages,
        'categorias': categorias_cursos,'authenticate': autenticado,
        'user': id_usuario, 'type_user': tipo_usuario, 'num_cursos_lista' : cursos_lista_deseos,
        'Monedas': monedas, 'MonedaSeleccionada':valor_moneda, 'nomenclatura': nomenclatura,
        'cursos_recientes_slider': cursos_recientes_slider, 'valor': valor,'entradas_blog_footer': entradas_blog_footer,
        'Evivo': Evivo}

    return render(request, 'Principal/todos-cursos.html', contexto)

def todos_cursos_categoria(request):
    if request.method == "GET":

        categoria = request.GET['palabra']

        cat = request.GET['cat']

        id_usuario =  ""
        tipo_usuario = ""
        autenticado = ""
        cursos_lista_deseos = 0
        if request.user.is_authenticated:
            autenticado = "authenticated"
            if request.user.tipo_usuario == 3:
                id_usuario =  str(request.user.id_relacionado)
                tipo_usuario = str(request.user.tipo_usuario)
                lista_deseos_consulta = Lista_Deseos.objects.filter(id_alumno=id_usuario, statusLD=1)
                cursos_lista_deseos = lista_deseos_consulta.count()
            else:
                id_usuario =  ""
                tipo_usuario = ""

        moneda(request)
        verificar_moneda(request)

        valor_moneda = request.session['moneda']

        moneda_valor = Moneda.objects.filter(nombre_moneda=valor_moneda)
        valor = moneda_valor[0].equivalente_peso_mx
        nomenclatura = moneda_valor[0].nomencaltura

        opcion = ElementosPagina.objects.get(id_elementoPagina=1)
        apro = opcion.aprobacion_cursos

        if apro == 1:
            cursos_recientes_slider = Curso.objects.order_by('-fecha_registro').filter(statusC=1, aprobado=1)[:10]
        else:
            cursos_recientes_slider = Curso.objects.order_by('-fecha_registro').filter(statusC=1)[:10]

        categorias_cursos = CursoCategoria.objects.all()
        monedas = Moneda.objects.filter(statusM=1)

        entradas_blog_footer = EntradasBlog.objects.order_by('-fecha_posteo')[:3]

        #Empieza consulta de transmision
        horas = datetime.now()

        horamas = horas + timedelta(hours=1)

        horamass = horamas.time()

        horamenos = horas + timedelta(hours=-1)

        horamenoss = horamenos.time()

        cadena1 = str(horamenoss)
        cadena2 = str(horamass)

        fechahoy = date.today()

        begin = datetime.strptime(cadena1, '%H:%M:%S.%f').time()
        end = datetime.strptime(cadena2, '%H:%M:%S.%f').time()

        Ctransmision = TransmisionesVivo.objects.filter(fecha_transmision=fechahoy, hora_transmision__range=[begin, end]).order_by('hora_transmision')[:1]

        Evivo = ""

        if Ctransmision:
            Evivo = "True"
        else:
            Evivo = "False"
        #Termina Consulta Transmision



        categoria_verifica = CursoCategoria.objects.get(id_categoria=cat)
        cursos_categoria_ar = []
        if categoria_verifica:
            cursos_encategoria = Cursos_Categorias.objects.filter(id_categoria=categoria_verifica.id_categoria)

            if cursos_encategoria:

                for curso_encategoria in cursos_encategoria:
                    consulta_instructor_curso = CursoInstructor.objects.filter(id_cursoR = curso_encategoria.id_curso)

                    if consulta_instructor_curso:
                        id_instructor = consulta_instructor_curso[0].id_instructorR
                        datos_instructor = Instructor.objects.get(id_instructor=id_instructor)
                        nombre_instructor_curso = datos_instructor.nombreI + " " + datos_instructor.apellidosI

                        if apro == 1:
                            curso_buscado = Curso.objects.get(id_curso=curso_encategoria.id_curso, statusC=1, aprobado=1)
                        else:
                            curso_buscado = Curso.objects.get(id_curso=curso_encategoria.id_curso, statusC=1)
                        precio_curso_convertir = float(curso_buscado.precio) * float(valor)
                        redondear = round(precio_curso_convertir)

                        if nomenclatura in 'EUR':
                            precio_comas_coma = '{:,}'.format(redondear)
                            precio_comas = precio_comas_coma.replace(',','.')


                        else:
                            precio_comas = '{:,}'.format(redondear)

                        cursos_categoria_ar.append((curso_buscado.id_curso, curso_buscado.nombreC, curso_buscado.fecha_inicio,
                            curso_buscado.fecha_cierre, precio_comas, curso_buscado.tipo_Curso, curso_buscado.ruta_imagen,
                            curso_buscado.descripcion_curso, curso_buscado.fecha_registro, nomenclatura, nombre_instructor_curso))


        paginacion_todos_cursos_categoria = Paginator(cursos_categoria_ar, 10)

        pagina_num = request.GET.get('page')

        page = paginacion_todos_cursos_categoria.get_page(pagina_num)

        contexto = {'CursosC': page, 'cursos_count': paginacion_todos_cursos_categoria.count, 'paginas': paginacion_todos_cursos_categoria.num_pages,
        'categoria': categoria_verifica,
        'categorias': categorias_cursos,'authenticate': autenticado,
        'user': id_usuario, 'type_user': tipo_usuario, 'num_cursos_lista' : cursos_lista_deseos,
        'nomenclatura': nomenclatura, 'Monedas': monedas, 'MonedaSeleccionada':valor_moneda,
        'cursos_recientes_slider': cursos_recientes_slider, 'valor': valor,'entradas_blog_footer': entradas_blog_footer,
        'Evivo': Evivo}

    return render(request, 'Principal/todos-cursos-categoria.html', contexto)



def categorias(request):
    if request.method == "GET":
        palabra = request.GET.get('palabra')
        if palabra == "":
            categorias = ""
        else:
            categorias = CursoCategoria.objects.filter(nombre_categoria__icontains=palabra)
        return render(request, 'Principal/categorias_buscadas.html',{'Categorias': categorias, 'Palabra': palabra})
    return redirect('/index/')



def show(request):
    cart = Cart(request.session)
    response = ''
    for item in cart.items:
        response += '%(quantity)s %(item)s for $%(price)s\n' % {
            'quantity': item.quantity,
            'item': item.product.name,
            'price': item.subtotal,
        }
        response += 'items count: %s\n' % cart.count
        response += 'unique count: %s\n' % cart.unique_count
    return HttpResponse(response)


def add(request):
    if request.method == "GET":
        id_curso = request.GET.get('curso')
        tipo_compra_get = request.GET.get('tipo_cursoc')
        tipo_compra = str(tipo_compra_get)

        consulta_instructor_curso = CursoInstructor.objects.filter(id_cursoR = id_curso)
        nombre_instructor_curso = ""
        if consulta_instructor_curso:
            id_instructor = consulta_instructor_curso[0].id_instructorR
            datos_instructor = Instructor.objects.get(id_instructor=id_instructor)
            nombre_instructor_curso = datos_instructor.nombreI + " " + datos_instructor.apellidosI

        tipo_compra_string = ""

        if int(tipo_compra) == 1:
            tipo_compra_string = "organico"
        elif int(tipo_compra) == 2:
            tipo_compra_string = "inorganico"
        elif int(tipo_compra) == 3:
            tipo_compra_string = "sensei"

        cart = Cart(request.session,0)
        curso = Curso.objects.get(id_curso=id_curso)
        cantidad = request.POST.get('cantidad', 1)
        descuento = request.POST.get('descuento', 0)
        precio = curso.precio
        curso_carro_inicio = cart.count
        #descuento_cursos_especial = Descuento_Cursos_Especial.objects.filter(statusDCE=1)
        descuento_especial = ""
        descuento_curso = ""
        cart.add(curso, precio, cantidad, descuento_especial, descuento_curso, tipo_compra_string, nombre_instructor_curso)

        """
        if descuento_cursos_especial:
            descuento_especial = "activo"
            descuento_curso = ""
            cart.add(curso, precio, cantidad, descuento_especial, descuento_curso, tipo_compra_string)
        else:

            descuento_curso = Descuento_Curso.objects.filter(id_curso=id_curso,statucDC=1)

            if descuento_curso:
                descuento_especial = ""
                descuento_curso = "activo"
                cart.add(curso, precio, cantidad, descuento_especial, descuento_curso, tipo_compra_string)
            else:
                descuento_especial = ""
                descuento_curso = ""
                cart.add(curso, precio, cantidad, descuento_especial, descuento_curso, tipo_compra_string)

        """

        curso_carro_final = cart.count
        respuesta = ""
        if curso_carro_final > curso_carro_inicio:
            respuesta = "exito"
        else:
            respuesta = "error"

        return JsonResponse({'content':{'message': respuesta,'cursos':curso_carro_final}})
    return redirect('/index/')


def acceder_cupon_cambio(request):
    if request.method == "POST":
        cupon = request.POST['coupon']

        #now = datetime.now()
        now_date = datetime.date.today()
        cupon_buscar = CuponesDescuento.objects.filter(codigo_cupon=cupon, status_cupon=1)
        if cupon_buscar:
            fecha_caduca_c = cupon_buscar[0].fecha_caduca

            if now_date <= fecha_caduca_c:
                porcentaje_asignado = int(cupon_buscar[0].porcentaje_asignado)
                if request.session.get('cpn'):
                    pass
                else:
                    CuponesDescuento.objects.filter(codigo_cupon=cupon, status_cupon=1).update(status_cupon=2)
                    request.session['cpn'] = str(porcentaje_asignado)
            else:
                pass
        else:
            pass

        return redirect('/carro/')
    return redirect('/index/')


def carro_vista_previa(request):
    if request.method == "GET":
        valor_moneda = request.session['moneda']

        moneda_valor = Moneda.objects.filter(nombre_moneda=valor_moneda)
        valor = moneda_valor[0].equivalente_peso_mx
        nomenclatura = moneda_valor[0].nomencaltura


        contexto = {'nomenclatura': nomenclatura, 'valor': valor}

        return render(request, 'Principal/carro-vista-previa.html', contexto)

    return redirect('/index/')

def remove(request):
    if request.method == "GET":
        id_curso = request.GET['curso']
        cart = Cart(request.session)
        product = Curso.objects.get(id_curso=id_curso)
        cart.remove(product)
        #return HttpResponse()
        return redirect('/carro/')
    return redirect('/index/')


def remove_single(request):
    cart = Cart(request.session)
    product = Product.objects.get(pk=request.POST.get('product_id'))
    cart.remove_single(product)
    return HttpResponse()


def clear(request):
    if request.method == "GET":
        cart = Cart(request.session)
        cart.clear()
        #return HttpResponse()
        return redirect('/carro/')
    return redirect('/index/')


def set_quantity(request):
    cart = Cart(request.session)
    product = Product.objects.get(pk=request.POST.get('product_id'))
    quantity = request.POST.get('quantity')
    cart.set_quantity(product, quantity)
    return HttpResponse()

def carro(request):
    id_usuario =  ""
    tipo_usuario = ""
    autenticado = ""
    cursos_lista_deseos = 0
    if request.user.is_authenticated:
        autenticado = "authenticated"
        if request.user.tipo_usuario == 3:
            id_usuario =  str(request.user.id_relacionado)
            tipo_usuario = str(request.user.tipo_usuario)
            lista_deseos_consulta = Lista_Deseos.objects.filter(id_alumno=id_usuario, statusLD=1)
            cursos_lista_deseos = lista_deseos_consulta.count()
        else:
            id_usuario =  ""
            tipo_usuario = ""

    moneda(request)
    verificar_moneda(request)

    valor_moneda = request.session['moneda']

    moneda_valor = Moneda.objects.filter(nombre_moneda=valor_moneda)
    valor = moneda_valor[0].equivalente_peso_mx
    nomenclatura = moneda_valor[0].nomencaltura

    opcion = ElementosPagina.objects.get(id_elementoPagina=1)
    apro = opcion.aprobacion_cursos

    if apro == 1:
        cursos_recientes_slider = Curso.objects.order_by('-fecha_registro').filter(statusC=1, aprobado=1)[:10]
    else:
        cursos_recientes_slider = Curso.objects.order_by('-fecha_registro').filter(statusC=1)[:10]

    categorias_cursos = CursoCategoria.objects.all()
    monedas = Moneda.objects.filter(statusM=1)

    entradas_blog_footer = EntradasBlog.objects.order_by('-fecha_posteo')[:3]


    #Empieza consulta de transmision
    horas = datetime.now()

    horamas = horas + timedelta(hours=1)

    horamass = horamas.time()

    horamenos = horas + timedelta(hours=-1)

    horamenoss = horamenos.time()

    cadena1 = str(horamenoss)
    cadena2 = str(horamass)

    fechahoy = date.today()

    begin = datetime.strptime(cadena1, '%H:%M:%S.%f').time()
    end = datetime.strptime(cadena2, '%H:%M:%S.%f').time()

    Ctransmision = TransmisionesVivo.objects.filter(fecha_transmision=fechahoy, hora_transmision__range=[begin, end]).order_by('hora_transmision')[:1]

    Evivo = ""

    if Ctransmision:
        Evivo = "True"
    else:
        Evivo = "False"
    #Termina Consulta Transmision

    contexto = {'categorias': categorias_cursos,'authenticate': autenticado,
        'user': id_usuario, 'type_user': tipo_usuario, 'num_cursos_lista' : cursos_lista_deseos,
        'nomenclatura': nomenclatura, 'Monedas': monedas, 'MonedaSeleccionada':valor_moneda,
        'cursos_recientes_slider': cursos_recientes_slider,'valor': valor,'entradas_blog_footer': entradas_blog_footer,
        'Evivo': Evivo}

    return render (request, "Principal/carro.html", contexto)


@login_required(login_url='/iniciar_sesion/')
def requisito_pago_carro(request):

    id_usuario =  ""
    tipo_usuario = ""
    autenticado = ""
    cursos_lista_deseos = 0
    if request.user.is_authenticated:
        autenticado = "authenticated"
        if request.user.tipo_usuario == 3:
            id_usuario =  str(request.user.id_relacionado)
            tipo_usuario = str(request.user.tipo_usuario)
            lista_deseos_consulta = Lista_Deseos.objects.filter(id_alumno=id_usuario, statusLD=1)
            cursos_lista_deseos = lista_deseos_consulta.count()
        else:
            id_usuario =  "0"
            tipo_usuario = "0"

    moneda(request)
    verificar_moneda(request)

    valor_moneda = request.session['moneda']

    moneda_valor = Moneda.objects.filter(nombre_moneda=valor_moneda)
    valor = moneda_valor[0].equivalente_peso_mx
    nomenclatura = moneda_valor[0].nomencaltura

    opcion = ElementosPagina.objects.get(id_elementoPagina=1)
    apro = opcion.aprobacion_cursos

    if apro == 1:
        cursos_recientes_slider = Curso.objects.order_by('-fecha_registro').filter(statusC=1, aprobado=1)[:10]
    else:
        cursos_recientes_slider = Curso.objects.order_by('-fecha_registro').filter(statusC=1)[:10]

    categorias_cursos = CursoCategoria.objects.all()
    monedas = Moneda.objects.filter(statusM=1)

    entradas_blog_footer = EntradasBlog.objects.order_by('-fecha_posteo')[:3]

    #Empieza consulta de transmision
    horas = datetime.now()

    horamas = horas + timedelta(hours=1)

    horamass = horamas.time()

    horamenos = horas + timedelta(hours=-1)

    horamenoss = horamenos.time()

    cadena1 = str(horamenoss)
    cadena2 = str(horamass)

    fechahoy = date.today()

    begin = datetime.strptime(cadena1, '%H:%M:%S.%f').time()
    end = datetime.strptime(cadena2, '%H:%M:%S.%f').time()

    Ctransmision = TransmisionesVivo.objects.filter(fecha_transmision=fechahoy, hora_transmision__range=[begin, end]).order_by('hora_transmision')[:1]

    Evivo = ""

    if Ctransmision:
        Evivo = "True"
    else:
        Evivo = "False"
    #Termina Consulta Transmision

    cart = Cart(request.session,0)

    cursos_comprados = []

    if int(tipo_usuario) == 3:
        for item in cart.items:

            consultar_curso_carro = CursoEstudiante.objects.filter(id_cursoR=item.curso.id_curso, id_estudianteR=id_usuario)

            if consultar_curso_carro:
                cursos_comprados.append(consultar_curso_carro[0].id_cursoR)

    for x in range(0,len(cursos_comprados)):
        product = Curso.objects.get(id_curso=cursos_comprados[x])
        cart.remove(product)


    totalp = cart.total_sinformT

    contexto = {'categorias': categorias_cursos,'authenticate': autenticado,
        'user': id_usuario, 'type_user': int(tipo_usuario), 'num_cursos_lista' : cursos_lista_deseos,
        'nomenclatura': nomenclatura, 'Monedas': monedas, 'MonedaSeleccionada':valor_moneda,
        'cursos_recientes_slider': cursos_recientes_slider, 'valor': valor, 'totalp': int(totalp),'entradas_blog_footer': entradas_blog_footer,
        'Evivo': Evivo}

    return render(request, "Principal/requisito-pago-carro.html", contexto)

def comparar_cursos(request):
    id_usuario =  ""
    tipo_usuario = ""
    autenticado = ""
    cursos_lista_deseos = 0
    if request.user.is_authenticated:
        autenticado = "authenticated"
        if request.user.tipo_usuario == 3:
            id_usuario =  str(request.user.id_relacionado)
            tipo_usuario = str(request.user.tipo_usuario)
            lista_deseos_consulta = Lista_Deseos.objects.filter(id_alumno=id_usuario, statusLD=1)
            cursos_lista_deseos = lista_deseos_consulta.count()
        else:
            id_usuario =  ""
            tipo_usuario = ""

    moneda(request)
    verificar_moneda(request)

    valor_moneda = request.session['moneda']

    moneda_valor = Moneda.objects.filter(nombre_moneda=valor_moneda)
    valor = moneda_valor[0].equivalente_peso_mx
    nomenclatura = moneda_valor[0].nomencaltura

    opcion = ElementosPagina.objects.get(id_elementoPagina=1)
    apro = opcion.aprobacion_cursos

    if apro == 1:
        cursos_recientes_slider = Curso.objects.order_by('-fecha_registro').filter(statusC=1, aprobado=1)[:10]
    else:
        cursos_recientes_slider = Curso.objects.order_by('-fecha_registro').filter(statusC=1)[:10]

    categorias_cursos = CursoCategoria.objects.all()
    monedas = Moneda.objects.filter(statusM=1)

    entradas_blog_footer = EntradasBlog.objects.order_by('-fecha_posteo')[:3]


    #Empieza consulta de transmision
    horas = datetime.now()

    horamas = horas + timedelta(hours=1)

    horamass = horamas.time()

    horamenos = horas + timedelta(hours=-1)

    horamenoss = horamenos.time()

    cadena1 = str(horamenoss)
    cadena2 = str(horamass)

    fechahoy = date.today()

    begin = datetime.strptime(cadena1, '%H:%M:%S.%f').time()
    end = datetime.strptime(cadena2, '%H:%M:%S.%f').time()

    Ctransmision = TransmisionesVivo.objects.filter(fecha_transmision=fechahoy, hora_transmision__range=[begin, end]).order_by('hora_transmision')[:1]

    Evivo = ""

    if Ctransmision:
        Evivo = "True"
    else:
        Evivo = "False"
    #Termina Consulta Transmision

    contexto = {'categorias': categorias_cursos,'authenticate': autenticado,
        'user': id_usuario, 'type_user': tipo_usuario, 'num_cursos_lista' : cursos_lista_deseos,
        'nomenclatura': nomenclatura, 'Monedas': monedas, 'MonedaSeleccionada':valor_moneda,
        'cursos_recientes_slider': cursos_recientes_slider, 'valor': valor,'entradas_blog_footer': entradas_blog_footer,
        'Evivo': Evivo}

    return render (request, "Principal/comparar-cursos.html", contexto)


def addcompare(request):
    if request.method == "GET":
        id_curso = request.GET.get('curso')
        compare = Compare(request.session)
        curso = Curso.objects.get(id_curso=id_curso)

        consulta_instructor_curso = CursoInstructor.objects.filter(id_cursoR = id_curso)
        nombre_instructor_curso = ""
        if consulta_instructor_curso:
            id_instructor = consulta_instructor_curso[0].id_instructorR
            datos_instructor = Instructor.objects.get(id_instructor=id_instructor)
            nombre_instructor_curso = datos_instructor.nombreI + " " + datos_instructor.apellidosI

        curso_compare_inicio = compare.count

        compare.add(curso,1, nombre_instructor_curso)


        curso_compare_final = compare.count
        respuesta = ""
        if curso_compare_final > curso_compare_inicio:
            respuesta = "exito"
        else:
            respuesta = "error"

        return JsonResponse({'content':{'message': respuesta,'cursoc':curso_compare_final}})
    return redirect('/index/')

def remove_compare(request):
    if request.method == "GET":
        id_curso = request.GET['curso']
        compare = Compare(request.session)
        product = Curso.objects.get(id_curso=id_curso)
        compare.remove(product)
        #return HttpResponse()
        return redirect('/comparar-cursos/')
    return redirect('/index/')

@login_required(login_url='/iniciar_sesion/')
def lista_deseos(request):


    id_usuario =  ""
    tipo_usuario = ""
    autenticado = ""
    cursos_lista_deseos = 0
    if request.user.is_authenticated:
        autenticado = "authenticated"
        if request.user.tipo_usuario == 3:
            id_usuario =  str(request.user.id_relacionado)
            tipo_usuario = str(request.user.tipo_usuario)
            lista_deseos_consulta = Lista_Deseos.objects.filter(id_alumno=id_usuario, statusLD=1)
            cursos_lista_deseos = lista_deseos_consulta.count()
        else:
            id_usuario =  ""
            tipo_usuario = ""

    moneda(request)
    verificar_moneda(request)

    valor_moneda = request.session['moneda']

    moneda_valor = Moneda.objects.filter(nombre_moneda=valor_moneda)
    valor = moneda_valor[0].equivalente_peso_mx
    nomenclatura = moneda_valor[0].nomencaltura

    opcion = ElementosPagina.objects.get(id_elementoPagina=1)
    apro = opcion.aprobacion_cursos

    if apro == 1:
        cursos_recientes_slider = Curso.objects.order_by('-fecha_registro').filter(statusC=1, aprobado=1)[:10]
    else:
        cursos_recientes_slider = Curso.objects.order_by('-fecha_registro').filter(statusC=1)[:10]

    categorias_cursos = CursoCategoria.objects.all()
    monedas = Moneda.objects.filter(statusM=1)


    entradas_blog_footer = EntradasBlog.objects.order_by('-fecha_posteo')[:3]


    #Empieza consulta de transmision
    horas = datetime.now()

    horamas = horas + timedelta(hours=1)

    horamass = horamas.time()

    horamenos = horas + timedelta(hours=-1)

    horamenoss = horamenos.time()

    cadena1 = str(horamenoss)
    cadena2 = str(horamass)

    fechahoy = date.today()

    begin = datetime.strptime(cadena1, '%H:%M:%S.%f').time()
    end = datetime.strptime(cadena2, '%H:%M:%S.%f').time()

    Ctransmision = TransmisionesVivo.objects.filter(fecha_transmision=fechahoy, hora_transmision__range=[begin, end]).order_by('hora_transmision')[:1]

    Evivo = ""

    if Ctransmision:
        Evivo = "True"
    else:
        Evivo = "False"
    #Termina Consulta Transmision


    id_usuario =  request.user.id_relacionado
    tipo_usuario = request.user.tipo_usuario
    cursos_lista_deseos = 0
    if tipo_usuario == 3:
        lista_deseos_consulta = Lista_Deseos.objects.filter(id_alumno=id_usuario, statusLD=1)
        cursos_lista_deseos = lista_deseos_consulta.count()
        info_curso_lista_deseos = []

        if lista_deseos_consulta:
            for curso_lista in lista_deseos_consulta:

                consulta_instructor_curso = CursoInstructor.objects.filter(id_cursoR = curso_lista.id_curso)

                if consulta_instructor_curso:
                    id_instructor = consulta_instructor_curso[0].id_instructorR
                    datos_instructor = Instructor.objects.get(id_instructor=id_instructor)
                    nombre_instructor_curso = datos_instructor.nombreI + " " + datos_instructor.apellidosI

                    curso_buscar = Curso.objects.get(id_curso=curso_lista.id_curso)
                    valor_conventir_curso_lista_deseos =  formato_moneda(curso_buscar.precio, valor, nomenclatura)

                    info_curso_lista_deseos.append((curso_buscar.id_curso, curso_buscar.nombreC,
                        valor_conventir_curso_lista_deseos, curso_buscar.tipo_Curso,
                        curso_buscar.ruta_imagen, curso_buscar.duracion_curso_numero,
                        curso_buscar.duracion_curso_tipo, nomenclatura, nombre_instructor_curso))

    else:
        info_curso_lista_deseos = []



    contexto = {'Cursos_Lista': info_curso_lista_deseos, 'user': id_usuario, 'num_cursos_lista' : cursos_lista_deseos,
        'categorias': categorias_cursos,'authenticate': autenticado,
        'user': id_usuario, 'type_user': tipo_usuario, 'num_cursos_lista' : cursos_lista_deseos,
        'nomenclatura': nomenclatura, 'Monedas': monedas, 'MonedaSeleccionada':valor_moneda,
        'cursos_recientes_slider': cursos_recientes_slider, 'valor': valor,'entradas_blog_footer': entradas_blog_footer,
        'Evivo': Evivo}

    return render (request, 'Principal/lista-deseos.html', contexto)

@login_required(login_url='/iniciar_sesion/')
def quitar_de_lista_deseos(request):
    if request.method == "GET":
        curso = request.GET['remove']
        user = request.GET['user']

        Lista_Deseos.objects.filter(id_alumno=user, id_curso=curso).update(statusLD=0)

        return redirect('/lista-deseos/')

    return redirect('/index/')

def add_lista_deseos(request):
    if request.method == "GET":
        curso = request.GET.get('curso')
        user = request.GET.get('user')

        count_lista_deseos_inicio = Lista_Deseos.objects.filter(id_alumno=user, statusLD=1)
        curso_lista_consulta_lis = Lista_Deseos.objects.filter(id_alumno=user, id_curso=curso)
        respuesta = ""
        if curso_lista_consulta_lis:
            if curso_lista_consulta_lis[0].statusLD == 1:
                count_lista_deseos_final = Lista_Deseos.objects.filter(id_alumno=user, statusLD=1)
                respuesta = "existe"
            elif curso_lista_consulta_lis[0].statusLD == 0:
                agregar_curso_lista = Lista_Deseos.objects.filter(id_alumno=user, id_curso=curso).update(statusLD=1)
                count_lista_deseos_final = Lista_Deseos.objects.filter(id_alumno=user, statusLD=1)
                respuesta = "agregado"
        else:
            agregar_curso_lista = Lista_Deseos.objects.create(id_alumno=user, id_curso=curso, statusLD=1)
            count_lista_deseos_final = Lista_Deseos.objects.filter(id_alumno=user, statusLD=1)
            respuesta = "agregado"

        count_lista = 0

        if count_lista_deseos_final.count() > count_lista_deseos_inicio.count():
            count_lista = count_lista_deseos_final.count()
        else:
            count_lista = count_lista_deseos_inicio.count()

        return JsonResponse({'content':{'message': respuesta,'messageN': count_lista}})
    return redirect('/index/')



def pregunta_informacion(request):
    if request.method == "POST":
        nombre = request.POST.get('nombre')
        correo = request.POST.get('correo')
        asunto = request.POST.get('asunto')
        mensaje = request.POST.get('mensaje')
        tipo_pregunta = request.POST.get('tipo_pregunta')
        curso = request.POST.get('curso')

        '''
        MANDRILL_API_KEY = 'Ya4SqTK0tCvIEq1MSZ7NtQ'
        mandrill_client = mandrill.Mandrill(MANDRILL_API_KEY)
        messageu = { 'from_email': 'hola@kaizen.lat',
          'from_name': 'Kaizen.lat',
          'to': [{
            'email': correo,
            'name': 'hola',
            'type': 'to'
           }],
          'subject': '',
          'text': '¡Hola '+correo+'! Resolveremos tu duda a la brevedad.'
        }

        result_mensaje_usuario = mandrill_client.messages.send(message = messageu)
        '''

        texto = '¡Hola '+correo+'! Resolveremos tu duda a la brevedad.'

        # import file with html content
        html_version = 'Principal/email_general.html'

        html_message = render_to_string(html_version, { 'context': texto, })

        message = EmailMessage('Pregunta', html_message, 'hola@seiko.dev', [correo])
        message.content_subtype = 'html'
        message.send()

        '''
        messagek = { 'from_email': 'hola@kaizen.lat',
          'from_name': 'Kaizen.lat',
          'to': [{
            'email': 'hola@kaizen.lat',
            'name': 'hola',
            'type': 'to'
           }],
          'subject': asunto,
          'text': 'Envia el mensaje: '+correo+'     '+mensaje
        }

        result_mensaje_kaizen = mandrill_client.messages.send(message = messagek)
        '''

        texto2 = 'Envia el mensaje: '+correo+'     '+mensaje
        correo = 'hola@kaizen.lat'

        # import file with html content
        html_version = 'Principal/email_general.html'

        html_message = render_to_string(html_version, { 'context': texto2, })

        message = EmailMessage(asunto, html_message, 'hola@seiko.dev', [correo])
        message.content_subtype = 'html'
        message.send()


        date = dt.datetime.now()
        Pregunta_usuario.objects.create(nombre=nombre, correo=correo, asunto=asunto,
            mensaje=mensaje, acepta_terminos="si", tipo_pregunta=tipo_pregunta, curso=curso, fecha=date,
            hora=date, statusP=1)

        respuesta = "gurdada"
        return JsonResponse({'content':{'message': respuesta}})

    return redirect('/index/')



def visitor_ip_address(request):

    x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')

    if x_forwarded_for:
        ip = x_forwarded_for.split(',')[0]
    else:
        ip = request.META.get('REMOTE_ADDR')
    return ip

def boletin(request):
    if request.method == "POST":
        correo = request.POST.get('correo')
        pais = request.POST.get('pais')

        '''
        MANDRILL_API_KEY = 'Ya4SqTK0tCvIEq1MSZ7NtQ'
        mandrill_client = mandrill.Mandrill(MANDRILL_API_KEY)
        messageu = { 'from_email': 'hola@kaizen.lat',
          'from_name': 'Kaizen.lat',
          'to': [{
            'email': correo,
            'name': 'hola',
            'type': 'to'
           }],
          'subject': '',
          'text': '¡Hola '+correo+'! Te suscribiste al boletín de kaizen.'
        }

        result_mensaje_usuario = mandrill_client.messages.send(message = messageu)
        '''

        texto = '¡Hola '+correo+'! Te suscribiste al boletín de kaizen.'

        # import file with html content
        html_version = 'Principal/email_general.html'

        html_message = render_to_string(html_version, { 'context': texto, })

        message = EmailMessage('Suscripción Boletin', html_message, 'hola@seiko.dev', [correo])
        message.content_subtype = 'html'
        message.send()


        ip = visitor_ip_address(request)

        date = dt.datetime.now()
        Boletin.objects.create(correo=correo, fecha=date, hora=date, ip=ip, pais=pais,statusBo=1)


        respuesta = "guardada"
        return JsonResponse({'content':{'message': respuesta}})

    return redirect('/index/')





def blog(request):

    id_usuario =  ""
    tipo_usuario = ""
    autenticado = ""
    cursos_lista_deseos = 0
    if request.user.is_authenticated:
        autenticado = "authenticated"
        if request.user.tipo_usuario == 3:
            id_usuario =  str(request.user.id_relacionado)
            tipo_usuario = str(request.user.tipo_usuario)
            lista_deseos_consulta = Lista_Deseos.objects.filter(id_alumno=id_usuario, statusLD=1)
            cursos_lista_deseos = lista_deseos_consulta.count()
        else:
            id_usuario =  ""
            tipo_usuario = ""

    moneda(request)
    verificar_moneda(request)

    valor_moneda = request.session['moneda']

    moneda_valor = Moneda.objects.filter(nombre_moneda=valor_moneda)
    valor = moneda_valor[0].equivalente_peso_mx
    nomenclatura = moneda_valor[0].nomencaltura

    opcion = ElementosPagina.objects.get(id_elementoPagina=1)
    apro = opcion.aprobacion_cursos

    if apro == 1:
        cursos_recientes_slider = Curso.objects.order_by('-fecha_registro').filter(statusC=1, aprobado=1)[:10]
    else:
        cursos_recientes_slider = Curso.objects.order_by('-fecha_registro').filter(statusC=1)[:10]

    categorias_cursos = CursoCategoria.objects.all()
    monedas = Moneda.objects.filter(statusM=1)

    entradas_blog_footer = EntradasBlog.objects.order_by('-fecha_posteo')[:3]

    #Empieza consulta de transmision
    horas = datetime.now()

    horamas = horas + timedelta(hours=1)

    horamass = horamas.time()

    horamenos = horas + timedelta(hours=-1)

    horamenoss = horamenos.time()

    cadena1 = str(horamenoss)
    cadena2 = str(horamass)

    fechahoy = date.today()

    begin = datetime.strptime(cadena1, '%H:%M:%S.%f').time()
    end = datetime.strptime(cadena2, '%H:%M:%S.%f').time()

    Ctransmision = TransmisionesVivo.objects.filter(fecha_transmision=fechahoy, hora_transmision__range=[begin, end]).order_by('hora_transmision')[:1]

    Evivo = ""

    if Ctransmision:
        Evivo = "True"
    else:
        Evivo = "False"
    #Termina Consulta Transmision


    entradad = EntradasBlog.objects.all()
    paginator = Paginator(entradad, 9)

    page_number = request.GET.get('page')
    entrada = paginator.get_page(page_number)


    contexto = {'entradas':entrada,'categorias': categorias_cursos,'authenticate': autenticado,
        'user': id_usuario, 'type_user': tipo_usuario, 'num_cursos_lista' : cursos_lista_deseos,
        'nomenclatura': nomenclatura, 'Monedas': monedas, 'MonedaSeleccionada':valor_moneda,
        'cursos_recientes_slider': cursos_recientes_slider, 'valor': valor,'entradas_blog_footer': entradas_blog_footer,
        'Evivo': Evivo}

    return render (request, 'Principal/blog.html', contexto)


def blog_post(request, id):


    id_usuario =  ""
    tipo_usuario = ""
    authenticated = ""
    cursos_lista_deseos = 0
    if request.user.is_authenticated:
        authenticated = "authenticated"
        if request.user.tipo_usuario == 3:
            id_usuario =  str(request.user.id_relacionado)
            tipo_usuario = str(request.user.tipo_usuario)
            lista_deseos_consulta = Lista_Deseos.objects.filter(id_alumno=id_usuario, statusLD=1)
            cursos_lista_deseos = lista_deseos_consulta.count()
        else:
            id_usuario =  ""
            tipo_usuario = ""

    moneda(request)
    verificar_moneda(request)

    valor_moneda = request.session['moneda']

    moneda_valor = Moneda.objects.filter(nombre_moneda=valor_moneda)
    valor = moneda_valor[0].equivalente_peso_mx
    nomenclatura = moneda_valor[0].nomencaltura

    opcion = ElementosPagina.objects.get(id_elementoPagina=1)
    apro = opcion.aprobacion_cursos

    if apro == 1:
        cursos_recientes_slider = Curso.objects.order_by('-fecha_registro').filter(statusC=1, aprobado=1)[:10]
    else:
        cursos_recientes_slider = Curso.objects.order_by('-fecha_registro').filter(statusC=1)[:10]

    categorias_cursos = CursoCategoria.objects.all()
    monedas = Moneda.objects.filter(statusM=1)

    entradas_blog_footer = EntradasBlog.objects.order_by('-fecha_posteo')[:3]


    #Empieza consulta de transmision
    horas = datetime.now()

    horamas = horas + timedelta(hours=1)

    horamass = horamas.time()

    horamenos = horas + timedelta(hours=-1)

    horamenoss = horamenos.time()

    cadena1 = str(horamenoss)
    cadena2 = str(horamass)

    fechahoy = date.today()

    begin = datetime.strptime(cadena1, '%H:%M:%S.%f').time()
    end = datetime.strptime(cadena2, '%H:%M:%S.%f').time()

    Ctransmision = TransmisionesVivo.objects.filter(fecha_transmision=fechahoy, hora_transmision__range=[begin, end]).order_by('hora_transmision')[:1]

    Evivo = ""

    if Ctransmision:
        Evivo = "True"
    else:
        Evivo = "False"
    #Termina Consulta Transmision


    idpost = id

    eb = EntradasBlog.objects.get(id_entrada=idpost)
    num = eb.no_vistas
    suma = num + 1
    eb.no_vistas = suma
    eb.save()


    if request.user.is_authenticated:

        if request.user.tipo_usuario == 3:

            idusuario = request.user.id_relacionado
            autenticado = "True"

        else:
            idusuario = 0
            autenticado = "False"
    else:

        autenticado = "False"


    entrada = EntradasBlog.objects.filter(id_entrada=idpost)
    comentario = ComentariosEntrada.objects.filter(id_entradaR=idpost)

    nocomentarios = ComentariosEntrada.objects.filter(id_entradaR=idpost).count()

    filtro = ComentariosEntrada.objects.filter(id_entradaR=idpost).values('id_alumno_comento')

    alumno = Alumno.objects.filter(id_alumno__in=filtro)


    contexto = {'entradas':entrada, 'comentarios':comentario, 'alumnos':alumno,
        'autenticado':autenticado, 'nocomentarios':nocomentarios,
        'categorias': categorias_cursos,'authenticate': authenticated,
        'user': id_usuario, 'type_user': tipo_usuario, 'num_cursos_lista' : cursos_lista_deseos,
        'nomenclatura': nomenclatura, 'Monedas': monedas, 'MonedaSeleccionada':valor_moneda,
        'cursos_recientes_slider': cursos_recientes_slider, 'valor': valor,'entradas_blog_footer': entradas_blog_footer,
        'Evivo': Evivo}

    return render (request, 'Principal/blog-post.html', contexto)


def reaccionar(request, id, id2):


    id_usuario =  ""
    tipo_usuario = ""
    autenticado = ""
    cursos_lista_deseos = 0
    if request.user.is_authenticated:
        autenticado = "authenticated"
        if request.user.tipo_usuario == 3:
            id_usuario =  str(request.user.id_relacionado)
            tipo_usuario = str(request.user.tipo_usuario)
            lista_deseos_consulta = Lista_Deseos.objects.filter(id_alumno=id_usuario, statusLD=1)
            cursos_lista_deseos = lista_deseos_consulta.count()
        else:
            id_usuario =  ""
            tipo_usuario = ""

    moneda(request)
    verificar_moneda(request)

    valor_moneda = request.session['moneda']

    moneda_valor = Moneda.objects.filter(nombre_moneda=valor_moneda)
    valor = moneda_valor[0].equivalente_peso_mx
    nomenclatura = moneda_valor[0].nomencaltura

    opcion = ElementosPagina.objects.get(id_elementoPagina=1)
    apro = opcion.aprobacion_cursos

    if apro == 1:
        cursos_recientes_slider = Curso.objects.order_by('-fecha_registro').filter(statusC=1, aprobado=1)[:10]
    else:
        cursos_recientes_slider = Curso.objects.order_by('-fecha_registro').filter(statusC=1)[:10]

    categorias_cursos = CursoCategoria.objects.all()
    monedas = Moneda.objects.filter(statusM=1)

    entradas_blog_footer = EntradasBlog.objects.order_by('-fecha_posteo')[:3]

    #Empieza consulta de transmision
    horas = datetime.now()

    horamas = horas + timedelta(hours=1)

    horamass = horamas.time()

    horamenos = horas + timedelta(hours=-1)

    horamenoss = horamenos.time()

    cadena1 = str(horamenoss)
    cadena2 = str(horamass)

    fechahoy = date.today()

    begin = datetime.strptime(cadena1, '%H:%M:%S.%f').time()
    end = datetime.strptime(cadena2, '%H:%M:%S.%f').time()

    Ctransmision = TransmisionesVivo.objects.filter(fecha_transmision=fechahoy, hora_transmision__range=[begin, end]).order_by('hora_transmision')[:1]

    Evivo = ""

    if Ctransmision:
        Evivo = "True"
    else:
        Evivo = "False"
    #Termina Consulta Transmision



    identrada = id
    tiporeaccion = id2

    if tiporeaccion == 1:

        eb = EntradasBlog.objects.get(id_entrada=identrada)
        num = eb.no_me_gusta
        suma = num + 1
        eb.no_me_gusta = suma
        eb.save()

    elif tiporeaccion == 2:

        eb = EntradasBlog.objects.get(id_entrada=identrada)
        num = eb.no_me_encanta
        suma = num + 1
        eb.no_me_encanta = suma
        eb.save()

    elif tiporeaccion == 3:

        eb = EntradasBlog.objects.get(id_entrada=identrada)
        num = eb.no_me_impresiona
        suma = num + 1
        eb.no_me_impresiona = suma
        eb.save()

    else:

        eb = EntradasBlog.objects.get(id_entrada=identrada)
        num = eb.no_me_risa
        suma = num + 1
        eb.no_me_risa = suma
        eb.save()

    entrada = EntradasBlog.objects.filter(id_entrada=identrada)


    contexto = {'entradas':entrada,'categorias': categorias_cursos,'authenticate': autenticado,
        'user': id_usuario, 'type_user': tipo_usuario, 'num_cursos_lista' : cursos_lista_deseos,
        'nomenclatura': nomenclatura, 'Monedas': monedas, 'MonedaSeleccionada':valor_moneda,
        'cursos_recientes_slider': cursos_recientes_slider, 'valor': valor,'entradas_blog_footer': entradas_blog_footer,
        'Evivo': Evivo}

    return render(request, 'Principal/reacciones.html', contexto)




@csrf_exempt
@login_required(login_url='/iniciar_sesion/')
@user_passes_test(identificar_estudiante, login_url='/iniciar_sesion/')
def publicar_comentario(request, id):

    if request.method == "POST":

        comentarioG = request.POST["comentario"]
        identrada = id
        idalumno = request.user.id_relacionado

        come = ComentariosEntrada(id_entradaR=identrada, id_alumno_comento=idalumno,
        comentario=comentarioG)
        come.save()

        ebl = EntradasBlog.objects.get(id_entrada=identrada)
        val = ebl.no_comentarios
        suma = val + 1
        ebl.no_comentarios = suma
        ebl.save()


        comentario = ComentariosEntrada.objects.filter(id_entradaR=identrada)

        nocomentarios = ComentariosEntrada.objects.filter(id_entradaR=identrada).count()

        filtro = ComentariosEntrada.objects.filter(id_entradaR=identrada).values('id_alumno_comento')

        alumno = Alumno.objects.filter(id_alumno__in=filtro)

        contexto = {'comentarios':comentario, 'alumnos':alumno,
        'nocomentarios':nocomentarios}

        ruta = "/blog-post/" + str(identrada)
        #return render(request, 'Principal/comentarios.html', contexto)
        return redirect(ruta)





def cambio_moneda(request):
    if request.method == "POST":
        moneda = request.POST.get('moneda')
        moneda_consultar = Moneda.objects.filter(nombre_moneda=moneda)
        if moneda_consultar:
            date = dt.datetime.now()
            if moneda_consultar[0].fecha_actualizar == date.date():
                request.session['moneda'] = moneda_consultar[0].nombre_moneda
            else:
                api_key = 'GF3SFCZCOCGIHSGA'

                base_url = 'https://www.alphavantage.co/query?function=CURRENCY_EXCHANGE_RATE'
                from_c = 'MXN'
                to_c = moneda_consultar[0].nomencaltura
                main_url = base_url + '&from_currency=' + from_c + '&to_currency='+ to_c + '&apikey=' + api_key
                response = requests.get(main_url)
                result = response.json()
                key = result['Realtime Currency Exchange Rate']
                rate = key['5. Exchange Rate']
                Moneda.objects.filter(id_moneda=moneda_consultar[0].id_moneda).update(equivalente_peso_mx=rate, fecha_actualizar=date, hora_actualizar=date)
                request.session['moneda'] = moneda_consultar[0].nombre_moneda
        else:
            request.session['moneda'] = "Peso mexicano"
    return redirect('/index/')



def mapa_sitio(request):


    id_usuario =  ""
    tipo_usuario = ""
    autenticado = ""
    cursos_lista_deseos = 0
    if request.user.is_authenticated:
        autenticado = "authenticated"
        if request.user.tipo_usuario == 3:
            id_usuario =  str(request.user.id_relacionado)
            tipo_usuario = str(request.user.tipo_usuario)
            lista_deseos_consulta = Lista_Deseos.objects.filter(id_alumno=id_usuario, statusLD=1)
            cursos_lista_deseos = lista_deseos_consulta.count()
        else:
            id_usuario =  ""
            tipo_usuario = ""

    moneda(request)
    verificar_moneda(request)

    valor_moneda = request.session['moneda']

    moneda_valor = Moneda.objects.filter(nombre_moneda=valor_moneda)
    valor = moneda_valor[0].equivalente_peso_mx
    nomenclatura = moneda_valor[0].nomencaltura

    opcion = ElementosPagina.objects.get(id_elementoPagina=1)
    apro = opcion.aprobacion_cursos

    if apro == 1:
        cursos_recientes_slider = Curso.objects.order_by('-fecha_registro').filter(statusC=1, aprobado=1)[:10]
    else:
        cursos_recientes_slider = Curso.objects.order_by('-fecha_registro').filter(statusC=1)[:10]

    categorias_cursos = CursoCategoria.objects.all()
    monedas = Moneda.objects.filter(statusM=1)

    entradas_blog_footer = EntradasBlog.objects.order_by('-fecha_posteo')[:3]

    #Empieza consulta de transmision
    horas = datetime.now()

    horamas = horas + timedelta(hours=1)

    horamass = horamas.time()

    horamenos = horas + timedelta(hours=-1)

    horamenoss = horamenos.time()

    cadena1 = str(horamenoss)
    cadena2 = str(horamass)

    fechahoy = date.today()

    begin = datetime.strptime(cadena1, '%H:%M:%S.%f').time()
    end = datetime.strptime(cadena2, '%H:%M:%S.%f').time()

    Ctransmision = TransmisionesVivo.objects.filter(fecha_transmision=fechahoy, hora_transmision__range=[begin, end]).order_by('hora_transmision')[:1]

    Evivo = ""

    if Ctransmision:
        Evivo = "True"
    else:
        Evivo = "False"
    #Termina Consulta Transmision

    contexto = {'categorias': categorias_cursos,'authenticate': autenticado,
        'user': id_usuario, 'type_user': tipo_usuario, 'num_cursos_lista' : cursos_lista_deseos,
        'nomenclatura': nomenclatura, 'Monedas': monedas, 'MonedaSeleccionada':valor_moneda,
        'cursos_recientes_slider': cursos_recientes_slider, 'valor': valor,'entradas_blog_footer': entradas_blog_footer,
        'Evivo': Evivo}

    return render(request, "Principal/mapa-sitio.html", contexto)




def politica_privacidad(request):

    id_usuario =  ""
    tipo_usuario = ""
    autenticado = ""
    cursos_lista_deseos = 0
    if request.user.is_authenticated:
        autenticado = "authenticated"
        if request.user.tipo_usuario == 3:
            id_usuario =  str(request.user.id_relacionado)
            tipo_usuario = str(request.user.tipo_usuario)
            lista_deseos_consulta = Lista_Deseos.objects.filter(id_alumno=id_usuario, statusLD=1)
            cursos_lista_deseos = lista_deseos_consulta.count()
        else:
            id_usuario =  ""
            tipo_usuario = ""

    moneda(request)
    verificar_moneda(request)

    valor_moneda = request.session['moneda']

    moneda_valor = Moneda.objects.filter(nombre_moneda=valor_moneda)
    valor = moneda_valor[0].equivalente_peso_mx
    nomenclatura = moneda_valor[0].nomencaltura

    opcion = ElementosPagina.objects.get(id_elementoPagina=1)
    apro = opcion.aprobacion_cursos

    if apro == 1:
        cursos_recientes_slider = Curso.objects.order_by('-fecha_registro').filter(statusC=1, aprobado=1)[:10]
    else:
        cursos_recientes_slider = Curso.objects.order_by('-fecha_registro').filter(statusC=1)[:10]

    categorias_cursos = CursoCategoria.objects.all()
    monedas = Moneda.objects.filter(statusM=1)

    entradas_blog_footer = EntradasBlog.objects.order_by('-fecha_posteo')[:3]

    if apro == 1:
        mas_valorados_cursos = Curso.objects.filter(valoracion=5, statusC=1, aprobado=1)[:9]
    else:
        mas_valorados_cursos = Curso.objects.filter(valoracion=5, statusC=1)[:9]

    #Empieza consulta de transmision
    horas = datetime.now()

    horamas = horas + timedelta(hours=1)

    horamass = horamas.time()

    horamenos = horas + timedelta(hours=-1)

    horamenoss = horamenos.time()

    cadena1 = str(horamenoss)
    cadena2 = str(horamass)

    fechahoy = date.today()

    begin = datetime.strptime(cadena1, '%H:%M:%S.%f').time()
    end = datetime.strptime(cadena2, '%H:%M:%S.%f').time()

    Ctransmision = TransmisionesVivo.objects.filter(fecha_transmision=fechahoy, hora_transmision__range=[begin, end]).order_by('hora_transmision')[:1]

    Evivo = ""

    if Ctransmision:
        Evivo = "True"
    else:
        Evivo = "False"
    #Termina Consulta Transmision

    texto_politica_privacidad_consulta = TextosPagina.objects.filter(id_empresaR=1, identificador="Politica de privacidad")

    if texto_politica_privacidad_consulta:
        texto_politica_privacidad = texto_politica_privacidad_consulta[0]
    else:
        texto_politica_privacidad = []

    contexto = {'mas_valorados_cursos': mas_valorados_cursos,'texto_politica_privacidad': texto_politica_privacidad,'categorias': categorias_cursos,'authenticate': autenticado,
        'user': id_usuario, 'type_user': tipo_usuario, 'num_cursos_lista' : cursos_lista_deseos,
        'nomenclatura': nomenclatura, 'Monedas': monedas, 'MonedaSeleccionada':valor_moneda,
        'cursos_recientes_slider': cursos_recientes_slider, 'valor': valor,'entradas_blog_footer': entradas_blog_footer,
        'Evivo': Evivo}

    return render(request, "Principal/politica-privacidad.html", contexto)



def terminos_condiciones(request):

    id_usuario =  ""
    tipo_usuario = ""
    autenticado = ""
    cursos_lista_deseos = 0
    if request.user.is_authenticated:
        autenticado = "authenticated"
        if request.user.tipo_usuario == 3:
            id_usuario =  str(request.user.id_relacionado)
            tipo_usuario = str(request.user.tipo_usuario)
            lista_deseos_consulta = Lista_Deseos.objects.filter(id_alumno=id_usuario, statusLD=1)
            cursos_lista_deseos = lista_deseos_consulta.count()
        else:
            id_usuario =  ""
            tipo_usuario = ""

    moneda(request)
    verificar_moneda(request)

    valor_moneda = request.session['moneda']

    moneda_valor = Moneda.objects.filter(nombre_moneda=valor_moneda)
    valor = moneda_valor[0].equivalente_peso_mx
    nomenclatura = moneda_valor[0].nomencaltura

    opcion = ElementosPagina.objects.get(id_elementoPagina=1)
    apro = opcion.aprobacion_cursos

    if apro == 1:
        cursos_recientes_slider = Curso.objects.order_by('-fecha_registro').filter(statusC=1, aprobado=1)[:10]
    else:
        cursos_recientes_slider = Curso.objects.order_by('-fecha_registro').filter(statusC=1)[:10]

    categorias_cursos = CursoCategoria.objects.all()
    monedas = Moneda.objects.filter(statusM=1)

    entradas_blog_footer = EntradasBlog.objects.order_by('-fecha_posteo')[:3]

    if apro == 1:
        mas_valorados_cursos = Curso.objects.filter(valoracion=5, statusC=1, aprobado=1)[:9]
    else:
        mas_valorados_cursos = Curso.objects.filter(valoracion=5, statusC=1)[:9]

    #Empieza consulta de transmision
    horas = datetime.now()

    horamas = horas + timedelta(hours=1)

    horamass = horamas.time()

    horamenos = horas + timedelta(hours=-1)

    horamenoss = horamenos.time()

    cadena1 = str(horamenoss)
    cadena2 = str(horamass)

    fechahoy = date.today()

    begin = datetime.strptime(cadena1, '%H:%M:%S.%f').time()
    end = datetime.strptime(cadena2, '%H:%M:%S.%f').time()

    Ctransmision = TransmisionesVivo.objects.filter(fecha_transmision=fechahoy, hora_transmision__range=[begin, end]).order_by('hora_transmision')[:1]

    Evivo = ""

    if Ctransmision:
        Evivo = "True"
    else:
        Evivo = "False"
    #Termina Consulta Transmision

    texto_terminos_condiciones_consulta = TextosPagina.objects.filter(id_empresaR=1, identificador="Terminos y condiciones")

    if texto_terminos_condiciones_consulta:
        texto_terminos_condiciones = texto_terminos_condiciones_consulta[0]
    else:
        texto_terminos_condiciones = []

    contexto = {'mas_valorados_cursos': mas_valorados_cursos,'texto_terminos_condiciones':texto_terminos_condiciones,'categorias': categorias_cursos,'authenticate': autenticado,
        'user': id_usuario, 'type_user': tipo_usuario, 'num_cursos_lista' : cursos_lista_deseos,
        'nomenclatura': nomenclatura, 'Monedas': monedas, 'MonedaSeleccionada':valor_moneda,
        'cursos_recientes_slider': cursos_recientes_slider, 'valor': valor,'entradas_blog_footer': entradas_blog_footer,
        'Evivo': Evivo}

    return render(request, "Principal/terminos-condiciones.html", contexto)



def sobre_nosotros(request):

    id_usuario =  ""
    tipo_usuario = ""
    autenticado = ""
    cursos_lista_deseos = 0
    if request.user.is_authenticated:
        autenticado = "authenticated"
        if request.user.tipo_usuario == 3:
            id_usuario =  str(request.user.id_relacionado)
            tipo_usuario = str(request.user.tipo_usuario)
            lista_deseos_consulta = Lista_Deseos.objects.filter(id_alumno=id_usuario, statusLD=1)
            cursos_lista_deseos = lista_deseos_consulta.count()
        else:
            id_usuario =  ""
            tipo_usuario = ""

    moneda(request)
    verificar_moneda(request)

    valor_moneda = request.session['moneda']

    moneda_valor = Moneda.objects.filter(nombre_moneda=valor_moneda)
    valor = moneda_valor[0].equivalente_peso_mx
    nomenclatura = moneda_valor[0].nomencaltura

    opcion = ElementosPagina.objects.get(id_elementoPagina=1)
    apro = opcion.aprobacion_cursos

    if apro == 1:
        cursos_recientes_slider = Curso.objects.order_by('-fecha_registro').filter(statusC=1, aprobado=1)[:10]
    else:
        cursos_recientes_slider = Curso.objects.order_by('-fecha_registro').filter(statusC=1)[:10]

    categorias_cursos = CursoCategoria.objects.all()
    monedas = Moneda.objects.filter(statusM=1)

    entradas_blog_footer = EntradasBlog.objects.order_by('-fecha_posteo')[:3]


    #Empieza consulta de transmision
    horas = datetime.now()

    horamas = horas + timedelta(hours=1)

    horamass = horamas.time()

    horamenos = horas + timedelta(hours=-1)

    horamenoss = horamenos.time()

    cadena1 = str(horamenoss)
    cadena2 = str(horamass)

    fechahoy = date.today()

    begin = datetime.strptime(cadena1, '%H:%M:%S.%f').time()
    end = datetime.strptime(cadena2, '%H:%M:%S.%f').time()

    Ctransmision = TransmisionesVivo.objects.filter(fecha_transmision=fechahoy, hora_transmision__range=[begin, end]).order_by('hora_transmision')[:1]

    Evivo = ""

    if Ctransmision:
        Evivo = "True"
    else:
        Evivo = "False"
    #Termina Consulta Transmision

    if apro == 1:
        mas_valorados_cursos = Curso.objects.filter(valoracion=5, statusC=1, aprobado=1)[:9]
    else:
        mas_valorados_cursos = Curso.objects.filter(valoracion=5, statusC=1)[:9]

    texto_sobre_nosotros_consulta = TextosPagina.objects.filter(id_empresaR=1, identificador="Sobre nosotros")

    if texto_sobre_nosotros_consulta:
        texto_sobre_nosotros = texto_sobre_nosotros_consulta[0]
    else:
        texto_sobre_nosotros = []


    contexto = {'mas_valorados_cursos': mas_valorados_cursos, 'texto_sobre_nosotros':texto_sobre_nosotros,'categorias': categorias_cursos,'authenticate': autenticado,
        'user': id_usuario, 'type_user': tipo_usuario, 'num_cursos_lista' : cursos_lista_deseos,
        'nomenclatura': nomenclatura, 'Monedas': monedas, 'MonedaSeleccionada':valor_moneda,
        'cursos_recientes_slider': cursos_recientes_slider, 'valor': valor,'entradas_blog_footer': entradas_blog_footer,
        'Evivo': Evivo}

    return render(request, "Principal/sobre-nosotros.html", contexto)



def metodos_pago(request):

    id_usuario =  ""
    tipo_usuario = ""
    autenticado = ""
    cursos_lista_deseos = 0
    if request.user.is_authenticated:
        autenticado = "authenticated"
        if request.user.tipo_usuario == 3:
            id_usuario =  str(request.user.id_relacionado)
            tipo_usuario = str(request.user.tipo_usuario)
            lista_deseos_consulta = Lista_Deseos.objects.filter(id_alumno=id_usuario, statusLD=1)
            cursos_lista_deseos = lista_deseos_consulta.count()
        else:
            id_usuario =  ""
            tipo_usuario = ""

    moneda(request)
    verificar_moneda(request)

    valor_moneda = request.session['moneda']

    moneda_valor = Moneda.objects.filter(nombre_moneda=valor_moneda)
    valor = moneda_valor[0].equivalente_peso_mx
    nomenclatura = moneda_valor[0].nomencaltura

    opcion = ElementosPagina.objects.get(id_elementoPagina=1)
    apro = opcion.aprobacion_cursos

    if apro == 1:
        cursos_recientes_slider = Curso.objects.order_by('-fecha_registro').filter(statusC=1, aprobado=1)[:10]
    else:
        cursos_recientes_slider = Curso.objects.order_by('-fecha_registro').filter(statusC=1)[:10]

    categorias_cursos = CursoCategoria.objects.all()
    monedas = Moneda.objects.filter(statusM=1)

    entradas_blog_footer = EntradasBlog.objects.order_by('-fecha_posteo')[:3]

    #Empieza consulta de transmision
    horas = datetime.now()

    horamas = horas + timedelta(hours=1)

    horamass = horamas.time()

    horamenos = horas + timedelta(hours=-1)

    horamenoss = horamenos.time()

    cadena1 = str(horamenoss)
    cadena2 = str(horamass)

    fechahoy = date.today()

    begin = datetime.strptime(cadena1, '%H:%M:%S.%f').time()
    end = datetime.strptime(cadena2, '%H:%M:%S.%f').time()

    Ctransmision = TransmisionesVivo.objects.filter(fecha_transmision=fechahoy, hora_transmision__range=[begin, end]).order_by('hora_transmision')[:1]

    Evivo = ""

    if Ctransmision:
        Evivo = "True"
    else:
        Evivo = "False"
    #Termina Consulta Transmision

    if apro == 1:
        mas_valorados_cursos = Curso.objects.filter(valoracion=5, statusC=1, aprobado=1)[:9]
    else:
        mas_valorados_cursos = Curso.objects.filter(valoracion=5, statusC=1)[:9]

    texto_metodo_pago_consulta = TextosPagina.objects.filter(id_empresaR=1, identificador="Metodo de pago")

    if texto_metodo_pago_consulta:
        texto_metodo_pago = texto_metodo_pago_consulta[0]
    else:
        texto_metodo_pago = []

    contexto = {'mas_valorados_cursos': mas_valorados_cursos, 'texto_metodo_pago':texto_metodo_pago,'categorias': categorias_cursos,'authenticate': autenticado,
        'user': id_usuario, 'type_user': tipo_usuario, 'num_cursos_lista' : cursos_lista_deseos,
        'nomenclatura': nomenclatura, 'Monedas': monedas, 'MonedaSeleccionada':valor_moneda,
        'cursos_recientes_slider': cursos_recientes_slider, 'valor': valor,'entradas_blog_footer': entradas_blog_footer,
        'Evivo': Evivo}

    return render(request, "Principal/metodos-pago.html", contexto)


@login_required(login_url='/iniciar_sesion/')
def detalle_compra(request):

    cart = Cart(request.session,0)
    cursos_ar = []
    for items in cart.items:
        print(items.curso.nombreC)
        cursos_ar.append(items.curso.nombreC)

    total_compra_detalle = cart.total

    cart.clear()

    id_usuario =  ""
    tipo_usuario = ""
    autenticado = ""
    cursos_lista_deseos = 0
    if request.user.is_authenticated:
        autenticado = "authenticated"
        if request.user.tipo_usuario == 3:
            id_usuario =  str(request.user.id_relacionado)
            tipo_usuario = str(request.user.tipo_usuario)
            lista_deseos_consulta = Lista_Deseos.objects.filter(id_alumno=id_usuario, statusLD=1)
            cursos_lista_deseos = lista_deseos_consulta.count()
        else:
            id_usuario =  ""
            tipo_usuario = ""

    moneda(request)
    verificar_moneda(request)

    valor_moneda = request.session['moneda']

    moneda_valor = Moneda.objects.filter(nombre_moneda=valor_moneda)
    valor = moneda_valor[0].equivalente_peso_mx
    nomenclatura = moneda_valor[0].nomencaltura

    opcion = ElementosPagina.objects.get(id_elementoPagina=1)
    apro = opcion.aprobacion_cursos

    if apro == 1:
        cursos_recientes_slider = Curso.objects.order_by('-fecha_registro').filter(statusC=1, aprobado=1)[:10]
    else:
        cursos_recientes_slider = Curso.objects.order_by('-fecha_registro').filter(statusC=1)[:10]

    categorias_cursos = CursoCategoria.objects.all()
    monedas = Moneda.objects.filter(statusM=1)

    entradas_blog_footer = EntradasBlog.objects.order_by('-fecha_posteo')[:3]

    #Empieza consulta de transmision
    horas = datetime.now()

    horamas = horas + timedelta(hours=1)

    horamass = horamas.time()

    horamenos = horas + timedelta(hours=-1)

    horamenoss = horamenos.time()

    cadena1 = str(horamenoss)
    cadena2 = str(horamass)

    fechahoy = date.today()

    begin = datetime.strptime(cadena1, '%H:%M:%S.%f').time()
    end = datetime.strptime(cadena2, '%H:%M:%S.%f').time()

    Ctransmision = TransmisionesVivo.objects.filter(fecha_transmision=fechahoy, hora_transmision__range=[begin, end]).order_by('hora_transmision')[:1]

    Evivo = ""

    if Ctransmision:
        Evivo = "True"
    else:
        Evivo = "False"
    #Termina Consulta Transmision

    if apro == 1:
        mas_valorados_cursos = Curso.objects.filter(valoracion=5, statusC=1, aprobado=1)[:9]
    else:
        mas_valorados_cursos = Curso.objects.filter(valoracion=5, statusC=1)[:9]



    contexto = {'mas_valorados_cursos': mas_valorados_cursos,'categorias': categorias_cursos,'authenticate': autenticado,
        'user': id_usuario, 'type_user': tipo_usuario, 'num_cursos_lista' : cursos_lista_deseos,
        'nomenclatura': nomenclatura, 'Monedas': monedas, 'MonedaSeleccionada':valor_moneda,
        'cursos_recientes_slider': cursos_recientes_slider, 'valor': valor, 'cursos_detalle': cursos_ar,
        'total_detalle': total_compra_detalle,'entradas_blog_footer': entradas_blog_footer, 'Evivo': Evivo}

    return render(request, "Principal/detalle-compra.html", contexto)



def entrega(request):

    id_usuario =  ""
    tipo_usuario = ""
    autenticado = ""
    cursos_lista_deseos = 0
    if request.user.is_authenticated:
        autenticado = "authenticated"
        if request.user.tipo_usuario == 3:
            id_usuario =  str(request.user.id_relacionado)
            tipo_usuario = str(request.user.tipo_usuario)
            lista_deseos_consulta = Lista_Deseos.objects.filter(id_alumno=id_usuario, statusLD=1)
            cursos_lista_deseos = lista_deseos_consulta.count()
        else:
            id_usuario =  ""
            tipo_usuario = ""

    moneda(request)
    verificar_moneda(request)

    valor_moneda = request.session['moneda']

    moneda_valor = Moneda.objects.filter(nombre_moneda=valor_moneda)
    valor = moneda_valor[0].equivalente_peso_mx
    nomenclatura = moneda_valor[0].nomencaltura

    opcion = ElementosPagina.objects.get(id_elementoPagina=1)
    apro = opcion.aprobacion_cursos

    if apro == 1:
        cursos_recientes_slider = Curso.objects.order_by('-fecha_registro').filter(statusC=1, aprobado=1)[:10]
    else:
        cursos_recientes_slider = Curso.objects.order_by('-fecha_registro').filter(statusC=1)[:10]

    categorias_cursos = CursoCategoria.objects.all()
    monedas = Moneda.objects.filter(statusM=1)

    entradas_blog_footer = EntradasBlog.objects.order_by('-fecha_posteo')[:3]

    #Empieza consulta de transmision
    horas = datetime.now()

    horamas = horas + timedelta(hours=1)

    horamass = horamas.time()

    horamenos = horas + timedelta(hours=-1)

    horamenoss = horamenos.time()

    cadena1 = str(horamenoss)
    cadena2 = str(horamass)

    fechahoy = date.today()

    begin = datetime.strptime(cadena1, '%H:%M:%S.%f').time()
    end = datetime.strptime(cadena2, '%H:%M:%S.%f').time()

    Ctransmision = TransmisionesVivo.objects.filter(fecha_transmision=fechahoy, hora_transmision__range=[begin, end]).order_by('hora_transmision')[:1]

    Evivo = ""

    if Ctransmision:
        Evivo = "True"
    else:
        Evivo = "False"
    #Termina Consulta Transmision

    if apro == 1:
        mas_valorados_cursos = Curso.objects.filter(valoracion=5, statusC=1, aprobado=1)[:9]
    else:
        mas_valorados_cursos = Curso.objects.filter(valoracion=5, statusC=1)[:9]



    contexto = {'mas_valorados_cursos': mas_valorados_cursos,'categorias': categorias_cursos,'authenticate': autenticado,
        'user': id_usuario, 'type_user': tipo_usuario, 'num_cursos_lista' : cursos_lista_deseos,
        'nomenclatura': nomenclatura, 'Monedas': monedas, 'MonedaSeleccionada':valor_moneda,
        'cursos_recientes_slider': cursos_recientes_slider, 'valor': valor,'entradas_blog_footer': entradas_blog_footer,
        'Evivo': Evivo}

    return render(request, "Principal/entrega.html", contexto)







def certificado_regalo(request):


    id_usuario =  ""
    tipo_usuario = ""
    autenticado = ""
    cursos_lista_deseos = 0
    if request.user.is_authenticated:
        autenticado = "authenticated"
        if request.user.tipo_usuario == 3:
            id_usuario =  str(request.user.id_relacionado)
            tipo_usuario = str(request.user.tipo_usuario)
            lista_deseos_consulta = Lista_Deseos.objects.filter(id_alumno=id_usuario, statusLD=1)
            cursos_lista_deseos = lista_deseos_consulta.count()
        else:
            id_usuario =  ""
            tipo_usuario = ""

    moneda(request)
    verificar_moneda(request)

    valor_moneda = request.session['moneda']

    moneda_valor = Moneda.objects.filter(nombre_moneda=valor_moneda)
    valor = moneda_valor[0].equivalente_peso_mx
    nomenclatura = moneda_valor[0].nomencaltura

    opcion = ElementosPagina.objects.get(id_elementoPagina=1)
    apro = opcion.aprobacion_cursos

    if apro == 1:
        cursos_recientes_slider = Curso.objects.order_by('-fecha_registro').filter(statusC=1, aprobado=1)[:10]
    else:
        cursos_recientes_slider = Curso.objects.order_by('-fecha_registro').filter(statusC=1)[:10]

    categorias_cursos = CursoCategoria.objects.all()
    monedas = Moneda.objects.filter(statusM=1)

    entradas_blog_footer = EntradasBlog.objects.order_by('-fecha_posteo')[:3]

    #Empieza consulta de transmision
    horas = datetime.now()

    horamas = horas + timedelta(hours=1)

    horamass = horamas.time()

    horamenos = horas + timedelta(hours=-1)

    horamenoss = horamenos.time()

    cadena1 = str(horamenoss)
    cadena2 = str(horamass)

    fechahoy = date.today()

    begin = datetime.strptime(cadena1, '%H:%M:%S.%f').time()
    end = datetime.strptime(cadena2, '%H:%M:%S.%f').time()

    Ctransmision = TransmisionesVivo.objects.filter(fecha_transmision=fechahoy, hora_transmision__range=[begin, end]).order_by('hora_transmision')[:1]

    Evivo = ""

    if Ctransmision:
        Evivo = "True"
    else:
        Evivo = "False"
    #Termina Consulta Transmision

    contexto = {'categorias': categorias_cursos,'authenticate': autenticado,
        'user': id_usuario, 'type_user': tipo_usuario, 'num_cursos_lista' : cursos_lista_deseos,
        'nomenclatura': nomenclatura, 'Monedas': monedas, 'MonedaSeleccionada':valor_moneda,
        'cursos_recientes_slider': cursos_recientes_slider, 'valor': valor,'entradas_blog_footer': entradas_blog_footer,
        'Evivo': Evivo}

    return render(request, "Principal/certificado-regalo.html", contexto)



def contactar(request):
    if request.method == "POST":
        nombre = request.POST['nombre_contacto']
        correo = request.POST['email_contacto']
        asunto = request.POST['asunto_contacto']
        mensaje = request.POST['mensaje_contacto']

        '''
        MANDRILL_API_KEY = 'Ya4SqTK0tCvIEq1MSZ7NtQ'
        mandrill_client = mandrill.Mandrill(MANDRILL_API_KEY)
        messageu = { 'from_email': 'hola@kaizen.lat',
          'from_name': 'Kaizen.lat',
          'to': [{
            'email': correo,
            'name': 'hola',
            'type': 'to'
           }],
          'subject': '',
          'text': '¡Hola '+correo+'! Resolveremos tu duda a la brevedad.'
        }

        result_mensaje_usuario = mandrill_client.messages.send(message = messageu)
        '''

        texto = '¡Hola '+correo+'! Resolveremos tu duda a la brevedad.'

        # import file with html content
        html_version = 'Principal/email_general.html'

        html_message = render_to_string(html_version, { 'context': texto, })

        message = EmailMessage('Contacto', html_message, 'hola@seiko.dev', [correo])
        message.content_subtype = 'html'
        message.send()

        '''
        messagek = { 'from_email': 'hola@kaizen.lat',
          'from_name': 'Kaizen.lat',
          'to': [{
            'email': 'hola@kaizen.lat',
            'name': 'hola',
            'type': 'to'
           }],
          'subject': asunto,
          'text': 'Envia el mensaje: '+correo+'     '+mensaje
        }

        result_mensaje_kaizen = mandrill_client.messages.send(message = messagek)
        '''

        texto = 'Envia el mensaje: '+correo+'     '+mensaje
        correo = 'hola@kaizen.lat'

        # import file with html content
        html_version = 'Principal/email_general.html'

        html_message = render_to_string(html_version, { 'context': texto, })

        message = EmailMessage('Contacto', html_message, 'hola@seiko.dev', [correo])
        message.content_subtype = 'html'
        message.send()

        dates = dt.datetime.now()

        Pregunta_usuario.objects.create(nombre=nombre, correo=correo, asunto=asunto, mensaje=mensaje,
            acepta_terminos="si", tipo_pregunta="contacto", curso="", fecha=dates, hora=dates, statusP=1)

    id_usuario =  ""
    tipo_usuario = ""
    autenticado = ""
    cursos_lista_deseos = 0
    if request.user.is_authenticated:
        autenticado = "authenticated"
        if request.user.tipo_usuario == 3:
            id_usuario =  str(request.user.id_relacionado)
            tipo_usuario = str(request.user.tipo_usuario)
            lista_deseos_consulta = Lista_Deseos.objects.filter(id_alumno=id_usuario, statusLD=1)
            cursos_lista_deseos = lista_deseos_consulta.count()
        else:
            id_usuario =  ""
            tipo_usuario = ""

    moneda(request)
    verificar_moneda(request)

    valor_moneda = request.session['moneda']

    moneda_valor = Moneda.objects.filter(nombre_moneda=valor_moneda)
    valor = moneda_valor[0].equivalente_peso_mx
    nomenclatura = moneda_valor[0].nomencaltura

    opcion = ElementosPagina.objects.get(id_elementoPagina=1)
    apro = opcion.aprobacion_cursos

    if apro == 1:
        cursos_recientes_slider = Curso.objects.order_by('-fecha_registro').filter(statusC=1, aprobado=1)[:10]
    else:
        cursos_recientes_slider = Curso.objects.order_by('-fecha_registro').filter(statusC=1)[:10]

    categorias_cursos = CursoCategoria.objects.all()
    monedas = Moneda.objects.filter(statusM=1)

    entradas_blog_footer = EntradasBlog.objects.order_by('-fecha_posteo')[:3]

    #Empieza consulta de transmision
    horas = datetime.now()

    horamas = horas + timedelta(hours=1)

    horamass = horamas.time()

    horamenos = horas + timedelta(hours=-1)

    horamenoss = horamenos.time()

    cadena1 = str(horamenoss)
    cadena2 = str(horamass)

    fechahoy = date.today()

    begin = datetime.strptime(cadena1, '%H:%M:%S.%f').time()
    end = datetime.strptime(cadena2, '%H:%M:%S.%f').time()

    Ctransmision = TransmisionesVivo.objects.filter(fecha_transmision=fechahoy, hora_transmision__range=[begin, end]).order_by('hora_transmision')[:1]

    Evivo = ""

    if Ctransmision:
        Evivo = "True"
    else:
        Evivo = "False"
    #Termina Consulta Transmision

    contexto = {'categorias': categorias_cursos,'authenticate': autenticado,
        'user': id_usuario, 'type_user': tipo_usuario, 'num_cursos_lista' : cursos_lista_deseos,
        'nomenclatura': nomenclatura, 'Monedas': monedas, 'MonedaSeleccionada':valor_moneda,
        'cursos_recientes_slider': cursos_recientes_slider, 'valor': valor,'entradas_blog_footer': entradas_blog_footer,
        'Evivo': Evivo}

    return render(request, "Principal/contactar.html", contexto)




def ayuda(request):
    if request.method == "POST":
        nombre = request.POST['nombre_contacto']
        correo = request.POST['email_contacto']
        asunto = request.POST['asunto_contacto']
        mensaje = request.POST['mensaje_contacto']

        '''
        MANDRILL_API_KEY = 'Ya4SqTK0tCvIEq1MSZ7NtQ'
        mandrill_client = mandrill.Mandrill(MANDRILL_API_KEY)
        messageu = { 'from_email': 'hola@kaizen.lat',
          'from_name': 'Kaizen.lat',
          'to': [{
            'email': correo,
            'name': 'hola',
            'type': 'to'
           }],
          'subject': '',
          'text': '¡Hola '+correo+'! Resolveremos tu duda a la brevedad.'
        }

        result_mensaje_usuario = mandrill_client.messages.send(message = messageu)
        '''

        texto = '¡Hola '+correo+'! Resolveremos tu duda a la brevedad.'

        # import file with html content
        html_version = 'Principal/email_general.html'

        html_message = render_to_string(html_version, { 'context': texto, })

        message = EmailMessage('Contacto', html_message, 'hola@seiko.dev', [correo])
        message.content_subtype = 'html'
        message.send()



        '''
        messagek = { 'from_email': 'hola@kaizen.lat',
          'from_name': 'Kaizen.lat',
          'to': [{
            'email': 'hola@kaizen.lat',
            'name': 'hola',
            'type': 'to'
           }],
          'subject': asunto,
          'text': 'Envia el mensaje: '+correo+'     '+mensaje
        }

        result_mensaje_kaizen = mandrill_client.messages.send(message = messagek)
        '''

        texto = 'Envia el mensaje: '+correo+'     '+mensaje
        correo = 'hola@kaizen.lat'

        # import file with html content
        html_version = 'Principal/email_general.html'

        html_message = render_to_string(html_version, { 'context': texto, })

        message = EmailMessage('Contacto', html_message, 'hola@seiko.dev', [correo])
        message.content_subtype = 'html'
        message.send()

        dates = dt.datetime.now()

        Pregunta_usuario.objects.create(nombre=nombre, correo=correo, asunto=asunto, mensaje=mensaje,
            acepta_terminos="si", tipo_pregunta="contacto", curso="", fecha=dates, hora=dates, statusP=1)

    id_usuario =  ""
    tipo_usuario = ""
    autenticado = ""
    cursos_lista_deseos = 0
    if request.user.is_authenticated:
        autenticado = "authenticated"
        if request.user.tipo_usuario == 3:
            id_usuario =  str(request.user.id_relacionado)
            tipo_usuario = str(request.user.tipo_usuario)
            lista_deseos_consulta = Lista_Deseos.objects.filter(id_alumno=id_usuario, statusLD=1)
            cursos_lista_deseos = lista_deseos_consulta.count()
        else:
            id_usuario =  ""
            tipo_usuario = ""

    moneda(request)
    verificar_moneda(request)

    valor_moneda = request.session['moneda']

    moneda_valor = Moneda.objects.filter(nombre_moneda=valor_moneda)
    valor = moneda_valor[0].equivalente_peso_mx
    nomenclatura = moneda_valor[0].nomencaltura

    opcion = ElementosPagina.objects.get(id_elementoPagina=1)
    apro = opcion.aprobacion_cursos

    if apro == 1:
        cursos_recientes_slider = Curso.objects.order_by('-fecha_registro').filter(statusC=1, aprobado=1)[:10]
    else:
        cursos_recientes_slider = Curso.objects.order_by('-fecha_registro').filter(statusC=1)[:10]

    categorias_cursos = CursoCategoria.objects.all()
    monedas = Moneda.objects.filter(statusM=1)

    entradas_blog_footer = EntradasBlog.objects.order_by('-fecha_posteo')[:3]

    #Empieza consulta de transmision
    horas = datetime.now()

    horamas = horas + timedelta(hours=1)

    horamass = horamas.time()

    horamenos = horas + timedelta(hours=-1)

    horamenoss = horamenos.time()

    cadena1 = str(horamenoss)
    cadena2 = str(horamass)

    fechahoy = date.today()

    begin = datetime.strptime(cadena1, '%H:%M:%S.%f').time()
    end = datetime.strptime(cadena2, '%H:%M:%S.%f').time()

    Ctransmision = TransmisionesVivo.objects.filter(fecha_transmision=fechahoy, hora_transmision__range=[begin, end]).order_by('hora_transmision')[:1]

    Evivo = ""

    if Ctransmision:
        Evivo = "True"
    else:
        Evivo = "False"
    #Termina Consulta Transmision

    texto_ayuda_consulta = TextosPagina.objects.filter(id_empresaR=1, identificador="Ayuda")

    if texto_ayuda_consulta:
        texto_ayuda = texto_ayuda_consulta[0]
    else:
        texto_ayuda = []


    contexto = {'texto_ayuda':texto_ayuda,'categorias': categorias_cursos,'authenticate': autenticado,
        'user': id_usuario, 'type_user': tipo_usuario, 'num_cursos_lista' : cursos_lista_deseos,
        'nomenclatura': nomenclatura, 'Monedas': monedas, 'MonedaSeleccionada':valor_moneda,
        'cursos_recientes_slider': cursos_recientes_slider, 'valor': valor ,'entradas_blog_footer': entradas_blog_footer,
        'Evivo': Evivo}

    return render(request, "Principal/ayuda.html", contexto)





def devoluciones_info(request):
    if request.method == "POST":
        nombre = request.POST['nombre_contacto']
        correo = request.POST['email_contacto']
        asunto = request.POST['asunto_contacto']
        mensaje = request.POST['mensaje_contacto']

        '''
        MANDRILL_API_KEY = 'Ya4SqTK0tCvIEq1MSZ7NtQ'
        mandrill_client = mandrill.Mandrill(MANDRILL_API_KEY)
        messageu = { 'from_email': 'hola@kaizen.lat',
          'from_name': 'Kaizen.lat',
          'to': [{
            'email': correo,
            'name': 'hola',
            'type': 'to'
           }],
          'subject': '',
          'text': '¡Hola '+correo+'! Resolveremos tu duda a la brevedad.'
        }

        result_mensaje_usuario = mandrill_client.messages.send(message = messageu)
        '''

        texto = '¡Hola '+correo+'! Resolveremos tu duda a la brevedad.'

        # import file with html content
        html_version = 'Principal/email_general.html'

        html_message = render_to_string(html_version, { 'context': texto, })

        message = EmailMessage('Contacto', html_message, 'hola@seiko.dev', [correo])
        message.content_subtype = 'html'
        message.send()

        '''
        messagek = { 'from_email': 'hola@kaizen.lat',
          'from_name': 'Kaizen.lat',
          'to': [{
            'email': 'hola@kaizen.lat',
            'name': 'hola',
            'type': 'to'
           }],
          'subject': asunto,
          'text': 'Envia el mensaje: '+correo+'     '+mensaje
        }

        result_mensaje_kaizen = mandrill_client.messages.send(message = messagek)
        '''

        texto = 'Envia el mensaje: '+correo+'     '+mensaje
        correo = 'hola@kaizen.lat'

        # import file with html content
        html_version = 'Principal/email_general.html'

        html_message = render_to_string(html_version, { 'context': texto, })

        message = EmailMessage('Contacto', html_message, 'hola@seiko.dev', [correo])
        message.content_subtype = 'html'
        message.send()

        dates = dt.datetime.now()

        Pregunta_usuario.objects.create(nombre=nombre, correo=correo, asunto=asunto, mensaje=mensaje,
            acepta_terminos="si", tipo_pregunta="contacto", curso="", fecha=dates, hora=dates, statusP=1)

    id_usuario =  ""
    tipo_usuario = ""
    autenticado = ""
    cursos_lista_deseos = 0
    if request.user.is_authenticated:
        autenticado = "authenticated"
        if request.user.tipo_usuario == 3:
            id_usuario =  str(request.user.id_relacionado)
            tipo_usuario = str(request.user.tipo_usuario)
            lista_deseos_consulta = Lista_Deseos.objects.filter(id_alumno=id_usuario, statusLD=1)
            cursos_lista_deseos = lista_deseos_consulta.count()
        else:
            id_usuario =  ""
            tipo_usuario = ""

    moneda(request)
    verificar_moneda(request)

    valor_moneda = request.session['moneda']

    moneda_valor = Moneda.objects.filter(nombre_moneda=valor_moneda)
    valor = moneda_valor[0].equivalente_peso_mx
    nomenclatura = moneda_valor[0].nomencaltura

    opcion = ElementosPagina.objects.get(id_elementoPagina=1)
    apro = opcion.aprobacion_cursos

    if apro == 1:
        cursos_recientes_slider = Curso.objects.order_by('-fecha_registro').filter(statusC=1, aprobado=1)[:10]
    else:
        cursos_recientes_slider = Curso.objects.order_by('-fecha_registro').filter(statusC=1)[:10]

    categorias_cursos = CursoCategoria.objects.all()
    monedas = Moneda.objects.filter(statusM=1)

    entradas_blog_footer = EntradasBlog.objects.order_by('-fecha_posteo')[:3]

    #Empieza consulta de transmision
    horas = datetime.now()

    horamas = horas + timedelta(hours=1)

    horamass = horamas.time()

    horamenos = horas + timedelta(hours=-1)

    horamenoss = horamenos.time()

    cadena1 = str(horamenoss)
    cadena2 = str(horamass)

    fechahoy = date.today()

    begin = datetime.strptime(cadena1, '%H:%M:%S.%f').time()
    end = datetime.strptime(cadena2, '%H:%M:%S.%f').time()

    Ctransmision = TransmisionesVivo.objects.filter(fecha_transmision=fechahoy, hora_transmision__range=[begin, end]).order_by('hora_transmision')[:1]

    Evivo = ""

    if Ctransmision:
        Evivo = "True"
    else:
        Evivo = "False"
    #Termina Consulta Transmision

    texto_devoluciones_consulta = TextosPagina.objects.filter(id_empresaR=1, identificador="Devoluciones")

    if texto_devoluciones_consulta:
        texto_devoluciones = texto_devoluciones_consulta[0]
    else:
        texto_devoluciones = []

    contexto = {'texto_devoluciones':texto_devoluciones,'categorias': categorias_cursos,'authenticate': autenticado,
        'user': id_usuario, 'type_user': tipo_usuario, 'num_cursos_lista' : cursos_lista_deseos,
        'nomenclatura': nomenclatura, 'Monedas': monedas, 'MonedaSeleccionada':valor_moneda,
        'cursos_recientes_slider': cursos_recientes_slider, 'valor': valor ,'entradas_blog_footer': entradas_blog_footer,
        'Evivo': Evivo}

    return render(request, "Principal/devoluciones-info.html", contexto)






def pago_paypal(request):

    id_usuario =  0
    tipo_usuario = 0
    autenticado = ""

    if request.user.is_authenticated:
        autenticado = "authenticated"
        if request.user.tipo_usuario == 3:
            id_usuario =  str(request.user.id_relacionado)
            tipo_usuario = str(request.user.tipo_usuario)
        else:
            id_usuario =  0
            tipo_usuario = 0

    if int(tipo_usuario) == 3:
        cart = Cart(request.session,0)

        cursos_total = float(cart.total_sinformT)
        data = json.loads(request.body)
        order_id = data['orderID']

        terminos_condiciones = data['term']
        politica_privacidad = data['pol']


        if terminos_condiciones == 1 and politica_privacidad == 1:

            valor_moneda = request.session['moneda']

            moneda_valor = Moneda.objects.filter(nombre_moneda=valor_moneda)
            valor = moneda_valor[0].equivalente_peso_mx
            nomenclatura = moneda_valor[0].nomencaltura


            detalle = GetOrder().get_order(order_id)
            detalle_precio = float(detalle.result.purchase_units[0].amount.value)

            currency = detalle.result.purchase_units[0].amount.currency_code
            #print(currency)

            if detalle_precio == cursos_total and nomenclatura in currency:
                trx = CaptureOrder().capture_order(order_id, debug=True)

                if  str(trx.result.status) in "COMPLETED":

                    try:
                        for items in cart.items:
                            print(items.curso.nombreC)


                            id_curso_comprado = items.curso.id_curso
                            nombre_curso = items.curso.nombreC
                            precio_curso = items.curso.precio


                            id_instructor_consulta = CursoInstructor.objects.filter(id_cursoR=id_curso_comprado)

                            id_instructor = id_instructor_consulta[0].id_instructorR
                            id_alumno_compro= int(id_usuario)

                            fecha_transaccion =  dt.datetime.now()
                            ruta_imagen_curso = items.curso.ruta_imagen

                            cupon = ""
                            descuento_cupon = 0
                            descuento_kaizen = 0
                            descuento_instructor = 0
                            tipo_pago = "Paypal"
                            total_instructor = 0

                            total_kaizen = 0

                            total_venta = 0

                            descuento_curso = 0

                            porcentajes_empresa_instructor=ElementosPagina.objects.filter(id_elementoPagina=1)
                            #print("###################################################### ", items.curso_tipoc)
                            tipo_venta = ""
                            if items.curso_tipoc in "organico":
                                porcentajeEmpresa =  porcentajes_empresa_instructor[0].porcentajeEmpresa
                                porcentajeInstructor = porcentajes_empresa_instructor[0].porcentajeInstructor
                                tipo_venta = "Organico"
                            elif items.curso_tipoc in "inorganico":
                                porcentajeEmpresa =  porcentajes_empresa_instructor[0].porcentajeEmpresaInorganico
                                porcentajeInstructor = porcentajes_empresa_instructor[0].porcentajeInstructorInorganico
                                tipo_venta = "Inorganico"
                            elif items.curso_tipoc in "sensei":
                                porcentajeEmpresa =  porcentajes_empresa_instructor[0].porcentajeEmpresaSensei
                                porcentajeInstructor = porcentajes_empresa_instructor[0].porcentajeInstructorSensei
                                tipo_venta = "Sensei"




                            if request.session.get('cpn'):


                                cupon = "Si"
                                descuento_cupon = int(request.session.get('cpn'))
                                desucnto = descuento_cupon / 2
                                descuento_kaizen = desucnto
                                descuento_instructor = desucnto



                                descuento_monto = cart.total_des()
                                numero_cursos = cart.count


                                descuento_curso = descuento_monto / numero_cursos


                                porcentaje_curso = int(precio_curso) - descuento_curso

                                porcentaje_em = (porcentaje_curso * porcentajeEmpresa) / 100

                                porcentaje_in = (porcentaje_curso * porcentajeInstructor) / 100

                                total_instructor = int(porcentaje_in)

                                total_kaizen = int(porcentaje_em)

                                total_venta = porcentaje_curso
                            else:
                                cupon = "No"


                                #descuento_curso = cart.cantidad_descuento  / cart.count

                                porcentaje_curso = int(precio_curso)

                                porcentaje_em = (porcentaje_curso * porcentajeEmpresa) / 100

                                porcentaje_in = (porcentaje_curso * porcentajeInstructor) / 100

                                total_instructor = int(porcentaje_in)

                                total_kaizen = int(porcentaje_em)

                                total_venta = porcentaje_curso



                            devolucion = 0


                            #tipo_venta = Organico
                            guardar_transaccion = Transacciones.objects.create(id_curso_comprado=id_curso_comprado,
                                nombre_curso=nombre_curso, precio_curso=precio_curso, id_instructor=id_instructor,
                                id_alumno_compro=id_alumno_compro,fecha_transaccion=fecha_transaccion,
                                ruta_imagen_curso=ruta_imagen_curso, cupon=cupon,descuento_cupon=descuento_cupon,
                                descuento_instructor=descuento_instructor, descuento_kaizen=descuento_kaizen,
                                devolucion=devolucion,tipo_pago=tipo_pago, total_instructor=total_instructor,
                                total_kaizen=total_kaizen, total_venta=total_venta, tipo_venta=tipo_venta)

                            transacccion = Transacciones.objects.filter(id_curso_comprado=id_curso_comprado,
                                nombre_curso=nombre_curso, precio_curso=precio_curso, id_instructor=id_instructor,
                                id_alumno_compro=id_alumno_compro,fecha_transaccion=fecha_transaccion,
                                ruta_imagen_curso=ruta_imagen_curso, cupon=cupon,descuento_cupon=descuento_cupon,
                                descuento_instructor=descuento_instructor, descuento_kaizen=descuento_kaizen,
                                devolucion=devolucion,tipo_pago=tipo_pago, total_instructor=total_instructor,
                                total_kaizen=total_kaizen, total_venta=total_venta, tipo_venta=tipo_venta)


                            id_transaccionR = transacccion[0].id_transaccion

                            #tipo_venta = Organico
                            MovimientosInstructor.objects.create(id_transaccionR=id_transaccionR, id_instructorR=id_instructor,
                                fecha_movimiento=fecha_transaccion, cantidad_total=precio_curso, descuento_aplicado=descuento_curso,
                                total_ganado=total_instructor, devuelto=0, estado=1, tipo_venta=tipo_venta)

                            alumno_consulta = Alumno.objects.filter(id_alumno=id_alumno_compro)

                            nombre_alumno = alumno_consulta[0].nombreA+" "+alumno_consulta[0].apellidosA

                            CursoEstudiante.objects.create(id_cursoR=id_curso_comprado, id_estudianteR=id_alumno_compro,
                                nombre_estudianteR=nombre_alumno,promedio_curso="0",
                                id_instructorRC=id_instructor)

                            request.session['cpn'] = ""



                        data = {
                            "id": f"{trx.result.id}",
                            "nombre_cliente": f"{trx.result.payer.name.given_name}",
                            "mensaje": "Éxito"
                        }
                        return JsonResponse(data)

                    except Exception as e:
                        data = {
                            "mensaje": "Error, vuelva a intentar"
                        }
                        return JsonResponse(data)
                else:
                    data = {
                        "mensaje": "Error, verifique que su cuenta esté activa y tenga suficiente saldo"
                    }
                    return JsonResponse(data)
            else:
                data = {
                    "mensaje": "Error, vuelva a intentar"
                }
                return JsonResponse(data)
        else:
            data = {
                "mensaje": "Debe de seleccionar la política de privacidad y los términos y condiciones."
            }
            return JsonResponse(data)
    else:
        data = {
            "mensaje": "Para conmprar debes de iniciar sesión como alumno."
        }
        return JsonResponse(data)

class PayPalClient:
    def __init__(self):
        self.client_id = "AUi8EeyC335limf0dauKsIC5Xju-oE3Ko7kNRdt4jKYDN_zbBSPSazdoA_8yvvwAXu4kq7NMC_96ae5q"
        self.client_secret = "EK4T8zBGGPVzmYkwQm783uJSE_r90sS1FBJI2waCycTsDkzVQFRrrCu0qFgyAQz_XIyZTQn_gsCjB9wb"

        """Set up and return PayPal Python SDK environment with PayPal access credentials.
           This sample uses SandboxEnvironment. In production, use LiveEnvironment."""

        self.environment = SandboxEnvironment(client_id=self.client_id, client_secret=self.client_secret)

        """ Returns PayPal HTTP client instance with environment that has access
            credentials context. Use this instance to invoke PayPal APIs, provided the
            credentials have access. """
        self.client = PayPalHttpClient(self.environment)

    def object_to_json(self, json_data):
        """
        Function to print all json data in an organized readable manner
        """
        result = {}
        if sys.version_info[0] < 3:
            itr = json_data.__dict__.iteritems()
        else:
            itr = json_data.__dict__.items()
        for key,value in itr:
            # Skip internal attributes.
            if key.startswith("__"):
                continue
            result[key] = self.array_to_json_array(value) if isinstance(value, list) else\
                        self.object_to_json(value) if not self.is_primittive(value) else\
                         value
        return result
    def array_to_json_array(self, json_array):
        result =[]
        if isinstance(json_array, list):
            for item in json_array:
                result.append(self.object_to_json(item) if  not self.is_primittive(item) \
                              else self.array_to_json_array(item) if isinstance(item, list) else item)
        return result

    def is_primittive(self, data):
        return isinstance(data, str) or isinstance(data, unicode) or isinstance(data, int)


## Obtener los detalles de la transacción
class GetOrder(PayPalClient):

  #2. Set up your server to receive a call from the client
  """You can use this function to retrieve an order by passing order ID as an argument"""
  def get_order(self, order_id):
    """Method to get order"""
    request = OrdersGetRequest(order_id)
    #3. Call PayPal to get the transaction
    response = self.client.execute(request)
    return response
    #4. Save the transaction in your database. Implement logic to save transaction to your database for future reference.
    # print 'Status Code: ', response.status_code
    # print 'Status: ', response.result.status
    # print 'Order ID: ', response.result.id
    # print 'Intent: ', response.result.intent
    # print 'Links:'
    # for link in response.result.links:
    #   print('\t{}: {}\tCall Type: {}'.format(link.rel, link.href, link.method))
    # print 'Gross Amount: {} {}'.format(response.result.purchase_units[0].amount.currency_code,
    #                    response.result.purchase_units[0].amount.value)

# """This driver function invokes the get_order function with
#    order ID to retrieve sample order details. """
# if __name__ == '__main__':
#   GetOrder().get_order('REPLACE-WITH-VALID-ORDER-ID')


class CaptureOrder(PayPalClient):

  #2. Set up your server to receive a call from the client
  """this sample function performs payment capture on the order.
  Approved order ID should be passed as an argument to this function"""

  def capture_order(self, order_id, debug=False):
    """Method to capture order using order_id"""
    request = OrdersCaptureRequest(order_id)
    #3. Call PayPal to capture an order
    response = self.client.execute(request)
    #4. Save the capture ID to your database. Implement logic to save capture to your database for future reference.
    if debug:
      #print ('Status Code: ', response.status_code)
      #print ('Status: ', response.result.status)
      #print ('Order ID: ', response.result.id)
      #print ('Links: ')
      for link in response.result.links:
        print('\t{}: {}\tCall Type: {}'.format(link.rel, link.href, link.method))
      #print ('Capture Ids: ')
      for purchase_unit in response.result.purchase_units:
        for capture in purchase_unit.payments.captures:
          print ('\t', capture.id)
      #print ("Buyer:")
        # print "\tEmail Address: {}\n\tName: {}\n\tPhone Number: {}".format(response.result.payer.email_address,
        # response.result.payer.name.given_name + " " + response.result.payer.name.surname,
        # response.result.payer.phone.phone_number.national_number)
    return response


"""This driver function invokes the capture order function.
Replace Order ID value with the approved order ID. """
# if __name__ == "__main__":
#   order_id = 'REPLACE-WITH-APPORVED-ORDER-ID'
#   CaptureOrder().capture_order(order_id, debug=True)









def cart_confirms(request):
    if request.session.has_key('cart_confirms'):
        pass
    else:
        request.session['cart_confirms'] = "vacio"


def cart_confirm_msgs(request):
    if request.session.has_key('cart_confirm_msgs'):
        pass
    else:
        request.session['cart_confirm_msgs'] = "vacio"

def cart_confirmc(request):
    if request.session.has_key('cart_confirmc'):
        pass
    else:
        request.session['cart_confirmc'] = "vacio"


def cart_confirm_msgc(request):
    if request.session.has_key('cart_confirm_msgc'):
        pass
    else:
        request.session['cart_confirm_msgc'] = "vacio"


def encrypt_AES_GCM(msg, secretKey):
    aesCipher = AES.new(secretKey, AES.MODE_GCM)
    ciphertext, authTag = aesCipher.encrypt_and_digest(msg)
    return (ciphertext, aesCipher.nonce, authTag)

def decrypt_AES_GCM(ciphertext,nonce, authTag, secretKey):
    #(ciphertext, nonce, authTag) = encryptedMsg
    aesCipher = AES.new(secretKey, AES.MODE_GCM, nonce)
    plaintext = aesCipher.decrypt_and_verify(ciphertext, authTag)
    return plaintext

def palabra_aleatoria():
    diccionario = "qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM._1234567890"
    contador_p = 0
    palabra = ""
    while contador_p < 11:
        palabra = palabra + random.choice(diccionario)
        contador_p = contador_p + 1
    return palabra


def payment(request):


    #print(request.GET.get('pk'))
    cart = Cart(request.session, 0)
    cursos_total = float(cart.total_sinformT)
    redondear = round(cursos_total)
    cursos_precio_total = int(redondear)
    #print("dddddddddddddddddddddddddddddddddddddddddddd", cursos_total)

    precio_carro = cursos_precio_total * 100

    valor_moneda = request.session['moneda']

    moneda_valor = Moneda.objects.filter(nombre_moneda=valor_moneda)
    #valor = moneda_valor[0].equivalente_peso_mx
    nomenclatura = moneda_valor[0].nomencaltura


    palabra1 = palabra_aleatoria()
    palabra2 = palabra_aleatoria()

    cart_confirms(request)
    request.session['cart_confirms'] = palabra1

    secretKey1 = b'\x9dmh\x1d\xfaAloE \xf2\x12H\xa7\xcf\x8f\xf74\xae\xfe&\xef\x8eWz\x9a\xfd\xa0v\xf1\x0f\xc4'

    msg1 = bytes(palabra1, 'utf-8')

    #msg = bytes(password_alumno, 'utf-8')
    #print(msg)
    encryptedMsg1 = encrypt_AES_GCM(msg1, secretKey1)

    cart_confirm_msgs(request)

    c1=encryptedMsg1[0].hex()
    n1=encryptedMsg1[1].hex()
    a1=encryptedMsg1[2].hex()
    msg_cifr1 = str(c1)+","+str(n1)+","+str(a1)

    request.session['cart_confirm_msgs'] = msg_cifr1


    cart_confirmc(request)
    request.session['cart_confirmc'] = palabra2

    secretKey2 = b'\xb4az\xe0B[\xfbI\x8eg\xe6`O\x1b\xe30/\xd1\x8c\xac\xed\xef0\xda\xcel\xb0\x95\x84\x8e\xa1\xb1'

    msg2 = bytes(palabra2, 'utf-8')

    #msg = bytes(password_alumno, 'utf-8')
    #print(msg)
    encryptedMsg2 = encrypt_AES_GCM(msg2, secretKey2)

    cart_confirm_msgc(request)

    c2=encryptedMsg2[0].hex()
    n2=encryptedMsg2[1].hex()
    a2=encryptedMsg2[2].hex()
    msg_cifr2 = str(c2)+","+str(n2)+","+str(a2)

    request.session['cart_confirm_msgc'] = msg_cifr2

    successt = request.session.get('cart_confirm_msgs')
    cancelt = request.session.get('cart_confirm_msgc')

    #print(successt)


    stripe.api_key = "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"

    YOUR_DOMAIN = "https://seiko.global"
    checkout_session = stripe.checkout.Session.create(
        payment_method_types=['card'],
        line_items=[
            {
                'price_data': {
                    'currency': nomenclatura,
                    'unit_amount': precio_carro,
                    'product_data': {
                        'name': 'Compra de cursos en Seikō Unlimited',
                        #'images': ['https://i.imgur.com/EHyR2nP.png'],
                    },
                },
                'quantity': 1,
            },
        ],
        mode='payment',
        success_url=YOUR_DOMAIN + '/success/?ords='+successt,
        cancel_url=YOUR_DOMAIN + '/cancel/?ordc='+cancelt,
    )


    return JsonResponse({
        'id': checkout_session.id
    })



def compra_stripe_exitosa(request):
    if request.method == "GET":
        palabra_encrip = request.GET['ords']


        if palabra_encrip.count(",") == 2:

            palabraCS = palabra_encrip.split(',')

            if str(palabraCS[0]) in "" or str(palabraCS[1]) in "" or str(palabraCS[2]) in "":

                return redirect('/index/')
            else:

                try:

                    ciphertext = bytes.fromhex(str(palabraCS[0]))
                    nonce = bytes.fromhex(str(palabraCS[1]))
                    authTag = bytes.fromhex(str(palabraCS[2]))
                    secretKey1 = b'\x9dmh\x1d\xfaAloE \xf2\x12H\xa7\xcf\x8f\xf74\xae\xfe&\xef\x8eWz\x9a\xfd\xa0v\xf1\x0f\xc4'

                    palabra_decrypt = str(decrypt_AES_GCM(ciphertext,nonce, authTag, secretKey1))

                    palabra_solo = palabra_decrypt[2:len(palabra_decrypt) - 1]
                    palabrasec = request.session.get('cart_confirms')

                    if palabra_solo == palabrasec:

                        cart = Cart(request.session,0)

                        id_usuario =  0
                        tipo_usuario = 0
                        autenticado = ""

                        if request.user.is_authenticated:
                            autenticado = "authenticated"
                            if request.user.tipo_usuario == 3:
                                id_usuario =  str(request.user.id_relacionado)
                                tipo_usuario = str(request.user.tipo_usuario)
                            else:
                                id_usuario =  0
                                tipo_usuario = 0


                        for items in cart.items:
                            #print(items.curso.id_curso)


                            id_curso_comprado = items.curso.id_curso
                            nombre_curso = items.curso.nombreC
                            precio_curso = items.curso.precio


                            id_instructor_consulta = CursoInstructor.objects.filter(id_cursoR=id_curso_comprado)

                            id_instructor = id_instructor_consulta[0].id_instructorR
                            id_alumno_compro= int(id_usuario)

                            fecha_transaccion =  dt.datetime.now()
                            ruta_imagen_curso = items.curso.ruta_imagen

                            cupon = ""
                            descuento_cupon = 0
                            descuento_kaizen = 0
                            descuento_instructor = 0
                            tipo_pago = "Stripe (Tarjeta)"
                            total_instructor = 0

                            total_kaizen = 0

                            total_venta = 0

                            descuento_curso = 0

                            porcentajes_empresa_instructor=ElementosPagina.objects.filter(id_elementoPagina=1)

                            tipo_venta = ""
                            if items.curso_tipoc in "organico":
                                porcentajeEmpresa =  porcentajes_empresa_instructor[0].porcentajeEmpresa
                                porcentajeInstructor = porcentajes_empresa_instructor[0].porcentajeInstructor
                                tipo_venta = "Organico"
                            elif items.curso_tipoc in "inorganico":
                                porcentajeEmpresa =  porcentajes_empresa_instructor[0].porcentajeEmpresaInorganico
                                porcentajeInstructor = porcentajes_empresa_instructor[0].porcentajeInstructorInorganico
                                tipo_venta = "Inorganico"
                            elif items.curso_tipoc in "sensei":
                                porcentajeEmpresa =  porcentajes_empresa_instructor[0].porcentajeEmpresaSensei
                                porcentajeInstructor = porcentajes_empresa_instructor[0].porcentajeInstructorSensei
                                tipo_venta = "Sensei"

                            #porcentajeEmpresa =  porcentajes_empresa_instructor[0].porcentajeEmpresa
                            #porcentajeInstructor = porcentajes_empresa_instructor[0].porcentajeInstructor

                            if request.session.get('cpn'):


                                cupon = "Si"
                                descuento_cupon = int(request.session.get('cpn'))
                                desucnto = descuento_cupon / 2
                                descuento_kaizen = desucnto
                                descuento_instructor = desucnto



                                descuento_monto = cart.total_des()
                                numero_cursos = cart.count


                                descuento_curso = descuento_monto / numero_cursos


                                porcentaje_curso = int(precio_curso) - descuento_curso

                                porcentaje_em = (porcentaje_curso * porcentajeEmpresa) / 100

                                porcentaje_in = (porcentaje_curso * porcentajeInstructor) / 100

                                total_instructor = int(porcentaje_in)

                                total_kaizen = int(porcentaje_em)

                                total_venta = porcentaje_curso
                            else:
                                cupon = "No"


                                #descuento_curso = cart.cantidad_descuento  / cart.count

                                porcentaje_curso = int(precio_curso)

                                porcentaje_em = (porcentaje_curso * porcentajeEmpresa) / 100

                                porcentaje_in = (porcentaje_curso * porcentajeInstructor) / 100

                                total_instructor = int(porcentaje_in)

                                total_kaizen = int(porcentaje_em)

                                total_venta = porcentaje_curso



                            devolucion = 0

                            #tipo_venta = Organico
                            guardar_transaccion = Transacciones.objects.create(id_curso_comprado=id_curso_comprado,
                                nombre_curso=nombre_curso, precio_curso=precio_curso, id_instructor=id_instructor,
                                id_alumno_compro=id_alumno_compro,fecha_transaccion=fecha_transaccion,
                                ruta_imagen_curso=ruta_imagen_curso, cupon=cupon,descuento_cupon=descuento_cupon,
                                descuento_instructor=descuento_instructor, descuento_kaizen=descuento_kaizen,
                                devolucion=devolucion,tipo_pago=tipo_pago, total_instructor=total_instructor,
                                total_kaizen=total_kaizen, total_venta=total_venta, tipo_venta=tipo_venta)

                            transacccion = Transacciones.objects.filter(id_curso_comprado=id_curso_comprado,
                                nombre_curso=nombre_curso, precio_curso=precio_curso, id_instructor=id_instructor,
                                id_alumno_compro=id_alumno_compro,fecha_transaccion=fecha_transaccion,
                                ruta_imagen_curso=ruta_imagen_curso, cupon=cupon,descuento_cupon=descuento_cupon,
                                descuento_instructor=descuento_instructor, descuento_kaizen=descuento_kaizen,
                                devolucion=devolucion,tipo_pago=tipo_pago, total_instructor=total_instructor,
                                total_kaizen=total_kaizen, total_venta=total_venta, tipo_venta=tipo_venta)


                            id_transaccionR = transacccion[0].id_transaccion

                            #tipo_venta = Organico
                            MovimientosInstructor.objects.create(id_transaccionR=id_transaccionR, id_instructorR=id_instructor,
                                fecha_movimiento=fecha_transaccion, cantidad_total=precio_curso, descuento_aplicado=descuento_curso,
                                total_ganado=total_instructor, devuelto=0, estado=1, tipo_venta=tipo_venta)

                            alumno_consulta = Alumno.objects.filter(id_alumno=id_alumno_compro)

                            nombre_alumno = alumno_consulta[0].nombreA+" "+alumno_consulta[0].apellidosA

                            CursoEstudiante.objects.create(id_cursoR=id_curso_comprado, id_estudianteR=id_alumno_compro,
                                nombre_estudianteR=nombre_alumno,promedio_curso="0",
                                id_instructorRC=id_instructor)

                        request.session['cpn'] = ""
                        request.session['cart_confirm_msgs'] = ""
                        request.session['cart_confirm_msgc'] = ""
                        request.session['cart_confirms'] = ""
                        request.session['cart_confirmc'] = ""


                        return redirect('/detalle-compra/')


                    else:

                        return redirect('/index/')

                except Exception as e:

                    return redirect('/index/')
        else:

            return redirect('/index/')
    return redirect('/index/')



def compra_stripe_cancelado(request):
    if request.method == "GET":
        palabra_encrip = request.GET['ordc']

        if palabra_encrip.count(",") == 2:

            palabraCS = palabra_encrip.split(',')

            if str(palabraCS[0]) in "" or str(palabraCS[1]) in "" or str(palabraCS[2]) in "":
                return redirect('/index/')
            else:

                try:
                    ciphertext = bytes.fromhex(str(palabraCS[0]))
                    nonce = bytes.fromhex(str(palabraCS[1]))
                    authTag = bytes.fromhex(str(palabraCS[2]))
                    secretKey2 = b'\xb4az\xe0B[\xfbI\x8eg\xe6`O\x1b\xe30/\xd1\x8c\xac\xed\xef0\xda\xcel\xb0\x95\x84\x8e\xa1\xb1'

                    palabra_decrypt = str(decrypt_AES_GCM(ciphertext,nonce, authTag, secretKey2))
                    palabra_solo = palabra_decrypt[2:len(palabra_decrypt) - 1]
                    palabrasec = request.session.get('cart_confirmc')

                    if palabra_solo == palabrasec:
                        return redirect('/index/')
                    else:
                        return redirect('/index/')

                except Exception as e:
                    return redirect('/index/')
        else:
            return redirect('/index/')


    return redirect('/index/')







@login_required(login_url='/inicio_sesion_admin/')
@user_passes_test(identificar_administrador, login_url='/inicio_sesion_admin/')
def mostrar_correos_boletin(request):
    if request.method == "POST":

        fecha_inicial = request.POST.get('fecha_inicial')
        fecha_final = request.POST.get('fecha_final')


        boletin_rango =  Boletin.objects.filter(fecha__range=(fecha_inicial, fecha_final))

        contexto = {'boletin':boletin_rango}

        return render(request, 'Admin/Extras/Boletin/boletin_ajax.html', contexto)



    instructor = Instructor.objects.all()

    boletin = Boletin.objects.all()

    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)
    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    contexto = {'boletin':boletin, 'usuarios':usuario, 'datosPagina':datoPagina}

    return render(request, 'Admin/Extras/Boletin/boletin.html', contexto)





def envio_correo_boletin(request):
    if request.method == "POST":
        fecha_inicial = request.POST.get('fecha_inicial')
        fecha_final = request.POST.get('fecha_final')
        correo = request.POST.get('correo')

        boletin_rango =  Boletin.objects.filter(fecha__range=(fecha_inicial, fecha_final))

        if boletin_rango:
            correos_boletin = ""
            for boletin_correo in boletin_rango:
                correos_boletin = correos_boletin + boletin_correo.correo + " "

            print(correos_boletin)
            return JsonResponse({'content':{'message': "exito"}})
            """
            MANDRILL_API_KEY = 'Ya4SqTK0tCvIEq1MSZ7NtQ'
            mandrill_client = mandrill.Mandrill(MANDRILL_API_KEY)
            messageu = { 'from_email': 'hola@kaizen.lat',
              'from_name': 'Kaizen.lat',
              'to': [{
                'email': correo,
                'name': 'hola',
                'type': 'to'
               }],
              'subject': '',
              'text': 'Correos registrados en el boletín: '+correos_boletin
            }

            result_mensaje_usuario = mandrill_client.messages.send(message = messageu)
            """
        return JsonResponse({'content':{'message': "error"}})




# Se agregaron


def registro_candidato(request):
    return render(request, 'Principal/registro-candidato.html')



def procesa_registro_candidato(request):
    if request.method == "POST":
        nombre = request.POST['nombre_c']
        apellidos = request.POST['apellidos_c']
        pais_c = request.POST['pais_c']
        pais_o = request.POST['pais_o']
        categoria = request.POST['categoria_c']
        correo = request.POST['correo_c']
        pregunta = request.POST['descripcion_comunidad_pregunta']


        date = dt.datetime.now()
        Candidatos_sensei.objects.create(nombres=nombre, apellidos=apellidos, pais_seleccionado=pais_c, pais_obtenido=pais_o,
            categoria=categoria, correo=correo, pregunta=pregunta, fecha=date, hora=date, statusCS=1)


        registro_candidato = Candidatos_sensei.objects.filter(nombres=nombre, apellidos=apellidos, pais_seleccionado=pais_c, pais_obtenido=pais_o,
            categoria=categoria, correo=correo, pregunta=pregunta, fecha=date, statusCS=1)

        mensaje = ""
        estatusMensaje = ""

        if registro_candidato:
            mensaje = "Datos guardados con éxito"
            estatusMensaje = "exito"
        else:
            mensaje = "Error al guardar los datos, intente de nuevo"
            estatusMensaje = "error"


        #Boletin.objects.create(correo=correo, fecha=date, hora=date, ip=ip, pais=pais,statusBo=1)
        contexto = {'mensaje':mensaje, 'estatusMensaje':estatusMensaje}
        return render(request, 'Principal/registro-candidato.html', contexto)



    return render(request, 'Principal/registro-candidato.html')



@login_required(login_url='/inicio_sesion_admin/')
@user_passes_test(identificar_administrador, login_url='/inicio_sesion_admin/')
def mostrar_candidatos_sensei(request):
    if request.method == "POST":

        fecha_inicial = request.POST.get('fecha_inicial')
        fecha_final = request.POST.get('fecha_final')


        candidatos_sensei =  Candidatos_sensei.objects.filter(fecha__range=(fecha_inicial, fecha_final))

        contexto = {'candidatos':candidatos_sensei}

        return render(request, 'Admin/Extras/CandidatosSensei/candidatos_sensei_ajax.html', contexto)



    instructor = Instructor.objects.all()

    candidatos = Candidatos_sensei.objects.all()

    idadmin = request.user.id_relacionado
    usuario = Administrador.objects.filter(id_admin=idadmin)
    datoPagina = ElementosPagina.objects.filter(id_elementoPagina=1)

    contexto = {'candidatos':candidatos, 'usuarios':usuario, 'datosPagina':datoPagina}

    return render(request, 'Admin/Extras/CandidatosSensei/candidatos_sensei.html', contexto)
