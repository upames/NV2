from django.db import models
from django.contrib.auth.models import AbstractBaseUser
from django.contrib.auth.models import UserManager
from ckeditor.fields import RichTextField

class Usuarios(AbstractBaseUser):

    id_usuario = models.AutoField(primary_key=True)
    email = models.CharField(max_length=255, unique=True)
    password = models.CharField(max_length=300)
    tipo_usuario = models.IntegerField() # 1 es para admin, 2 para instructores, 3 alumnos
    id_relacionado = models.IntegerField()
    is_active = models.IntegerField(default=1)
    ultima_actualizacion = models.DateTimeField(default="2021-04-16 03:28:58.363130")
    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['password']
    objects = UserManager()



class Pais(models.Model):

    PaisCodigo = models.CharField(max_length=3)
    PaisNombre = models.CharField(max_length=60)


class Ciudad(models.Model):

    CiudadID = models.IntegerField()
    CiudadNombre = models.CharField(max_length=40)
    PaisCodigo = models.CharField(max_length=3)
    CiudadDistrito = models.CharField(max_length=35)



class Administrador(models.Model):

    id_admin = models.AutoField(primary_key=True)
    nombre = models.CharField(max_length=200)
    correoA = models.CharField(max_length=300, default="Ninguno")
    statusA = models.IntegerField(default=1)
    ruta_imagen_admin = models.CharField(max_length=1000, default="avatar.png")


class Instructor(models.Model):

    id_instructor = models.AutoField(primary_key=True)
    nombreI = models.CharField(max_length=60)
    apellidosI = models.CharField(max_length=60)
    direccionI = models.CharField(max_length=200)
    codigopostalI = models.CharField(max_length=15)
    estadoI = models.CharField(max_length=100)
    ciudadI = models.CharField(max_length=100)
    paisI = models.CharField(max_length=60)
    estudiosI = models.CharField(max_length=60)
    profesionI = models.CharField(max_length=200)
    edadI = models.IntegerField()
    celularI = models.CharField(max_length=15)
    experienciaP = models.CharField(max_length=600)
    experienciaI = models.CharField(max_length=600)
    socio_kaizen = models.CharField(max_length=10)
    statusI = models.IntegerField(default=1)
    correoI = models.CharField(max_length=300, default="Ninguno")
    ruta_imagen_perfil = models.CharField(max_length=100, default="avatar.png")
    sexo_instructor = models.CharField(max_length=50, default="")
    fecha_registro = models.DateField(null=True, auto_now_add=True)
    imagen_portada = models.CharField(max_length=500, default="portada.jpg")

class Alumno(models.Model):

    id_alumno = models.AutoField(primary_key=True)
    nombreA = models.CharField(max_length=60)
    apellidosA = models.CharField(max_length=60)
    direccionA = models.CharField(max_length=200)
    codigopostalA = models.CharField(max_length=15)
    estadoA = models.CharField(max_length=100)
    ciudadA = models.CharField(max_length=100)
    paisA = models.CharField(max_length=60)
    profesionA = models.CharField(max_length=200)
    edadA = models.IntegerField()
    celularA = models.CharField(max_length=20, default="")
    tiposangreA = models.CharField(max_length=10)
    alergiasA = models.CharField(max_length=250)
    nombreT = models.CharField(max_length=60)
    apellidosT = models.CharField(max_length=60)
    direccionT = models.CharField(max_length=200)
    codigopostalT = models.CharField(max_length=15)
    estadoT = models.CharField(max_length=100)
    ciudadT = models.CharField(max_length=100)
    paisT = models.CharField(max_length=60)
    profesionT = models.CharField(max_length=200)
    edadT = models.IntegerField()
    celularT = models.IntegerField()
    statusAL = models.IntegerField(default=1)
    correoAL = models.CharField(max_length=300, default="Ninguno")
    ruta_avatar = models.CharField(max_length=500, default="avatar.png")
    sexo_alumno = models.CharField(max_length=50, default="")
    imagen_portada = models.CharField(max_length=500, default="portada.jpg")
    imagen_qr = models.CharField(max_length=200, default="Ninguna")
    fecha_registro = models.DateField(null=True, auto_now_add=True)
    matricula = models.CharField(max_length=50, default="")
    licenciatura = models.IntegerField(default=0)
    grado = models.IntegerField(default=1)



class Curso(models.Model):

    id_curso = models.AutoField(primary_key=True)
    nombreC = models.CharField(max_length=250)
    fecha_inicio = models.DateField()
    fecha_cierre = models.DateField()
    no_minimo_alumnos = models.IntegerField()
    no_maximo_alumnos = models.IntegerField()
    precio = models.IntegerField(default=0)
    tipo_Curso = models.CharField(max_length=20, default="Ninguno")
    statusC = models.IntegerField(default=1)
    ruta_imagen = models.CharField(max_length=500, default="")
    descripcion_curso = models.CharField(max_length=5000, default="")
    video_muestra = models.CharField(max_length=1000, default="")
    fecha_registro = models.DateField(null=True, auto_now_add=True)
    hora_registro = models.TimeField(null=True, auto_now_add=True)
    duracion_curso_numero = models.IntegerField(default=15)
    duracion_curso_tipo = models.CharField(max_length=100, default="Horas")
    veces_vendido = models.IntegerField(default=2)
    valoracion = models.IntegerField(default=3)
    aprobado = models.IntegerField(default=0)
    es_libre = models.IntegerField(default=0)
    url_inorganico = models.CharField(max_length=500, default="")
    url_sensei = models.CharField(max_length=500, default="")
    aprendizaje = RichTextField()
    temario = RichTextField()
    recursos = RichTextField()
    requisitos = RichTextField()
    no_lecciones = models.IntegerField(default=0)
    tareas_actividades = RichTextField()
    no_horas_video = models.IntegerField(default=0)
    tipo_horario = models.CharField(max_length=100, default="")
    horario = models.CharField(max_length=100, default="")




class CursoInstructor(models.Model):

    id_cursoInstructor = models.AutoField(primary_key=True)
    id_cursoR = models.IntegerField()
    id_instructorR = models.IntegerField()


class CursoEstudiante(models.Model):

    id_cursoEstudiante = models.AutoField(primary_key=True)
    id_cursoR = models.IntegerField()
    id_estudianteR = models.IntegerField()
    nombre_estudianteR = models.CharField(max_length=500, default="")
    promedio_curso = models.IntegerField(default=0)
    id_instructorRC = models.IntegerField(default=0)
    valoracion_curso = models.IntegerField(default=1)


class Unidades(models.Model):

    id_unidad = models.AutoField(primary_key=True)
    nombre_unidad = models.CharField(max_length=400)
    statusU = models.IntegerField(default=1)
    id_cursoR = models.IntegerField(default=0)
    id_instructorR = models.IntegerField(default=0)
    ruta_imagen_unidad = models.CharField(max_length=500, default="")
    url_video_unidad = models.CharField(max_length=1000, default="")
    ruta_arcivos = models.CharField(max_length=500, default="")

class Actividad(models.Model):

    id_actividad = models.AutoField(primary_key=True)
    nombre_actividad = models.CharField(max_length=100)
    descripcion = models.CharField(max_length=500)
    fecha_vencimiento = models.DateField()
    statusAC = models.IntegerField(default=1)
    id_cursoR = models.IntegerField(default=0)
    id_unidadR = models.IntegerField(default=0)
    id_instructorR = models.IntegerField(default=0)
    archivos_actividad = models.CharField(max_length=500, default="")
    objetivo = RichTextField(default="")

class UnidadActividadCurso(models.Model):

    id_unidadActividadCurso = models.AutoField(primary_key=True)
    id_unidadR = models.IntegerField()
    id_actividadR = models.IntegerField()
    id_cursoR = models.IntegerField()


class EvaluacionesServicio(models.Model):

    id_evalucionServicio = models.AutoField(primary_key=True)
    categoria = models.CharField(max_length=20)
    fecha_publicacion = models.DateField(null=True)
    statusES = models.IntegerField(default=1)

class EvaluacionServicioInstructor(models.Model):

    id_evaluacionServicioI = models.AutoField(primary_key=True)
    id_EvaluacionServicioR = models.IntegerField()
    id_instructorR = models.IntegerField()
    nombre_instructorEva = models.CharField(max_length=500)
    calificacion = models.IntegerField()

class EvaluacionServicioCurso(models.Model):

    id_evaluacionServicioC = models.AutoField(primary_key=True)
    id_EvaluacionServicioR = models.IntegerField()
    id_cursoR = models.IntegerField()
    nombre_cursoEva = models.CharField(max_length=500)
    calificacion = models.IntegerField()

class EvaluacionServicioOtro(models.Model):

    id_evaluacionServicioO = models.AutoField(primary_key=True)
    id_EvaluacionServicioR = models.IntegerField()
    nombre_otroEva = models.CharField(max_length=500)
    calificacion = models.IntegerField()

class PreguntasEvaluacionServicio(models.Model):

    id_PreguntaEvaluacionServicio = models.AutoField(primary_key=True)
    id_EvaluacionServicioR = models.IntegerField()
    pregunta = models.CharField(max_length=500)


class EvaluacionSEstudiante(models.Model):

    id_evalucionSEstudiante = models.AutoField(primary_key=True)
    id_evalucionServicioR = models.IntegerField()
    id_estudianteR = models.IntegerField()
    respuestas = models.CharField(max_length=1000)
    resultadoE = models.IntegerField()
    tipo_evaluacion = models.CharField(max_length=20, default="")
    id_evaluado = models.IntegerField(default=1)
    nombre_evaluado = models.CharField(max_length=200, default="")


class PaginasActivas(models.Model):

    id_paginaActiva = models.AutoField(primary_key=True)
    nombre_empresa = models.CharField(max_length=500)
    nombre_bd = models.CharField(max_length=200)
    statusPA = models.IntegerField(default=1)
    ruta_logo = models.CharField(max_length=500, default="")
    ruta_portada = models.CharField(max_length=500, default="")
    ruta_instalador = models.CharField(max_length=500, default="")
    tarea_programada = models.IntegerField(default=0)
    ruta_actualizacion = models.CharField(max_length=500, default="")

class ElementosPagina(models.Model):

    id_elementoPagina = models.AutoField(primary_key=True)
    id_paginaActivaR = models.IntegerField()
    formato_hora = models.CharField(max_length=200)
    videoconferencias = models.IntegerField()
    crear_examenes = models.IntegerField()
    actividades = models.IntegerField()
    evaluaciones_servicio = models.IntegerField()
    agregar_curso_instructor = models.IntegerField(default=1)
    aprobacion_cursos = models.IntegerField(default=0)
    configuraciones = models.IntegerField(default=0)
    cupones = models.IntegerField(default=0)
    pagos = models.IntegerField(default=0)
    devoluciones = models.IntegerField(default=0)
    blog = models.IntegerField(default=0)
    transmisiones = models.IntegerField(default=0)
    categorias = models.IntegerField(default=0)
    boletin = models.IntegerField(default=0)
    porcentajeEmpresa = models.IntegerField(default=40)
    porcentajeInstructor = models.IntegerField(default=60)
    porcentajeEmpresaInorganico = models.IntegerField(default=40)
    porcentajeInstructorInorganico = models.IntegerField(default=60)
    porcentajeEmpresaSensei = models.IntegerField(default=40)
    porcentajeInstructorSensei = models.IntegerField(default=60)
    profesiones = models.IntegerField(default=0)
    agregar_alumnos = models.IntegerField(default=0)
    grupos = models.IntegerField(default=0)
    tipo_institucion = models.IntegerField(default=1) #1-Universidad  2-Kinder, Primaria, Secundaria, Bachillerato
    tipo_empresa = models.IntegerField(default=1) #1-Escuela   2-Otro



class LogAdmin(models.Model):

    id_log = models.AutoField(primary_key=True)
    fecha_accion = models.DateTimeField()
    id_admin_accion = models.IntegerField()
    nombre_admin_accion = models.CharField(max_length=300)
    detalles_accion = models.CharField(max_length=600)


class ActividadAlumno(models.Model):

    id_actividadAlumno = models.AutoField(primary_key=True)
    id_actividadR = models.IntegerField()
    id_alumnoR = models.IntegerField()
    nombre_alumnoR = models.CharField(max_length=500, default="")
    fecha_entrega = models.DateField(default="2021-01-01")
    nombre_archivo = models.CharField(max_length=2000)
    comentario = models.CharField(max_length=2000, default="")
    comentario_instructor = models.CharField(max_length=2000, default="")
    calificacion = models.IntegerField()
    fecha_revisado = models.DateField(default="2021-01-01")
    id_cursoR = models.IntegerField(default=0)
    revisado = models.IntegerField(default=0)
    id_unidadR = models.IntegerField(default=0)
    no_reentrega = models.IntegerField(default=0)


class DocumentosCurso(models.Model):

    id_documentoCurso = models.AutoField(primary_key=True)
    id_cursoR = models.IntegerField()
    id_instructorR = models.IntegerField()
    id_actividad = models.IntegerField()
    nombre_documento = models.CharField(max_length=500)


class EvaluacionesCursos(models.Model):

    id_evalucionCurso = models.AutoField(primary_key=True)
    id_cursoR = models.IntegerField()
    id_instructorR = models.IntegerField()
    id_unidadR = models.IntegerField(default=0)
    titulo_evaluacion = models.CharField(max_length=200)
    descripcionE = models.CharField(max_length=100)
    statusEC = models.IntegerField()
    fecha_vencimientoE = models.DateField(default="2021-01-28")
    tiempo_limite = models.IntegerField(default=60)


class PreguntasEvaluacionCursos(models.Model):

    id_PreguntaEvaluacionCurso = models.AutoField(primary_key=True)
    id_EvaluacionCursoR = models.IntegerField()
    id_cursoR = models.IntegerField(default=0)
    id_instructorR = models.IntegerField(default=0)
    preguntaC = models.CharField(max_length=500)
    valor_pregunta = models.IntegerField(default=0)
    respuesta_uno = models.CharField(max_length=200, default="")
    respuesta_dos = models.CharField(max_length=200, default="")
    respuesta_tres = models.CharField(max_length=200, default="")
    respuesta_correcta = models.CharField(max_length=200, default="")


class RespuestasEvaluacionCursos(models.Model):

    id_RespuestaEvaluacionCurso = models.AutoField(primary_key=True)
    id_EvaluacionCursoR = models.IntegerField()
    id_PreguntaEvaluacionCursoR = models.IntegerField()
    respuestaC = models.CharField(max_length=500)
    es_correcta = models.IntegerField()


class EvaluacionCursosEstudiante(models.Model):

    id_evalucionCursoEstudiante = models.AutoField(primary_key=True)
    id_evaluacionCursoR = models.IntegerField()
    id_cursoR = models.IntegerField(default=0)
    id_instructorR = models.IntegerField(default=0)
    id_estudianteR = models.IntegerField()
    nombre_alumnoR = models.CharField(max_length=500, default="")
    respuestas = models.CharField(max_length=1000)
    puntajeE = models.IntegerField(default=0)
    resultadoE = models.IntegerField()
    fecha_contestado = models.DateField(default="1999-01-01")

class RespuestasEvaluacionCursosEstudiante(models.Model):

    id_RespuestaEvaluacionCursoEstudiante = models.AutoField(primary_key=True)
    id_evaluacionCursoR = models.IntegerField()
    id_PreguntaEvaluacionCursoR = models.IntegerField()
    id_cursoR = models.IntegerField()
    id_instructorR = models.IntegerField()
    id_estudianteR = models.IntegerField()
    pregunta = models.CharField(max_length=1000)
    valor_pregunta = models.IntegerField()
    mi_respuesta = models.CharField(max_length=500)
    respuesta_correcta = models.CharField(max_length=500)
    es_correcta = models.IntegerField()



class Transacciones(models.Model):

    id_transaccion = models.AutoField(primary_key=True)
    id_curso_comprado = models.IntegerField()
    nombre_curso = models.CharField(max_length=500)
    precio_curso = models.CharField(max_length=25)
    id_instructor = models.IntegerField()
    id_alumno_compro = models.IntegerField()
    fecha_transaccion = models.DateField()
    ruta_imagen_curso = models.CharField(max_length=500, default="")
    cupon = models.CharField(max_length=50, default="No")
    descuento_cupon = models.IntegerField(default=0)
    descuento_kaizen = models.IntegerField(default=0)
    descuento_instructor = models.IntegerField(default=0)
    tipo_pago = models.CharField(max_length=50, default="Tarjeta")
    total_instructor = models.IntegerField(default=0)
    total_kaizen = models.IntegerField(default=0)
    total_venta = models.IntegerField(default=0)
    devolucion = models.IntegerField(default=0)
    tipo_venta = models.CharField(max_length=50, default="Organico")


class MovimientosInstructor(models.Model):

    id_movimientoInstructor = models.AutoField(primary_key=True)
    id_transaccionR = models.IntegerField()
    id_instructorR = models.IntegerField()
    fecha_movimiento = models.DateField()
    cantidad_total = models.IntegerField()
    descuento_aplicado = models.IntegerField()
    total_ganado = models.IntegerField()
    devuelto = models.IntegerField(default=0)
    estado = models.IntegerField()
    tipo_venta = models.CharField(max_length=50, default="Organico")



class Asistencias(models.Model):

    id_asistencia = models.AutoField(primary_key=True)
    id_cursoR = models.IntegerField()
    id_instructorR = models.IntegerField()
    id_alumnoR = models.IntegerField()
    nombre_alumnoR = models.CharField(max_length=500)
    valor_asistencia = models.CharField(max_length=50)
    fecha_asistencia = models.DateField()


class OpcionesAlumno(models.Model):

    id_opcionAlumno = models.AutoField(primary_key=True)
    id_alumnoR = models.IntegerField()
    color_barra = models.CharField(max_length=50)
    tipo_plantilla = models.CharField(max_length=25, default="_boton")
    widget_clima = models.IntegerField()
    widget_juego_tetris = models.IntegerField()
    widget_juego_cartas = models.IntegerField()


class OpcionesInstructor(models.Model):

    id_opcionInstructor = models.AutoField(primary_key=True)
    id_instructorR = models.IntegerField()
    color_barra = models.CharField(max_length=50)
    tipo_plantilla = models.CharField(max_length=25, default="_boton")
    widget_clima = models.IntegerField()
    widget_juego_tetris = models.IntegerField()
    widget_juego_cartas = models.IntegerField()


class NotificacionesAlumnos(models.Model):

    id_notificacionAlumno = models.AutoField(primary_key=True)
    id_alumnoR = models.IntegerField()
    mensaje_notificacion = models.CharField(max_length=1000)
    fecha_notificacion = models.DateField()
    hora_notificacion = models.TimeField(auto_now=False, auto_now_add=False)
    fecha_fin = models.DateField(default="1999-01-01")
    id_elementoNotificacion = models.IntegerField(default=0)
    tipo_elementoNotificacion = models.CharField(max_length=250, default="")
    statusN = models.IntegerField(default=0)


class NotificacionesInstructores(models.Model):

    id_notificacionInstructor = models.AutoField(primary_key=True)
    id_instructorR = models.IntegerField()
    mensaje_notificacion = models.CharField(max_length=1000)
    fecha_notificacion = models.DateField()
    hora_notificacion = models.TimeField(auto_now=False, auto_now_add=False)
    fecha_fin = models.DateField(default="1999-01-01")
    id_elementoNotificacion = models.IntegerField(default=0)
    tipo_elementoNotificacion = models.CharField(max_length=250, default="")
    statusN = models.IntegerField(default=0)


class MensajesUsuarios(models.Model):

    id_mensaje = models.AutoField(primary_key=True)
    id_alumnoR = models.IntegerField()
    id_instructorR = models.IntegerField()
    mensaje = models.CharField(max_length=2000)
    fecha = models.DateTimeField()
    hora = models.TimeField(auto_now=False, auto_now_add=False, default="12:00:00")
    remitente = models.CharField(max_length=1000, default="Alumno")


class MensajesUsuariosCompa(models.Model):

    id_mensaje = models.AutoField(primary_key=True)
    id_alumnoEnvio = models.IntegerField()
    id_alumnoDestino = models.IntegerField()
    mensaje = models.CharField(max_length=2000)
    fecha = models.DateTimeField()
    hora = models.TimeField()
    remitente = models.IntegerField(default=0)




class CuponesDescuento(models.Model):

    id_cupon = models.AutoField(primary_key=True)
    codigo_cupon = models.CharField(max_length=10)
    porcentaje_asignado = models.IntegerField()
    fecha_caduca = models.DateField()
    nombre_identificador = models.CharField(max_length=500, default="")
    status_cupon = models.IntegerField(default=1)


class CompartirCurso(models.Model):

    id_compartirCurso = models.AutoField(primary_key=True)
    id_cursoR = models.IntegerField()
    id_alumnoR = models.IntegerField()
    fecha_compartido = models.DateField()
    plataforma_compartio = models.CharField(max_length=100)
    invitado = models.CharField(max_length=50)



class EntradasBlog(models.Model):

    id_entrada = models.AutoField(primary_key=True)
    titulo_entrada = models.CharField(max_length=500)
    contenido_entrada = RichTextField()
    posteador = models.CharField(max_length=500)
    id_posteador = models.IntegerField()
    fecha_posteo = models.DateTimeField(auto_now_add=True)
    no_vistas = models.IntegerField()
    imagen_entrada = models.CharField(max_length=500)
    video_entrada = models.CharField(max_length=500)
    no_me_gusta = models.IntegerField()
    no_me_encanta = models.IntegerField()
    no_me_impresiona = models.IntegerField()
    no_me_risa = models.IntegerField()
    statusB = models.IntegerField(default=0)
    no_comentarios = models.IntegerField(default=0)
    descripcion = models.CharField(max_length=500, default="")


class ComentariosEntrada(models.Model):

    id_comentario = models.AutoField(primary_key=True)
    id_entradaR = models.IntegerField()
    id_alumno_comento = models.IntegerField()
    comentario = models.TextField()
    fecha_comentario = models.DateTimeField(auto_now_add=True)


class VerificarCuenta(models.Model):

    id_verificacion = models.AutoField(primary_key=True)
    correo_vinculado = models.CharField(max_length=1000)
    fecha_creacion = models.DateField(null=True, auto_now_add=True)
    fecha_limite = models.DateField(null=True)
    codigo = models.CharField(max_length=15)
    verificado = models.IntegerField(default=0)
    perfil_editado = models.IntegerField(default=0)


class CambiarContra(models.Model):

    id_cambio = models.AutoField(primary_key=True)
    correo_vinculado = models.CharField(max_length=1000)
    fecha_creacion = models.DateField(null=True, auto_now_add=True)
    fecha_limite = models.DateField(null=True)
    codigo = models.CharField(max_length=15)
    usado = models.IntegerField(default=0)


class TransmisionesVivo(models.Model):

    id_transmision = models.AutoField(primary_key=True)
    url_video = models.CharField(max_length=500)
    fecha_transmision = models.DateField()
    hora_transmision = models.TimeField()
    publico = models.IntegerField()
    statusT = models.IntegerField()
    fecha_completa = models.DateTimeField(null=True)
    nombre_transmision = models.CharField(max_length=500, default="")

class OpcionesTransmisiones(models.Model):

    id_opcionTransmision = models.AutoField(primary_key=True)
    dominio = models.CharField(max_length=500)


class TransmisionesInstructores(models.Model):

    id_transmisionInstructor = models.AutoField(primary_key=True)
    id_instructorR = models.IntegerField()
    id_cursoR = models.IntegerField()
    nombre_transmision = models.CharField(max_length=500, default="")
    fecha_transmision = models.DateField()
    hora_transmision = models.TimeField()
    fecha_completa = models.DateTimeField(null=True)
    statusT = models.IntegerField()
    numero_reunion = models.CharField(max_length=20, default="")
    contra_reunion = models.CharField(max_length=20, default="")


class TransmisionesInstructoresAnteriores(models.Model):

    id_transmisionInstructorAnterior = models.AutoField(primary_key=True)
    id_instructorR = models.IntegerField()
    id_cursoR = models.IntegerField()
    nombre_transmision = models.CharField(max_length=500)
    fecha_transmision = models.DateField()
    hora_transmision = models.TimeField()
    fecha_completa = models.DateTimeField()
    statusT = models.IntegerField()
    url_video = models.CharField(max_length=500)

    

class Profesiones(models.Model):

    id_profesion = models.AutoField(primary_key=True)
    nombre_profesion = models.CharField(max_length=500)
    status = models.IntegerField()


class RelacionProfesiones(models.Model):

    id_relacionProfesion = models.AutoField(primary_key=True)
    id_profesionR = models.IntegerField()
    id_usuarioR = models.IntegerField()
    tipo_usuarioR = models.CharField(max_length=100)


class Carreras(models.Model):

    id_carrera = models.AutoField(primary_key=True)
    nombre_carrera = models.CharField(max_length=250)
    statusCA = models.IntegerField()


class Grupos(models.Model):

    id_grupo = models.AutoField(primary_key=True)
    nombre_grupo = models.CharField(max_length=250)
    id_carreraR = models.IntegerField(default=0)
    statusG = models.IntegerField()


class GruposCursos(models.Model):

    id_grupoCurso = models.AutoField(primary_key=True)
    id_grupoR = models.IntegerField()
    id_cursoR = models.IntegerField()
    nombre_cursoR = models.CharField(max_length=300)
    id_instructorR = models.IntegerField()
    nombre_instructorR = models.CharField(max_length=300)


class GruposAlumnos(models.Model):

    id_grupoAlumno = models.AutoField(primary_key=True)
    id_grupoCursoR = models.IntegerField()
    id_grupoR = models.IntegerField()
    id_cursoR = models.IntegerField()
    id_instructorR = models.IntegerField()
    id_alumnoR = models.IntegerField()
    nombre_alumnoR = models.CharField(max_length=300)



class CursoCategoria(models.Model):
    id_categoria = models.AutoField(primary_key=True)
    nombre_categoria = models.CharField(max_length=300)
    ruta_imagen = models.CharField(max_length=500, default="")
    fecha_completa = models.DateField(null=True, auto_now_add=True)
    statusC = models.IntegerField(default=1)

class Cursos_Categorias(models.Model):
    id_curso = models.IntegerField()
    id_categoria = models.IntegerField()




class Descuento_Curso(models.Model):
    id_descuento = models.AutoField(primary_key=True)
    porcentaje_descuento = models.IntegerField()
    id_curso = models.IntegerField()
    statucDC = models.IntegerField()


class Descuento_Cursos_Especial(models.Model):
    id_descuento_especial = models.AutoField(primary_key=True)
    porcentaje_descuento = models.IntegerField()
    cantidad_superar = models.IntegerField()
    motivo_descuento = models.CharField(max_length=200, null=True)
    statusDCE = models.IntegerField()


class Lista_Deseos(models.Model):
    id_lista_deseos = models.AutoField(primary_key=True)
    id_alumno = models.IntegerField()
    id_curso = models.IntegerField()
    statusLD = models.IntegerField()

class Moneda(models.Model):
    id_moneda = models.AutoField(primary_key=True)
    nombre_moneda = models.CharField(max_length=100)
    pais = models.CharField(max_length=100, null=True)
    equivalente_peso_mx = models.FloatField()
    simbolo = models.CharField(max_length=10, null=True)
    nomencaltura = models.CharField(max_length=10, null=True)
    fecha_actualizar = models.DateField(null = True, auto_now_add=True)
    hora_actualizar = models.TimeField(null = True, auto_now_add=True)
    statusM = models.IntegerField()


class TextosPagina(models.Model):

    id_textoPagina = models.AutoField(primary_key=True)
    id_empresaR = models.IntegerField()
    identificador = models.CharField(max_length=500)
    texto_guardado = RichTextField()


class Pregunta_usuario(models.Model):
    id_pregunta_usuario = models.AutoField(primary_key=True)
    nombre = models.CharField(max_length=300, null=True)
    correo = models.CharField(max_length=200, null=True)
    asunto = models.TextField(null=True)
    mensaje = models.TextField(null=True)
    acepta_terminos = models.CharField(max_length=2, null=True)
    tipo_pregunta = models.CharField(max_length=40, null=True)
    curso = models.CharField(max_length=500, null=True)
    fecha = models.DateField(null = True, auto_now_add=True)
    hora = models.TimeField(null = True, auto_now_add=True)
    statusP = models.IntegerField(default=1)



class Boletin(models.Model):
    id_boletin = models.AutoField(primary_key=True)
    correo = models.CharField(max_length=100)
    fecha = models.DateField(null = True, auto_now_add=True)
    hora = models.TimeField(null = True, auto_now_add=True)
    ip = models.CharField(max_length=200, null = True)
    pais = models.CharField(max_length=500, null = True)
    statusBo = models.IntegerField(default=1)



class Candidatos_sensei(models.Model):
    id_candidatos_sensei = models.AutoField(primary_key=True)
    nombres = models.CharField(max_length=200)
    apellidos = models.CharField(max_length=200)
    pais_seleccionado = models.CharField(max_length=200)
    pais_obtenido = models.CharField(max_length=200)
    categoria = models.CharField(max_length=200)
    correo = models.CharField(max_length=200)
    pregunta = models.TextField(null=True)
    fecha = models.DateField(null = True, auto_now_add=True)
    hora = models.TimeField(null = True, auto_now_add=True)
    statusCS = models.IntegerField()
